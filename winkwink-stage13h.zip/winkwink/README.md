# WinkWink — FOUNDATION

*Your people. Your space. Your rules.*

Nowa platforma społecznościowa. Repozytorium zawiera dwa niezależne projekty:

- `backend/` — Kotlin + Ktor + PostgreSQL (Flyway)
- `android/` — Kotlin + Jetpack Compose + Hilt + Retrofit

## Uruchomienie backendu

```bash
cp .env.example .env        # uzupełnij hasła (POSTGRES_PASSWORD) i WINKWINK_PUBLIC_HOST
docker compose up --build   # PostgreSQL + backend + Caddy (HTTPS, Let's Encrypt)
curl https://TWOJA_DOMENA/api/v1/health
```

Bez Dockera: ustaw zmienne z `.env.example` i uruchom `cd backend && gradle run`
(wymaga JDK 17 i PostgreSQL). Testy: `gradle test`.

## Konfiguracja adresu HTTPS

- **Backend**: albo TLS w procesie Ktor (`WINKWINK_TLS_KEYSTORE_PATH` + hasło, PKCS12),
  albo `WINKWINK_TRUST_PROXY=true` za reverse proxy kończącym TLS (domyślnie Caddy z `docker-compose.yml`).
  Bez jednej z tych opcji serwer **nie uruchomi się**. Żądania bez HTTPS dostają `403 https_required`.
- **Android**: adres z `WINKWINK_API_BASE_URL` lub `-Pwinkwink.apiBaseUrl=https://...`.
  Build kończy się błędem, jeśli adres nie zaczyna się od `https://`.
  Domyślna wartość to zastrzeżony placeholder `https://api.winkwink.example`.
- **Gradle Wrapper jest niekompletny.** W repozytorium są tylko `backend/gradle/wrapper/gradle-wrapper.properties`
  i `android/gradle/wrapper/gradle-wrapper.properties` (Gradle 8.10.2). Brakujące `gradlew`, `gradlew.bat` i
  `gradle-wrapper.jar` wygeneruj jednorazowo: `./scripts/bootstrap-wrapper.sh` (wymaga Gradle ≥ 8.10 i sieci),
  po czym zacommituj wszystkie wygenerowane pliki. Do tego czasu używaj `gradle` zamiast `./gradlew`.

## Zaimplementowane

Backend: start Ktor z HTTPS, konfiguracja ze zmiennych środowiskowych (z walidacją), pula Hikari,
migracje Flyway (V1 funkcja `updated_at`, V2 `accounts`/`profiles`/`devices`/`sessions` z ograniczeniami
i indeksami), `GET /api/v1/health` (żywotność + sprawdzenie bazy + wersja schematu), wersjonowanie `/api/v1`,
spójne błędy JSON z `requestId`, rate limiting, HSTS i nagłówki bezpieczeństwa, logowanie wywołań
i zdarzeń bezpieczeństwa, testy jednostkowe.

Android: ekran startowy, motyw jasny/ciemny/systemowy (zapamiętywany w DataStore), pięć zakładek,
wspólny system komponentów (kolory, typografia, odstępy, kształty, animacje), klient Retrofit/OkHttp
tylko przez HTTPS (blokada cleartext w manifeście, interceptorze i TLS 1.2+), ekran diagnostyki
połączenia z obsługą braku sieci, timeoutu, błędu TLS, błędu serwera i niepoprawnej odpowiedzi.

## Etap 1 — konta i uwierzytelnianie (kod napisany, niezweryfikowany buildem)

Rejestracja, logowanie, wylogowanie, odświeżanie tokenów z rotacją, Argon2id, blokada brute force, reset i zmiana hasła,
zarządzanie sesjami/urządzeniami (backend + ekrany Androida). Dokumentacja API: `docs/API.md`.
Szczegółowy stan prac, ograniczenia i otwarte decyzje: `PROJECT_STATUS.md`.
Wymagane nowe zmienne: `WINKWINK_JWT_SECRET` (≥32 znaki; `openssl rand -base64 48`).
Reset hasła zwraca `503` do czasu wyboru dostawcy poczty.

## Zostawione na kolejne etapy

Tabela `reports` i moderacja, E2EE (wybór biblioteki z oceną licencji), powiadomienia FCM, Object Storage,
Room, WorkManager. Komunikator ma backend REST (V10, V14), WSS ze wskaźnikiem pisania i ekrany Androida (Etapy D–E, niezbudowane); wiadomości **nie są** szyfrowane end-to-end — aplikacja pokazuje to wprost.
Feed, Communities i Activity mają kod po stronie backendu i Androida — **żaden z nich nie został jeszcze zbudowany ani uruchomiony** (patrz niżej).

## Weryfikacja i stan buildów (Stage 12) — uczciwie

**Nic z tego repozytorium nie zostało jeszcze skompilowane ani uruchomione.** Środowisko, w którym powstał Stage 12,
miało tylko JDK 21 — bez Gradle, Kotlina, Android SDK, PostgreSQL i sieci. Wykonano wyłącznie przegląd statyczny
i kontrole składniowe; szczegóły i lista poprawek: `PROJECT_STATUS.md` (sesja 15). Wyniki testów: **brak (nie uruchomiono)**.

Pierwsze uruchomienie (kolejność ma znaczenie — wklej błędy, jeśli się pojawią):

```bash
./scripts/bootstrap-wrapper.sh                       # raz: pełny wrapper (patrz wyżej)
cd backend && gradle build                            # kompilacja + testy jednostkowe (JDK 17 pobierze się samo przez foojay)
cd ../android && gradle testDebugUnitTest assembleDebug   # wymaga Android SDK (ANDROID_HOME), licencje zaakceptowane
```

Testy na prawdziwym PostgreSQL (migracje V1–V10, magazyny `Postgres*Store`, rotacja refresh tokenów, prywatność
anonimowych powiadomień) są w `PostgresIntegrationTest` i **same się pomijają**, jeśli nie ma bazy:

```bash
docker run --rm -d --name ww-test-pg -e POSTGRES_PASSWORD=pw -e POSTGRES_DB=winkwink_test -p 5432:5432 postgres:16
export WINKWINK_TEST_DATABASE_URL=jdbc:postgresql://localhost:5432/winkwink_test
export WINKWINK_TEST_DATABASE_USER=postgres WINKWINK_TEST_DATABASE_PASSWORD=pw
cd backend && gradle test --tests '*PostgresIntegrationTest'
```

Uwaga: te testy wykonują `flyway clean` — nazwa bazy musi zawierać „test”, inaczej odmawiają pracy.
Wynik „skipped” oznacza, że testów **nie** uruchomiono, a nie że przeszły.

## Branding

Oryginały logo: `branding/`. W aplikacji: ikona launchera (adaptive, `ic_launcher_foreground.png` na tle `ww_icon_background`)
oraz znak na ekranie startowym (`logo_mark_dark.png` / `logo_mark_light.png`, wybierany wg jasności motywu).


## Pliki użytkowników
Avatary i tła trafiają do `MediaStorage` (domyślnie katalog z `WINKWINK_MEDIA_DIR`, w Dockerze wolumen `media`). Kopie zapasowe bazy bez tego katalogu nie zawierają zdjęć. Kontrakt: `docs/API.md`, „Etap A”.

## Social Feed — media i udostępnianie (Etap B; kod niezweryfikowany buildem)

Posty mogą mieć zdjęcia (galeria), jeden film MP4 i do 3 dokumentów PDF. Pliki są wysyłane osobno (`POST /attachments`), trafiają do `MediaStorage` i są dostępne tylko tym, którzy widzą post. Anonimowe posty przyjmują wyłącznie zdjęcia. Udostępnianie dotyczy postów publicznych. Kontrakt i limity: `docs/API.md`, „Etap B”. Stan prac i znane ograniczenia: `PROJECT_STATUS.md`, „Sesja 20”.

## Wiadomości — zdjęcia, dokumenty i głosówki (Etap F; kod niezweryfikowany buildem)

Czat obsługuje galerię do 10 zdjęć, do 5 dokumentów (PDF, DOCX, XLSX, PPTX, ODT/ODS/ODP, RTF, TXT, CSV) i nagrywane wiadomości głosowe (AAC w MP4/M4A, do 10 min). Pliki są wysyłane osobno (`POST /message-attachments`), trafiają do `MediaStorage` (nie do PostgreSQL), a pobiera je wyłącznie aktualny członek rozmowy (`GET /message-attachments/{id}`). Serwer rozpoznaje typ po **zawartości** i odrzuca pliki wykonywalne, HTML/SVG, skrypty, dokumenty z makrami i PDF z JavaScriptem; wysyłki są ograniczane tempem na konto. Treści plików nie przechodzą przez WSS — zdarzenia tylko informują, a Android pobiera dane przez REST. Uprawnienie mikrofonu (`RECORD_AUDIO`) jest proszone dopiero przy pierwszym nagrywaniu. Kontrakt: `docs/API.md`, „Etap F”; stan i ograniczenia: `PROJECT_STATUS.md`, „Sesja 24”. **Wiadomości nadal nie są szyfrowane end-to-end**, a pliki leżą na serwerze w postaci jawnej — kopie zapasowe muszą obejmować `WINKWINK_MEDIA_DIR`.

## Niezawodność (Stage 13G)
Trwała kolejka wysyłania (Room + WorkManager), idempotencja żądań (`Idempotency-Key`, `clientId` wiadomości), synchronizacja różnicowa
(`GET /conversations/{id}/messages/changes`), streaming plików z `Range`, rekoncyliacja magazynu plików i usuwanie konta (`POST /me/delete`).
Szczegóły: `docs/SYNC_AND_OUTBOX.md`, `docs/API.md` (sekcja Stage 13G). Migracja `V16__reliability_idempotency_sync.sql` uruchamia się sama (Flyway).
Nic z tego nie zostało zbudowane ani uruchomione — patrz `PROJECT_STATUS.md`.

## Beta (Stage 13H)
Push FCM, usuwanie konta z aplikacji, strumieniowe pobieranie mediów, konfiguracja release. Konfiguracja Firebase: `docs/FIREBASE.md`; wydanie, podpisywanie, zmienne środowiskowe i brakujący Gradle Wrapper: `docs/RELEASE.md`.
