plugins {
    // Automatycznie pobiera JDK 17 wymagane przez jvmToolchain(17), gdy lokalnie jest inna wersja JDK.
    id("org.gradle.toolchains.foojay-resolver-convention") version "0.8.0"
}

rootProject.name = "winkwink-server"
