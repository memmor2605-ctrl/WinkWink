package app.winkwink.server.media

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Clock
import java.time.Duration
import javax.sql.DataSource

/** Które z podanych kluczy obiektów są wciąż przez coś używane (załączniki wiadomości i postów, avatary, tła). */
fun interface MediaReferences {
    suspend fun referenced(keys: Collection<String>): Set<String>
}

class PostgresMediaReferences(private val dataSource: DataSource) : MediaReferences {
    override suspend fun referenced(keys: Collection<String>): Set<String> = if (keys.isEmpty()) emptySet() else withContext(Dispatchers.IO) {
        dataSource.connection.use { c ->
            val array = c.createArrayOf("text", keys.toTypedArray())
            c.prepareStatement(
                "SELECT k FROM unnest(?::text[]) AS k WHERE " +
                    "EXISTS (SELECT 1 FROM message_attachments WHERE object_key = k) OR " +
                    "EXISTS (SELECT 1 FROM post_attachments WHERE object_key = k) OR " +
                    "EXISTS (SELECT 1 FROM profiles WHERE avatar_object_key = k OR background_object_key = k)",
            ).use { ps ->
                ps.setArray(1, array)
                ps.executeQuery().use { rs -> buildSet { while (rs.next()) add(rs.getString(1)) } }
            }
        }
    }
}

/**
 * Rekoncyliacja magazynu z bazą: usuwa pliki, do których nic w bazie już nie prowadzi (po usunięciu konta/rozmowy kaskadą,
 * po nieudanym kasowaniu, po awarii między zapisem pliku a zapisem wiersza). Chroni świeże pliki ([MIN_AGE]) — wysyłka właśnie trwa.
 * Pliki wciąż wskazywane przez bazę (także oznaczone do usunięcia, które obsługują własne zadania) nigdy nie są ruszane.
 */
class MediaReconciler(
    private val storage: MediaStorage,
    private val references: MediaReferences,
    private val clock: Clock = Clock.systemUTC(),
) {
    companion object {
        val MIN_AGE: Duration = Duration.ofHours(24)
        private const val BATCH = 500
    }

    /** Przegląda cały magazyn partiami i zwraca liczbę usuniętych osieroconych plików. */
    suspend fun reconcile(): Int {
        val olderThan = clock.instant().minus(MIN_AGE)
        var removed = 0
        var after: String? = null
        while (true) {
            val page = storage.listOlderThan(olderThan, BATCH, after)
            if (page.isEmpty()) break
            val used = references.referenced(page)
            for (key in page) {
                if (key in used) continue
                if (storage.deleteQuietly(key)) removed++
            }
            after = page.last()
            if (page.size < BATCH) break
        }
        return removed
    }
}
