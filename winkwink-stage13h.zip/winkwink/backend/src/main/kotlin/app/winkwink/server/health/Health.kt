package app.winkwink.server.health

import app.winkwink.server.config.AppConfig
import io.ktor.http.HttpStatusCode
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.get
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import org.slf4j.LoggerFactory
import java.time.Instant
import javax.sql.DataSource

object AppInfo {
    const val SERVICE = "winkwink-server"
    const val API_VERSION = "v1"
    val version: String = AppInfo::class.java.`package`?.implementationVersion ?: "dev"
}

@Serializable
data class DatabaseHealth(
    val status: String,
    val latencyMs: Long? = null,
    val schemaVersion: String? = null,
)

@Serializable
data class HealthResponse(
    val status: String,
    val service: String,
    val apiVersion: String,
    val appVersion: String,
    val environment: String,
    val serverTime: String,
    val database: DatabaseHealth,
)

fun interface HealthProbe {
    suspend fun check(): DatabaseHealth
}

class PostgresHealthProbe(private val dataSource: DataSource) : HealthProbe {
    private val log = LoggerFactory.getLogger(PostgresHealthProbe::class.java)

    override suspend fun check(): DatabaseHealth = withContext(Dispatchers.IO) {
        try {
            val started = System.nanoTime()
            dataSource.connection.use { connection ->
                connection.createStatement().use { st ->
                    st.queryTimeout = 2
                    st.executeQuery("SELECT 1").use { it.next() }
                }
                val latencyMs = (System.nanoTime() - started) / 1_000_000
                val schemaVersion = connection.createStatement().use { st ->
                    st.queryTimeout = 2
                    st.executeQuery(
                        "SELECT version FROM flyway_schema_history WHERE success ORDER BY installed_rank DESC LIMIT 1"
                    ).use { rs -> if (rs.next()) rs.getString(1) else null }
                }
                DatabaseHealth("up", latencyMs, schemaVersion)
            }
        } catch (e: Exception) {
            // Szczegóły tylko w logu serwera — nie wyciekają do klienta.
            log.warn("Database health check failed: {}", e.message)
            DatabaseHealth("down")
        }
    }
}

fun Route.healthRoutes(config: AppConfig, probe: HealthProbe) {
    get("/health") {
        val database = probe.check()
        val healthy = database.status == "up"
        call.respond(
            if (healthy) HttpStatusCode.OK else HttpStatusCode.ServiceUnavailable,
            HealthResponse(
                status = if (healthy) "ok" else "degraded",
                service = AppInfo.SERVICE,
                apiVersion = AppInfo.API_VERSION,
                appVersion = AppInfo.version,
                environment = config.environment.name.lowercase(),
                serverTime = Instant.now().toString(),
                database = database,
            )
        )
    }
}
