package app.winkwink.server.plugins

import io.ktor.serialization.kotlinx.json.json
import io.ktor.server.application.Application
import io.ktor.server.application.install
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import kotlinx.serialization.json.Json

/** Jedna konfiguracja JSON dla całego API (także dla odpowiedzi zapamiętywanych przez mechanizm idempotencji). */
val ApiJson = Json { ignoreUnknownKeys = false; explicitNulls = true }

fun Application.configureSerialization() {
    install(ContentNegotiation) {
        json(ApiJson)
    }
}
