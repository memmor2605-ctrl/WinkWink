package app.winkwink.server.notification

import app.winkwink.server.api.ApiException
import app.winkwink.server.auth.JWT_AUTH
import app.winkwink.server.auth.UserPrincipal
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.auth.authenticate
import io.ktor.server.auth.principal
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.put
import java.util.UUID

private fun ApplicationCall.viewer(): UUID =
    (principal<UserPrincipal>() ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")).accountId

private fun ApplicationCall.limit(): Int? = request.queryParameters["limit"]?.let {
    it.toIntOrNull() ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "limit must be an integer.")
}

private fun ApplicationCall.notificationId(): UUID =
    runCatching { UUID.fromString(parameters["id"]) }.getOrNull()
        ?: throw ApiException(HttpStatusCode.NotFound, "notification_not_found", "Notification not found.")

fun Route.notificationRoutes(service: NotificationService) {
    authenticate(JWT_AUTH) {
        get("/notifications") {
            val q = call.request.queryParameters
            val page = service.list(call.viewer(), q["type"], q["unread"] == "true", call.limit(), q["cursor"])
            call.respond(NotificationListResponse(page.items.map { it.toDto() }, page.nextCursor, page.unreadCount))
        }
        get("/notifications/unread-count") { call.respond(UnreadCountResponse(service.unreadCount(call.viewer()))) }
        post("/notifications/read-all") {
            service.markAllRead(call.viewer(), call.request.queryParameters["type"])
            call.respond(HttpStatusCode.NoContent)
        }
        get("/notifications/settings") { call.respond(NotificationSettingsDto(service.settings(call.viewer()))) }
        put("/notifications/settings") {
            val body = call.receive<NotificationSettingsDto>()
            call.respond(NotificationSettingsDto(service.updateSettings(call.viewer(), body.types)))
        }
        post("/notifications/{id}/read") {
            service.markRead(call.viewer(), call.notificationId())
            call.respond(HttpStatusCode.NoContent)
        }
    }
}
