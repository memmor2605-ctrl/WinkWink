package app.winkwink.server.media

import java.awt.RenderingHints
import java.awt.image.BufferedImage
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import javax.imageio.IIOException
import javax.imageio.ImageIO
import javax.imageio.ImageWriteParam
import javax.imageio.stream.MemoryCacheImageInputStream

class InvalidImageException(val code: String, message: String) : RuntimeException(message)

data class ProcessedImage(val bytes: ByteArray, val mime: String)

/**
 * Walidacja i normalizacja obrazów wysyłanych przez użytkowników:
 *  - typ ustalany po sygnaturze bajtów (nagłówek Content-Type klienta nie jest zaufany), dozwolone: JPEG, PNG;
 *  - limit wymiarów sprawdzany z nagłówka PRZED dekodowaniem (ochrona przed „bombą dekompresyjną”);
 *  - obraz jest dekodowany i kodowany od nowa, co usuwa metadane (EXIF/GPS, komentarze) i ewentualny dopisany payload;
 *  - większe obrazy są skalowane do [maxEdge].
 * WebP/HEIC są odrzucane: klient Androida zamienia wybrane zdjęcie na JPEG przed wysłaniem.
 */
object ImageProcessor {
    const val MAX_SOURCE_PIXELS = 25_000_000L
    const val MAX_SOURCE_EDGE = 10_000

    fun sniff(b: ByteArray): String? = when {
        b.size >= 3 && b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte() && b[2] == 0xFF.toByte() -> "image/jpeg"
        b.size >= 8 && b[0] == 0x89.toByte() && b[1] == 'P'.code.toByte() && b[2] == 'N'.code.toByte() && b[3] == 'G'.code.toByte() &&
            b[4] == 0x0D.toByte() && b[5] == 0x0A.toByte() && b[6] == 0x1A.toByte() && b[7] == 0x0A.toByte() -> "image/png"
        else -> null
    }

    fun process(raw: ByteArray, maxEdge: Int): ProcessedImage {
        val mime = sniff(raw) ?: throw InvalidImageException("unsupported_media_type", "Only JPEG and PNG images are accepted.")
        val image = try {
            decode(raw)
        } catch (e: InvalidImageException) {
            throw e
        } catch (e: Exception) {
            throw InvalidImageException("invalid_image", "The file is not a valid image.")
        }
        val scaled = scaleDown(image, maxEdge)
        return if (mime == "image/png" && image.colorModel.hasAlpha()) ProcessedImage(encodePng(scaled), "image/png")
        else ProcessedImage(encodeJpeg(flatten(scaled)), "image/jpeg")
    }

    private fun decode(raw: ByteArray): BufferedImage {
        val iis = MemoryCacheImageInputStream(ByteArrayInputStream(raw))
        val readers = ImageIO.getImageReaders(iis)
        if (!readers.hasNext()) throw InvalidImageException("invalid_image", "The file is not a valid image.")
        val reader = readers.next()
        try {
            reader.input = iis
            val w = reader.getWidth(0)
            val h = reader.getHeight(0)
            if (w <= 0 || h <= 0 || w > MAX_SOURCE_EDGE || h > MAX_SOURCE_EDGE || w.toLong() * h > MAX_SOURCE_PIXELS) {
                throw InvalidImageException("image_too_large", "Image dimensions are too large.")
            }
            return reader.read(0)
        } catch (e: IIOException) {
            throw InvalidImageException("invalid_image", "The file is not a valid image.")
        } finally {
            reader.dispose()
        }
    }

    private fun scaleDown(src: BufferedImage, maxEdge: Int): BufferedImage {
        val longest = maxOf(src.width, src.height)
        if (longest <= maxEdge) return src
        val f = maxEdge.toDouble() / longest
        val w = maxOf(1, (src.width * f).toInt())
        val h = maxOf(1, (src.height * f).toInt())
        val type = if (src.colorModel.hasAlpha()) BufferedImage.TYPE_INT_ARGB else BufferedImage.TYPE_INT_RGB
        val out = BufferedImage(w, h, type)
        val g = out.createGraphics()
        try {
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR)
            g.drawImage(src, 0, 0, w, h, null)
        } finally {
            g.dispose()
        }
        return out
    }

    /** JPEG nie ma kanału alfa; przezroczystość (gdy PNG został wybrany do JPEG) jest składana na białe tło. */
    private fun flatten(src: BufferedImage): BufferedImage {
        if (src.type == BufferedImage.TYPE_INT_RGB) return src
        val out = BufferedImage(src.width, src.height, BufferedImage.TYPE_INT_RGB)
        val g = out.createGraphics()
        try {
            g.color = java.awt.Color.WHITE
            g.fillRect(0, 0, src.width, src.height)
            g.drawImage(src, 0, 0, null)
        } finally {
            g.dispose()
        }
        return out
    }

    private fun encodePng(img: BufferedImage): ByteArray =
        ByteArrayOutputStream().also { check(ImageIO.write(img, "png", it)) { "png writer missing" } }.toByteArray()

    private fun encodeJpeg(img: BufferedImage): ByteArray {
        val writer = ImageIO.getImageWritersByFormatName("jpeg").next()
        val out = ByteArrayOutputStream()
        try {
            val param = writer.defaultWriteParam.apply {
                compressionMode = ImageWriteParam.MODE_EXPLICIT
                compressionQuality = 0.85f
            }
            javax.imageio.stream.MemoryCacheImageOutputStream(out).use { ios ->
                writer.output = ios
                writer.write(null, javax.imageio.IIOImage(img, null, null), param)
            }
        } finally {
            writer.dispose()
        }
        return out.toByteArray()
    }
}
