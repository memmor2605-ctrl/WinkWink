package app.winkwink.server.media

import java.io.ByteArrayInputStream
import javax.imageio.ImageIO

/**
 * Rozpoznawanie typu po sygnaturze bajtów (nagłówek Content-Type klienta nie jest zaufany) i sanityzacja nazw plików.
 * Obrazy są dodatkowo normalizowane przez [ImageProcessor]; filmy i dokumenty są przechowywane bez zmian
 * (serwer ich nie przetwarza — patrz ograniczenia w docs/API.md).
 */
object MediaSniffer {
    private val MP4_BRANDS = setOf("isom", "iso2", "iso4", "iso5", "iso6", "mp41", "mp42", "avc1", "M4V ", "dash")

    /** MP4: bajty 4..8 = „ftyp”, a marka główna jest na liście. Inne kontenery (MOV, MKV, AVI) są odrzucane. */
    fun isMp4(b: ByteArray): Boolean {
        if (b.size < 12) return false
        if (b[4] != 'f'.code.toByte() || b[5] != 't'.code.toByte() || b[6] != 'y'.code.toByte() || b[7] != 'p'.code.toByte()) return false
        return String(b, 8, 4, Charsets.ISO_8859_1) in MP4_BRANDS
    }

    fun isPdf(b: ByteArray): Boolean =
        b.size >= 5 && b[0] == '%'.code.toByte() && b[1] == 'P'.code.toByte() && b[2] == 'D'.code.toByte() && b[3] == 'F'.code.toByte() && b[4] == '-'.code.toByte()

    /** @return (kind, mime) albo null, gdy typ nie jest dozwolony. kind: image | video | document */
    fun classify(b: ByteArray): Pair<String, String>? {
        ImageProcessor.sniff(b)?.let { return "image" to it }
        if (isMp4(b)) return "video" to "video/mp4"
        if (isPdf(b)) return "document" to "application/pdf"
        return null
    }

    /** Kategoria deklarowanego Content-Type (do porównania z wynikiem [classify]); null = niedozwolony. */
    fun declaredKind(mime: String): String? = when (mime.lowercase().substringBefore(';').trim()) {
        "image/jpeg", "image/png" -> "image"
        "video/mp4" -> "video"
        "application/pdf" -> "document"
        else -> null
    }

    fun dimensions(imageBytes: ByteArray): Pair<Int, Int>? = runCatching {
        val iis = ImageIO.createImageInputStream(ByteArrayInputStream(imageBytes)) ?: return null
        iis.use {
            val readers = ImageIO.getImageReaders(it)
            if (!readers.hasNext()) return null
            val r = readers.next()
            try { r.input = it; r.getWidth(0) to r.getHeight(0) } finally { r.dispose() }
        }
    }.getOrNull()

    /** Usuwa ścieżki, znaki sterujące i separatory; skraca do 100 znaków. Nazwa służy tylko do wyświetlania i nagłówka pobierania. */
    fun sanitizeFileName(raw: String?): String? {
        val base = raw?.substringAfterLast('/')?.substringAfterLast('\\') ?: return null
        val cleaned = base.filter { !it.isISOControl() && it !in "\"<>:|?*;" }.trim().trimStart('.')
        if (cleaned.isEmpty()) return null
        return if (cleaned.length <= 100) cleaned else cleaned.take(100)
    }
}
