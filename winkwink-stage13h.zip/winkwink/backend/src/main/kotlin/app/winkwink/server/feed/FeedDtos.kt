package app.winkwink.server.feed

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class AuthorDto(val winkwinkId: String, val nickname: String, val displayName: String?, val hasAvatar: Boolean = false, val avatarTag: String? = null)

/**
 * Dla postów anonimowych [author] jest zawsze null — także dla samego autora; autor rozpoznaje swój post po [mine].
 * Odpowiedź nigdy nie zawiera authorId ani identyfikatora konta.
 */
@Serializable
data class PostDto(
    val id: String,
    val author: AuthorDto?,
    val anonymous: Boolean,
    val mine: Boolean,
    val body: String,
    val visibility: String,
    val createdAt: String,
    val editedAt: String?,
    val reactions: Int,
    val comments: Int,
    val myReaction: String?,
    val saved: Boolean,
    val communityId: String? = null,
    val channelId: String? = null,
    val attachments: List<AttachmentDto> = emptyList(),
    /** Liczba publicznych udostępnień tego posta. */
    val shares: Int = 0,
    /** true, gdy ten post jest udostępnieniem innego; [shared] albo [sharedUnavailable] opisuje oryginał. */
    val isShare: Boolean = false,
    val shared: PostDto? = null,
    val sharedUnavailable: Boolean = false,
)

/** Bez klucza obiektu i bez właściciela (anonimowość). Plik pobiera się z GET /attachments/{id}. */
@Serializable
data class AttachmentDto(
    val id: String,
    /** image | video | document */
    val kind: String,
    val mime: String,
    val sizeBytes: Long,
    val fileName: String? = null,
    val width: Int? = null,
    val height: Int? = null,
)

@Serializable data class PostListResponse(val posts: List<PostDto>, val nextCursor: String? = null)

@Serializable
data class CommentDto(
    val id: String,
    val postId: String,
    val parentId: String?,
    val author: AuthorDto?,
    /** true, gdy autor komentarza jest ukryty, bo to autor anonimowego posta. */
    val authorHidden: Boolean,
    val mine: Boolean,
    val body: String,
    val createdAt: String,
    val replyCount: Int,
)

@Serializable data class CommentListResponse(val comments: List<CommentDto>, val nextCursor: String? = null)

@Serializable data class CreatePostRequest(
    val body: String = "", val visibility: String = "public", val anonymous: Boolean = false,
    val communityId: String? = null, val channelId: String? = null,
    val attachmentIds: List<String> = emptyList(),
)
@Serializable data class SharePostRequest(val comment: String = "", val visibility: String = "public")
@Serializable data class UpdatePostRequest(val body: String)
@Serializable data class ReactionRequest(val type: String)
@Serializable data class CreateCommentRequest(val body: String, val parentId: String? = null)

fun PostRow.toDto(viewer: UUID): PostDto = PostDto(
    id = id.toString(),
    author = if (anonymous) null else AuthorDto(authorWinkwinkId, authorNickname, authorDisplayName, authorAvatarKey != null, app.winkwink.server.profile.mediaTag(authorAvatarKey)),
    anonymous = anonymous,
    mine = authorId == viewer,
    body = body,
    visibility = visibility,
    createdAt = createdAt.toString(),
    editedAt = editedAt?.toString(),
    reactions = reactions,
    comments = comments,
    myReaction = myReaction,
    saved = saved,
    communityId = communityId?.toString(),
    channelId = channelId?.toString(),
    attachments = attachments.map { it.toDto() },
    shares = shares,
    isShare = isShare,
    shared = sharedPost?.toDto(viewer),
    sharedUnavailable = sharedUnavailable,
)

fun AttachmentRow.toDto() = AttachmentDto(id.toString(), kind, mime, sizeBytes, fileName, width, height)

fun CommentRow.toDto(viewer: UUID): CommentDto {
    val hidden = postAnonymous && authorId == postAuthorId
    return CommentDto(
        id = id.toString(), postId = postId.toString(), parentId = parentId?.toString(),
        author = if (hidden) null else AuthorDto(authorWinkwinkId, authorNickname, authorDisplayName, authorAvatarKey != null, app.winkwink.server.profile.mediaTag(authorAvatarKey)),
        authorHidden = hidden, mine = authorId == viewer, body = body, createdAt = createdAt.toString(), replyCount = replyCount,
    )
}

fun PostPage.toResponse(viewer: UUID) = PostListResponse(items.map { it.toDto(viewer) }, nextCursor)
fun CommentPage.toResponse(viewer: UUID) = CommentListResponse(items.map { it.toDto(viewer) }, nextCursor)
