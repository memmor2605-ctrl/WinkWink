package app.winkwink.server.feed

import java.time.Instant
import java.util.UUID

/** Metadane załącznika. Klucz obiektu i właściciel NIE trafiają do DTO (anonimowość + brak zgadywania ścieżek). */
data class AttachmentRow(
    val id: UUID,
    val ownerId: UUID,
    val postId: UUID?,
    val position: Int,
    /** image | video | document */
    val kind: String,
    val mime: String,
    val sizeBytes: Long,
    val objectKey: String,
    val fileName: String?,
    val width: Int?,
    val height: Int?,
    val createdAt: Instant,
)

/** Załączniki i udostępnienia postów. Osobny magazyn, żeby nie zmieniać kontraktu [FeedStore]. */
interface PostExtrasStore {
    suspend fun createAttachment(row: AttachmentRow)
    suspend fun getAttachment(id: UUID): AttachmentRow?
    suspend fun pendingCount(owner: UUID): Int
    /** Usuwa tylko niedołączony załącznik właściciela; zwraca jego wiersz (do usunięcia pliku) albo null. */
    suspend fun deletePending(owner: UUID, id: UUID): AttachmentRow?
    /** Dołącza załączniki (kolejność = kolejność [ids]) do posta; zwraca false, jeśli któryś nie należy do [owner] lub jest już użyty. */
    suspend fun attach(owner: UUID, postId: UUID, ids: List<UUID>): Boolean
    suspend fun forPosts(postIds: Collection<UUID>): Map<UUID, List<AttachmentRow>>

    suspend fun setShare(postId: UUID, originalId: UUID)
    suspend fun originalsOf(postIds: Collection<UUID>): Map<UUID, UUID>
    /** Liczba publicznych, nieusuniętych udostępnień danego posta (prywatne/obserwujących nie są liczone — nie zdradzamy ich). */
    suspend fun publicShareCounts(originalIds: Collection<UUID>): Map<UUID, Int>
    /** Klucze obiektów porzuconych (niedołączonych) załączników starszych niż [before]; wiersze są usuwane. */
    suspend fun purgePending(before: Instant): List<String>
    /** Usuwa wiersze załączników usuniętych postów (do [limit]) i zwraca ich klucze obiektów, żeby wołający skasował pliki. */
    suspend fun purgeForDeletedPosts(limit: Int): List<String> = emptyList()
}
