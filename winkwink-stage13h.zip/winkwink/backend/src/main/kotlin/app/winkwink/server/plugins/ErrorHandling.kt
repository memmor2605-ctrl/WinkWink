package app.winkwink.server.plugins

import app.winkwink.server.api.ApiException
import app.winkwink.server.api.respondError
import io.ktor.http.HttpHeaders
import io.ktor.server.plugins.ContentTransformationException
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.Application
import io.ktor.server.application.install
import io.ktor.server.application.log
import io.ktor.server.plugins.BadRequestException
import io.ktor.server.plugins.statuspages.StatusPages

fun Application.configureErrorHandling() {
    install(StatusPages) {
        exception<ApiException> { call, e ->
            e.retryAfterSeconds?.let { call.response.headers.append(HttpHeaders.RetryAfter, it.toString()) }
            call.respondError(e.status, e.code, e.message, e.details)
        }
        exception<ContentTransformationException> { call, _ ->
            call.respondError(HttpStatusCode.BadRequest, "bad_request", "The request body is missing or malformed.")
        }
        exception<BadRequestException> { call, _ ->
            call.respondError(HttpStatusCode.BadRequest, "bad_request", "The request could not be processed.")
        }
        exception<Throwable> { call, cause ->
            // Pełny stack trace tylko w logu; klient dostaje ogólny komunikat z requestId.
            call.application.log.error("Unhandled error", cause)
            call.respondError(HttpStatusCode.InternalServerError, "internal_error", "Unexpected server error.")
        }
        status(HttpStatusCode.NotFound) { call, _ ->
            call.respondError(HttpStatusCode.NotFound, "not_found", "Resource not found.")
        }
        status(HttpStatusCode.MethodNotAllowed) { call, _ ->
            call.respondError(HttpStatusCode.MethodNotAllowed, "method_not_allowed", "Method not allowed.")
        }
    }
}
