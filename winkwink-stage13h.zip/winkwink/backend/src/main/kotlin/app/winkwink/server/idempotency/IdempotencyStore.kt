package app.winkwink.server.idempotency

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.sql.Timestamp
import java.time.Instant
import java.util.UUID
import javax.sql.DataSource

/** Zapisany wynik operacji. [response] == null → operacja jest nadal w toku (albo proces padł w jej trakcie). */
data class IdempotencyRecord(val scope: String, val fingerprint: String, val status: Int?, val response: String?, val createdAt: Instant)

interface IdempotencyStore {
    /**
     * Atomowo rezerwuje klucz dla konta. `true` = ta operacja jest właścicielem klucza i ma ją wykonać.
     * Rezerwację niedokończoną i starszą niż [staleBefore] (proces padł w trakcie) wolno przejąć.
     */
    suspend fun claim(account: UUID, key: String, scope: String, fingerprint: String, now: Instant, staleBefore: Instant): Boolean
    suspend fun find(account: UUID, key: String): IdempotencyRecord?
    /**
     * Zapisuje wynik — tylko jeśli rezerwacja nadal należy do [claimedAt] (nie została przejęta po wygaśnięciu przez inne żądanie).
     * @return false, gdy rezerwację przejęto (wynik nie zostaje zapisany; to żądanie nie jest już „właścicielem” klucza).
     */
    suspend fun complete(account: UUID, key: String, claimedAt: Instant, status: Int, response: String, now: Instant): Boolean
    /** Zwalnia WŁASNĄ rezerwację ([claimedAt]) po błędzie. Nie rusza zakończonych wpisów ani rezerwacji przejętych przez inne żądanie. */
    suspend fun release(account: UUID, key: String, claimedAt: Instant)
    suspend fun purge(before: Instant): Int
}

class PostgresIdempotencyStore(private val dataSource: DataSource) : IdempotencyStore {
    private suspend fun <T> run(block: (java.sql.Connection) -> T): T = withContext(Dispatchers.IO) {
        dataSource.connection.use { c ->
            c.autoCommit = false
            try { val r = block(c); c.commit(); r } catch (e: Throwable) { c.rollback(); throw e }
        }
    }

    override suspend fun claim(account: UUID, key: String, scope: String, fingerprint: String, now: Instant, staleBefore: Instant): Boolean = run { c ->
        // Przejmujemy tylko NIEDOKOŃCZONĄ rezerwację starszą niż staleBefore I o tym samym scope/odcisku (inne żądanie z tym samym kluczem
        // nie może wyprzeć trwającej operacji — dostanie 422). created_at służy też jako znacznik własności (fencing token).
        c.prepareStatement(
            "INSERT INTO idempotency_keys (account_id, key, scope, fingerprint, created_at) VALUES (?, ?, ?, ?, ?) " +
                "ON CONFLICT (account_id, key) DO UPDATE SET created_at = EXCLUDED.created_at " +
                "WHERE idempotency_keys.completed_at IS NULL AND idempotency_keys.created_at < ? " +
                "AND idempotency_keys.scope = EXCLUDED.scope AND idempotency_keys.fingerprint = EXCLUDED.fingerprint RETURNING 1",
        ).use { ps ->
            ps.setObject(1, account); ps.setString(2, key); ps.setString(3, scope); ps.setString(4, fingerprint)
            ps.setTimestamp(5, Timestamp.from(now)); ps.setTimestamp(6, Timestamp.from(staleBefore))
            ps.executeQuery().use { it.next() }
        }
    }

    override suspend fun find(account: UUID, key: String): IdempotencyRecord? = run { c ->
        c.prepareStatement("SELECT scope, fingerprint, status, response, created_at FROM idempotency_keys WHERE account_id = ? AND key = ?").use { ps ->
            ps.setObject(1, account); ps.setString(2, key)
            ps.executeQuery().use { rs ->
                if (!rs.next()) null
                else IdempotencyRecord(rs.getString("scope"), rs.getString("fingerprint"), rs.getInt("status").takeUnless { rs.wasNull() }, rs.getString("response"), rs.getTimestamp("created_at").toInstant())
            }
        }
    }

    override suspend fun complete(account: UUID, key: String, claimedAt: Instant, status: Int, response: String, now: Instant): Boolean = run { c ->
        c.prepareStatement(
            "UPDATE idempotency_keys SET status = ?, response = ?, completed_at = ? " +
                "WHERE account_id = ? AND key = ? AND created_at = ? AND completed_at IS NULL",
        ).use { ps ->
            ps.setInt(1, status); ps.setString(2, response); ps.setTimestamp(3, Timestamp.from(now))
            ps.setObject(4, account); ps.setString(5, key); ps.setTimestamp(6, Timestamp.from(claimedAt))
            ps.executeUpdate() == 1
        }
    }

    override suspend fun release(account: UUID, key: String, claimedAt: Instant) = run { c ->
        c.prepareStatement("DELETE FROM idempotency_keys WHERE account_id = ? AND key = ? AND created_at = ? AND completed_at IS NULL").use { ps ->
            ps.setObject(1, account); ps.setString(2, key); ps.setTimestamp(3, Timestamp.from(claimedAt)); ps.executeUpdate()
        }
        Unit
    }

    override suspend fun purge(before: Instant): Int = run { c ->
        c.prepareStatement("DELETE FROM idempotency_keys WHERE created_at < ?").use { ps -> ps.setTimestamp(1, Timestamp.from(before)); ps.executeUpdate() }
    }
}
