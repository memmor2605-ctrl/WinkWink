package app.winkwink.server.auth

import java.time.Instant
import java.util.UUID

data class Account(val id: UUID, val email: String, val passwordHash: String, val status: String)

data class ProfileRecord(
    val accountId: UUID,
    val nickname: String,
    val winkwinkId: String,
    val bio: String?,
    val visibility: String,
)

data class FoundSession(
    val id: UUID,
    val accountId: UUID,
    val expiresAt: Instant,
    val revokedAt: Instant?,
    /** true, gdy przedstawiono bieżący token; false, gdy poprzedni (już zrotowany) — sygnał kradzieży. */
    val isCurrentToken: Boolean,
)

data class SessionView(
    val id: UUID,
    val platform: String?,
    val deviceName: String?,
    val createdAt: Instant,
    val lastUsedAt: Instant,
    val userAgent: String?,
)

class DuplicateException(val field: String) : RuntimeException("Duplicate value for $field")

/** Kontrakt trwałości dla uwierzytelniania. Implementacja produkcyjna: [PostgresAuthStore]. */
interface AuthStore {
    suspend fun createAccount(email: String, passwordHash: String, nickname: String, winkwinkId: String): Account
    suspend fun findAccountByEmail(email: String): Account?
    suspend fun findAccountById(id: UUID): Account?
    suspend fun findProfile(accountId: UUID): ProfileRecord?
    suspend fun updatePasswordHash(accountId: UUID, passwordHash: String)

    suspend fun createSession(
        accountId: UUID,
        platform: String,
        deviceName: String?,
        userAgent: String?,
        refreshHash: ByteArray,
        now: Instant,
        expiresAt: Instant,
    ): UUID

    suspend fun findSessionByRefreshHash(hash: ByteArray): FoundSession?
    suspend fun rotateSession(sessionId: UUID, expectedCurrentHash: ByteArray, newHash: ByteArray, now: Instant, newExpiresAt: Instant): Boolean
    suspend fun isSessionActive(sessionId: UUID, accountId: UUID, now: Instant): Boolean
    suspend fun revokeSession(sessionId: UUID, accountId: UUID, now: Instant): Boolean
    suspend fun revokeSessionById(sessionId: UUID, now: Instant)
    suspend fun revokeAllSessions(accountId: UUID, exceptSessionId: UUID?, now: Instant): Int
    suspend fun listSessions(accountId: UUID, now: Instant): List<SessionView>

    suspend fun recordAttempt(keyHash: String, at: Instant)
    suspend fun countAttempts(keyHash: String, since: Instant): Int
    suspend fun clearAttempts(keyHash: String)

    suspend fun createResetToken(accountId: UUID, tokenHash: ByteArray, now: Instant, expiresAt: Instant)
    suspend fun consumeResetToken(tokenHash: ByteArray, now: Instant): UUID?
    /**
     * Trwale usuwa konto i (kaskadą kluczy obcych) wszystko, co do niego należy: profil, sesje, posty, komentarze, reakcje,
     * wiadomości, załączniki, powiadomienia. @return false, gdy konta już nie ma (operacja jest idempotentna).
     */
    suspend fun deleteAccount(accountId: UUID): Boolean = false
}
