package app.winkwink.server.media

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.IOException
import java.io.InputStream
import java.nio.file.Files
import java.nio.file.NoSuchFileException
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.time.Instant
import java.util.UUID

/** Obiekt w magazynie otwierany strumieniowo: [open] daje świeży strumień od bajtu 0 (wołający zamyka go sam). */
class StoredObject(val length: Long, val open: () -> InputStream)

/**
 * Wspólna warstwa przechowywania plików (avatary, tła, a w kolejnych etapach: posty, wiadomości, dokumenty, głosówki).
 * Moduły biznesowe znają tylko ten interfejs i nieprzejrzyste klucze — podłączenie S3-compatible Object Storage
 * to nowa implementacja [MediaStorage], bez zmian w profilach. Kontrola dostępu NIE należy do magazynu: sprawdza ją serwis wołający.
 */
interface MediaStorage {
    /** Zapisuje obiekt pod [key] (nadpisuje). Zapis jest atomowy: czytelnik nie zobaczy częściowego pliku. */
    suspend fun put(key: String, bytes: ByteArray)

    /** @return zawartość albo null, gdy obiekt nie istnieje. */
    suspend fun get(key: String): ByteArray?

    /**
     * Idempotentne: brak obiektu nie jest błędem. Rzeczywisty błąd wejścia/wyjścia (np. brak uprawnień, dysk) jest PROPAGOWANY jako
     * [IOException] — wołający nie może uznać pliku za usunięty, gdy nadal leży na dysku (wtedy zostawia wiersz do ponowienia).
     */
    suspend fun delete(key: String)

    /**
     * Otwiera obiekt do strumieniowego odczytu (bez ładowania całości do pamięci) albo zwraca null, gdy nie istnieje.
     * Domyślna implementacja opiera się na [get]; magazyny plikowe i S3 nadpisują ją prawdziwym strumieniem.
     */
    suspend fun open(key: String): StoredObject? = get(key)?.let { bytes -> StoredObject(bytes.size.toLong()) { ByteArrayInputStream(bytes) } }

    /**
     * Klucze obiektów starszych niż [olderThan], rosnąco, tylko większe od [afterKey] (stronicowanie do rekoncyliacji z bazą).
     * Domyślnie pusta lista — magazyn, który nie umie wyliczać, nie jest rekoncyliowany.
     */
    suspend fun listOlderThan(olderThan: Instant, limit: Int, afterKey: String? = null): List<String> = emptyList()
}

object MediaKeys {
    private val KEY = Regex("^[a-z]{1,16}/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")

    /** Klucz = kategoria + losowy UUID. Nazwa nadana przez użytkownika nigdy nie trafia do ścieżki ani klucza. */
    fun newKey(category: String): String {
        require(category.matches(Regex("^[a-z]{1,16}$"))) { "invalid category" }
        return "$category/${UUID.randomUUID()}"
    }

    fun isValid(key: String) = KEY.matches(key)
}

/** Magazyn na dysku serwera. Klucze są walidowane, a ścieżka ostatecznie sprawdzana względem katalogu głównego (brak path traversal). */
class LocalFileMediaStorage(root: Path) : MediaStorage {
    private val root: Path = root.toAbsolutePath().normalize()

    init {
        Files.createDirectories(this.root)
    }

    private fun resolve(key: String): Path {
        require(MediaKeys.isValid(key)) { "invalid media key" }
        val p = root.resolve(key).normalize()
        require(p.startsWith(root)) { "invalid media key" }
        return p
    }

    override suspend fun put(key: String, bytes: ByteArray) = withContext(Dispatchers.IO) {
        val target = resolve(key)
        Files.createDirectories(target.parent)
        val tmp = Files.createTempFile(target.parent, ".upload-", ".tmp")
        try {
            Files.write(tmp, bytes)
            try {
                Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            } catch (e: java.nio.file.AtomicMoveNotSupportedException) {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING)
            }
        } finally {
            Files.deleteIfExists(tmp)
        }
    }

    override suspend fun get(key: String): ByteArray? = withContext(Dispatchers.IO) {
        try {
            Files.readAllBytes(resolve(key))
        } catch (e: NoSuchFileException) {
            null
        }
    }

    override suspend fun delete(key: String) = withContext(Dispatchers.IO) {
        // Brak pliku to sukces (deleteIfExists); inne błędy IO lecą do wołającego, który decyduje, czy ponowić.
        Files.deleteIfExists(resolve(key))
        Unit
    }

    override suspend fun open(key: String): StoredObject? = withContext(Dispatchers.IO) {
        val path = resolve(key)
        try {
            val length = Files.size(path)
            // Plik usunięty między sprawdzeniem a otwarciem → NoSuchFileException przy open() (obsługuje wołający jako 404).
            StoredObject(length) { Files.newInputStream(path) }
        } catch (e: NoSuchFileException) {
            null
        }
    }

    override suspend fun listOlderThan(olderThan: Instant, limit: Int, afterKey: String?): List<String> = withContext(Dispatchers.IO) {
        if (!Files.isDirectory(root)) return@withContext emptyList()
        val out = ArrayList<String>()
        Files.newDirectoryStream(root).use { categories ->
            for (dir in categories) {
                if (!Files.isDirectory(dir)) continue
                Files.newDirectoryStream(dir).use { files ->
                    for (f in files) {
                        val key = root.relativize(f).joinToString("/")
                        // Pliki tymczasowe (.upload-*) i obce nazwy omijamy; świeże pliki mogą być w trakcie zapisu.
                        if (!MediaKeys.isValid(key) || (afterKey != null && key <= afterKey)) continue
                        if (Files.getLastModifiedTime(f).toInstant().isBefore(olderThan)) out += key
                    }
                }
            }
        }
        out.sorted().take(limit)
    }
}

/**
 * Usuwanie „best effort” dla ścieżek, w których rekord w bazie jest już zmieniony: błąd IO jest logowany (bez ścieżek ani treści),
 * a plik, który został, zbierze okresowa rekoncyliacja ([MediaReconciler]). @return true, gdy obiektu już nie ma.
 */
suspend fun MediaStorage.deleteQuietly(key: String): Boolean = try {
    delete(key)
    true
} catch (e: kotlinx.coroutines.CancellationException) {
    throw e
} catch (e: Exception) {
    org.slf4j.LoggerFactory.getLogger("app.winkwink.media").warn("Could not delete media object {} ({})", key, e.javaClass.simpleName)
    false
}
