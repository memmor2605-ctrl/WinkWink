package app.winkwink.server.media

import app.winkwink.server.api.ApiException
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.http.content.OutgoingContent
import io.ktor.server.application.ApplicationCall
import io.ktor.server.response.header
import io.ktor.server.response.respond
import io.ktor.utils.io.ByteWriteChannel
import io.ktor.utils.io.writeFully
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.InputStream
import java.nio.file.NoSuchFileException

private val RANGE = Regex("^bytes=(\\d*)-(\\d*)$")
private const val CHUNK = 64 * 1024

/**
 * Odpowiada plikiem z magazynu strumieniowo (stały bufor 64 KB zamiast całego pliku w pamięci) z obsługą pojedynczego
 * zakresu `Range: bytes=a-b` (wznawianie pobierania, seek w odtwarzaczu). Rozłączenie klienta przerywa kopiowanie i zamyka plik.
 * Kontrola dostępu MUSI nastąpić przed wywołaniem — ta funkcja tylko wysyła bajty.
 */
suspend fun ApplicationCall.respondStored(obj: StoredObject, contentType: ContentType) {
    val total = obj.length
    var start = 0L
    var end = total - 1
    var partial = false
    val match = request.headers[HttpHeaders.Range]?.trim()?.let { RANGE.matchEntire(it) }
    if (match != null && (match.groupValues[1].isNotEmpty() || match.groupValues[2].isNotEmpty())) {
        val first = match.groupValues[1]
        val last = match.groupValues[2]
        if (first.isEmpty()) {
            val suffix = last.toLongOrNull() ?: 0L
            start = maxOf(0L, total - suffix)
        } else {
            start = first.toLongOrNull() ?: Long.MAX_VALUE
            if (last.isNotEmpty()) end = minOf(end, last.toLongOrNull() ?: end)
        }
        if (total == 0L || start >= total || start > end) {
            response.header(HttpHeaders.ContentRange, "bytes */$total")
            throw ApiException(HttpStatusCode.RequestedRangeNotSatisfiable, "range_not_satisfiable", "The requested range is not satisfiable.")
        }
        partial = true
    }
    val length = if (total == 0L) 0L else end - start + 1
    val input: InputStream = try {
        withContext(Dispatchers.IO) { obj.open() }
    } catch (e: NoSuchFileException) {
        // Plik zniknął między sprawdzeniem dostępu a otwarciem (równoległe usunięcie): dla klienta to zwykłe „nie ma”.
        throw ApiException(HttpStatusCode.NotFound, "attachment_not_found", "Attachment not found.")
    }
    response.header(HttpHeaders.AcceptRanges, "bytes")
    if (partial) response.header(HttpHeaders.ContentRange, "bytes $start-$end/$total")
    val content = object : OutgoingContent.WriteChannelContent() {
        override val contentType: ContentType = contentType
        override val contentLength: Long = length
        override val status: HttpStatusCode = if (partial) HttpStatusCode.PartialContent else HttpStatusCode.OK
        override suspend fun writeTo(channel: ByteWriteChannel) {
            input.use { stream ->
                withContext(Dispatchers.IO) { skipFully(stream, start) }
                val buffer = ByteArray(CHUNK)
                var remaining = length
                while (remaining > 0) {
                    val read = withContext(Dispatchers.IO) { stream.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt()) }
                    if (read < 0) break
                    channel.writeFully(buffer, 0, read)
                    remaining -= read
                }
            }
        }
    }
    try {
        respond(content)
    } finally {
        try { input.close() } catch (_: IOException) { }
    }
}

private fun skipFully(stream: InputStream, count: Long) {
    var left = count
    while (left > 0) {
        val skipped = stream.skip(left)
        if (skipped <= 0) {
            if (stream.read() < 0) return
            left--
        } else left -= skipped
    }
}
