package app.winkwink.server.idempotency

import app.winkwink.server.api.ApiException
import app.winkwink.server.plugins.ApiJson
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.request.header
import io.ktor.server.response.header
import io.ktor.server.response.respond
import io.ktor.server.response.respondText
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import kotlinx.serialization.KSerializer
import kotlinx.serialization.serializer
import java.time.Clock
import java.time.Duration
import java.time.temporal.ChronoUnit
import java.util.UUID

/**
 * Bezpieczne ponawianie operacji tworzących (posty, komentarze, udostępnienia, społeczności, grupy, wysyłanie plików).
 *
 * Klient wysyła nagłówek `Idempotency-Key` (UUID lub inny losowy ciąg 8–100 znaków `[A-Za-z0-9_.:-]`), ten sam przy każdym
 * ponowieniu TEJ SAMEJ operacji. Serwer wykonuje operację raz, zapamiętuje status i treść odpowiedzi (do 48 h) i przy ponowieniu
 * zwraca zapisaną odpowiedź z nagłówkiem `Idempotent-Replayed: true`. Ten sam klucz użyty do innej operacji → 422;
 * ponowienie w trakcie wykonywania pierwszego żądania → 409 `request_in_progress` (klient ponawia po chwili).
 * Błędy nie są zapamiętywane (rezerwacja jest zwalniana), więc po błędzie ponowienie wykonuje operację od nowa.
 * Brak nagłówka = zachowanie jak dotąd (bez ochrony).
 */
class Idempotency(
    @PublishedApi internal val store: IdempotencyStore,
    @PublishedApi internal val clock: Clock = Clock.systemUTC(),
) {
    companion object {
        const val HEADER = "Idempotency-Key"
        private val KEY = Regex("^[A-Za-z0-9_.:-]{8,100}$")
        /**
         * Po tym czasie niedokończona rezerwacja (proces padł w trakcie) może zostać przejęta przez ponowienie.
         * Dłuższy niż najdłuższy możliwy upload (klient: do 4 min), żeby wolna, ale żywa operacja nie została zdublowana.
         */
        val CLAIM_TTL: Duration = Duration.ofMinutes(10)
        val RETENTION: Duration = Duration.ofHours(48)
    }

    suspend fun <T : Any> respondWith(
        call: ApplicationCall, account: UUID, scope: String, status: HttpStatusCode, serializer: KSerializer<T>,
        fingerprint: String = "", block: suspend () -> T,
    ) {
        val key = call.request.header(HEADER)
        if (key == null) {
            call.respondText(ApiJson.encodeToString(serializer, block()), ContentType.Application.Json, status)
            return
        }
        if (!KEY.matches(key)) throw ApiException(HttpStatusCode.BadRequest, "invalid_idempotency_key", "Idempotency-Key must be 8-100 characters: letters, digits, _ . : -")
        // Mikrosekundy: tyle trzyma PostgreSQL — znacznik własności rezerwacji musi być porównywalny po zapisie i odczycie.
        val now = clock.instant().truncatedTo(ChronoUnit.MICROS)
        val print = app.winkwink.server.auth.Crypto.sha256Hex("$scope\n$fingerprint")
        if (!store.claim(account, key, scope, print, now, now.minus(CLAIM_TTL))) {
            val record = store.find(account, key)
                ?: throw ApiException(HttpStatusCode.Conflict, "request_in_progress", "Please retry the request.", retryAfterSeconds = 1)
            if (record.scope != scope || record.fingerprint != print) throw ApiException(HttpStatusCode.UnprocessableEntity, "idempotency_key_reused", "This Idempotency-Key was already used for a different request.")
            val body = record.response
            if (body == null || record.status == null) {
                throw ApiException(HttpStatusCode.Conflict, "request_in_progress", "The original request is still being processed.", retryAfterSeconds = 1)
            }
            call.response.header("Idempotent-Replayed", "true")
            call.respondText(body, ContentType.Application.Json, HttpStatusCode.fromValue(record.status))
            return
        }
        val result = try {
            block()
        } catch (e: Throwable) {
            withContext(NonCancellable) { runCatching { store.release(account, key, now) } }
            throw e
        }
        val text = ApiJson.encodeToString(serializer, result)
        // Zapis wyniku jest ważniejszy niż anulowanie żądania: bez niego ponowienie wykonałoby operację drugi raz.
        withContext(NonCancellable) {
            var saved = false
            repeat(3) { if (!saved) saved = runCatching { store.complete(account, key, now, status.value, text, clock.instant()) }.isSuccess }
        }
        call.respondText(text, ContentType.Application.Json, status)
    }

    suspend fun purge(): Int = store.purge(clock.instant().minus(RETENTION))
}

/**
 * Odpowiada wynikiem [block] — z ochroną przed duplikatami, gdy skonfigurowano [idem], a bez niej (jak dotąd) w przeciwnym razie.
 * `account` to konto z tokenu; klucz jest zawsze liczony per konto, więc nie da się odtworzyć cudzej odpowiedzi.
 */
suspend inline fun <reified T : Any> ApplicationCall.respondIdempotent(
    idem: Idempotency?, account: UUID, scope: String, status: HttpStatusCode, fingerprint: String = "", noinline block: suspend () -> T,
) {
    if (idem == null) respond(status, block()) else idem.respondWith(this, account, scope, status, serializer<T>(), fingerprint, block)
}
