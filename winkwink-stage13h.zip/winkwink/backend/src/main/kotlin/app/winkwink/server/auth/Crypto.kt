package app.winkwink.server.auth

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

/** Wyłącznie prymitywy z JDK (SHA-256, SecureRandom) — bez własnych algorytmów. */
object Crypto {
    fun sha256(input: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(input)

    fun sha256(input: String): ByteArray = sha256(input.toByteArray(Charsets.UTF_8))

    fun sha256Hex(input: String): String = sha256(input).joinToString("") { "%02x".format(it) }

    /** 256 bitów losowości, base64url bez dopełnienia. */
    fun randomToken(random: SecureRandom): String {
        val bytes = ByteArray(32).also(random::nextBytes)
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
    }
}
