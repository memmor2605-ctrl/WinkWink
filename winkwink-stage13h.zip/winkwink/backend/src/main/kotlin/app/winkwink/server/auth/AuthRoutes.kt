package app.winkwink.server.auth

import app.winkwink.server.api.ApiException
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.auth.authenticate
import io.ktor.server.auth.principal
import io.ktor.server.plugins.origin
import io.ktor.server.plugins.ratelimit.RateLimitName
import io.ktor.server.plugins.ratelimit.rateLimit
import io.ktor.server.request.header
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.delete
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.route
import java.util.UUID

data class UserPrincipal(val accountId: UUID, val sessionId: UUID)

val AUTH_RATE_LIMIT = RateLimitName("auth")
const val JWT_AUTH = "auth-jwt"

private fun ApplicationCall.user(): UserPrincipal =
    principal<UserPrincipal>() ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")

private fun ApplicationCall.userAgent(): String? = request.header(HttpHeaders.UserAgent)
private fun ApplicationCall.clientIp(): String = request.origin.remoteAddress

fun Route.authRoutes(service: AuthService) {
    // Endpointy publiczne (bez tokenu) — dodatkowo objęte ostrzejszym limitem żądań.
    rateLimit(AUTH_RATE_LIMIT) {
        route("/auth") {
            post("/register") {
                val body = call.receive<RegisterRequest>()
                val result = service.register(body.email, body.password, body.nickname, body.platform, body.deviceName, call.userAgent())
                call.respond(HttpStatusCode.Created, result.toResponse())
            }
            post("/login") {
                val body = call.receive<LoginRequest>()
                val result = service.login(body.email, body.password, body.platform, body.deviceName, call.userAgent(), call.clientIp())
                call.respond(result.toResponse())
            }
            post("/refresh") {
                val body = call.receive<RefreshRequest>()
                call.respond(service.refresh(body.refreshToken).toDto())
            }
            post("/password/forgot") {
                val body = call.receive<ForgotPasswordRequest>()
                service.requestPasswordReset(body.email)
                call.respond(HttpStatusCode.Accepted, mapOf("status" to "accepted"))
            }
            post("/password/reset") {
                val body = call.receive<ResetPasswordRequest>()
                service.resetPassword(body.token, body.newPassword)
                call.respond(mapOf("status" to "password_changed"))
            }
        }
    }

    authenticate(JWT_AUTH) {
        post("/auth/logout") {
            val u = call.user()
            service.logout(u.accountId, u.sessionId)
            call.respond(HttpStatusCode.NoContent)
        }
        route("/me") {
            get {
                val me = service.me(call.user().accountId)
                call.respond(MeResponse(me.email, me.profile.toDto()))
            }
            post("/password") {
                val u = call.user()
                val body = call.receive<ChangePasswordRequest>()
                service.changePassword(u.accountId, u.sessionId, body.currentPassword, body.newPassword)
                call.respond(mapOf("status" to "password_changed"))
            }
            // Trwałe usunięcie konta i wszystkich jego danych. POST (nie DELETE z ciałem), bo wymaga hasła w treści.
            post("/delete") {
                val u = call.user()
                val body = call.receive<DeleteAccountRequest>()
                service.deleteAccount(u.accountId, body.password)
                call.respond(HttpStatusCode.NoContent)
            }
            get("/sessions") {
                val u = call.user()
                val sessions = service.listSessions(u.accountId).map {
                    SessionDto(it.id.toString(), it.platform, it.deviceName, it.createdAt.toString(), it.lastUsedAt.toString(), it.id == u.sessionId)
                }
                call.respond(SessionsResponse(sessions))
            }
            delete("/sessions") {
                val u = call.user()
                call.respond(RevokedResponse(service.revokeOtherSessions(u.accountId, u.sessionId)))
            }
            delete("/sessions/{id}") {
                val u = call.user()
                val id = runCatching { UUID.fromString(call.parameters["id"]) }.getOrNull()
                    ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "Invalid session id.")
                service.revokeSession(u.accountId, id)
                call.respond(HttpStatusCode.NoContent)
            }
        }
    }
}
