package app.winkwink.server.notification

import kotlinx.serialization.Serializable

@Serializable data class NotificationActorDto(val winkwinkId: String, val nickname: String, val displayName: String? = null, val hasAvatar: Boolean = false)

@Serializable
data class NotificationDto(
    val id: String,
    val type: String,
    /** `null`, gdy [actorAnonymous] — wtedy konto autora anonimowej treści nie opuszcza backendu. */
    val actor: NotificationActorDto? = null,
    val actorAnonymous: Boolean = false,
    val postId: String? = null,
    val commentId: String? = null,
    val communityId: String? = null,
    val createdAt: String,
    val read: Boolean,
)

@Serializable data class NotificationListResponse(val notifications: List<NotificationDto>, val nextCursor: String? = null, val unreadCount: Int)
@Serializable data class UnreadCountResponse(val unreadCount: Int)
@Serializable data class NotificationSettingsDto(val types: Map<String, Boolean>)

fun NotificationRow.toDto() = NotificationDto(
    id = id.toString(), type = type,
    actor = if (actorAnonymous) null else NotificationActorDto(actorWinkwinkId, actorNickname, actorDisplayName, actorHasAvatar),
    actorAnonymous = actorAnonymous,
    postId = postId?.toString(), commentId = commentId?.toString(), communityId = communityId?.toString(),
    createdAt = createdAt.toString(), read = readAt != null,
)
