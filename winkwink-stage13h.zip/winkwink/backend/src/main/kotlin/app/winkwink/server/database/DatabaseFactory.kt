package app.winkwink.server.database

import app.winkwink.server.config.DatabaseConfig
import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import org.flywaydb.core.Flyway
import javax.sql.DataSource

object DatabaseFactory {
    /** Tworzy pulę połączeń. Rzuca wyjątek (fail-fast), jeśli PostgreSQL jest niedostępny. */
    fun createDataSource(config: DatabaseConfig): HikariDataSource {
        val hikari = HikariConfig().apply {
            jdbcUrl = config.jdbcUrl
            username = config.user
            password = config.password
            driverClassName = "org.postgresql.Driver"
            maximumPoolSize = config.maxPoolSize
            connectionTimeout = 3_000
            validationTimeout = 2_000
            poolName = "winkwink-pg"
        }
        return HikariDataSource(hikari)
    }

    /** Uruchamia migracje Flyway z classpath:db/migration. Zwraca liczbę wykonanych migracji. */
    fun migrate(dataSource: DataSource): Int =
        Flyway.configure()
            .dataSource(dataSource)
            .locations("classpath:db/migration")
            .load()
            .migrate()
            .migrationsExecuted
}
