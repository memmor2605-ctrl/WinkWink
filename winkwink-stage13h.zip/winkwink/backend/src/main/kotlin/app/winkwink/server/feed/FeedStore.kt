package app.winkwink.server.feed

import app.winkwink.server.profile.PageCursor
import java.time.Instant
import java.util.UUID

data class PostRow(
    val id: UUID,
    val authorId: UUID,
    val authorNickname: String,
    val authorWinkwinkId: String,
    val authorDisplayName: String?,
    val body: String,
    val visibility: String,
    val anonymous: Boolean,
    val createdAt: Instant,
    val editedAt: Instant?,
    val reactions: Int,
    val comments: Int,
    val myReaction: String?,
    val saved: Boolean,
    /** Klucz stronicowania: created_at posta albo (dla zapisanych) czas zapisu. */
    val cursorAt: Instant,
    /** Ustawione wyłącznie dla visibility = "community". */
    val communityId: UUID? = null,
    val channelId: UUID? = null,
    /** Klucz avatara autora. NIGDY nie jest używany dla postów anonimowych (DTO pomija autora). */
    val authorAvatarKey: String? = null,
    /** Uzupełniane przez [FeedService] (nie przez magazyn): załączniki, licznik publicznych udostępnień, oryginał udostępnionego posta. */
    val attachments: List<AttachmentRow> = emptyList(),
    val shares: Int = 0,
    val isShare: Boolean = false,
    /** Oryginał widoczny dla widza (dla postów będących udostępnieniem); przy anonimowym oryginale autor pozostaje ukryty w DTO. */
    val sharedPost: PostRow? = null,
    /** Post jest udostępnieniem, ale oryginał jest dla widza niedostępny (usunięty, prywatny, zablokowany). */
    val sharedUnavailable: Boolean = false,
)

data class CommentRow(
    val id: UUID,
    val postId: UUID,
    val parentId: UUID?,
    val authorId: UUID,
    val authorNickname: String,
    val authorWinkwinkId: String,
    val authorDisplayName: String?,
    val body: String,
    val createdAt: Instant,
    val postAuthorId: UUID,
    val postAnonymous: Boolean,
    val replyCount: Int,
    val authorAvatarKey: String? = null,
)

/**
 * Reguła widoczności posta dla widza (jedno źródło prawdy; Postgres odwzorowuje ją w SQL):
 * autor zawsze widzi swój post; blokada w którąkolwiek stronę ukrywa — z jednym wyjątkiem: dla posta ANONIMOWEGO liczy się tylko blokada
 * „autor zablokował widza” (inaczej widz mógłby zablokować podejrzaną osobę i po zniknięciu posta poznać autora; wołający przekazuje
 * w [canView] `blockedEitherWay` już obliczone według tej reguły); `private` widzi tylko autor;
 * `followers` — zaakceptowani obserwujący; `public` — wszyscy, o ile profil autora jest publiczny,
 * a w przeciwnym razie tylko zaakceptowani obserwujący; `community` — członkowie społeczności posta.
 */
object PostVisibility {
    fun canView(
        viewer: UUID, authorId: UUID, postVisibility: String, authorProfileVisibility: String,
        viewerFollowsAuthor: Boolean, blockedEitherWay: Boolean, viewerIsCommunityMember: Boolean = false,
    ): Boolean = when {
        viewer == authorId -> true
        blockedEitherWay -> false
        postVisibility == "private" -> false
        postVisibility == "followers" -> viewerFollowsAuthor
        postVisibility == "public" -> authorProfileVisibility == "public" || viewerFollowsAuthor
        postVisibility == "community" -> viewerIsCommunityMember
        else -> false
    }
}

interface FeedStore {
    suspend fun createPost(
        authorId: UUID, body: String, visibility: String, anonymous: Boolean, now: Instant,
        communityId: UUID? = null, channelId: UUID? = null,
    ): UUID
    /** Zwraca post tylko jeśli jest widoczny dla [viewer] (patrz [PostVisibility]); inaczej null. */
    suspend fun getPost(id: UUID, viewer: UUID): PostRow?
    suspend fun updatePostBody(id: UUID, body: String, now: Instant): Boolean
    suspend fun deletePost(id: UUID, now: Instant): Boolean

    /** Posty własne i obserwowanych (bez anonimowych i prywatnych). */
    suspend fun followingFeed(viewer: UUID, limit: Int, after: PageCursor?): List<PostRow>
    /** Publiczne posty spoza kręgu obserwowanych; anonimowe zawsze dopuszczone (brak przecieku powiązań). */
    suspend fun discoverFeed(viewer: UUID, limit: Int, after: PageCursor?): List<PostRow>
    /** Nieanonimowe posty wskazanego autora widoczne dla widza. */
    suspend fun userPosts(viewer: UUID, authorId: UUID, limit: Int, after: PageCursor?): List<PostRow>
    /** Posty społeczności (opcjonalnie jednego kanału) widoczne dla widza; wywołujący sprawdza członkostwo. */
    suspend fun communityPosts(viewer: UUID, communityId: UUID, channelId: UUID?, limit: Int, after: PageCursor?): List<PostRow>
    /** Rola konta w nieusuniętej społeczności albo null, gdy nie jest członkiem lub społeczność nie istnieje. */
    suspend fun communityRole(communityId: UUID, accountId: UUID): String?
    /** Wyciszony członek społeczności nie może w niej pisać (posty, komentarze). */
    suspend fun communityMuted(communityId: UUID, accountId: UUID): Boolean = false
    suspend fun channelInCommunity(communityId: UUID, channelId: UUID): Boolean
    suspend fun searchPosts(viewer: UUID, query: String, limit: Int, after: PageCursor?): List<PostRow>
    suspend fun savedPosts(viewer: UUID, limit: Int, after: PageCursor?): List<PostRow>

    suspend fun setReaction(postId: UUID, accountId: UUID, type: String, now: Instant)
    suspend fun removeReaction(postId: UUID, accountId: UUID)
    suspend fun savePost(postId: UUID, accountId: UUID, now: Instant)
    suspend fun unsavePost(postId: UUID, accountId: UUID)

    suspend fun createComment(postId: UUID, parentId: UUID?, authorId: UUID, body: String, now: Instant): UUID
    suspend fun getComment(id: UUID): CommentRow?
    /** Komentarze rosnąco; [parentId] = null → najwyższy poziom. Bez komentarzy użytkowników zablokowanych względem [viewer]. */
    suspend fun listComments(postId: UUID, parentId: UUID?, viewer: UUID, limit: Int, after: PageCursor?): List<CommentRow>
    /** Usuwa komentarz razem z jego odpowiedziami (miękko). */
    suspend fun deleteComment(id: UUID, now: Instant): Boolean
}
