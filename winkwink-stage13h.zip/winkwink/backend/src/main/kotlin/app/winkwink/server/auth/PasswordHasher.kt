package app.winkwink.server.auth

import org.bouncycastle.crypto.generators.Argon2BytesGenerator
import org.bouncycastle.crypto.params.Argon2Parameters
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

interface PasswordHasher {
    fun hash(password: String): String
    fun verify(password: String, encoded: String): Boolean
}

/**
 * Argon2id (RFC 9106) z Bouncy Castle. Domyślne parametry: m=19 MiB, t=2, p=1 (minimum rekomendowane przez OWASP).
 * Format: $argon2id$v=19$m=..,t=..,p=..$<salt>$<hash> (base64 bez dopełnienia).
 */
class Argon2idPasswordHasher(
    private val memoryKb: Int = 19_456,
    private val iterations: Int = 2,
    private val parallelism: Int = 1,
    private val random: SecureRandom = SecureRandom(),
) : PasswordHasher {
    private val encoder = Base64.getEncoder().withoutPadding()
    private val decoder = Base64.getDecoder()

    override fun hash(password: String): String {
        val salt = ByteArray(SALT_BYTES).also(random::nextBytes)
        val digest = derive(password, salt, memoryKb, iterations, parallelism, HASH_BYTES)
        return listOf(
            "", "argon2id", "v=19", "m=$memoryKb,t=$iterations,p=$parallelism",
            encoder.encodeToString(salt), encoder.encodeToString(digest),
        ).joinToString("\$")
    }

    override fun verify(password: String, encoded: String): Boolean {
        return try {
            val parts = encoded.split('$')
            if (parts.size != 6 || parts[1] != "argon2id" || parts[2] != "v=19") return false
            val params = parts[3].split(',').associate { it.substringBefore('=') to it.substringAfter('=') }
            val m = params["m"]?.toIntOrNull() ?: return false
            val t = params["t"]?.toIntOrNull() ?: return false
            val p = params["p"]?.toIntOrNull() ?: return false
            // Ochrona przed uszkodzonym rekordem wymuszającym ogromne zużycie pamięci.
            if (m !in 8..MAX_MEMORY_KB || t !in 1..10 || p !in 1..8) return false
            val salt = decoder.decode(parts[4])
            val expected = decoder.decode(parts[5])
            if (expected.size < 16) return false
            val actual = derive(password, salt, m, t, p, expected.size)
            MessageDigest.isEqual(expected, actual)
        } catch (e: IllegalArgumentException) {
            false
        }
    }

    private fun derive(password: String, salt: ByteArray, m: Int, t: Int, p: Int, length: Int): ByteArray {
        val params = Argon2Parameters.Builder(Argon2Parameters.ARGON2_id)
            .withVersion(Argon2Parameters.ARGON2_VERSION_13)
            .withSalt(salt)
            .withMemoryAsKB(m)
            .withIterations(t)
            .withParallelism(p)
            .build()
        val generator = Argon2BytesGenerator().apply { init(params) }
        val out = ByteArray(length)
        generator.generateBytes(password.toByteArray(Charsets.UTF_8), out)
        return out
    }

    private companion object {
        const val SALT_BYTES = 16
        const val HASH_BYTES = 32
        const val MAX_MEMORY_KB = 262_144
    }
}
