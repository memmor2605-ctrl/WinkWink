package app.winkwink.server.feed

import app.winkwink.server.api.ApiException
import app.winkwink.server.auth.JWT_AUTH
import app.winkwink.server.auth.UserPrincipal
import app.winkwink.server.idempotency.Idempotency
import app.winkwink.server.idempotency.respondIdempotent
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.auth.authenticate
import io.ktor.server.auth.principal
import io.ktor.server.request.contentLength
import io.ktor.server.request.contentType
import io.ktor.server.request.receive
import io.ktor.server.response.header
import io.ktor.server.response.respond
import app.winkwink.server.media.respondStored
import io.ktor.server.routing.Route
import io.ktor.server.routing.delete
import io.ktor.server.routing.get
import io.ktor.server.routing.post

private fun ApplicationCall.viewer() =
    (principal<UserPrincipal>() ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")).accountId

private fun ApplicationCall.attachmentId(): java.util.UUID =
    parameters["id"]?.let { runCatching { java.util.UUID.fromString(it) }.getOrNull() }
        ?: throw ApiException(HttpStatusCode.NotFound, "attachment_not_found", "Attachment not found.")

fun Route.attachmentRoutes(service: AttachmentService, idem: Idempotency? = null) {
    authenticate(JWT_AUTH) {
        // Surowe ciało = plik (bez multipartu). Content-Length jest wymagany, żeby odrzucić zbyt duży plik zanim trafi do pamięci.
        post("/attachments") {
            val v = call.viewer()
            val type = call.request.contentType()
            val mime = "${type.contentType}/${type.contentSubtype}".lowercase()
            val max = AttachmentService.maxBytesFor(mime)
                ?: throw ApiException(HttpStatusCode.UnsupportedMediaType, "unsupported_media_type", "Allowed: image/jpeg, image/png, video/mp4, application/pdf.")
            val len = call.request.contentLength()
                ?: throw ApiException(HttpStatusCode.LengthRequired, "length_required", "Content-Length is required.")
            if (len > max) throw ApiException(HttpStatusCode.PayloadTooLarge, "payload_too_large", "File is too large.")
            val name = call.request.queryParameters["name"]
            call.respondIdempotent(idem, v, "POST /attachments", HttpStatusCode.Created, fingerprint = "$mime|$name|${call.request.headers["Content-Length"]}") { service.upload(v, call.receive<ByteArray>(), mime, name).toDto() }
        }
        delete("/attachments/{id}") {
            service.deletePending(call.viewer(), call.attachmentId())
            call.respond(HttpStatusCode.NoContent)
        }
        get("/attachments/{id}") {
            val file = service.download(call.viewer(), call.attachmentId())
            // Prywatna treść: tylko cache klienta; brak sniffingu; sandbox CSP chroni przed wykonaniem treści w przeglądarce.
            call.response.header(HttpHeaders.CacheControl, "private, max-age=3600")
            call.response.header("X-Content-Type-Options", "nosniff")
            call.response.header("Content-Security-Policy", "default-src 'none'; sandbox")
            val disposition = if (file.kind == "document") {
                "attachment; filename*=UTF-8''" + java.net.URLEncoder.encode(file.fileName ?: "document.pdf", Charsets.UTF_8).replace("+", "%20")
            } else "inline"
            call.response.header(HttpHeaders.ContentDisposition, disposition)
            call.respondStored(file.stored, ContentType.parse(file.mime))
        }
    }
}
