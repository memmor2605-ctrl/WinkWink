package app.winkwink.server.notification

import app.winkwink.server.api.ApiException
import app.winkwink.server.profile.PageCursor
import app.winkwink.server.profile.ProfileService
import app.winkwink.server.profile.ProfileStore
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.CancellationException
import org.slf4j.LoggerFactory
import java.time.Clock
import java.util.UUID

data class NotificationPage(val items: List<NotificationRow>, val nextCursor: String?, val unreadCount: Int)

class NotificationService(
    private val store: NotificationStore,
    private val profiles: ProfileStore,
    private val clock: Clock = Clock.systemUTC(),
    private val push: app.winkwink.server.push.PushGateway = app.winkwink.server.push.PushGateway.None,
) : Notifier {
    private val log = LoggerFactory.getLogger("app.winkwink.notifications")

    /**
     * Tworzy powiadomienie, jeśli wolno: nie dla samego siebie, nie między zablokowanymi, nie dla wyłączonego typu.
     * Błąd tutaj nigdy nie psuje akcji użytkownika (reakcji, komentarza…); logujemy tylko typ i klasę wyjątku (bez treści).
     */
    override suspend fun notify(event: NotificationEvent) {
        try {
            if (event.type !in NotificationTypes.ALL || event.recipient == event.actor) return
            // Zdarzenie anonimowe: blokada „odbiorca → aktor” jest ignorowana, bo jej skutek (brak powiadomienia) zdradzałby tożsamość aktora.
            val blocked = if (event.actorAnonymous) profiles.hasBlocked(event.actor, event.recipient)
            else profiles.isBlockedEitherWay(event.recipient, event.actor)
            if (blocked) return
            // Wyciszenie ukrywa powiadomienia od jawnego aktora; anonimowe zdarzenia nie są filtrowane (anty-deanonimizacja).
            if (!event.actorAnonymous && profiles.isMuted(event.recipient, event.actor)) return
            if (NotificationTypes.settingKey(event.type) in store.disabledTypes(event.recipient)) return
            val id = store.insert(event, clock.instant()) ?: return // zdeduplikowane: bez push
            // Push tylko dla faktycznie zapisanego powiadomienia — te same filtry (blokady, wyciszenia, ustawienia typów) co lista.
            val actor = if (event.actorAnonymous) null else profiles.findById(event.actor)
            push.notification(
                event.recipient,
                app.winkwink.server.push.PushNotification(
                    id, event.type, actor?.let { it.displayName?.takeIf { n -> n.isNotBlank() } ?: it.nickname }, actor?.winkwinkId,
                    event.postId, event.commentId, event.communityId,
                ),
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            log.warn("notification_failed type={} error={}", event.type, e.javaClass.simpleName)
        }
    }

    suspend fun list(viewer: UUID, type: String?, unreadOnly: Boolean, limit: Int?, cursor: String?): NotificationPage {
        if (type != null && type !in NotificationTypes.ALL) throw bad("type: one of ${NotificationTypes.ALL.sorted().joinToString()}")
        val l = ProfileService.clampLimit(limit)
        val rows = store.list(viewer, type, unreadOnly, l + 1, PageCursor.decode(cursor))
        val items = rows.take(l)
        val next = if (rows.size > l) items.last().let { PageCursor(it.createdAt, it.id).encode() } else null
        return NotificationPage(items, next, store.unreadCount(viewer))
    }

    suspend fun unreadCount(viewer: UUID) = store.unreadCount(viewer)

    suspend fun markRead(viewer: UUID, id: UUID) {
        // Cudze i nieistniejące powiadomienia są nierozróżnialne (404), idempotentne dla już przeczytanych własnych.
        if (!store.markRead(viewer, id, clock.instant())) throw ApiException(HttpStatusCode.NotFound, "notification_not_found", "Notification not found.")
        push.dismiss(viewer, id.toString(), null, null) // inne urządzenia zdejmują wyświetlone powiadomienie
    }

    suspend fun markAllRead(viewer: UUID, type: String?) {
        if (type != null && type !in NotificationTypes.ALL) throw bad("type: one of ${NotificationTypes.ALL.sorted().joinToString()}")
        store.markAllRead(viewer, type, clock.instant())
        push.dismiss(viewer, "all", null, null)
    }

    /** Mapa typ → włączony. */
    suspend fun settings(viewer: UUID): Map<String, Boolean> {
        val disabled = store.disabledTypes(viewer)
        return NotificationTypes.ALL.sorted().associateWith { it !in disabled }
    }

    /** Aktualizacja częściowa: zmieniane są tylko podane typy. */
    suspend fun updateSettings(viewer: UUID, changes: Map<String, Boolean>): Map<String, Boolean> {
        val unknown = changes.keys - NotificationTypes.ALL
        if (unknown.isNotEmpty()) throw bad("types: unknown type")
        val disabled = store.disabledTypes(viewer).toMutableSet()
        changes.forEach { (t, enabled) -> if (enabled) disabled.remove(t) else disabled.add(t) }
        store.setDisabledTypes(viewer, disabled)
        return settings(viewer)
    }

    private fun bad(msg: String) = ApiException(HttpStatusCode.BadRequest, "validation_failed", msg)
}
