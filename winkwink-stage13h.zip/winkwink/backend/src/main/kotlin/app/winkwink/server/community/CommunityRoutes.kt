package app.winkwink.server.community

import app.winkwink.server.api.ApiException
import app.winkwink.server.auth.JWT_AUTH
import app.winkwink.server.auth.UserPrincipal
import app.winkwink.server.idempotency.Idempotency
import app.winkwink.server.idempotency.respondIdempotent
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.auth.authenticate
import io.ktor.server.auth.principal
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.delete
import io.ktor.server.routing.get
import io.ktor.server.routing.patch
import io.ktor.server.routing.post
import io.ktor.server.routing.put
import java.util.UUID

private fun ApplicationCall.actor(): UUID =
    (principal<UserPrincipal>() ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")).accountId

private fun ApplicationCall.limit(): Int? = request.queryParameters["limit"]?.let {
    it.toIntOrNull() ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "limit must be an integer.")
}
private fun ApplicationCall.cursor(): String? = request.queryParameters["cursor"]
private fun ApplicationCall.cid() = CommunityService.communityId(parameters["id"])
private fun ApplicationCall.userParam() =
    parameters["user"] ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "Missing user identifier.")

private fun ListPage<CommunityRow>.toResponse() = CommunityListResponse(items.map { it.toDto() }, nextCursor)
private fun ListPage<PersonRow>.toResponse() = PersonListResponse(items.map { it.toDto() }, nextCursor)

fun Route.communityRoutes(service: CommunityService, idem: Idempotency? = null) {
    authenticate(JWT_AUTH) {
        post("/communities") {
            val b = call.receive<CreateCommunityRequest>()
            val actor = call.actor()
            call.respondIdempotent(idem, actor, "POST /communities", HttpStatusCode.Created, fingerprint = b.toString()) { service.create(actor, b.name, b.description, b.rules, b.type).toDto() }
        }
        // Stałe segmenty mają pierwszeństwo przed {id}.
        get("/communities/search") {
            val q = call.request.queryParameters["q"] ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "Missing q.")
            call.respond(service.search(call.actor(), q, call.limit(), call.cursor()).toResponse())
        }
        get("/me/communities") { call.respond(service.mine(call.actor(), call.limit(), call.cursor()).toResponse()) }
        get("/me/community-invites") { call.respond(service.myInvites(call.actor(), call.limit(), call.cursor()).toResponse()) }

        get("/communities/{id}") { call.respond(service.view(call.actor(), call.cid()).toDto()) }
        patch("/communities/{id}") {
            val b = call.receive<UpdateCommunityRequest>()
            call.respond(service.update(call.actor(), call.cid(), b.name, b.description, b.rules, b.type).toDto())
        }
        delete("/communities/{id}") { service.delete(call.actor(), call.cid()); call.respond(HttpStatusCode.NoContent) }

        post("/communities/{id}/membership") { call.respond(JoinResponse(service.join(call.actor(), call.cid()))) }
        delete("/communities/{id}/membership") { service.leave(call.actor(), call.cid()); call.respond(HttpStatusCode.NoContent) }
        delete("/communities/{id}/join-request") { service.cancelRequest(call.actor(), call.cid()); call.respond(HttpStatusCode.NoContent) }

        get("/communities/{id}/members") { call.respond(service.members(call.actor(), call.cid(), call.limit(), call.cursor()).toResponse()) }
        put("/communities/{id}/members/{user}/role") {
            service.setRole(call.actor(), call.cid(), call.userParam(), call.receive<RoleRequest>().role)
            call.respond(HttpStatusCode.NoContent)
        }
        delete("/communities/{id}/members/{user}") {
            service.removeMember(call.actor(), call.cid(), call.userParam()); call.respond(HttpStatusCode.NoContent)
        }

        post("/communities/{id}/transfer-ownership") {
            service.transferOwnership(call.actor(), call.cid(), call.receive<TransferOwnershipRequest>().user); call.respond(HttpStatusCode.NoContent)
        }
        put("/communities/{id}/members/{user}/mute") {
            service.setMuted(call.actor(), call.cid(), call.userParam(), true); call.respond(HttpStatusCode.NoContent)
        }
        delete("/communities/{id}/members/{user}/mute") {
            service.setMuted(call.actor(), call.cid(), call.userParam(), false); call.respond(HttpStatusCode.NoContent)
        }
        get("/communities/{id}/invite-candidates") {
            val q = call.request.queryParameters["q"] ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "Missing q.")
            call.respond(InviteCandidateListResponse(service.inviteCandidates(call.actor(), call.cid(), q).map { (u, invited) ->
                InviteCandidateDto(u.winkwinkId, u.nickname, u.displayName, invited)
            }))
        }
        post("/communities/{id}/invites") {
            service.invite(call.actor(), call.cid(), call.receive<InviteRequest>().user); call.respond(HttpStatusCode.NoContent)
        }
        post("/communities/{id}/invitation/accept") { service.respondToInvite(call.actor(), call.cid(), true); call.respond(HttpStatusCode.NoContent) }
        post("/communities/{id}/invitation/decline") { service.respondToInvite(call.actor(), call.cid(), false); call.respond(HttpStatusCode.NoContent) }

        get("/communities/{id}/requests") { call.respond(service.requests(call.actor(), call.cid(), call.limit(), call.cursor()).toResponse()) }
        post("/communities/{id}/requests/{user}/approve") {
            service.decideRequest(call.actor(), call.cid(), call.userParam(), true); call.respond(HttpStatusCode.NoContent)
        }
        post("/communities/{id}/requests/{user}/reject") {
            service.decideRequest(call.actor(), call.cid(), call.userParam(), false); call.respond(HttpStatusCode.NoContent)
        }

        get("/communities/{id}/channels") { call.respond(ChannelListResponse(service.channels(call.actor(), call.cid()).map { it.toDto() })) }
        post("/communities/{id}/channels") {
            call.respond(HttpStatusCode.Created, service.createChannel(call.actor(), call.cid(), call.receive<CreateChannelRequest>().name).toDto())
        }
        delete("/communities/{id}/channels/{channelId}") {
            val ch = runCatching { UUID.fromString(call.parameters["channelId"]) }.getOrNull()
                ?: throw ApiException(HttpStatusCode.NotFound, "channel_not_found", "Channel not found.")
            service.deleteChannel(call.actor(), call.cid(), ch); call.respond(HttpStatusCode.NoContent)
        }
    }
}
