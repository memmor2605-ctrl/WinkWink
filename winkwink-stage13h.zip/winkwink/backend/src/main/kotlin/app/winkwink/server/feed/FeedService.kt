package app.winkwink.server.feed

import app.winkwink.server.notification.NotificationEvent
import app.winkwink.server.notification.NotificationTypes
import app.winkwink.server.notification.Notifier
import app.winkwink.server.api.ApiException
import app.winkwink.server.profile.PageCursor
import app.winkwink.server.profile.ProfileService
import io.ktor.http.HttpStatusCode
import java.time.Clock
import java.util.UUID

data class PostPage(val items: List<PostRow>, val nextCursor: String?)
data class CommentPage(val items: List<CommentRow>, val nextCursor: String?)

class FeedService(
    private val store: FeedStore,
    private val profiles: ProfileService,
    private val clock: Clock = Clock.systemUTC(),
    private val notifier: Notifier = Notifier.None,
    /** null = załączniki i udostępnianie wyłączone (np. w testach, które ich nie dotyczą). */
    private val extras: PostExtrasStore? = null,
) {
    companion object {
        const val BODY_MAX = 5000
        const val COMMENT_MAX = 2000
        val VISIBILITIES = setOf("public", "followers", "private", "community")
        val COMMUNITY_MODERATOR_ROLES = setOf("moderator", "admin", "owner")
        private fun communityNotFound() = ApiException(HttpStatusCode.NotFound, "community_not_found", "Community not found.")
        private fun channelNotFound() = ApiException(HttpStatusCode.NotFound, "channel_not_found", "Channel not found.")
        const val MAX_ATTACHMENTS = 10
        const val MAX_VIDEOS = 1
        const val MAX_DOCUMENTS = 3
        val SHARE_VISIBILITIES = setOf("public", "followers")
        private fun communityMuted() = ApiException(HttpStatusCode.Forbidden, "muted_in_community", "You are muted in this community.")
        private fun attachmentNotFound() = ApiException(HttpStatusCode.NotFound, "attachment_not_found", "Attachment not found.")
        val REACTIONS = setOf("like", "love", "laugh", "wow", "sad")
        private fun postNotFound() = ApiException(HttpStatusCode.NotFound, "post_not_found", "Post not found.")
        private fun commentNotFound() = ApiException(HttpStatusCode.NotFound, "comment_not_found", "Comment not found.")
        private fun bad(msg: String) = ApiException(HttpStatusCode.BadRequest, "validation_failed", msg, listOf(msg))
        fun parseId(raw: String?, notFound: ApiException): UUID = raw?.let { runCatching { UUID.fromString(it) }.getOrNull() } ?: throw notFound
        fun postId(raw: String?) = parseId(raw, postNotFound())
        fun commentId(raw: String?) = parseId(raw, commentNotFound())
    }

    private fun cleanBody(raw: String, max: Int, field: String): String {
        val b = raw.trim()
        if (b.isEmpty()) throw bad("$field: must not be empty")
        if (b.length > max) throw bad("$field: at most $max characters")
        return b
    }

    private suspend fun page(viewer: UUID, rows: List<PostRow>, limit: Int): PostPage {
        val items = rows.take(limit)
        val next = if (rows.size > limit) items.last().let { PageCursor(it.cursorAt, it.id).encode() } else null
        return PostPage(enrich(viewer, items), next)
    }

    /** Autoryzacja: post widoczny dla widza, bez dociągania załączników (tanie; używane przed akcjami). */
    private suspend fun visibleRaw(viewer: UUID, id: UUID): PostRow = store.getPost(id, viewer) ?: throw postNotFound()

    /** Post widoczny dla widza, z załącznikami i oryginałem udostępnienia (do odpowiedzi API). */
    private suspend fun visible(viewer: UUID, id: UUID): PostRow = enrich(viewer, listOf(visibleRaw(viewer, id))).first()

    /**
     * Dokleja załączniki, liczniki udostępnień i oryginały udostępnionych postów (jeden poziom — udostępnienie zawsze wskazuje oryginał).
     * Oryginał jest pobierany z perspektywy widza, więc blokady, prywatność i anonimowość działają tak samo jak przy zwykłym poście.
     */
    private suspend fun enrich(viewer: UUID, rows: List<PostRow>, nested: Boolean = true): List<PostRow> {
        val ex = extras ?: return rows
        if (rows.isEmpty()) return rows
        val ids = rows.map { it.id }
        val attachments = ex.forPosts(ids)
        val shares = ex.publicShareCounts(ids)
        val originals = if (nested) ex.originalsOf(ids) else emptyMap()
        val originalRows: Map<UUID, PostRow> = if (originals.isEmpty()) emptyMap() else {
            val visibleOriginals = originals.values.distinct().mapNotNull { store.getPost(it, viewer) }
            enrich(viewer, visibleOriginals, nested = false).associateBy { it.id }
        }
        return rows.map { r ->
            val original = originals[r.id]
            r.copy(
                attachments = attachments[r.id].orEmpty(),
                shares = shares[r.id] ?: 0,
                isShare = original != null,
                sharedPost = original?.let { originalRows[it] },
                sharedUnavailable = original != null && originalRows[original] == null,
            )
        }
    }

    private fun cleanOptionalBody(raw: String, max: Int, field: String): String {
        val b = raw.trim()
        if (b.length > max) throw bad("$field: at most $max characters")
        return b
    }

    /** Sprawdza załączniki przed utworzeniem posta (właściciel, niedołączone, limity, anonimowość). */
    private suspend fun resolveAttachments(viewer: UUID, rawIds: List<String>, anonymous: Boolean): List<UUID> {
        if (rawIds.isEmpty()) return emptyList()
        val ex = extras ?: throw bad("attachments: not supported")
        if (rawIds.size > MAX_ATTACHMENTS) throw bad("attachmentIds: at most $MAX_ATTACHMENTS")
        val ids = rawIds.map { parseId(it, attachmentNotFound()) }
        if (ids.toSet().size != ids.size) throw bad("attachmentIds: duplicates")
        val rows = ids.map { id -> ex.getAttachment(id)?.takeIf { it.ownerId == viewer && it.postId == null } ?: throw attachmentNotFound() }
        if (rows.count { it.kind == "video" } > MAX_VIDEOS) throw bad("attachmentIds: at most $MAX_VIDEOS video")
        if (rows.count { it.kind == "document" } > MAX_DOCUMENTS) throw bad("attachmentIds: at most $MAX_DOCUMENTS documents")
        // Obrazy są ponownie kodowane (bez EXIF); filmów i dokumentów serwer nie czyści z metadanych, więc anonimowe posty ich nie przyjmują.
        if (anonymous && rows.any { it.kind != "image" }) throw bad("attachmentIds: anonymous posts accept images only")
        return ids
    }

    suspend fun create(
        viewer: UUID, rawBody: String, visibility: String, anonymous: Boolean,
        rawCommunityId: String? = null, rawChannelId: String? = null, attachmentIds: List<String> = emptyList(),
    ): PostRow {
        val body = if (attachmentIds.isEmpty()) cleanBody(rawBody, BODY_MAX, "body") else cleanOptionalBody(rawBody, BODY_MAX, "body")
        if (visibility !in VISIBILITIES) throw bad("visibility: public, followers, private or community")
        if (anonymous && visibility != "public") throw bad("anonymous: only public posts can be anonymous")
        var communityId: UUID? = null
        var channelId: UUID? = null
        if (visibility == "community") {
            if (rawCommunityId == null || rawChannelId == null) throw bad("communityId and channelId are required for community posts")
            communityId = parseId(rawCommunityId, communityNotFound())
            channelId = parseId(rawChannelId, channelNotFound())
            // Nie-członek (także społeczności ukrytej lub usuniętej) dostaje 404 — nie zdradzamy istnienia społeczności.
            if (store.communityRole(communityId, viewer) == null) throw communityNotFound()
            if (store.communityMuted(communityId, viewer)) throw communityMuted()
            if (!store.channelInCommunity(communityId, channelId)) throw channelNotFound()
        } else if (rawCommunityId != null || rawChannelId != null) {
            throw bad("communityId and channelId are only allowed for community posts")
        }
        val attachmentUuids = resolveAttachments(viewer, attachmentIds, anonymous)
        val id = store.createPost(viewer, body, visibility, anonymous, clock.instant(), communityId, channelId)
        if (attachmentUuids.isNotEmpty()) {
            // Post i dołączenie plików to dwie transakcje (osobne magazyny): przy każdym niepowodzeniu wycofujemy post,
            // żeby nie zostawić posta bez obiecanych plików (wyścig o załącznik albo błąd bazy w trakcie).
            val attached = try {
                extras!!.attach(viewer, id, attachmentUuids)
            } catch (e: Throwable) {
                runCatching { store.deletePost(id, clock.instant()) }
                throw e
            }
            if (!attached) {
                store.deletePost(id, clock.instant())
                throw attachmentNotFound()
            }
        }
        return visible(viewer, id)
    }

    /**
     * Udostępnienie = nowy post z opcjonalnym komentarzem, wskazujący oryginał. Dozwolone tylko dla postów publicznych (nie obserwujących,
     * prywatnych ani społeczności — inaczej udostępnienie ujawniałoby treść poza jej kręgiem). Udostępnienie udostępnienia wskazuje oryginał.
     * Udostępnienie jest zawsze jawne (nie anonimowe); oryginał anonimowy pozostaje anonimowy w odpowiedzi.
     */
    suspend fun share(viewer: UUID, id: UUID, rawComment: String, visibility: String): PostRow {
        val ex = extras ?: throw bad("sharing: not supported")
        if (visibility !in SHARE_VISIBILITIES) throw bad("visibility: public or followers")
        val comment = cleanOptionalBody(rawComment, BODY_MAX, "comment")
        var target = visibleRaw(viewer, id)
        ex.originalsOf(listOf(id))[id]?.let { target = store.getPost(it, viewer) ?: throw postNotFound() }
        if (target.visibility != "public") throw ApiException(HttpStatusCode.Forbidden, "not_shareable", "Only public posts can be shared.")
        val newId = store.createPost(viewer, comment, visibility, false, clock.instant(), null, null)
        try {
            ex.setShare(newId, target.id)
        } catch (e: Throwable) {
            runCatching { store.deletePost(newId, clock.instant()) } // bez powiązania z oryginałem to byłby pusty, zwykły post
            throw e
        }
        return visible(viewer, newId)
    }

    suspend fun get(viewer: UUID, id: UUID) = visible(viewer, id)

    suspend fun update(viewer: UUID, id: UUID, rawBody: String): PostRow {
        val post = visible(viewer, id)
        if (post.authorId != viewer) throw ApiException(HttpStatusCode.Forbidden, "forbidden", "Only the author can edit this post.")
        val mayBeEmpty = post.attachments.isNotEmpty() || post.isShare
        store.updatePostBody(id, if (mayBeEmpty) cleanOptionalBody(rawBody, BODY_MAX, "body") else cleanBody(rawBody, BODY_MAX, "body"), clock.instant())
        return visible(viewer, id)
    }

    suspend fun delete(viewer: UUID, id: UUID) {
        val post = visibleRaw(viewer, id)
        if (post.authorId != viewer && !isCommunityModerator(viewer, post)) {
            throw ApiException(HttpStatusCode.Forbidden, "forbidden", "Only the author can delete this post.")
        }
        store.deletePost(id, clock.instant())
    }

    /** Moderator+ społeczności posta może usuwać jego posty; rola jest sprawdzana w bazie przy każdym żądaniu. */
    private suspend fun isCommunityModerator(viewer: UUID, post: PostRow): Boolean {
        val cid = post.communityId ?: return false
        return store.communityRole(cid, viewer) in COMMUNITY_MODERATOR_ROLES
    }

    suspend fun communityPosts(viewer: UUID, rawCommunityId: String?, rawChannelId: String?, limit: Int?, cursor: String?): PostPage {
        val communityId = parseId(rawCommunityId, communityNotFound())
        if (store.communityRole(communityId, viewer) == null) throw communityNotFound()
        val channelId = rawChannelId?.let { parseId(it, channelNotFound()) }
        if (channelId != null && !store.channelInCommunity(communityId, channelId)) throw channelNotFound()
        val l = ProfileService.clampLimit(limit)
        return page(viewer, store.communityPosts(viewer, communityId, channelId, l + 1, PageCursor.decode(cursor)), l)
    }

    suspend fun followingFeed(viewer: UUID, limit: Int?, cursor: String?): PostPage {
        val l = ProfileService.clampLimit(limit)
        return page(viewer, store.followingFeed(viewer, l + 1, PageCursor.decode(cursor)), l)
    }

    suspend fun discover(viewer: UUID, limit: Int?, cursor: String?): PostPage {
        val l = ProfileService.clampLimit(limit)
        return page(viewer, store.discoverFeed(viewer, l + 1, PageCursor.decode(cursor)), l)
    }

    suspend fun userPosts(viewer: UUID, identifier: String, limit: Int?, cursor: String?): PostPage {
        val author = profiles.view(viewer, identifier).user // 404 dla zablokowanych/nieistniejących
        val l = ProfileService.clampLimit(limit)
        return page(viewer, store.userPosts(viewer, author.accountId, l + 1, PageCursor.decode(cursor)), l)
    }

    suspend fun search(viewer: UUID, rawQuery: String, limit: Int?, cursor: String?): PostPage {
        val q = rawQuery.trim()
        if (q.length < 3) throw bad("q: at least 3 characters")
        if (q.length > 60) throw bad("q: at most 60 characters")
        val l = ProfileService.clampLimit(limit)
        return page(viewer, store.searchPosts(viewer, q, l + 1, PageCursor.decode(cursor)), l)
    }

    suspend fun saved(viewer: UUID, limit: Int?, cursor: String?): PostPage {
        val l = ProfileService.clampLimit(limit)
        return page(viewer, store.savedPosts(viewer, l + 1, PageCursor.decode(cursor)), l)
    }

    suspend fun react(viewer: UUID, id: UUID, type: String): PostRow {
        if (type !in REACTIONS) throw bad("type: like, love, laugh, wow or sad")
        val post = visibleRaw(viewer, id)
        store.setReaction(id, viewer, type, clock.instant())
        // Autor posta (także anonimowego) dowiaduje się o reakcji; powiadomienie nie ujawnia nikomu innemu powiązania z kontem.
        notifier.notify(NotificationEvent(NotificationTypes.REACTION, recipient = post.authorId, actor = viewer, postId = id))
        return visible(viewer, id)
    }

    suspend fun unreact(viewer: UUID, id: UUID): PostRow {
        visibleRaw(viewer, id)
        store.removeReaction(id, viewer)
        return visible(viewer, id)
    }

    suspend fun save(viewer: UUID, id: UUID) { visibleRaw(viewer, id); store.savePost(id, viewer, clock.instant()) }
    suspend fun unsave(viewer: UUID, id: UUID) { visibleRaw(viewer, id); store.unsavePost(id, viewer) }

    // ---- komentarze ----

    suspend fun addComment(viewer: UUID, postId: UUID, parentId: UUID?, rawBody: String): CommentRow {
        val post = visibleRaw(viewer, postId)
        post.communityId?.let { if (store.communityMuted(it, viewer)) throw communityMuted() }
        val body = cleanBody(rawBody, COMMENT_MAX, "body")
        var parentAuthor: UUID? = null
        if (parentId != null) {
            val parent = store.getComment(parentId)
            if (parent == null || parent.postId != postId) throw commentNotFound()
            if (parent.parentId != null) throw ApiException(HttpStatusCode.BadRequest, "invalid_parent", "Replies can only be added to top-level comments.")
            parentAuthor = parent.authorId
        }
        val id = store.createComment(postId, parentId, viewer, body, clock.instant())
        val asAnonymousAuthor = post.anonymous && viewer == post.authorId
        if (parentAuthor != null) notifier.notify(NotificationEvent(NotificationTypes.REPLY, parentAuthor, viewer, postId = postId, commentId = id, actorAnonymous = asAnonymousAuthor))
        if (parentAuthor != post.authorId) notifier.notify(NotificationEvent(NotificationTypes.COMMENT, post.authorId, viewer, postId = postId, commentId = id))
        return store.getComment(id) ?: throw commentNotFound()
    }

    suspend fun comments(viewer: UUID, postId: UUID, parentId: UUID?, limit: Int?, cursor: String?): CommentPage {
        visibleRaw(viewer, postId)
        if (parentId != null) {
            val parent = store.getComment(parentId)
            if (parent == null || parent.postId != postId) throw commentNotFound()
        }
        val l = ProfileService.clampLimit(limit)
        val rows = store.listComments(postId, parentId, viewer, l + 1, PageCursor.decode(cursor))
        val items = rows.take(l)
        val next = if (rows.size > l) items.last().let { PageCursor(it.createdAt, it.id).encode() } else null
        return CommentPage(items, next)
    }

    suspend fun deleteComment(viewer: UUID, id: UUID) {
        val comment = store.getComment(id) ?: throw commentNotFound()
        visibleRaw(viewer, comment.postId)
        if (comment.authorId != viewer && comment.postAuthorId != viewer) {
            throw ApiException(HttpStatusCode.Forbidden, "forbidden", "You cannot delete this comment.")
        }
        store.deleteComment(id, clock.instant())
    }
}
