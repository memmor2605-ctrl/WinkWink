package app.winkwink.server.auth

import app.winkwink.server.media.MediaStorage
import app.winkwink.server.media.deleteQuietly
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID
import javax.sql.DataSource

/** Pliki należące do konta (do usunięcia razem z nim). Magazyn plików jest osobno od bazy, więc kaskada SQL ich nie obejmuje. */
interface AccountMedia {
    suspend fun keysOf(accountId: UUID): List<String>
    suspend fun deleteFiles(keys: Collection<String>)
}

class PostgresAccountMedia(private val dataSource: DataSource, private val storage: MediaStorage) : AccountMedia {
    override suspend fun keysOf(accountId: UUID): List<String> = withContext(Dispatchers.IO) {
        dataSource.connection.use { c ->
            c.prepareStatement(
                "SELECT object_key FROM message_attachments WHERE owner_id = ? " +
                    "UNION SELECT object_key FROM post_attachments WHERE owner_id = ? " +
                    "UNION SELECT avatar_object_key FROM profiles WHERE account_id = ? AND avatar_object_key IS NOT NULL " +
                    "UNION SELECT background_object_key FROM profiles WHERE account_id = ? AND background_object_key IS NOT NULL",
            ).use { ps ->
                repeat(4) { ps.setObject(it + 1, accountId) }
                ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.getString(1)) } }
            }
        }
    }

    override suspend fun deleteFiles(keys: Collection<String>) {
        keys.forEach { storage.deleteQuietly(it) } // błąd pojedynczego pliku nie przerywa reszty; resztki zbiera MediaReconciler
    }
}
