package app.winkwink.server.message

import app.winkwink.server.profile.PageCursor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.Timestamp
import java.time.Instant
import java.util.UUID
import javax.sql.DataSource

class PostgresMessageStore(private val dataSource: DataSource) : MessageStore {

    private suspend fun <T> tx(block: (Connection) -> T): T = withContext(Dispatchers.IO) {
        dataSource.connection.use { c ->
            c.autoCommit = false
            try { val r = block(c); c.commit(); r } catch (e: Throwable) { c.rollback(); throw e }
        }
    }

    private fun bind(ps: PreparedStatement, args: List<Any?>) = args.forEachIndexed { i, a ->
        if (a is Instant) ps.setTimestamp(i + 1, Timestamp.from(a)) else ps.setObject(i + 1, a)
    }

    private fun ResultSet.instant(col: String): Instant? = getTimestamp(col)?.toInstant()
    private fun ResultSet.uuid(col: String): UUID? = getObject(col, UUID::class.java)

    private companion object {
        const val MEMBERS_SQL =
            "SELECT m.conversation_id, m.role, m.joined_at, m.last_read_at, m.muted, m.archived, " +
                "p.account_id, p.nickname, p.winkwink_id, p.display_name, p.avatar_object_key, m.last_delivered_at, coalesce(s.read_receipts, true) AS share_read " +
                "FROM conversation_members m JOIN profiles p ON p.account_id = m.account_id " +
                "LEFT JOIN message_settings s ON s.account_id = m.account_id " +
                "WHERE m.conversation_id = ? AND m.left_at IS NULL"
        const val MESSAGE_SQL =
            "SELECT x.id, x.conversation_id, x.body, x.reply_to_id, x.created_at, x.edited_at, x.deleted_at, x.changed_at, " +
                "p.account_id, p.nickname, p.winkwink_id, p.display_name, p.avatar_object_key " +
                "FROM messages x JOIN profiles p ON p.account_id = x.sender_id"
        const val ATT_COLS = "id, owner_id, conversation_id, message_id, position, kind, mime, size_bytes, object_key, file_name, width, height, duration_ms, created_at, deleted_at"
        /** Znaki specjalne LIKE traktujemy dosłownie. */
        fun like(q: String) = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    }

    private fun ResultSet.attachmentRow() = MessageAttachmentRow(
        id = uuid("id")!!, ownerId = uuid("owner_id")!!, conversationId = uuid("conversation_id")!!, messageId = uuid("message_id"),
        position = getInt("position"), kind = getString("kind"), mime = getString("mime"), sizeBytes = getLong("size_bytes"),
        objectKey = getString("object_key"), fileName = getString("file_name"),
        width = getInt("width").takeUnless { wasNull() }, height = getInt("height").takeUnless { wasNull() },
        durationMs = getLong("duration_ms").takeUnless { wasNull() }, createdAt = instant("created_at")!!, deletedAt = instant("deleted_at"),
    )

    private fun ResultSet.member() = MemberRow(
        conversationId = uuid("conversation_id")!!,
        person = PersonRef(uuid("account_id")!!, getString("nickname"), getString("winkwink_id"), getString("display_name"), getString("avatar_object_key")),
        role = getString("role"), joinedAt = instant("joined_at")!!, lastReadAt = instant("last_read_at"),
        muted = getBoolean("muted"), archived = getBoolean("archived"), shareRead = getBoolean("share_read"),
        lastDeliveredAt = instant("last_delivered_at"),
    )

    private fun ResultSet.message(prefix: String = "") = MessageRow(
        id = uuid("${prefix}id")!!, conversationId = uuid("${prefix}conversation_id")!!,
        sender = PersonRef(uuid("${prefix}account_id")!!, getString("${prefix}nickname"), getString("${prefix}winkwink_id"), getString("${prefix}display_name"), getString("${prefix}avatar_object_key")),
        // Usunięta wiadomość nigdy nie oddaje treści.
        body = if (instant("${prefix}deleted_at") != null) null else getString("${prefix}body"),
        replyToId = uuid("${prefix}reply_to_id"), createdAt = instant("${prefix}created_at")!!,
        editedAt = instant("${prefix}edited_at"), deleted = instant("${prefix}deleted_at") != null,
        changedAt = try { instant("${prefix}changed_at") } catch (_: java.sql.SQLException) { null },
    )

    override suspend fun findDirect(directKey: String): UUID? = tx { c ->
        c.prepareStatement("SELECT id FROM conversations WHERE direct_key = ?").use { ps ->
            bind(ps, listOf(directKey)); ps.executeQuery().use { if (it.next()) it.uuid("id") else null }
        }
    }

    override suspend fun createConversation(kind: String, title: String?, createdBy: UUID, directKey: String?, members: List<Pair<UUID, String>>, now: Instant): UUID = tx { c ->
        val created = c.prepareStatement(
            "INSERT INTO conversations (kind, title, created_by, direct_key, created_at) VALUES (?, ?, ?, ?, ?) " +
                "ON CONFLICT (direct_key) DO NOTHING RETURNING id",
        ).use { ps -> bind(ps, listOf(kind, title, createdBy, directKey, now)); ps.executeQuery().use { if (it.next()) it.uuid("id") else null } }
        val id = created ?: c.prepareStatement("SELECT id FROM conversations WHERE direct_key = ?").use { ps ->
            bind(ps, listOf(directKey)); ps.executeQuery().use { it.next(); it.uuid("id")!! }
        }
        if (created != null) {
            c.prepareStatement("INSERT INTO conversation_members (conversation_id, account_id, role, joined_at) VALUES (?, ?, ?, ?)").use { ps ->
                members.forEach { (acc, role) -> bind(ps, listOf(id, acc, role, now)); ps.addBatch() }
                ps.executeBatch()
            }
        }
        id
    }

    override suspend fun conversation(id: UUID): ConversationRow? = tx { c ->
        c.prepareStatement("SELECT id, kind, title, created_by, created_at FROM conversations WHERE id = ?").use { ps ->
            bind(ps, listOf(id))
            ps.executeQuery().use { if (it.next()) ConversationRow(it.uuid("id")!!, it.getString("kind"), it.getString("title"), it.uuid("created_by")!!, it.instant("created_at")!!) else null }
        }
    }

    override suspend fun member(conversationId: UUID, account: UUID): MemberRow? = tx { c ->
        c.prepareStatement("$MEMBERS_SQL AND m.account_id = ?").use { ps ->
            bind(ps, listOf(conversationId, account)); ps.executeQuery().use { if (it.next()) it.member() else null }
        }
    }

    override suspend fun members(conversationId: UUID): List<MemberRow> = tx { c ->
        c.prepareStatement("$MEMBERS_SQL ORDER BY m.joined_at, m.account_id").use { ps ->
            bind(ps, listOf(conversationId)); ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.member()) } }
        }
    }

    override suspend fun addMember(conversationId: UUID, account: UUID, role: String, now: Instant) = tx { c ->
        // Powrót do grupy czyści left_at i zaczyna czytanie od nowa.
        c.prepareStatement(
            "INSERT INTO conversation_members (conversation_id, account_id, role, joined_at) VALUES (?, ?, ?, ?) " +
                "ON CONFLICT (conversation_id, account_id) DO UPDATE SET left_at = NULL, role = EXCLUDED.role, joined_at = EXCLUDED.joined_at, last_read_at = NULL",
        ).use { ps -> bind(ps, listOf(conversationId, account, role, now)); ps.executeUpdate() }
        Unit
    }

    override suspend fun removeMember(conversationId: UUID, account: UUID, now: Instant) = tx { c ->
        c.prepareStatement("UPDATE conversation_members SET left_at = ? WHERE conversation_id = ? AND account_id = ? AND left_at IS NULL").use { ps ->
            bind(ps, listOf(now, conversationId, account)); ps.executeUpdate()
        }
        Unit
    }

    override suspend fun insertMessage(conversationId: UUID, sender: UUID, body: String, replyTo: UUID?, now: Instant, attachmentIds: List<UUID>, clientId: UUID?): UUID = tx { c ->
        // ON CONFLICT na (sender_id, client_id): równoległe ponowienie tej samej wiadomości nie tworzy duplikatu —
        // zwracamy wiersz istniejący (załączniki dołączyła pierwsza transakcja, więc tu ich nie ruszamy).
        val inserted = c.prepareStatement(
            "INSERT INTO messages (conversation_id, sender_id, body, reply_to_id, created_at, changed_at, client_id) VALUES (?, ?, ?, ?, ?, ?, ?) " +
                "ON CONFLICT (sender_id, client_id) WHERE client_id IS NOT NULL DO NOTHING RETURNING id",
        ).use { ps ->
            bind(ps, listOf(conversationId, sender, body, replyTo, now, now, clientId))
            ps.executeQuery().use { if (it.next()) it.uuid("id") else null }
        }
        if (inserted == null) {
            return@tx c.prepareStatement("SELECT id FROM messages WHERE sender_id = ? AND client_id = ?").use { ps ->
                bind(ps, listOf(sender, clientId)); ps.executeQuery().use { it.next(); it.uuid("id")!! }
            }
        }
        // Dołączenie w tej samej transakcji: albo wiadomość z kompletem załączników, albo nic (wyjątek = rollback).
        attachmentIds.forEachIndexed { index, attachmentId ->
            val n = c.prepareStatement(
                "UPDATE message_attachments SET message_id = ?, position = ? WHERE id = ? AND owner_id = ? AND conversation_id = ? " +
                    "AND message_id IS NULL AND deleted_at IS NULL",
            ).use { ps -> bind(ps, listOf(inserted, index, attachmentId, sender, conversationId)); ps.executeUpdate() }
            if (n != 1) throw AttachmentsUnavailableException()
        }
        inserted
    }

    override suspend fun findByClientId(sender: UUID, clientId: UUID): MessageRow? = tx { c ->
        c.prepareStatement("$MESSAGE_SQL WHERE x.sender_id = ? AND x.client_id = ?").use { ps ->
            bind(ps, listOf(sender, clientId)); ps.executeQuery().use { if (it.next()) it.message() else null }
        }
    }

    override suspend fun changes(conversationId: UUID, since: Instant, after: PageCursor?, limit: Int): List<MessageRow> = tx { c ->
        val args = mutableListOf<Any?>(conversationId)
        val cond = if (after != null) { args += after.at; args += after.id; "(x.changed_at, x.id) > (?, ?)" } else { args += since; "x.changed_at > ?" }
        args += limit
        c.prepareStatement("$MESSAGE_SQL WHERE x.conversation_id = ? AND $cond ORDER BY x.changed_at, x.id LIMIT ?").use { ps ->
            bind(ps, args); ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.message()) } }
        }
    }

    override suspend fun message(id: UUID): MessageRow? = tx { c ->
        c.prepareStatement("$MESSAGE_SQL WHERE x.id = ?").use { ps -> bind(ps, listOf(id)); ps.executeQuery().use { if (it.next()) it.message() else null } }
    }

    override suspend fun messages(conversationId: UUID, limit: Int, after: PageCursor?): List<MessageRow> = tx { c ->
        val args = mutableListOf<Any?>(conversationId)
        val extra = if (after != null) { args += after.at; args += after.id; " AND (x.created_at, x.id) < (?, ?)" } else ""
        args += limit
        c.prepareStatement("$MESSAGE_SQL WHERE x.conversation_id = ?$extra ORDER BY x.created_at DESC, x.id DESC LIMIT ?").use { ps ->
            bind(ps, args); ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.message()) } }
        }
    }

    override suspend fun editMessage(id: UUID, body: String, now: Instant) = tx { c ->
        c.prepareStatement("UPDATE messages SET body = ?, edited_at = ?, changed_at = ? WHERE id = ? AND deleted_at IS NULL").use { ps -> bind(ps, listOf(body, now, now, id)); ps.executeUpdate() }
        Unit
    }

    override suspend fun deleteMessage(id: UUID, now: Instant): List<MessageAttachmentRow> = tx { c ->
        c.prepareStatement("UPDATE messages SET body = '', deleted_at = ?, changed_at = ? WHERE id = ? AND deleted_at IS NULL").use { ps -> bind(ps, listOf(now, now, id)); ps.executeUpdate() }
        c.prepareStatement("DELETE FROM message_reactions WHERE message_id = ?").use { ps -> bind(ps, listOf(id)); ps.executeUpdate() }
        // Załączniki znikają natychmiast z widoku (deleted_at), a plik jest kasowany przez serwis; sprzątanie okresowe ponawia błędy.
        c.prepareStatement("UPDATE message_attachments SET deleted_at = coalesce(deleted_at, ?) WHERE message_id = ? RETURNING $ATT_COLS").use { ps ->
            bind(ps, listOf(now, id)); ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.attachmentRow()) } }
        }
    }

    override suspend fun markRead(conversationId: UUID, account: UUID, now: Instant) = tx { c ->
        c.prepareStatement("UPDATE conversation_members SET last_read_at = ?, last_delivered_at = greatest(coalesce(last_delivered_at, ?), ?) WHERE conversation_id = ? AND account_id = ? AND left_at IS NULL").use { ps ->
            bind(ps, listOf(now, now, now, conversationId, account)); ps.executeUpdate()
        }
        Unit
    }

    override suspend fun setFlags(conversationId: UUID, account: UUID, muted: Boolean?, archived: Boolean?) = tx { c ->
        val sets = mutableListOf<String>(); val args = mutableListOf<Any?>()
        if (muted != null) { sets += "muted = ?"; args += muted }
        if (archived != null) { sets += "archived = ?"; args += archived }
        if (sets.isNotEmpty()) {
            args += conversationId; args += account
            c.prepareStatement("UPDATE conversation_members SET ${sets.joinToString()} WHERE conversation_id = ? AND account_id = ? AND left_at IS NULL").use { ps -> bind(ps, args); ps.executeUpdate() }
        }
        Unit
    }

    override suspend fun summaries(viewer: UUID, archived: Boolean?, query: String?, conversationId: UUID?, limit: Int, after: PageCursor?): List<SummaryRow> = tx { c ->
        // Kolejność placeholderów = kolejność wystąpienia w tekście SQL.
        val args = mutableListOf<Any?>(viewer, viewer)
        val filters = StringBuilder()
        if (archived != null) { filters.append(" AND m.archived = ?"); args += archived }
        if (conversationId != null) { filters.append(" AND c.id = ?"); args += conversationId }
        if (query != null) {
            filters.append(" AND (c.title ILIKE ? OR op.nickname ILIKE ? OR op.display_name ILIKE ?)")
            repeat(3) { args += like(query) }
        }
        val outer = StringBuilder()
        if (after != null) { outer.append(" WHERE (s.activity, s.id) < (?, ?)"); args += after.at; args += after.id }
        args += limit
        val sql = "SELECT * FROM (" +
            "SELECT c.id, c.kind, c.title, c.created_by, c.created_at, m.role, m.last_read_at, m.muted, m.archived, " +
            "(SELECT count(*) FROM conversation_members cm WHERE cm.conversation_id = c.id AND cm.left_at IS NULL) AS member_count, " +
            "coalesce(lm.created_at, c.created_at) AS activity, " +
            "(SELECT count(*) FROM messages u WHERE u.conversation_id = c.id AND u.deleted_at IS NULL AND u.sender_id <> ? " +
            "AND (m.last_read_at IS NULL OR u.created_at > m.last_read_at)) AS unread, " +
            "op.account_id AS o_account_id, op.nickname AS o_nickname, op.winkwink_id AS o_winkwink_id, op.display_name AS o_display_name, op.avatar_object_key AS o_avatar_object_key, " +
            "lm.id AS l_id, lm.conversation_id AS l_conversation_id, lm.body AS l_body, lm.reply_to_id AS l_reply_to_id, " +
            "lm.created_at AS l_created_at, lm.edited_at AS l_edited_at, lm.deleted_at AS l_deleted_at, " +
            "lp.account_id AS l_account_id, lp.nickname AS l_nickname, lp.winkwink_id AS l_winkwink_id, lp.display_name AS l_display_name, lp.avatar_object_key AS l_avatar_object_key " +
            "FROM conversation_members m JOIN conversations c ON c.id = m.conversation_id " +
            "LEFT JOIN LATERAL (SELECT x.* FROM messages x WHERE x.conversation_id = c.id ORDER BY x.created_at DESC, x.id DESC LIMIT 1) lm ON true " +
            "LEFT JOIN LATERAL (SELECT cm.account_id FROM conversation_members cm WHERE c.kind = 'direct' AND cm.conversation_id = c.id AND cm.account_id <> m.account_id LIMIT 1) oth ON true " +
            "LEFT JOIN profiles op ON op.account_id = oth.account_id " +
            "LEFT JOIN profiles lp ON lp.account_id = lm.sender_id " +
            "WHERE m.account_id = ? AND m.left_at IS NULL$filters" +
            ") s$outer ORDER BY s.activity DESC, s.id DESC LIMIT ?"
        c.prepareStatement(sql).use { ps ->
            bind(ps, args)
            ps.executeQuery().use { rs ->
                buildList {
                    while (rs.next()) {
                        val last = if (rs.uuid("l_id") != null) rs.message("l_") else null
                        val peer = rs.uuid("o_account_id")?.let { PersonRef(it, rs.getString("o_nickname"), rs.getString("o_winkwink_id"), rs.getString("o_display_name"), rs.getString("o_avatar_object_key")) }
                        add(
                            SummaryRow(
                                ConversationRow(rs.uuid("id")!!, rs.getString("kind"), rs.getString("title"), rs.uuid("created_by")!!, rs.instant("created_at")!!),
                                rs.getString("role"), rs.getBoolean("muted"), rs.getBoolean("archived"), rs.getInt("member_count"),
                                peer, last, rs.getInt("unread"), rs.instant("activity")!!,
                            ),
                        )
                    }
                }
            }
        }
    }

    override suspend fun setReaction(messageId: UUID, account: UUID, kind: String?, now: Instant) = tx { c ->
        val changed = if (kind == null) {
            c.prepareStatement("DELETE FROM message_reactions WHERE message_id = ? AND account_id = ?").use { ps -> bind(ps, listOf(messageId, account)); ps.executeUpdate() }
        } else {
            c.prepareStatement(
                "INSERT INTO message_reactions (message_id, account_id, kind, created_at) VALUES (?, ?, ?, ?) " +
                    "ON CONFLICT (message_id, account_id) DO UPDATE SET kind = EXCLUDED.kind, created_at = EXCLUDED.created_at " +
                    "WHERE message_reactions.kind <> EXCLUDED.kind",
            ).use { ps -> bind(ps, listOf(messageId, account, kind, now)); ps.executeUpdate() }
        }
        // Zmiana reakcji jest zmianą wiadomości (synchronizacja różnicowa); powtórzone ustawienie tej samej reakcji niczego nie zmienia.
        if (changed > 0) c.prepareStatement("UPDATE messages SET changed_at = ? WHERE id = ?").use { ps -> bind(ps, listOf(now, messageId)); ps.executeUpdate() }
        Unit
    }

    override suspend fun reactions(messageIds: List<UUID>): List<ReactionRow> = if (messageIds.isEmpty()) emptyList() else tx { c ->
        val marks = messageIds.joinToString(",") { "?" }
        c.prepareStatement("SELECT message_id, account_id, kind FROM message_reactions WHERE message_id IN ($marks)").use { ps ->
            bind(ps, messageIds)
            ps.executeQuery().use { rs -> buildList { while (rs.next()) add(ReactionRow(rs.uuid("message_id")!!, rs.uuid("account_id")!!, rs.getString("kind"))) } }
        }
    }

    override suspend fun markDelivered(account: UUID, conversationIds: List<UUID>, now: Instant): List<UUID> {
        if (conversationIds.isEmpty()) return emptyList()
        return tx { c ->
            val marks = conversationIds.joinToString(",") { "?" }
            c.prepareStatement(
                "UPDATE conversation_members cm SET last_delivered_at = ? " +
                    "WHERE cm.account_id = ? AND cm.left_at IS NULL AND cm.conversation_id IN ($marks) " +
                    "AND EXISTS (SELECT 1 FROM messages x WHERE x.conversation_id = cm.conversation_id AND x.sender_id <> cm.account_id " +
                    "AND x.created_at > coalesce(cm.last_delivered_at, '-infinity'::timestamptz)) " +
                    "RETURNING cm.conversation_id",
            ).use { ps ->
                bind(ps, listOf<Any?>(now, account) + conversationIds)
                ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.uuid("conversation_id")!!) } }
            }
        }
    }

    override suspend fun setRole(conversationId: UUID, account: UUID, role: String) = tx { c ->
        c.prepareStatement("UPDATE conversation_members SET role = ? WHERE conversation_id = ? AND account_id = ? AND left_at IS NULL").use { ps ->
            bind(ps, listOf(role, conversationId, account)); ps.executeUpdate()
        }
        Unit
    }

    override suspend fun readReceipts(account: UUID): Boolean = tx { c ->
        c.prepareStatement("SELECT read_receipts FROM message_settings WHERE account_id = ?").use { ps ->
            bind(ps, listOf(account)); ps.executeQuery().use { if (it.next()) it.getBoolean(1) else true }
        }
    }

    override suspend fun setReadReceipts(account: UUID, enabled: Boolean) = tx { c ->
        c.prepareStatement(
            "INSERT INTO message_settings (account_id, read_receipts) VALUES (?, ?) ON CONFLICT (account_id) DO UPDATE SET read_receipts = EXCLUDED.read_receipts",
        ).use { ps -> bind(ps, listOf(account, enabled)); ps.executeUpdate() }
        Unit
    }

    // ---- załączniki ----

    override suspend fun createAttachment(row: MessageAttachmentRow) = tx { c ->
        c.prepareStatement("INSERT INTO message_attachments ($ATT_COLS) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").use { ps ->
            bind(ps, listOf(row.id, row.ownerId, row.conversationId, row.messageId, row.position, row.kind, row.mime, row.sizeBytes, row.objectKey, row.fileName, row.width, row.height, row.durationMs, row.createdAt, row.deletedAt))
            ps.executeUpdate()
        }
        Unit
    }

    override suspend fun attachment(id: UUID): MessageAttachmentRow? = tx { c ->
        c.prepareStatement("SELECT $ATT_COLS FROM message_attachments WHERE id = ?").use { ps ->
            bind(ps, listOf(id)); ps.executeQuery().use { if (it.next()) it.attachmentRow() else null }
        }
    }

    override suspend fun pendingAttachmentCount(owner: UUID): Int = tx { c ->
        c.prepareStatement("SELECT count(*) FROM message_attachments WHERE owner_id = ? AND message_id IS NULL AND deleted_at IS NULL").use { ps ->
            bind(ps, listOf(owner)); ps.executeQuery().use { it.next(); it.getInt(1) }
        }
    }

    override suspend fun tombstonePending(owner: UUID, id: UUID, now: Instant): MessageAttachmentRow? = tx { c ->
        c.prepareStatement("UPDATE message_attachments SET deleted_at = ? WHERE id = ? AND owner_id = ? AND message_id IS NULL AND deleted_at IS NULL RETURNING $ATT_COLS").use { ps ->
            bind(ps, listOf(now, id, owner)); ps.executeQuery().use { if (it.next()) it.attachmentRow() else null }
        }
    }

    override suspend fun attachmentsFor(messageIds: Collection<UUID>): Map<UUID, List<MessageAttachmentRow>> {
        if (messageIds.isEmpty()) return emptyMap()
        return tx { c ->
            val marks = messageIds.joinToString(",") { "?" }
            c.prepareStatement("SELECT $ATT_COLS FROM message_attachments WHERE message_id IN ($marks) AND deleted_at IS NULL ORDER BY position, created_at, id").use { ps ->
                bind(ps, messageIds.toList())
                ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.attachmentRow()) } }
            }.groupBy { it.messageId!! }
        }
    }

    override suspend fun purgeCandidates(pendingBefore: Instant, limit: Int): List<MessageAttachmentRow> = tx { c ->
        c.prepareStatement(
            "SELECT $ATT_COLS FROM message_attachments WHERE deleted_at IS NOT NULL OR (message_id IS NULL AND created_at < ?) ORDER BY created_at LIMIT ?",
        ).use { ps ->
            bind(ps, listOf(pendingBefore, limit)); ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.attachmentRow()) } }
        }
    }

    override suspend fun removeAttachmentRows(ids: Collection<UUID>) {
        if (ids.isEmpty()) return
        tx { c ->
            val marks = ids.joinToString(",") { "?" }
            c.prepareStatement("DELETE FROM message_attachments WHERE id IN ($marks)").use { ps -> bind(ps, ids.toList()); ps.executeUpdate() }
        }
    }
}
