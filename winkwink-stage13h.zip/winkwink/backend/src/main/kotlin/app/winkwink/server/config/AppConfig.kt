package app.winkwink.server.config

enum class Environment {
    DEVELOPMENT, STAGING, PRODUCTION;

    companion object {
        fun parse(raw: String?): Environment = when (raw?.trim()?.lowercase()) {
            null, "", "development", "dev" -> DEVELOPMENT
            "staging" -> STAGING
            "production", "prod" -> PRODUCTION
            else -> throw ConfigException("WINKWINK_ENV must be development, staging or production (got '$raw')")
        }
    }
}

class ConfigException(message: String) : IllegalStateException(message)

data class TlsConfig(
    val keyStorePath: String,
    val keyStorePassword: String,
    val keyAlias: String,
    val keyPassword: String,
) {
    override fun toString() = "TlsConfig(keyStorePath=$keyStorePath, keyAlias=$keyAlias, secrets=***)"
}

data class DatabaseConfig(
    val jdbcUrl: String,
    val user: String,
    val password: String,
    val maxPoolSize: Int,
    val migrateOnStart: Boolean,
) {
    override fun toString() = "DatabaseConfig(jdbcUrl=$jdbcUrl, user=$user, password=***)"
}

data class AuthConfig(
    val jwtSecret: String,
    val issuer: String = "winkwink",
    val accessTtlSeconds: Long = 900,
    val refreshTtlDays: Long = 30,
    val resetTtlMinutes: Long = 60,
    val lockoutWindowMinutes: Long = 15,
    val maxFailuresPerAccount: Int = 5,
    val maxFailuresPerIp: Int = 30,
    val authRateLimitPerMinute: Int = 20,
) {
    init {
        require(jwtSecret.length >= 32) { "JWT secret must have at least 32 characters" }
    }

    override fun toString() = "AuthConfig(issuer=$issuer, accessTtlSeconds=$accessTtlSeconds, secret=***)"
}

/**
 * Cała konfiguracja pochodzi ze zmiennych środowiskowych. Aplikacja nie wystartuje,
 * jeśli nie da się zagwarantować, że ruch klienta jest szyfrowany (HTTPS).
 */
data class AppConfig(
    val environment: Environment,
    val host: String,
    val port: Int,
    val tls: TlsConfig?,
    val trustProxy: Boolean,
    val database: DatabaseConfig,
    val rateLimitPerMinute: Int,
    val auth: AuthConfig,
    /** Katalog magazynu plików (avatary, tła, w kolejnych etapach media postów i wiadomości). Musi być trwałym wolumenem. */
    val mediaDir: String = "./data/media",
    /** Plik JSON konta serwisowego Firebase (FCM HTTP v1). Brak = powiadomienia push wyłączone (reszta działa). Nigdy w repozytorium. */
    val fcmCredentialsFile: String? = null,
) {
    companion object {
        fun fromEnvironment(env: Map<String, String> = System.getenv()): AppConfig {
            fun opt(name: String): String? = env[name]?.trim()?.takeIf { it.isNotEmpty() }
            fun req(name: String): String =
                opt(name) ?: throw ConfigException("Missing required environment variable $name")

            fun int(name: String, default: Int, range: IntRange): Int {
                val raw = opt(name) ?: return default
                val value = raw.toIntOrNull()
                if (value == null || value !in range) {
                    throw ConfigException("$name must be an integer in $range (got '$raw')")
                }
                return value
            }

            fun bool(name: String, default: Boolean): Boolean = when (opt(name)?.lowercase()) {
                null -> default
                "true" -> true
                "false" -> false
                else -> throw ConfigException("$name must be 'true' or 'false'")
            }

            val environment = Environment.parse(opt("WINKWINK_ENV"))
            val trustProxy = bool("WINKWINK_TRUST_PROXY", false)

            val tls = opt("WINKWINK_TLS_KEYSTORE_PATH")?.let { path ->
                val password = req("WINKWINK_TLS_KEYSTORE_PASSWORD")
                TlsConfig(
                    keyStorePath = path,
                    keyStorePassword = password,
                    keyAlias = opt("WINKWINK_TLS_KEY_ALIAS") ?: "winkwink",
                    keyPassword = opt("WINKWINK_TLS_KEY_PASSWORD") ?: password,
                )
            }

            if (tls == null && !trustProxy) {
                throw ConfigException(
                    "HTTPS is mandatory: set WINKWINK_TLS_KEYSTORE_PATH (+ password) " +
                        "or WINKWINK_TRUST_PROXY=true behind a TLS-terminating reverse proxy."
                )
            }
            if (tls != null && trustProxy) {
                throw ConfigException("Choose either in-process TLS or WINKWINK_TRUST_PROXY, not both.")
            }

            val jdbcUrl = req("WINKWINK_DB_URL")
            if (!jdbcUrl.startsWith("jdbc:postgresql://")) {
                throw ConfigException("WINKWINK_DB_URL must start with jdbc:postgresql://")
            }
            if (environment == Environment.PRODUCTION &&
                !Regex("sslmode=(require|verify-ca|verify-full)").containsMatchIn(jdbcUrl)
            ) {
                throw ConfigException("In production WINKWINK_DB_URL must set sslmode=require|verify-ca|verify-full")
            }

            return AppConfig(
                environment = environment,
                host = opt("WINKWINK_HOST") ?: "0.0.0.0",
                port = int("WINKWINK_PORT", if (tls != null) 8443 else 8080, 1..65535),
                tls = tls,
                trustProxy = trustProxy,
                database = DatabaseConfig(
                    jdbcUrl = jdbcUrl,
                    user = req("WINKWINK_DB_USER"),
                    password = req("WINKWINK_DB_PASSWORD"),
                    maxPoolSize = int("WINKWINK_DB_POOL_SIZE", 10, 1..100),
                    migrateOnStart = bool("WINKWINK_DB_MIGRATE_ON_START", true),
                ),
                rateLimitPerMinute = int("WINKWINK_RATE_LIMIT_PER_MINUTE", 120, 1..100_000),
                mediaDir = opt("WINKWINK_MEDIA_DIR") ?: "./data/media",
                fcmCredentialsFile = opt("WINKWINK_FCM_CREDENTIALS_FILE"),
                auth = AuthConfig(
                    jwtSecret = req("WINKWINK_JWT_SECRET").also {
                        if (it.length < 32) throw ConfigException("WINKWINK_JWT_SECRET must have at least 32 characters")
                    },
                    accessTtlSeconds = int("WINKWINK_ACCESS_TTL_SECONDS", 900, 60..3600).toLong(),
                    refreshTtlDays = int("WINKWINK_REFRESH_TTL_DAYS", 30, 1..90).toLong(),
                    authRateLimitPerMinute = int("WINKWINK_AUTH_RATE_LIMIT_PER_MINUTE", 20, 1..10_000),
                ),
            )
        }
    }
}
