package app.winkwink.server.api

import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.plugins.callid.callId
import io.ktor.server.response.respond
import kotlinx.serialization.Serializable

object ApiPaths {
    const val V1 = "/api/v1"
}

@Serializable
data class ApiError(val error: ApiErrorBody)

@Serializable
data class ApiErrorBody(
    val code: String,
    val message: String,
    val requestId: String? = null,
    val details: List<String>? = null,
)

suspend fun ApplicationCall.respondError(
    status: HttpStatusCode,
    code: String,
    message: String,
    details: List<String>? = null,
) = respond(status, ApiError(ApiErrorBody(code, message, callId, details)))

/** Błąd biznesowy mapowany na odpowiedź HTTP przez StatusPages. */
class ApiException(
    val status: HttpStatusCode,
    val code: String,
    override val message: String,
    val details: List<String>? = null,
    val retryAfterSeconds: Long? = null,
) : RuntimeException(message)
