package app.winkwink.server.message

import app.winkwink.server.api.ApiException
import app.winkwink.server.media.MediaStorage
import app.winkwink.server.media.MessageMedia
import app.winkwink.server.profile.PageCursor
import app.winkwink.server.profile.ProfileService
import app.winkwink.server.profile.ProfileStore
import app.winkwink.server.realtime.MessageEvents
import app.winkwink.server.realtime.RealtimeEvent
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.CancellationException
import java.time.Clock
import java.util.UUID

data class SummaryPage(val items: List<SummaryRow>, val nextCursor: String?)
/** Zagregowana reakcja: bez informacji, kto zareagował (poza własną reakcją widza). */
data class ReactionSummary(val kind: String, val count: Int, val mine: Boolean)

/**
 * [status] tylko dla własnych wiadomości: "sent" | "delivered" | "read".
 * "delivered" = urządzenie odbiorcy pobrało wiadomość (REST lub, po Etapie E, WSS); to NIE znaczy, że ktoś ją zobaczył.
 * Oba statusy ponad "sent" są widoczne tylko, gdy zarówno widz, jak i każdy odbiorca udostępniają potwierdzenia.
 */
data class MessageView(
    val row: MessageRow, val mine: Boolean, val status: String?, val reactions: List<ReactionSummary> = emptyList(),
    val attachments: List<MessageAttachmentRow> = emptyList(),
)
data class MessagePage(val items: List<MessageView>, val nextCursor: String?)
/** Strona zmian (synchronizacja różnicowa). [serverTime] pochodzi z zegara serwera, żeby klient nie polegał na swoim. */
data class MessageChangesPage(val items: List<MessageView>, val nextCursor: String?, val serverTime: java.time.Instant)

/**
 * Rozmowy i wiadomości. Cała autoryzacja jest tutaj (backend), klient tylko ją odzwierciedla.
 * Nie-członek nie odróżnia rozmowy nieistniejącej od cudzej (404). Treść NIE jest szyfrowana end-to-end.
 */
class MessageService(
    private val store: MessageStore,
    private val profiles: ProfileStore,
    private val clock: Clock = Clock.systemUTC(),
    private val events: MessageEvents = MessageEvents.None,
    /** Magazyn plików do sprzątania po usunięciu wiadomości; `null` = tylko metadane (testy bez plików). */
    private val media: MediaStorage? = null,
    private val push: app.winkwink.server.push.PushGateway = app.winkwink.server.push.PushGateway.None,
) {
    companion object {
        const val BODY_MAX = 4000
        const val TITLE_MAX = 80
        const val GROUP_MAX = 50
        val REACTION_KINDS = setOf("like", "love", "laugh", "wow", "sad", "thanks")
        const val MAX_ATTACHMENTS = MessageMedia.MAX_IMAGES
        private fun rank(role: String?) = when (role) { "owner" -> 3; "admin" -> 2; "member" -> 1; else -> 0 }
    }

    private fun bad(msg: String) = ApiException(HttpStatusCode.BadRequest, "validation_failed", msg)
    private fun convNotFound() = ApiException(HttpStatusCode.NotFound, "conversation_not_found", "Conversation not found.")
    private fun userNotFound() = ApiException(HttpStatusCode.NotFound, "user_not_found", "User not found.")
    private fun unavailable() = ApiException(HttpStatusCode.Forbidden, "user_unavailable", "You can't message this user.")
    private fun forbidden() = ApiException(HttpStatusCode.Forbidden, "forbidden", "Not allowed.")

    private fun clean(raw: String, max: Int, field: String): String {
        val t = raw.trim()
        if (t.isEmpty() || t.length > max || t.any { it == '\u0000' }) throw bad("$field: 1-$max characters")
        return t
    }

    /** Zdarzenia czasu rzeczywistego są wskazówkami — ich błąd nigdy nie psuje właściwej operacji (REST jest źródłem prawdy). */
    private suspend fun emit(recipients: Collection<UUID>, type: String, conversationId: UUID?, messageId: UUID? = null, actor: PersonRef? = null) {
        try {
            events.publish(recipients, RealtimeEvent(type, conversationId?.toString(), messageId?.toString(), actor?.toDto()))
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        }
    }

    private suspend fun emitToMembers(conversationId: UUID, type: String, messageId: UUID? = null, actor: PersonRef? = null) =
        emit(store.members(conversationId).map { it.person.accountId }, type, conversationId, messageId, actor)

    /** Po zmianie stanu dostarczenia nadawcy muszą się o tym dowiedzieć (status „dostarczono”). */
    private suspend fun markDeliveredAndNotify(viewer: UUID, conversationIds: List<UUID>) {
        store.markDelivered(viewer, conversationIds, clock.instant()).forEach { emitToMembers(it, "receipt") }
    }

    /** Pusta treść jest dozwolona tylko wtedy, gdy wiadomość ma załącznik. */
    private fun cleanOptional(raw: String, max: Int, field: String): String {
        val t = raw.trim()
        if (t.length > max || t.any { it == '\u0000' }) throw bad("$field: at most $max characters")
        return t
    }

    private fun attachmentsUnavailable() =
        ApiException(HttpStatusCode.Conflict, "attachments_unavailable", "An attachment is missing, already used or belongs to another conversation.")

    /** Usuwa pliki z magazynu i dopiero potem wiersze; to, co się nie uda, zostaje do okresowego sprzątania. */
    private suspend fun purgeFiles(rows: List<MessageAttachmentRow>) {
        if (rows.isEmpty()) return
        try {
            val storage = media ?: return
            rows.forEach { storage.delete(it.objectKey) }
            store.removeAttachmentRows(rows.map { it.id })
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        }
    }

    private suspend fun target(identifier: String) = profiles.findByIdentifier(identifier.trim()) ?: throw userNotFound()

    private suspend fun requireMember(viewer: UUID, conversationId: UUID): MemberRow =
        store.member(conversationId, viewer) ?: throw convNotFound()

    private suspend fun withLastAttachments(rows: List<SummaryRow>): List<SummaryRow> {
        val ids = rows.mapNotNull { it.last }.filter { !it.deleted }.map { it.id }
        if (ids.isEmpty()) return rows
        val atts = store.attachmentsFor(ids)
        return rows.map { r -> r.last?.let { l -> r.copy(lastAttachments = atts[l.id].orEmpty()) } ?: r }
    }

    private suspend fun summary(viewer: UUID, id: UUID): SummaryRow =
        withLastAttachments(store.summaries(viewer, null, null, id, 1, null)).firstOrNull() ?: throw convNotFound()

    // ---- tworzenie rozmów ----

    suspend fun startDirect(viewer: UUID, identifier: String): SummaryRow {
        val other = target(identifier)
        if (other.accountId == viewer) throw bad("user: can't message yourself")
        if (profiles.isBlockedEitherWay(viewer, other.accountId)) throw unavailable()
        val key = listOf(viewer, other.accountId).map { it.toString() }.sorted().joinToString("|")
        val existing = store.findDirect(key)
        val id = existing ?: store.createConversation("direct", null, viewer, key, listOf(viewer to "member", other.accountId to "member"), clock.instant())
        if (existing == null) emit(listOf(viewer, other.accountId), "conversation.new", id)
        return summary(viewer, id)
    }

    suspend fun createGroup(viewer: UUID, rawTitle: String, identifiers: List<String>): SummaryRow {
        val title = clean(rawTitle, TITLE_MAX, "title")
        val others = identifiers.map { target(it) }.distinctBy { it.accountId }.filter { it.accountId != viewer }
        if (others.isEmpty()) throw bad("members: at least one other user")
        if (others.size + 1 > GROUP_MAX) throw bad("members: at most ${GROUP_MAX - 1}")
        if (others.any { profiles.isBlockedEitherWay(viewer, it.accountId) }) throw unavailable()
        val id = store.createConversation("group", title, viewer, null, listOf(viewer to "owner") + others.map { it.accountId to "member" }, clock.instant())
        emit(listOf(viewer) + others.map { it.accountId }, "conversation.new", id)
        return summary(viewer, id)
    }

    // ---- odczyt rozmów ----

    suspend fun list(viewer: UUID, archived: Boolean, query: String?, limit: Int?, cursor: String?): SummaryPage {
        val l = ProfileService.clampLimit(limit)
        val q = query?.trim()?.takeIf { it.isNotEmpty() }?.take(50)
        val rows = withLastAttachments(store.summaries(viewer, archived, q, null, l + 1, PageCursor.decode(cursor)))
        val items = rows.take(l)
        markDeliveredAndNotify(viewer, items.map { it.conversation.id })
        return SummaryPage(items, if (rows.size > l) items.last().let { PageCursor(it.activity, it.conversation.id).encode() } else null)
    }

    suspend fun get(viewer: UUID, id: UUID): SummaryRow = summary(viewer, id)

    suspend fun members(viewer: UUID, id: UUID): List<MemberRow> { requireMember(viewer, id); return store.members(id) }

    suspend fun setFlags(viewer: UUID, id: UUID, muted: Boolean?, archived: Boolean?): SummaryRow {
        requireMember(viewer, id)
        if (muted != null || archived != null) {
            store.setFlags(id, viewer, muted, archived)
            emit(listOf(viewer), "conversation.updated", id) // synchronizacja własnych urządzeń
        }
        return summary(viewer, id)
    }

    suspend fun markRead(viewer: UUID, id: UUID) {
        requireMember(viewer, id)
        store.markRead(id, viewer, clock.instant())
        push.dismiss(viewer, null, id.toString(), null) // przeczytane na jednym urządzeniu → znika na pozostałych
        emitToMembers(id, "receipt")
    }

    // ---- wiadomości ----

    private suspend fun views(viewer: UUID, conversationId: UUID, rows: List<MessageRow>): List<MessageView> {
        val sees = store.readReceipts(viewer)
        val others = if (sees) store.members(conversationId).filter { it.person.accountId != viewer } else emptyList()
        val liveIds = rows.filter { !it.deleted }.map { it.id }
        val reactions = store.reactions(liveIds).groupBy { it.messageId }
        val attachments = store.attachmentsFor(liveIds)
        return rows.map { r ->
            val mine = r.sender.accountId == viewer
            val status = if (!mine || r.deleted) null else when {
                others.isNotEmpty() && others.all { it.shareRead && it.lastReadAt != null && !it.lastReadAt.isBefore(r.createdAt) } -> "read"
                others.isNotEmpty() && others.all {
                    it.shareRead && ((it.lastDeliveredAt != null && !it.lastDeliveredAt.isBefore(r.createdAt)) ||
                        (it.lastReadAt != null && !it.lastReadAt.isBefore(r.createdAt)))
                } -> "delivered"
                else -> "sent"
            }
            val summary = reactions[r.id].orEmpty().groupBy { it.kind }
                .map { (kind, list) -> ReactionSummary(kind, list.size, list.any { it.account == viewer }) }
                .sortedWith(compareByDescending<ReactionSummary> { it.count }.thenBy { it.kind })
            MessageView(r, mine, status, summary, attachments[r.id].orEmpty())
        }
    }

    suspend fun messages(viewer: UUID, id: UUID, limit: Int?, cursor: String?): MessagePage {
        requireMember(viewer, id)
        val l = ProfileService.clampLimit(limit)
        val rows = store.messages(id, l + 1, PageCursor.decode(cursor))
        val items = rows.take(l)
        markDeliveredAndNotify(viewer, listOf(id))
        return MessagePage(views(viewer, id, items), if (rows.size > l) items.last().let { PageCursor(it.createdAt, it.id).encode() } else null)
    }

    /**
     * Wysyła wiadomość. [attachmentIds] to wcześniej wysłane pliki (`POST /message-attachments`). Zasady: albo do 10 zdjęć,
     * albo do 5 dokumentów, albo dokładnie jedna wiadomość głosowa (bez treści); bez załączników treść jest wymagana.
     */
    suspend fun send(viewer: UUID, id: UUID, rawBody: String, replyTo: UUID?, attachmentIds: List<UUID> = emptyList(), clientId: UUID? = null): MessageView {
        val conv = store.conversation(id) ?: throw convNotFound()
        requireMember(viewer, id)
        // Idempotencja: ta sama wiadomość (clientId) wysłana ponownie po timeoucie/utracie odpowiedzi nie powstaje drugi raz.
        // Sprawdzamy PRZED walidacją załączników — pierwsza próba już je zużyła, więc ponowienie nie może dostać „attachments_unavailable”.
        if (clientId != null) {
            val existing = store.findByClientId(viewer, clientId)
            if (existing != null) {
                if (existing.conversationId != id) throw ApiException(HttpStatusCode.Conflict, "client_id_reused", "This clientId was used for a different conversation.")
                return views(viewer, id, listOf(existing)).single()
            }
        }
        val ids = attachmentIds.distinct()
        if (ids.size != attachmentIds.size) throw bad("attachmentIds: duplicates")
        if (ids.size > MAX_ATTACHMENTS) throw bad("attachmentIds: at most $MAX_ATTACHMENTS")
        val body = if (ids.isEmpty()) clean(rawBody, BODY_MAX, "body") else cleanOptional(rawBody, BODY_MAX, "body")
        if (ids.isNotEmpty()) {
            // Nie zdradzamy, czy cudzy/nieistniejący załącznik istnieje: każdy powód to ten sam błąd.
            val rows = ids.map { aid ->
                store.attachment(aid)?.takeIf { it.ownerId == viewer && it.conversationId == id && it.messageId == null && it.deletedAt == null }
                    ?: throw attachmentsUnavailable()
            }
            val kinds = rows.map { it.kind }.toSet()
            if (kinds.size != 1) throw bad("attachmentIds: one kind per message (images, documents or one voice message)")
            when (kinds.single()) {
                "image" -> if (rows.size > MessageMedia.MAX_IMAGES) throw bad("attachmentIds: at most ${MessageMedia.MAX_IMAGES} images")
                "document" -> if (rows.size > MessageMedia.MAX_DOCUMENTS) throw bad("attachmentIds: at most ${MessageMedia.MAX_DOCUMENTS} documents")
                "voice" -> if (rows.size != 1 || body.isNotEmpty()) throw bad("attachmentIds: a voice message is a single recording without text")
                else -> throw bad("attachmentIds: unsupported kind")
            }
        }
        if (conv.kind == "direct") {
            val other = store.members(id).firstOrNull { it.person.accountId != viewer }
            if (other == null || profiles.isBlockedEitherWay(viewer, other.person.accountId)) throw unavailable()
        }
        if (replyTo != null) {
            val parent = store.message(replyTo)
            if (parent == null || parent.conversationId != id || parent.deleted) throw bad("replyToId: message not found in this conversation")
        }
        val mid = try {
            store.insertMessage(id, viewer, body, replyTo, clock.instant(), ids, clientId)
        } catch (e: AttachmentsUnavailableException) {
            throw attachmentsUnavailable()
        }
        emitToMembers(id, "message.new", mid, actor = store.member(id, viewer)?.person)
        pushNewMessage(conv, viewer, body, ids.size.takeIf { it > 0 }?.let { store.attachmentsFor(listOf(mid))[mid]?.firstOrNull()?.kind }, mid)
        return views(viewer, id, listOf(store.message(mid) ?: throw convNotFound())).single()
    }

    /**
     * Synchronizacja różnicowa: wiadomości rozmowy zmienione (nowe, edytowane, usunięte, z nową reakcją) od [rawSince] albo od [cursor].
     * Klient dostaje je rosnąco; to uzupełnienie `GET …/messages` (strona najnowszych) po utracie połączenia lub zdarzeń WSS.
     */
    suspend fun changes(viewer: UUID, id: UUID, rawSince: String?, limit: Int?, cursor: String?): MessageChangesPage {
        requireMember(viewer, id)
        val since = rawSince?.let { runCatching { java.time.Instant.parse(it) }.getOrNull() ?: throw bad("since: ISO-8601 instant") }
        val after = PageCursor.decode(cursor)
        if (since == null && after == null) throw bad("since or cursor is required")
        val l = ProfileService.clampLimit(limit)
        val serverTime = clock.instant()
        val rows = store.changes(id, since ?: java.time.Instant.EPOCH, after, l + 1)
        val items = rows.take(l)
        markDeliveredAndNotify(viewer, listOf(id))
        val next = if (rows.size > l) items.last().let { PageCursor(it.changedAt ?: it.createdAt, it.id).encode() } else null
        return MessageChangesPage(views(viewer, id, items), next, serverTime)
    }

    /**
     * Push o nowej wiadomości do członków, którzy: nie wyciszyli rozmowy, nie wyciszyli/zablokowali nadawcy i nie są jego zablokowanym
     * rozmówcą w 1:1. Dalsze reguły (ustawienia push, podgląd treści, obecność na pierwszym planie) stosuje [push].
     * Błąd nigdy nie psuje wysyłania wiadomości.
     */
    private suspend fun pushNewMessage(conv: ConversationRow, sender: UUID, body: String, attachmentKind: String?, messageId: UUID) {
        try {
            val members = store.members(conv.id)
            val me = members.firstOrNull { it.person.accountId == sender }?.person ?: return
            val name = me.displayName?.takeIf { it.isNotBlank() } ?: me.nickname
            for (m in members) {
                val rid = m.person.accountId
                if (rid == sender || m.muted) continue
                if (profiles.isBlockedEitherWay(rid, sender) || profiles.isMuted(rid, sender)) continue
                push.message(rid, app.winkwink.server.push.PushMessage(conv.id, messageId, conv.kind == "group", conv.title, name, body.takeIf { it.isNotBlank() }, attachmentKind))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        }
    }

    private suspend fun ownable(viewer: UUID, messageId: UUID): MessageRow {
        fun missing() = ApiException(HttpStatusCode.NotFound, "message_not_found", "Message not found.")
        val m = store.message(messageId) ?: throw missing()
        // Nie-członek dostaje ten sam błąd co przy nieistniejącej wiadomości (brak wyroczni istnienia cudzych wiadomości).
        if (store.member(m.conversationId, viewer) == null) throw missing()
        if (m.deleted) throw missing()
        return m
    }

    suspend fun edit(viewer: UUID, messageId: UUID, rawBody: String): MessageView {
        val m = ownable(viewer, messageId)
        if (m.sender.accountId != viewer) throw forbidden()
        val atts = store.attachmentsFor(listOf(messageId))[messageId].orEmpty()
        if (atts.any { it.kind == "voice" }) throw bad("body: a voice message can't be edited")
        // Wiadomość ze zdjęciami/dokumentami może mieć pusty podpis; zwykła wiadomość nie.
        val newBody = if (atts.isEmpty()) clean(rawBody, BODY_MAX, "body") else cleanOptional(rawBody, BODY_MAX, "body")
        store.editMessage(messageId, newBody, clock.instant())
        emitToMembers(m.conversationId, "message.updated", messageId)
        return views(viewer, m.conversationId, listOf(store.message(messageId)!!)).single()
    }

    /** Reakcja na żywą wiadomość rozmowy, w której widz jest członkiem. [kind] == null usuwa własną reakcję. */
    suspend fun react(viewer: UUID, messageId: UUID, kind: String?): MessageView {
        if (kind != null && kind !in REACTION_KINDS) throw bad("kind: one of ${REACTION_KINDS.sorted().joinToString()}")
        val m = ownable(viewer, messageId)
        val conv = store.conversation(m.conversationId) ?: throw convNotFound()
        if (conv.kind == "direct" && kind != null) {
            val other = store.members(m.conversationId).firstOrNull { it.person.accountId != viewer }
            if (other == null || profiles.isBlockedEitherWay(viewer, other.person.accountId)) throw unavailable()
        }
        store.setReaction(messageId, viewer, kind, clock.instant())
        emitToMembers(m.conversationId, "message.updated", messageId)
        return views(viewer, m.conversationId, listOf(store.message(messageId)!!)).single()
    }

    /** Usuwa autor; w grupie także właściciel/administrator. Treść jest czyszczona, wiersz zostaje jako „usunięta”. */
    suspend fun delete(viewer: UUID, messageId: UUID) {
        val m = ownable(viewer, messageId)
        if (m.sender.accountId != viewer && rank(requireMember(viewer, m.conversationId).role) < rank("admin")) throw forbidden()
        val removed = store.deleteMessage(messageId, clock.instant())
        purgeFiles(removed)
        emitToMembers(m.conversationId, "message.deleted", messageId)
    }

    // ---- członkowie grup ----

    private suspend fun group(id: UUID): ConversationRow =
        store.conversation(id)?.also { if (it.kind != "group") throw ApiException(HttpStatusCode.BadRequest, "not_a_group", "Not a group conversation.") } ?: throw convNotFound()

    suspend fun addMember(viewer: UUID, id: UUID, identifier: String): List<MemberRow> {
        val me = requireMember(viewer, id)
        group(id)
        if (rank(me.role) < rank("admin")) throw forbidden()
        val user = target(identifier)
        if (profiles.isBlockedEitherWay(viewer, user.accountId)) throw unavailable()
        val current = store.members(id)
        if (current.none { it.person.accountId == user.accountId }) {
            if (current.size >= GROUP_MAX) throw ApiException(HttpStatusCode.Conflict, "group_full", "Group is full.")
            store.addMember(id, user.accountId, "member", clock.instant())
            emitToMembers(id, "member.changed")
        }
        return store.members(id)
    }

    /** Tylko właściciel; rola `admin` albo `member` (właściciela nie da się zdegradować ani zmienić sobie roli). */
    suspend fun setMemberRole(viewer: UUID, id: UUID, identifier: String, role: String): List<MemberRow> {
        val me = requireMember(viewer, id)
        group(id)
        if (role != "admin" && role != "member") throw bad("role: admin or member")
        if (me.role != "owner") throw forbidden()
        val user = target(identifier)
        val victim = store.member(id, user.accountId) ?: throw userNotFound()
        if (victim.role == "owner") throw forbidden()
        store.setRole(id, user.accountId, role)
        emitToMembers(id, "member.changed")
        return store.members(id)
    }

    /** [identifier] równy własnemu kontu = opuszczenie grupy. Właściciel nie może opuścić grupy (brak przekazania własności). */
    suspend fun removeMember(viewer: UUID, id: UUID, identifier: String) {
        val me = requireMember(viewer, id)
        group(id)
        val user = target(identifier)
        val victim = store.member(id, user.accountId) ?: throw userNotFound()
        if (user.accountId == viewer) {
            if (me.role == "owner") throw ApiException(HttpStatusCode.Conflict, "owner_cannot_leave", "The owner can't leave the group.")
        } else if (rank(me.role) <= rank(victim.role)) throw forbidden()
        val audience = store.members(id).map { it.person.accountId } // także usuwany: ma od razu stracić dostęp w UI
        store.removeMember(id, user.accountId, clock.instant())
        emit(audience, "member.changed", id)
    }

    // ---- wskaźnik pisania ----

    /**
     * Wskaźnik pisania (z WSS). Prywatność: wysyła go tylko ten, kto sam udostępnia potwierdzenia, i dostają go tylko
     * osoby, które też je udostępniają; w 1:1 nie dociera przez blokadę. Brak błędów — nieuprawnione ramki są ignorowane.
     */
    suspend fun typing(viewer: UUID, id: UUID) {
        val me = store.member(id, viewer) ?: return
        if (!me.shareRead) return
        val conv = store.conversation(id) ?: return
        val others = store.members(id).filter { it.person.accountId != viewer && it.shareRead }
            .filter { conv.kind != "direct" || !profiles.isBlockedEitherWay(viewer, it.person.accountId) }
        if (others.isNotEmpty()) emit(others.map { it.person.accountId }, "typing", id, actor = me.person)
    }

    // ---- prywatność ----

    suspend fun readReceipts(viewer: UUID) = store.readReceipts(viewer)
    suspend fun setReadReceipts(viewer: UUID, enabled: Boolean): Boolean { store.setReadReceipts(viewer, enabled); return enabled }
}
