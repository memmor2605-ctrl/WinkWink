package app.winkwink.server.notification

import app.winkwink.server.profile.PageCursor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.Timestamp
import java.time.Instant
import java.util.UUID
import javax.sql.DataSource

class PostgresNotificationStore(private val dataSource: DataSource) : NotificationStore {

    private suspend fun <T> tx(block: (Connection) -> T): T = withContext(Dispatchers.IO) {
        dataSource.connection.use { c ->
            c.autoCommit = false
            try { val r = block(c); c.commit(); r } catch (e: Throwable) { c.rollback(); throw e }
        }
    }

    private fun bind(ps: PreparedStatement, args: List<Any?>) = args.forEachIndexed { i, a ->
        if (a is Instant) ps.setTimestamp(i + 1, Timestamp.from(a)) else ps.setObject(i + 1, a)
    }

    private companion object {
        /** Wspólny filtr listy i licznika (placeholder: 1 × recipient). */
        const val FROM_VISIBLE =
            "FROM notifications n " +
                "JOIN profiles ap ON ap.account_id = n.actor_id " +
                "JOIN accounts aa ON aa.id = n.actor_id AND aa.status = 'active' " +
                "LEFT JOIN posts po ON po.id = n.post_id " +
                "LEFT JOIN comments cm ON cm.id = n.comment_id " +
                "LEFT JOIN communities cc ON cc.id = n.community_id " +
                "WHERE n.recipient_id = ? " +
                "AND (n.post_id IS NULL OR po.deleted_at IS NULL) " +
                "AND (n.comment_id IS NULL OR cm.deleted_at IS NULL) " +
                "AND (n.community_id IS NULL OR cc.deleted_at IS NULL) " +
                "AND NOT EXISTS (SELECT 1 FROM blocks b WHERE (b.blocker_id = n.recipient_id AND b.blocked_id = n.actor_id AND NOT n.actor_anonymous) " +
                "OR (b.blocker_id = n.actor_id AND b.blocked_id = n.recipient_id))"
    }

    override suspend fun insert(event: NotificationEvent, now: Instant): UUID? = tx { c ->
        c.prepareStatement(
            "INSERT INTO notifications (recipient_id, type, actor_id, post_id, comment_id, community_id, created_at, actor_anonymous) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT DO NOTHING RETURNING id",
        ).use { ps ->
            bind(ps, listOf(event.recipient, event.type, event.actor, event.postId, event.commentId, event.communityId, now, event.actorAnonymous))
            ps.executeQuery().use { rs -> if (rs.next()) rs.getObject(1, UUID::class.java) else null }
        }
    }

    override suspend fun list(recipient: UUID, type: String?, unreadOnly: Boolean, limit: Int, after: PageCursor?): List<NotificationRow> = tx { c ->
        val args = mutableListOf<Any?>(recipient)
        val extra = StringBuilder()
        if (type != null) { extra.append(" AND n.type = ?"); args += type }
        if (unreadOnly) extra.append(" AND n.read_at IS NULL")
        if (after != null) { extra.append(" AND (n.created_at, n.id) < (?, ?)"); args += after.at; args += after.id }
        args += limit
        c.prepareStatement(
            "SELECT n.id, n.type, n.post_id, n.comment_id, n.community_id, n.created_at, n.read_at, n.actor_anonymous, " +
                "ap.nickname, ap.winkwink_id, ap.display_name, (ap.avatar_object_key IS NOT NULL) AS has_avatar " +
                "$FROM_VISIBLE$extra ORDER BY n.created_at DESC, n.id DESC LIMIT ?",
        ).use { ps ->
            bind(ps, args)
            ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.row()) } }
        }
    }

    private fun ResultSet.row() = NotificationRow(
        id = getObject("id", UUID::class.java), type = getString("type"),
        actorNickname = getString("nickname"), actorWinkwinkId = getString("winkwink_id"),
        actorDisplayName = getString("display_name"), actorHasAvatar = getBoolean("has_avatar"),
        postId = getObject("post_id", UUID::class.java), commentId = getObject("comment_id", UUID::class.java),
        communityId = getObject("community_id", UUID::class.java),
        createdAt = getTimestamp("created_at").toInstant(), readAt = getTimestamp("read_at")?.toInstant(),
        actorAnonymous = getBoolean("actor_anonymous"),
    )

    override suspend fun unreadCount(recipient: UUID): Int = tx { c ->
        c.prepareStatement("SELECT count(*) $FROM_VISIBLE AND n.read_at IS NULL").use { ps ->
            bind(ps, listOf(recipient)); ps.executeQuery().use { it.next(); it.getInt(1) }
        }
    }

    override suspend fun markRead(recipient: UUID, id: UUID, now: Instant): Boolean = tx { c ->
        // Zwraca true także dla już przeczytanego własnego powiadomienia (idempotentność), false dla cudzego/nieistniejącego.
        c.prepareStatement(
            "WITH own AS (SELECT id FROM notifications WHERE id = ? AND recipient_id = ?), " +
                "upd AS (UPDATE notifications SET read_at = ? WHERE id IN (SELECT id FROM own) AND read_at IS NULL RETURNING id) " +
                "SELECT count(*) FROM own",
        ).use { ps -> bind(ps, listOf(id, recipient, now)); ps.executeQuery().use { it.next(); it.getInt(1) > 0 } }
    }

    override suspend fun markAllRead(recipient: UUID, type: String?, now: Instant) = tx { c ->
        val args = mutableListOf<Any?>(now, recipient)
        val typeSql = if (type != null) { args += type; " AND type = ?" } else ""
        c.prepareStatement("UPDATE notifications SET read_at = ? WHERE recipient_id = ? AND read_at IS NULL$typeSql").use { ps ->
            bind(ps, args); ps.executeUpdate()
        }
        Unit
    }

    override suspend fun disabledTypes(recipient: UUID): Set<String> = tx { c ->
        c.prepareStatement("SELECT disabled_types FROM notification_settings WHERE account_id = ?").use { ps ->
            bind(ps, listOf(recipient))
            ps.executeQuery().use { rs -> if (rs.next()) (rs.getArray(1).array as Array<*>).map { it as String }.toSet() else emptySet() }
        }
    }

    override suspend fun setDisabledTypes(recipient: UUID, types: Set<String>) = tx { c ->
        c.prepareStatement(
            "INSERT INTO notification_settings (account_id, disabled_types) VALUES (?, ?) " +
                "ON CONFLICT (account_id) DO UPDATE SET disabled_types = EXCLUDED.disabled_types",
        ).use { ps ->
            ps.setObject(1, recipient)
            ps.setArray(2, c.createArrayOf("text", types.sorted().toTypedArray()))
            ps.executeUpdate()
        }
        Unit
    }
}
