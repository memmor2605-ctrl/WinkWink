package app.winkwink.server.auth

object Validators {
    private val EMAIL = Regex("^[A-Za-z0-9._%+\\-]+@[A-Za-z0-9\\-]+(\\.[A-Za-z0-9\\-]+)*\\.[A-Za-z]{2,}$")
    private val NICKNAME = Regex("^[A-Za-z0-9_.]{3,30}$")
    private val PLATFORMS = setOf("android", "ios", "web")

    const val PASSWORD_MIN = 10
    const val PASSWORD_MAX = 128

    fun normalizeEmail(raw: String): String = raw.trim().lowercase()

    fun emailError(email: String): String? = when {
        email.length > 254 -> "email: too long"
        email.contains("..") -> "email: invalid format"
        !EMAIL.matches(email) -> "email: invalid format"
        else -> null
    }

    fun nicknameError(nickname: String): String? =
        if (NICKNAME.matches(nickname)) null else "nickname: 3-30 characters, letters, digits, '_' or '.'"

    fun passwordError(password: String, email: String?): String? = when {
        password.length < PASSWORD_MIN -> "password: at least $PASSWORD_MIN characters"
        password.length > PASSWORD_MAX -> "password: at most $PASSWORD_MAX characters"
        password.isBlank() -> "password: must not be blank"
        email != null && password.equals(email, ignoreCase = true) -> "password: must not equal the e-mail"
        password.toSet().size < 4 -> "password: too repetitive"
        else -> null
    }

    fun platformError(platform: String): String? =
        if (platform in PLATFORMS) null else "platform: must be android, ios or web"

    fun deviceNameError(name: String?): String? =
        if (name != null && name.length > 100) "deviceName: at most 100 characters" else null
}
