package app.winkwink.server.realtime

import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.util.UUID

/**
 * Zdarzenie czasu rzeczywistego. Celowo NIE niesie treści wiadomości — to tylko wskazówka „coś się zmieniło”;
 * klient pobiera stan przez REST (źródło prawdy, z kontrolą dostępu i polami zależnymi od widza).
 * Typy: `hello`, `message.new`, `message.updated`, `message.deleted`, `receipt`, `conversation.new`,
 * `conversation.updated`, `member.changed`, `typing`.
 */
@Serializable
data class RealtimeEvent(
    val type: String,
    val conversationId: String? = null,
    val messageId: String? = null,
    /** Kto wywołał zdarzenie (nadawca wiadomości, osoba piszące); brak dla zdarzeń bez autora. */
    val actor: app.winkwink.server.message.PersonDto? = null,
)

/** Odbiorca zdarzeń domenowych (implementowany przez [RealtimeEvents]); serwisy nie znają WebSocketów. */
fun interface MessageEvents {
    suspend fun publish(recipients: Collection<UUID>, event: RealtimeEvent)

    companion object { val None = MessageEvents { _, _ -> } }
}

/**
 * Rejestr aktywnych połączeń. Każde połączenie ma ograniczoną kolejkę wyjściową (najstarsze zdarzenia są odrzucane
 * dla wolnego klienta — i tak odzyska je przez REST). Na konto przypada maks. [maxPerAccount] połączeń; najstarsze jest zamykane.
 */
class RealtimeHub(private val maxPerAccount: Int = 5) {
    class Connection(val accountId: UUID, val sessionId: UUID) {
        val outbox = Channel<String>(OUTBOX_SIZE, BufferOverflow.DROP_OLDEST)
    }

    private val lock = Any()
    private val byAccount = HashMap<UUID, ArrayDeque<Connection>>()

    fun connect(accountId: UUID, sessionId: UUID): Connection {
        val c = Connection(accountId, sessionId)
        val evicted = mutableListOf<Connection>()
        synchronized(lock) {
            val list = byAccount.getOrPut(accountId) { ArrayDeque() }
            list.addLast(c)
            while (list.size > maxPerAccount) evicted += list.removeFirst()
        }
        evicted.forEach { it.outbox.close() }
        return c
    }

    fun disconnect(c: Connection) {
        synchronized(lock) {
            byAccount[c.accountId]?.let { list -> list.remove(c); if (list.isEmpty()) byAccount.remove(c.accountId) }
        }
        c.outbox.close()
    }

    /** Zamyka wszystkie połączenia sesji (np. po jej unieważnieniu). */
    fun disconnectSession(sessionId: UUID) {
        val victims = synchronized(lock) { byAccount.values.flatten().filter { it.sessionId == sessionId } }
        victims.forEach { it.outbox.close() }
    }

    fun publish(accounts: Collection<UUID>, json: String) {
        val targets = synchronized(lock) { accounts.distinct().flatMap { byAccount[it].orEmpty() } }
        targets.forEach { it.outbox.trySend(json) }
    }

    fun connectionCount(account: UUID): Int = synchronized(lock) { byAccount[account]?.size ?: 0 }

    private companion object { const val OUTBOX_SIZE = 64 }
}

/** Adapter zdarzeń domenowych na ramki JSON w [RealtimeHub]. */
class RealtimeEvents(private val hub: RealtimeHub) : MessageEvents {
    override suspend fun publish(recipients: Collection<UUID>, event: RealtimeEvent) {
        hub.publish(recipients, encode(event))
    }

    companion object {
        private val json = Json { encodeDefaults = false; explicitNulls = false }
        fun encode(event: RealtimeEvent): String = json.encodeToString(RealtimeEvent.serializer(), event)
    }
}
