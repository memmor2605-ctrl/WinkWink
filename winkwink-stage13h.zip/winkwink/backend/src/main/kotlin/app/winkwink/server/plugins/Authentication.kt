package app.winkwink.server.plugins

import app.winkwink.server.api.respondError
import app.winkwink.server.auth.AuthService
import app.winkwink.server.auth.JWT_AUTH
import app.winkwink.server.auth.TokenService
import app.winkwink.server.auth.UserPrincipal
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.Application
import io.ktor.server.application.install
import io.ktor.server.auth.Authentication
import io.ktor.server.auth.jwt.jwt
import java.util.UUID

private fun parseUuid(raw: String?): UUID? = raw?.let { runCatching { UUID.fromString(it) }.getOrNull() }

fun Application.configureAuthentication(auth: AuthService) {
    install(Authentication) {
        jwt(JWT_AUTH) {
            realm = "winkwink"
            verifier(auth.tokens.verifier)
            validate { credential ->
                val accountId = parseUuid(credential.payload.subject)
                val sessionId = parseUuid(credential.payload.getClaim(TokenService.CLAIM_SESSION).asString())
                // Token jest ważny tylko, dopóki sesja istnieje, nie została unieważniona, a konto jest aktywne.
                if (accountId != null && sessionId != null && auth.isSessionActive(sessionId, accountId)) {
                    UserPrincipal(accountId, sessionId)
                } else {
                    null
                }
            }
            challenge { _, _ ->
                call.respondError(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")
            }
        }
    }
}
