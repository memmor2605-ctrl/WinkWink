package app.winkwink.server.profile

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.Timestamp
import java.time.Instant
import java.util.UUID
import javax.sql.DataSource

class PostgresProfileStore(private val dataSource: DataSource) : ProfileStore {

    private suspend fun <T> tx(block: (Connection) -> T): T = withContext(Dispatchers.IO) {
        dataSource.connection.use { c ->
            c.autoCommit = false
            try {
                val r = block(c)
                c.commit()
                r
            } catch (e: Throwable) {
                c.rollback()
                throw e
            }
        }
    }

    private companion object {
        const val USER_COLS =
            "p.account_id, p.nickname, p.winkwink_id, p.display_name, p.bio, p.links, p.visibility, p.avatar_object_key, p.background_object_key, p.hide_follow_lists"
        const val ACTIVE_JOIN = "JOIN accounts a ON a.id = p.account_id AND a.status = 'active'"
    }

    private fun ResultSet.user(): UserRow = UserRow(
        accountId = getObject("account_id", UUID::class.java),
        nickname = getString("nickname"),
        winkwinkId = getString("winkwink_id"),
        displayName = getString("display_name"),
        bio = getString("bio"),
        links = (getArray("links").array as Array<*>).map { it as String },
        visibility = getString("visibility"),
        avatarObjectKey = getString("avatar_object_key"),
        backgroundObjectKey = getString("background_object_key"),
        hideFollowLists = getBoolean("hide_follow_lists"),
    )

    private fun ResultSet.edge() = Edge(user(), getTimestamp("edge_at").toInstant())

    override suspend fun findByIdentifier(identifier: String): UserRow? = tx { c ->
        c.prepareStatement(
            "SELECT $USER_COLS FROM profiles p $ACTIVE_JOIN WHERE p.winkwink_id = lower(?) OR lower(p.nickname) = lower(?) LIMIT 1",
        ).use { ps ->
            ps.setString(1, identifier); ps.setString(2, identifier)
            ps.executeQuery().use { rs -> if (rs.next()) rs.user() else null }
        }
    }

    override suspend fun findById(accountId: UUID): UserRow? = tx { c ->
        c.prepareStatement("SELECT $USER_COLS FROM profiles p $ACTIVE_JOIN WHERE p.account_id = ?").use { ps ->
            ps.setObject(1, accountId)
            ps.executeQuery().use { rs -> if (rs.next()) rs.user() else null }
        }
    }

    override suspend fun updateProfile(accountId: UUID, displayName: String?, bio: String?, links: List<String>, visibility: String) {
        tx { c ->
            c.prepareStatement("UPDATE profiles SET display_name = ?, bio = ?, links = ?, visibility = ? WHERE account_id = ?").use { ps ->
                ps.setString(1, displayName)
                ps.setString(2, bio)
                ps.setArray(3, c.createArrayOf("text", links.toTypedArray()))
                ps.setString(4, visibility)
                ps.setObject(5, accountId)
                ps.executeUpdate()
            }
        }
    }

    override suspend fun isBlockedEitherWay(a: UUID, b: UUID): Boolean = tx { c ->
        c.prepareStatement(
            "SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?) LIMIT 1",
        ).use { ps ->
            ps.setObject(1, a); ps.setObject(2, b); ps.setObject(3, b); ps.setObject(4, a)
            ps.executeQuery().use { it.next() }
        }
    }

    override suspend fun hasBlocked(blocker: UUID, blocked: UUID): Boolean = tx { c ->
        c.prepareStatement("SELECT 1 FROM blocks WHERE blocker_id = ? AND blocked_id = ?").use { ps ->
            ps.setObject(1, blocker); ps.setObject(2, blocked)
            ps.executeQuery().use { it.next() }
        }
    }

    override suspend fun followState(follower: UUID, followee: UUID): String? = tx { c ->
        c.prepareStatement("SELECT status FROM follows WHERE follower_id = ? AND followee_id = ?").use { ps ->
            ps.setObject(1, follower); ps.setObject(2, followee)
            ps.executeQuery().use { rs -> if (rs.next()) rs.getString(1) else null }
        }
    }

    override suspend fun upsertFollow(follower: UUID, followee: UUID, status: String, now: Instant) {
        tx { c ->
            c.prepareStatement(
                "INSERT INTO follows (follower_id, followee_id, status, created_at) VALUES (?, ?, ?, ?) " +
                    "ON CONFLICT (follower_id, followee_id) DO NOTHING",
            ).use { ps ->
                ps.setObject(1, follower); ps.setObject(2, followee); ps.setString(3, status); ps.setTimestamp(4, Timestamp.from(now))
                ps.executeUpdate()
            }
        }
    }

    override suspend fun deleteFollow(follower: UUID, followee: UUID): Boolean = tx { c ->
        c.prepareStatement("DELETE FROM follows WHERE follower_id = ? AND followee_id = ?").use { ps ->
            ps.setObject(1, follower); ps.setObject(2, followee); ps.executeUpdate() > 0
        }
    }

    override suspend fun acceptPending(follower: UUID, followee: UUID): Boolean = tx { c ->
        c.prepareStatement("UPDATE follows SET status = 'accepted' WHERE follower_id = ? AND followee_id = ? AND status = 'pending'").use { ps ->
            ps.setObject(1, follower); ps.setObject(2, followee); ps.executeUpdate() > 0
        }
    }

    override suspend fun rejectPending(follower: UUID, followee: UUID): Boolean = tx { c ->
        c.prepareStatement("DELETE FROM follows WHERE follower_id = ? AND followee_id = ? AND status = 'pending'").use { ps ->
            ps.setObject(1, follower); ps.setObject(2, followee); ps.executeUpdate() > 0
        }
    }

    private fun count(c: Connection, sql: String, id: UUID): Int =
        c.prepareStatement(sql).use { ps -> ps.setObject(1, id); ps.executeQuery().use { it.next(); it.getInt(1) } }

    override suspend fun followerCount(accountId: UUID) = tx { c ->
        count(c, "SELECT count(*) FROM follows f JOIN accounts a ON a.id = f.follower_id AND a.status = 'active' WHERE f.followee_id = ? AND f.status = 'accepted'", accountId)
    }

    override suspend fun followingCount(accountId: UUID) = tx { c ->
        count(c, "SELECT count(*) FROM follows f JOIN accounts a ON a.id = f.followee_id AND a.status = 'active' WHERE f.follower_id = ? AND f.status = 'accepted'", accountId)
    }

    /** Wspólny, kursorowy (keyset) odczyt krawędzi: sort po (created_at, id) malejąco. */
    private fun edges(
        c: Connection, table: String, ownerCol: String, otherCol: String, extraWhere: String,
        owner: UUID, limit: Int, after: PageCursor?,
    ): List<Edge> {
        val cursorSql = if (after != null) "AND (t.created_at, t.$otherCol) < (?, ?)" else ""
        val sql = "SELECT $USER_COLS, t.created_at AS edge_at FROM $table t " +
            "JOIN profiles p ON p.account_id = t.$otherCol $ACTIVE_JOIN " +
            "WHERE t.$ownerCol = ? $extraWhere $cursorSql ORDER BY t.created_at DESC, t.$otherCol DESC LIMIT ?"
        return c.prepareStatement(sql).use { ps: PreparedStatement ->
            var i = 1
            ps.setObject(i++, owner)
            if (after != null) { ps.setTimestamp(i++, Timestamp.from(after.at)); ps.setObject(i++, after.id) }
            ps.setInt(i, limit)
            ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.edge()) } }
        }
    }

    override suspend fun listFollowers(accountId: UUID, limit: Int, after: PageCursor?) =
        tx { c -> edges(c, "follows", "followee_id", "follower_id", "AND t.status = 'accepted'", accountId, limit, after) }

    override suspend fun listFollowing(accountId: UUID, limit: Int, after: PageCursor?) =
        tx { c -> edges(c, "follows", "follower_id", "followee_id", "AND t.status = 'accepted'", accountId, limit, after) }

    override suspend fun listPendingRequests(accountId: UUID, limit: Int, after: PageCursor?) =
        tx { c -> edges(c, "follows", "followee_id", "follower_id", "AND t.status = 'pending'", accountId, limit, after) }

    override suspend fun listBlocks(blocker: UUID, limit: Int, after: PageCursor?) =
        tx { c -> edges(c, "blocks", "blocker_id", "blocked_id", "", blocker, limit, after) }

    override suspend fun addBlock(blocker: UUID, blocked: UUID, now: Instant) {
        tx { c ->
            c.prepareStatement("INSERT INTO blocks (blocker_id, blocked_id, created_at) VALUES (?, ?, ?) ON CONFLICT DO NOTHING").use { ps ->
                ps.setObject(1, blocker); ps.setObject(2, blocked); ps.setTimestamp(3, Timestamp.from(now)); ps.executeUpdate()
            }
            c.prepareStatement("DELETE FROM follows WHERE (follower_id = ? AND followee_id = ?) OR (follower_id = ? AND followee_id = ?)").use { ps ->
                ps.setObject(1, blocker); ps.setObject(2, blocked); ps.setObject(3, blocked); ps.setObject(4, blocker); ps.executeUpdate()
            }
        }
    }

    override suspend fun removeBlock(blocker: UUID, blocked: UUID): Boolean = tx { c ->
        c.prepareStatement("DELETE FROM blocks WHERE blocker_id = ? AND blocked_id = ?").use { ps ->
            ps.setObject(1, blocker); ps.setObject(2, blocked); ps.executeUpdate() > 0
        }
    }

    private fun likeEscape(s: String) = s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    override suspend fun search(viewer: UUID, query: String, limit: Int): List<UserRow> = tx { c ->
        val pattern = likeEscape(query.lowercase()) + "%"
        c.prepareStatement(
            "SELECT $USER_COLS FROM profiles p $ACTIVE_JOIN " +
                "WHERE (lower(p.nickname) LIKE ? ESCAPE '\\' OR lower(p.display_name) LIKE ? ESCAPE '\\' OR p.winkwink_id = lower(?)) " +
                "AND p.account_id <> ? " +
                "AND NOT EXISTS (SELECT 1 FROM blocks b WHERE (b.blocker_id = ? AND b.blocked_id = p.account_id) OR (b.blocker_id = p.account_id AND b.blocked_id = ?)) " +
                "ORDER BY (lower(p.nickname) = lower(?)) DESC, lower(p.nickname) LIMIT ?",
        ).use { ps ->
            ps.setString(1, pattern); ps.setString(2, pattern); ps.setString(3, query)
            ps.setObject(4, viewer); ps.setObject(5, viewer); ps.setObject(6, viewer)
            ps.setString(7, query); ps.setInt(8, limit)
            ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.user()) } }
        }
    }

    private fun swapKey(c: Connection, column: String, accountId: UUID, key: String?): String? {
        val previous = c.prepareStatement("SELECT $column FROM profiles WHERE account_id = ? FOR UPDATE").use { ps ->
            ps.setObject(1, accountId)
            ps.executeQuery().use { rs -> if (rs.next()) rs.getString(1) else null }
        }
        c.prepareStatement("UPDATE profiles SET $column = ? WHERE account_id = ?").use { ps ->
            ps.setString(1, key); ps.setObject(2, accountId); ps.executeUpdate()
        }
        return previous
    }

    override suspend fun setAvatarKey(accountId: UUID, key: String?): String? = tx { c -> swapKey(c, "avatar_object_key", accountId, key) }
    override suspend fun setBackgroundKey(accountId: UUID, key: String?): String? = tx { c -> swapKey(c, "background_object_key", accountId, key) }

    override suspend fun setHideFollowLists(accountId: UUID, hide: Boolean) {
        tx { c ->
            c.prepareStatement("UPDATE profiles SET hide_follow_lists = ? WHERE account_id = ?").use { ps ->
                ps.setBoolean(1, hide); ps.setObject(2, accountId); ps.executeUpdate()
            }
        }
    }

    override suspend fun addMute(muter: UUID, muted: UUID, now: Instant) {
        tx { c ->
            c.prepareStatement("INSERT INTO user_mutes (muter_id, muted_id, created_at) VALUES (?, ?, ?) ON CONFLICT DO NOTHING").use { ps ->
                ps.setObject(1, muter); ps.setObject(2, muted); ps.setTimestamp(3, Timestamp.from(now)); ps.executeUpdate()
            }
        }
    }

    override suspend fun removeMute(muter: UUID, muted: UUID): Boolean = tx { c ->
        c.prepareStatement("DELETE FROM user_mutes WHERE muter_id = ? AND muted_id = ?").use { ps ->
            ps.setObject(1, muter); ps.setObject(2, muted); ps.executeUpdate() > 0
        }
    }

    override suspend fun isMuted(muter: UUID, muted: UUID): Boolean = tx { c ->
        c.prepareStatement("SELECT 1 FROM user_mutes WHERE muter_id = ? AND muted_id = ?").use { ps ->
            ps.setObject(1, muter); ps.setObject(2, muted); ps.executeQuery().use { it.next() }
        }
    }

    override suspend fun listMutes(muter: UUID, limit: Int, after: PageCursor?) =
        tx { c -> edges(c, "user_mutes", "muter_id", "muted_id", "", muter, limit, after) }
}
