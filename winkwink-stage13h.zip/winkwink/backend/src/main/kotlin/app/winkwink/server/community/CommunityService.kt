package app.winkwink.server.community

import app.winkwink.server.notification.NotificationEvent
import app.winkwink.server.notification.NotificationTypes
import app.winkwink.server.notification.Notifier
import app.winkwink.server.api.ApiException
import app.winkwink.server.profile.PageCursor
import app.winkwink.server.profile.ProfileService
import app.winkwink.server.profile.ProfileStore
import app.winkwink.server.profile.UserRow
import io.ktor.http.HttpStatusCode
import java.time.Clock
import java.util.UUID

data class CommunityView(val community: CommunityRow, val myRole: String?, /** member | requested | invited | none */ val myStatus: String)
data class ListPage<T>(val items: List<T>, val nextCursor: String?)

/**
 * Wszystkie uprawnienia są weryfikowane tutaj (nie w kliencie).
 * Role: owner > admin > moderator > member. Społeczność „invite” jest niewidoczna (404) dla osób bez członkostwa i zaproszenia.
 */
class CommunityService(
    private val store: CommunityStore,
    private val profiles: ProfileStore,
    private val clock: Clock = Clock.systemUTC(),
    private val notifier: Notifier = Notifier.None,
) {
    companion object {
        val TYPES = setOf("public", "private", "invite")
        val ASSIGNABLE_ROLES = setOf("admin", "moderator", "member")
        const val DEFAULT_CHANNEL = "general"
        const val MAX_CHANNELS = 20
        const val CANDIDATE_LIMIT = 10
        private val CHANNEL_NAME = Regex("^[\\p{L}\\p{N}][\\p{L}\\p{N} _-]{1,29}$")

        const val MEMBER = 0
        const val MODERATOR = 1
        const val ADMIN = 2
        const val OWNER = 3

        fun rank(role: String?) = when (role) { "owner" -> OWNER; "admin" -> ADMIN; "moderator" -> MODERATOR; "member" -> MEMBER; else -> -1 }

        private fun bad(msg: String) = ApiException(HttpStatusCode.BadRequest, "validation_failed", msg, listOf(msg))
        private fun notFound() = ApiException(HttpStatusCode.NotFound, "community_not_found", "Community not found.")
        private fun forbidden() = ApiException(HttpStatusCode.Forbidden, "forbidden", "You do not have permission to do this.")
        private fun conflict(code: String, msg: String) = ApiException(HttpStatusCode.Conflict, code, msg)
        private fun userNotFound() = ApiException(HttpStatusCode.NotFound, "user_not_found", "User not found.")

        fun communityId(raw: String?): UUID = runCatching { UUID.fromString(raw) }.getOrNull() ?: throw notFound()
        fun clampLimit(raw: Int?) = ProfileService.clampLimit(raw)

        fun validName(raw: String): String {
            val n = raw.trim()
            if (n.length !in 3..50) throw bad("name: 3 to 50 characters")
            if (n.any { it.isISOControl() }) throw bad("name: control characters are not allowed")
            return n
        }
        fun validDescription(raw: String) = raw.trim().also { if (it.length > 500) throw bad("description: at most 500 characters") }
        fun validRules(raw: String) = raw.trim().also { if (it.length > 2000) throw bad("rules: at most 2000 characters") }
        fun validType(raw: String) = raw.also { if (it !in TYPES) throw bad("type: one of public, private, invite") }
        fun validChannelName(raw: String) = raw.trim().also { if (!CHANNEL_NAME.matches(it)) throw bad("channel name: 2 to 30 letters, digits, spaces, _ or -") }
    }

    // ---------- pomocnicze ----------

    private class Ctx(val community: CommunityRow, val role: String?)

    /** Ładuje społeczność widoczną dla [viewer]; inaczej 404 (nieodróżnialne od nieistniejącej). */
    private suspend fun load(viewer: UUID, id: UUID): Ctx {
        val c = store.find(id) ?: throw notFound()
        val role = store.roleOf(id, viewer)
        if (role == null && c.type == "invite" && !store.hasInvite(id, viewer)) throw notFound()
        return Ctx(c, role)
    }

    private fun require(ctx: Ctx, minRank: Int) { if (rank(ctx.role) < minRank) throw forbidden() }

    private suspend fun resolveUser(actor: UUID, identifier: String): UserRow {
        val ident = identifier.trim().removePrefix("@")
        if (ident.isEmpty() || ident.length > 40) throw userNotFound()
        val u = profiles.findByIdentifier(ident) ?: throw userNotFound()
        if (u.accountId != actor && profiles.isBlockedEitherWay(actor, u.accountId)) throw userNotFound()
        return u
    }

    private suspend fun statusOf(c: CommunityRow, viewer: UUID, role: String?): String = when {
        role != null -> "member"
        store.hasRequest(c.id, viewer) -> "requested"
        store.hasInvite(c.id, viewer) -> "invited"
        else -> "none"
    }

    private fun <T> page(rows: List<T>, limit: Int, key: (T) -> PageCursor): ListPage<T> {
        val more = rows.size > limit
        val items = if (more) rows.take(limit) else rows
        return ListPage(items, if (more) items.lastOrNull()?.let { key(it).encode() } else null)
    }

    // ---------- społeczność ----------

    suspend fun create(owner: UUID, name: String, description: String, rules: String, type: String): CommunityView {
        val n = validName(name); val d = validDescription(description); val r = validRules(rules); val t = validType(type)
        if (store.nameTakenByOther(n, null)) throw conflict("community_name_taken", "A community with this name already exists.")
        val id = store.create(owner, n, d, r, t, DEFAULT_CHANNEL, clock.instant())
        return view(owner, id)
    }

    suspend fun view(viewer: UUID, id: UUID): CommunityView {
        val ctx = load(viewer, id)
        return CommunityView(ctx.community, ctx.role, statusOf(ctx.community, viewer, ctx.role))
    }

    /** Pola null = bez zmian. Admin edytuje nazwę, opis i zasady; zmiana typu wyłącznie przez właściciela. */
    suspend fun update(actor: UUID, id: UUID, name: String?, description: String?, rules: String?, type: String?): CommunityView {
        val ctx = load(actor, id)
        require(ctx, ADMIN)
        val c = ctx.community
        val n = name?.let { validName(it) } ?: c.name
        val d = description?.let { validDescription(it) } ?: c.description
        val r = rules?.let { validRules(it) } ?: c.rules
        val t = type?.let { validType(it) } ?: c.type
        if (t != c.type) require(ctx, OWNER)
        if (!n.equals(c.name, ignoreCase = true) && store.nameTakenByOther(n, id)) throw conflict("community_name_taken", "A community with this name already exists.")
        store.update(id, n, d, r, t)
        return view(actor, id)
    }

    /** Usunięcie społeczności należy wyłącznie do właściciela. */
    suspend fun delete(actor: UUID, id: UUID) {
        val ctx = load(actor, id)
        require(ctx, OWNER)
        store.softDelete(id, clock.instant())
    }

    // ---------- członkostwo ----------

    /** @return "member" albo "requested". */
    suspend fun join(actor: UUID, id: UUID): String {
        val ctx = load(actor, id)
        if (ctx.role != null) throw conflict("already_member", "You are already a member.")
        val now = clock.instant()
        val invited = store.hasInvite(id, actor)
        return when {
            invited || ctx.community.type == "public" -> {
                store.addMember(id, actor, "member", now)
                store.removeInvite(id, actor); store.removeRequest(id, actor)
                "member"
            }
            else -> { // private (typ invite bez zaproszenia został już odrzucony w load)
                if (store.hasRequest(id, actor)) throw conflict("already_requested", "Join request already sent.")
                store.addRequest(id, actor, now)
                "requested"
            }
        }
    }

    suspend fun cancelRequest(actor: UUID, id: UUID) {
        load(actor, id)
        if (!store.removeRequest(id, actor)) throw ApiException(HttpStatusCode.NotFound, "request_not_found", "No pending request.")
    }

    suspend fun leave(actor: UUID, id: UUID) {
        val ctx = load(actor, id)
        if (ctx.role == null) throw ApiException(HttpStatusCode.NotFound, "not_member", "You are not a member.")
        if (ctx.role == "owner") throw conflict("owner_cannot_leave", "The owner cannot leave. Delete the community instead.")
        store.removeMember(id, actor)
    }

    suspend fun members(viewer: UUID, id: UUID, limit: Int?, cursor: String?): ListPage<PersonRow> {
        val ctx = load(viewer, id)
        if (ctx.community.type != "public") require(ctx, MEMBER)
        val l = clampLimit(limit)
        val result = page(store.members(id, l + 1, PageCursor.decode(cursor)), l) { PageCursor(it.at, it.accountId) }
        // Flagę „wyciszony” widzą tylko moderatorzy i wyżej (zwykli członkowie nie dowiadują się, kto został wyciszony).
        if (rank(ctx.role) < MODERATOR) return result
        val muted = store.mutedAmong(id, result.items.map { it.accountId })
        return result.copy(items = result.items.map { it.copy(muted = it.accountId in muted) })
    }

    /**
     * Przekazanie własności: tylko właściciel, wyłącznie istniejącemu członkowi (nie sobie). Dotychczasowy właściciel zostaje administratorem.
     * Operacja jest atomowa w magazynie, więc społeczność zawsze ma dokładnie jednego właściciela.
     */
    suspend fun transferOwnership(actor: UUID, id: UUID, targetIdentifier: String) {
        val ctx = load(actor, id)
        require(ctx, OWNER)
        val target = resolveUser(actor, targetIdentifier)
        if (target.accountId == actor) throw bad("You already own this community.")
        if (store.roleOf(id, target.accountId) == null) throw ApiException(HttpStatusCode.NotFound, "not_member", "User is not a member.")
        store.transferOwnership(id, actor, target.accountId)
    }

    /**
     * Wyciszony członek zostaje w społeczności i może czytać, ale nie może publikować postów ani komentarzy.
     * Wyciszać może moderator+ wyłącznie osoby o niższej randze; właściciela nie da się wyciszyć.
     */
    suspend fun setMuted(actor: UUID, id: UUID, targetIdentifier: String, muted: Boolean) {
        val ctx = load(actor, id)
        require(ctx, MODERATOR)
        val target = resolveUser(actor, targetIdentifier)
        if (target.accountId == actor) throw bad("You cannot mute yourself.")
        val targetRole = store.roleOf(id, target.accountId) ?: throw ApiException(HttpStatusCode.NotFound, "not_member", "User is not a member.")
        if (rank(ctx.role) <= rank(targetRole)) throw forbidden()
        store.setMuted(id, target.accountId, actor, muted, clock.instant())
    }

    /**
     * Wyszukiwanie osób do zaproszenia (moderator+). Używa tego samego wyszukiwania co /users/search (blokady są pomijane),
     * odfiltrowuje obecnych członków i oznacza osoby, które mają już zaproszenie.
     */
    suspend fun inviteCandidates(actor: UUID, id: UUID, query: String): List<Pair<UserRow, Boolean>> {
        val ctx = load(actor, id)
        require(ctx, MODERATOR)
        val q = query.trim().removePrefix("@")
        if (q.length < 2) throw bad("q: at least 2 characters")
        if (q.length > 40) throw bad("q: at most 40 characters")
        return profiles.search(actor, q, CANDIDATE_LIMIT + 1).asSequence()
            .filter { it.accountId != actor && store.roleOf(id, it.accountId) == null }
            .take(CANDIDATE_LIMIT)
            .map { it to store.hasInvite(id, it.accountId) }
            .toList()
    }

    /** Tylko właściciel; nie można nadać roli „owner” ani zmienić roli samego siebie. */
    suspend fun setRole(actor: UUID, id: UUID, targetIdentifier: String, role: String) {
        val ctx = load(actor, id)
        require(ctx, OWNER)
        if (role !in ASSIGNABLE_ROLES) throw bad("role: one of admin, moderator, member")
        val target = resolveUser(actor, targetIdentifier)
        if (target.accountId == actor) throw bad("You cannot change your own role.")
        if (store.roleOf(id, target.accountId) == null) throw ApiException(HttpStatusCode.NotFound, "not_member", "User is not a member.")
        store.setRole(id, target.accountId, role)
    }

    /** Usuwać można wyłącznie osoby o niższej randze; wymagany co najmniej moderator. */
    suspend fun removeMember(actor: UUID, id: UUID, targetIdentifier: String) {
        val ctx = load(actor, id)
        require(ctx, MODERATOR)
        val target = resolveUser(actor, targetIdentifier)
        if (target.accountId == actor) throw bad("Use leave to leave a community.")
        val targetRole = store.roleOf(id, target.accountId) ?: throw ApiException(HttpStatusCode.NotFound, "not_member", "User is not a member.")
        if (rank(ctx.role) <= rank(targetRole)) throw forbidden()
        store.removeMember(id, target.accountId)
    }

    // ---------- zaproszenia i prośby ----------

    suspend fun invite(actor: UUID, id: UUID, targetIdentifier: String) {
        val ctx = load(actor, id)
        require(ctx, MODERATOR)
        val target = resolveUser(actor, targetIdentifier)
        if (store.roleOf(id, target.accountId) != null) throw conflict("already_member", "User is already a member.")
        if (store.hasInvite(id, target.accountId)) return // idempotentnie
        store.addInvite(id, target.accountId, actor, clock.instant())
        notifier.notify(NotificationEvent(NotificationTypes.COMMUNITY_INVITE, recipient = target.accountId, actor = actor, communityId = id))
    }

    suspend fun myInvites(viewer: UUID, limit: Int?, cursor: String?): ListPage<CommunityRow> {
        val l = clampLimit(limit)
        return page(store.invitesFor(viewer, l + 1, PageCursor.decode(cursor)), l) { PageCursor(it.cursorAt, it.id) }
    }

    suspend fun respondToInvite(actor: UUID, id: UUID, accept: Boolean) {
        store.find(id) ?: throw notFound()
        if (!store.hasInvite(id, actor)) throw ApiException(HttpStatusCode.NotFound, "invitation_not_found", "No invitation.")
        val inviter = store.inviterOf(id, actor)
        if (accept && store.roleOf(id, actor) == null) store.addMember(id, actor, "member", clock.instant())
        store.removeInvite(id, actor)
        if (accept && inviter != null) {
            notifier.notify(NotificationEvent(NotificationTypes.COMMUNITY_INVITE_ACCEPTED, recipient = inviter, actor = actor, communityId = id))
        }
        store.removeRequest(id, actor)
    }

    suspend fun requests(actor: UUID, id: UUID, limit: Int?, cursor: String?): ListPage<PersonRow> {
        val ctx = load(actor, id)
        require(ctx, MODERATOR)
        val l = clampLimit(limit)
        return page(store.requests(id, l + 1, PageCursor.decode(cursor)), l) { PageCursor(it.at, it.accountId) }
    }

    suspend fun decideRequest(actor: UUID, id: UUID, targetIdentifier: String, approve: Boolean) {
        val ctx = load(actor, id)
        require(ctx, MODERATOR)
        val target = resolveUser(actor, targetIdentifier)
        if (!store.hasRequest(id, target.accountId)) throw ApiException(HttpStatusCode.NotFound, "request_not_found", "No pending request.")
        if (approve && store.roleOf(id, target.accountId) == null) store.addMember(id, target.accountId, "member", clock.instant())
        store.removeRequest(id, target.accountId)
        if (approve) notifier.notify(NotificationEvent(NotificationTypes.COMMUNITY_REQUEST_APPROVED, recipient = target.accountId, actor = actor, communityId = id))
    }

    // ---------- listy i wyszukiwanie ----------

    suspend fun mine(viewer: UUID, limit: Int?, cursor: String?): ListPage<CommunityRow> {
        val l = clampLimit(limit)
        return page(store.memberships(viewer, l + 1, PageCursor.decode(cursor)), l) { PageCursor(it.cursorAt, it.id) }
    }

    suspend fun search(viewer: UUID, query: String, limit: Int?, cursor: String?): ListPage<CommunityRow> {
        val q = query.trim()
        if (q.length < 2) throw bad("q: at least 2 characters")
        if (q.length > 50) throw bad("q: at most 50 characters")
        val l = clampLimit(limit)
        return page(store.search(viewer, q, l + 1, PageCursor.decode(cursor)), l) { PageCursor(it.cursorAt, it.id) }
    }

    // ---------- kanały ----------

    suspend fun channels(viewer: UUID, id: UUID): List<ChannelRow> {
        load(viewer, id)
        return store.channels(id)
    }

    suspend fun createChannel(actor: UUID, id: UUID, name: String): ChannelRow {
        val ctx = load(actor, id)
        require(ctx, ADMIN)
        val n = validChannelName(name)
        val existing = store.channels(id)
        if (existing.size >= MAX_CHANNELS) throw conflict("channel_limit", "A community can have at most $MAX_CHANNELS channels.")
        if (store.channelNameTaken(id, n)) throw conflict("channel_name_taken", "A channel with this name already exists.")
        val cid = store.addChannel(id, n, clock.instant())
        return store.channels(id).first { it.id == cid }
    }

    suspend fun deleteChannel(actor: UUID, id: UUID, channelId: UUID) {
        val ctx = load(actor, id)
        require(ctx, ADMIN)
        val existing = store.channels(id)
        if (existing.none { it.id == channelId }) throw ApiException(HttpStatusCode.NotFound, "channel_not_found", "Channel not found.")
        if (existing.size <= 1) throw conflict("last_channel", "A community must keep at least one channel.")
        store.deleteChannel(id, channelId)
    }
}
