package app.winkwink.server.plugins

import app.winkwink.server.api.respondError
import app.winkwink.server.config.AppConfig
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.Application
import io.ktor.server.application.ApplicationCallPipeline
import io.ktor.server.application.install
import io.ktor.server.plugins.defaultheaders.DefaultHeaders
import io.ktor.server.plugins.forwardedheaders.XForwardedHeaders
import io.ktor.server.plugins.hsts.HSTS
import io.ktor.server.plugins.origin
import app.winkwink.server.auth.AUTH_RATE_LIMIT
import io.ktor.server.plugins.ratelimit.RateLimit
import org.slf4j.LoggerFactory
import kotlin.time.Duration.Companion.seconds

private val securityLog = LoggerFactory.getLogger("app.winkwink.security")

fun Application.configureSecurity(config: AppConfig) {
    // Za reverse proxy schemat żądania pochodzi z X-Forwarded-Proto (proxy musi być jedyną drogą dostępu).
    if (config.trustProxy) install(XForwardedHeaders)

    install(HSTS) {
        maxAgeInSeconds = 31_536_000
        includeSubDomains = true
    }

    install(DefaultHeaders) {
        header("X-Content-Type-Options", "nosniff")
        header("Referrer-Policy", "no-referrer")
        header(HttpHeaders.CacheControl, "no-store")
        header(HttpHeaders.Server, "WinkWink")
    }

    install(RateLimit) {
        global {
            rateLimiter(limit = config.rateLimitPerMinute, refillPeriod = 60.seconds)
            requestKey { call -> call.request.origin.remoteAddress }
        }
        // Ostrzejszy limit dla publicznych endpointów uwierzytelniania (dodatkowo do blokad brute force w AuthService).
        register(AUTH_RATE_LIMIT) {
            rateLimiter(limit = config.auth.authRateLimitPerMinute, refillPeriod = 60.seconds)
            requestKey { call -> call.request.origin.remoteAddress }
        }
    }

    // Twarda zasada: żadne żądanie nie jest obsługiwane, jeśli nie przyszło przez HTTPS.
    intercept(ApplicationCallPipeline.Plugins) {
        if (!call.request.origin.scheme.equals("https", ignoreCase = true)) {
            securityLog.warn("Rejected non-HTTPS request from {}", call.request.origin.remoteAddress)
            call.respondError(HttpStatusCode.Forbidden, "https_required", "This API is available over HTTPS only.")
            finish()
        }
    }
}
