package app.winkwink.server.media

import app.winkwink.server.api.ApiException
import io.ktor.http.HttpStatusCode
import java.time.Clock
import java.time.Duration
import java.time.Instant
import java.util.UUID

/**
 * Limit tempa wysyłania plików na konto (okno przesuwne: [perMinute] na minutę i [perHour] na godzinę).
 * Stan jest w pamięci procesu (jak [app.winkwink.server.realtime.RealtimeHub]); przy wielu instancjach każda liczy osobno.
 * Uzupełnia globalny limit żądań na IP — ten tutaj chroni dysk i CPU przed pojedynczym kontem.
 */
class UploadRateLimiter(
    private val perMinute: Int = 20,
    private val perHour: Int = 200,
    private val clock: Clock = Clock.systemUTC(),
) {
    private val hits = HashMap<UUID, ArrayDeque<Instant>>()

    /** Zalicza próbę wysłania; przy przekroczeniu rzuca 429 z `Retry-After`. */
    fun check(account: UUID) {
        val now = clock.instant()
        synchronized(hits) {
            val q = hits.getOrPut(account) { ArrayDeque() }
            while (q.isNotEmpty() && q.first().isBefore(now.minus(Duration.ofHours(1)))) q.removeFirst()
            val inMinute = q.filter { it.isAfter(now.minus(Duration.ofMinutes(1))) }
            val retry = when {
                q.size >= perHour -> Duration.between(now.minus(Duration.ofHours(1)), q.first()).seconds
                inMinute.size >= perMinute -> Duration.between(now.minus(Duration.ofMinutes(1)), inMinute.first()).seconds
                else -> null
            }
            if (retry != null) {
                throw ApiException(HttpStatusCode.TooManyRequests, "upload_rate_limited", "Too many uploads; try again later.", retryAfterSeconds = maxOf(1L, retry))
            }
            q.addLast(now)
            if (hits.size > 10_000) hits.entries.removeIf { it.value.isEmpty() || it.value.last().isBefore(now.minus(Duration.ofHours(1))) }
        }
    }
}
