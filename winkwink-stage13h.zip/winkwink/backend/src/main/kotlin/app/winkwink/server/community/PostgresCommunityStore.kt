package app.winkwink.server.community

import app.winkwink.server.api.ApiException
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.SQLException
import java.sql.Timestamp
import java.time.Instant
import java.util.UUID
import javax.sql.DataSource

class PostgresCommunityStore(private val dataSource: DataSource) : CommunityStore {

    private suspend fun <T> tx(block: (Connection) -> T): T = withContext(Dispatchers.IO) {
        dataSource.connection.use { c ->
            c.autoCommit = false
            try {
                val r = block(c)
                c.commit()
                r
            } catch (e: SQLException) {
                c.rollback()
                // 23505 = naruszenie unikalności (wyścig przy nazwie społeczności/kanału).
                if (e.sqlState == "23505") throw ApiException(HttpStatusCode.Conflict, "conflict", "The value is already taken.")
                throw e
            } catch (e: Throwable) {
                c.rollback()
                throw e
            }
        }
    }

    private companion object {
        const val COMMUNITY_COLS = "c.id, c.name, c.description, c.rules, c.type, c.owner_id, c.created_at, " +
            "(SELECT count(*) FROM community_members mc WHERE mc.community_id = c.id) AS member_count"
        const val PERSON_COLS = "p.account_id, p.nickname, p.winkwink_id, p.display_name"
        const val ACTIVE = "JOIN accounts a ON a.id = p.account_id AND a.status = 'active'"

        fun escapeLike(q: String) = q.lowercase().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    }

    private fun PreparedStatement.ts(i: Int, t: Instant) = setTimestamp(i, Timestamp.from(t))
    private fun ResultSet.uuid(col: String) = getObject(col, UUID::class.java)

    private fun ResultSet.community(cursorCol: String = "created_at") = CommunityRow(
        id = uuid("id"), name = getString("name"), description = getString("description"), rules = getString("rules"),
        type = getString("type"), ownerId = uuid("owner_id"), createdAt = getTimestamp("created_at").toInstant(),
        memberCount = getInt("member_count"), cursorAt = getTimestamp(cursorCol).toInstant(),
    )

    private fun ResultSet.person(roleCol: String?, atCol: String) = PersonRow(
        accountId = uuid("account_id"), nickname = getString("nickname"), winkwinkId = getString("winkwink_id"),
        displayName = getString("display_name"), role = roleCol?.let { getString(it) }, at = getTimestamp(atCol).toInstant(),
    )

    override suspend fun create(ownerId: UUID, name: String, description: String, rules: String, type: String, defaultChannel: String, now: Instant): UUID = tx { c ->
        val id = c.prepareStatement(
            "INSERT INTO communities (name, description, rules, type, owner_id, created_at) VALUES (?, ?, ?, ?, ?, ?) RETURNING id",
        ).use { ps ->
            ps.setString(1, name); ps.setString(2, description); ps.setString(3, rules); ps.setString(4, type)
            ps.setObject(5, ownerId); ps.ts(6, now)
            ps.executeQuery().use { rs -> rs.next(); rs.uuid("id") }
        }
        c.prepareStatement("INSERT INTO community_members (community_id, account_id, role, joined_at) VALUES (?, ?, 'owner', ?)").use { ps ->
            ps.setObject(1, id); ps.setObject(2, ownerId); ps.ts(3, now); ps.executeUpdate()
        }
        c.prepareStatement("INSERT INTO community_channels (community_id, name, created_at) VALUES (?, ?, ?)").use { ps ->
            ps.setObject(1, id); ps.setString(2, defaultChannel); ps.ts(3, now); ps.executeUpdate()
        }
        id
    }

    override suspend fun find(id: UUID): CommunityRow? = tx { c ->
        c.prepareStatement("SELECT $COMMUNITY_COLS FROM communities c WHERE c.id = ? AND c.deleted_at IS NULL").use { ps ->
            ps.setObject(1, id)
            ps.executeQuery().use { rs -> if (rs.next()) rs.community() else null }
        }
    }

    override suspend fun nameTakenByOther(name: String, exceptId: UUID?): Boolean = tx { c ->
        c.prepareStatement("SELECT 1 FROM communities WHERE lower(name) = lower(?) AND deleted_at IS NULL AND (?::uuid IS NULL OR id <> ?::uuid)").use { ps ->
            ps.setString(1, name); ps.setObject(2, exceptId); ps.setObject(3, exceptId)
            ps.executeQuery().use { it.next() }
        }
    }

    override suspend fun update(id: UUID, name: String, description: String, rules: String, type: String) = tx { c ->
        c.prepareStatement("UPDATE communities SET name = ?, description = ?, rules = ?, type = ? WHERE id = ? AND deleted_at IS NULL").use { ps ->
            ps.setString(1, name); ps.setString(2, description); ps.setString(3, rules); ps.setString(4, type); ps.setObject(5, id)
            ps.executeUpdate()
        }
        Unit
    }

    override suspend fun softDelete(id: UUID, now: Instant) = tx { c ->
        c.prepareStatement("UPDATE communities SET deleted_at = ? WHERE id = ? AND deleted_at IS NULL").use { ps ->
            ps.ts(1, now); ps.setObject(2, id); ps.executeUpdate()
        }
        Unit
    }

    override suspend fun roleOf(communityId: UUID, accountId: UUID): String? = tx { c ->
        c.prepareStatement("SELECT role FROM community_members WHERE community_id = ? AND account_id = ?").use { ps ->
            ps.setObject(1, communityId); ps.setObject(2, accountId)
            ps.executeQuery().use { rs -> if (rs.next()) rs.getString(1) else null }
        }
    }

    override suspend fun addMember(communityId: UUID, accountId: UUID, role: String, now: Instant) = tx { c ->
        c.prepareStatement(
            "INSERT INTO community_members (community_id, account_id, role, joined_at) VALUES (?, ?, ?, ?) ON CONFLICT DO NOTHING",
        ).use { ps -> ps.setObject(1, communityId); ps.setObject(2, accountId); ps.setString(3, role); ps.ts(4, now); ps.executeUpdate() }
        Unit
    }

    override suspend fun removeMember(communityId: UUID, accountId: UUID): Boolean = tx { c ->
        c.prepareStatement("DELETE FROM community_members WHERE community_id = ? AND account_id = ? AND role <> 'owner'").use { ps ->
            ps.setObject(1, communityId); ps.setObject(2, accountId); ps.executeUpdate() > 0
        }
    }

    override suspend fun setRole(communityId: UUID, accountId: UUID, role: String) = tx { c ->
        c.prepareStatement("UPDATE community_members SET role = ? WHERE community_id = ? AND account_id = ? AND role <> 'owner'").use { ps ->
            ps.setString(1, role); ps.setObject(2, communityId); ps.setObject(3, accountId); ps.executeUpdate()
        }
        Unit
    }

    override suspend fun transferOwnership(communityId: UUID, from: UUID, to: UUID) = tx { c ->
        c.prepareStatement("UPDATE community_members SET role = 'admin' WHERE community_id = ? AND account_id = ? AND role = 'owner'").use { ps ->
            ps.setObject(1, communityId); ps.setObject(2, from); ps.executeUpdate()
        }
        c.prepareStatement("UPDATE community_members SET role = 'owner' WHERE community_id = ? AND account_id = ?").use { ps ->
            ps.setObject(1, communityId); ps.setObject(2, to); ps.executeUpdate()
        }
        c.prepareStatement("UPDATE communities SET owner_id = ? WHERE id = ?").use { ps ->
            ps.setObject(1, to); ps.setObject(2, communityId); ps.executeUpdate()
        }
        c.prepareStatement("DELETE FROM community_mutes WHERE community_id = ? AND account_id = ?").use { ps ->
            ps.setObject(1, communityId); ps.setObject(2, to); ps.executeUpdate()
        }
        Unit
    }

    override suspend fun setMuted(communityId: UUID, accountId: UUID, mutedBy: UUID, muted: Boolean, now: Instant) = tx { c ->
        if (muted) {
            c.prepareStatement("INSERT INTO community_mutes (community_id, account_id, muted_by, created_at) VALUES (?, ?, ?, ?) ON CONFLICT DO NOTHING").use { ps ->
                ps.setObject(1, communityId); ps.setObject(2, accountId); ps.setObject(3, mutedBy); ps.ts(4, now); ps.executeUpdate()
            }
        } else {
            c.prepareStatement("DELETE FROM community_mutes WHERE community_id = ? AND account_id = ?").use { ps ->
                ps.setObject(1, communityId); ps.setObject(2, accountId); ps.executeUpdate()
            }
        }
        Unit
    }

    override suspend fun isMuted(communityId: UUID, accountId: UUID) = tx { c -> exists(c, "community_mutes", communityId, accountId) }

    override suspend fun mutedAmong(communityId: UUID, accountIds: Collection<UUID>): Set<UUID> {
        if (accountIds.isEmpty()) return emptySet()
        return tx { c ->
            c.prepareStatement("SELECT account_id FROM community_mutes WHERE community_id = ? AND account_id IN (${accountIds.joinToString(",") { "?" }})").use { ps ->
                ps.setObject(1, communityId)
                accountIds.forEachIndexed { i, id -> ps.setObject(i + 2, id) }
                ps.executeQuery().use { rs -> buildSet { while (rs.next()) add(rs.getObject(1, UUID::class.java)) } }
            }
        }
    }

    override suspend fun inviterOf(communityId: UUID, accountId: UUID): UUID? = tx { c ->
        c.prepareStatement("SELECT invited_by FROM community_invites WHERE community_id = ? AND account_id = ?").use { ps ->
            ps.setObject(1, communityId); ps.setObject(2, accountId)
            ps.executeQuery().use { rs -> if (rs.next()) rs.getObject(1, UUID::class.java) else null }
        }
    }

    private fun people(c: Connection, table: String, atCol: String, roleCol: String?, communityId: UUID, limit: Int, after: app.winkwink.server.profile.PageCursor?): List<PersonRow> {
        val roleSel = roleCol?.let { ", t.$it" } ?: ""
        val cursorSql = if (after != null) "AND (t.$atCol, t.account_id) < (?, ?)" else ""
        val sql = "SELECT $PERSON_COLS, t.$atCol AS edge_at$roleSel FROM $table t JOIN profiles p ON p.account_id = t.account_id $ACTIVE " +
            "WHERE t.community_id = ? $cursorSql ORDER BY t.$atCol DESC, t.account_id DESC LIMIT ?"
        return c.prepareStatement(sql).use { ps ->
            var i = 1
            ps.setObject(i++, communityId)
            if (after != null) { ps.ts(i++, after.at); ps.setObject(i++, after.id) }
            ps.setInt(i, limit)
            ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.person(roleCol, "edge_at")) } }
        }
    }

    override suspend fun members(communityId: UUID, limit: Int, after: PageCursorKey?) =
        tx { c -> people(c, "community_members", "joined_at", "role", communityId, limit, after) }

    override suspend fun requests(communityId: UUID, limit: Int, after: PageCursorKey?) =
        tx { c -> people(c, "community_join_requests", "created_at", null, communityId, limit, after) }

    private fun exists(c: Connection, table: String, communityId: UUID, accountId: UUID) =
        c.prepareStatement("SELECT 1 FROM $table WHERE community_id = ? AND account_id = ?").use { ps ->
            ps.setObject(1, communityId); ps.setObject(2, accountId); ps.executeQuery().use { it.next() }
        }

    override suspend fun hasRequest(communityId: UUID, accountId: UUID) = tx { c -> exists(c, "community_join_requests", communityId, accountId) }

    override suspend fun addRequest(communityId: UUID, accountId: UUID, now: Instant) = tx { c ->
        c.prepareStatement("INSERT INTO community_join_requests (community_id, account_id, created_at) VALUES (?, ?, ?) ON CONFLICT DO NOTHING").use { ps ->
            ps.setObject(1, communityId); ps.setObject(2, accountId); ps.ts(3, now); ps.executeUpdate()
        }
        Unit
    }

    override suspend fun removeRequest(communityId: UUID, accountId: UUID): Boolean = tx { c ->
        c.prepareStatement("DELETE FROM community_join_requests WHERE community_id = ? AND account_id = ?").use { ps ->
            ps.setObject(1, communityId); ps.setObject(2, accountId); ps.executeUpdate() > 0
        }
    }

    override suspend fun hasInvite(communityId: UUID, accountId: UUID) = tx { c -> exists(c, "community_invites", communityId, accountId) }

    override suspend fun addInvite(communityId: UUID, accountId: UUID, invitedBy: UUID, now: Instant) = tx { c ->
        c.prepareStatement("INSERT INTO community_invites (community_id, account_id, invited_by, created_at) VALUES (?, ?, ?, ?) ON CONFLICT DO NOTHING").use { ps ->
            ps.setObject(1, communityId); ps.setObject(2, accountId); ps.setObject(3, invitedBy); ps.ts(4, now); ps.executeUpdate()
        }
        Unit
    }

    override suspend fun removeInvite(communityId: UUID, accountId: UUID): Boolean = tx { c ->
        c.prepareStatement("DELETE FROM community_invites WHERE community_id = ? AND account_id = ?").use { ps ->
            ps.setObject(1, communityId); ps.setObject(2, accountId); ps.executeUpdate() > 0
        }
    }

    private fun communityList(c: Connection, from: String, cursorExpr: String, where: String, binds: List<Any>, limit: Int, after: PageCursorKey?): List<CommunityRow> {
        val cursorSql = if (after != null) "AND ($cursorExpr, c.id) < (?, ?)" else ""
        val sql = "SELECT $COMMUNITY_COLS, $cursorExpr AS cursor_at FROM $from WHERE c.deleted_at IS NULL AND $where $cursorSql " +
            "ORDER BY $cursorExpr DESC, c.id DESC LIMIT ?"
        return c.prepareStatement(sql).use { ps ->
            var i = 1
            binds.forEach { ps.setObject(i++, it) }
            if (after != null) { ps.ts(i++, after.at); ps.setObject(i++, after.id) }
            ps.setInt(i, limit)
            ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.community("cursor_at")) } }
        }
    }

    override suspend fun invitesFor(accountId: UUID, limit: Int, after: PageCursorKey?) = tx { c ->
        communityList(c, "community_invites i JOIN communities c ON c.id = i.community_id", "i.created_at", "i.account_id = ?", listOf(accountId), limit, after)
    }

    override suspend fun memberships(accountId: UUID, limit: Int, after: PageCursorKey?) = tx { c ->
        communityList(c, "community_members m JOIN communities c ON c.id = m.community_id", "m.joined_at", "m.account_id = ?", listOf(accountId), limit, after)
    }

    override suspend fun search(viewer: UUID, query: String, limit: Int, after: PageCursorKey?) = tx { c ->
        communityList(
            c, "communities c", "c.created_at",
            "lower(c.name) LIKE ? ESCAPE '\\' AND (c.type IN ('public', 'private') OR EXISTS " +
                "(SELECT 1 FROM community_members sm WHERE sm.community_id = c.id AND sm.account_id = ?))",
            listOf("%${escapeLike(query)}%", viewer), limit, after,
        )
    }

    override suspend fun channels(communityId: UUID): List<ChannelRow> = tx { c ->
        c.prepareStatement("SELECT id, community_id, name, created_at FROM community_channels WHERE community_id = ? ORDER BY created_at, id").use { ps ->
            ps.setObject(1, communityId)
            ps.executeQuery().use { rs ->
                buildList { while (rs.next()) add(ChannelRow(rs.uuid("id"), rs.uuid("community_id"), rs.getString("name"), rs.getTimestamp("created_at").toInstant())) }
            }
        }
    }

    override suspend fun addChannel(communityId: UUID, name: String, now: Instant): UUID = tx { c ->
        c.prepareStatement("INSERT INTO community_channels (community_id, name, created_at) VALUES (?, ?, ?) RETURNING id").use { ps ->
            ps.setObject(1, communityId); ps.setString(2, name); ps.ts(3, now)
            ps.executeQuery().use { rs -> rs.next(); rs.uuid("id") }
        }
    }

    override suspend fun channelNameTaken(communityId: UUID, name: String): Boolean = tx { c ->
        c.prepareStatement("SELECT 1 FROM community_channels WHERE community_id = ? AND lower(name) = lower(?)").use { ps ->
            ps.setObject(1, communityId); ps.setString(2, name); ps.executeQuery().use { it.next() }
        }
    }

    override suspend fun deleteChannel(communityId: UUID, channelId: UUID): Boolean = tx { c ->
        c.prepareStatement("DELETE FROM community_channels WHERE community_id = ? AND id = ?").use { ps ->
            ps.setObject(1, communityId); ps.setObject(2, channelId); ps.executeUpdate() > 0
        }
    }
}
