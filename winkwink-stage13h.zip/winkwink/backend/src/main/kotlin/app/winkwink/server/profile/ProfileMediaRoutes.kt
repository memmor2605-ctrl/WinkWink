package app.winkwink.server.profile

import app.winkwink.server.api.ApiException
import app.winkwink.server.auth.JWT_AUTH
import app.winkwink.server.auth.UserPrincipal
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.auth.authenticate
import io.ktor.server.auth.principal
import io.ktor.server.request.contentLength
import io.ktor.server.request.contentType
import io.ktor.server.request.receive
import io.ktor.server.response.header
import io.ktor.server.response.respond
import io.ktor.server.response.respondBytes
import io.ktor.server.routing.Route
import io.ktor.server.routing.delete
import io.ktor.server.routing.get
import io.ktor.server.routing.put

private fun ApplicationCall.viewer() =
    (principal<UserPrincipal>() ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")).accountId

private val ALLOWED = setOf("image/jpeg", "image/png")

/**
 * Surowe ciało = obraz (bez multipartu). Wymagamy Content-Length, żeby odrzucić zbyt duży plik zanim trafi do pamięci;
 * prawdziwy typ i tak ustala sygnatura bajtów w [app.winkwink.server.media.ImageProcessor].
 */
private suspend fun ApplicationCall.imageBytes(max: Int): ByteArray {
    val len = request.contentLength()
        ?: throw ApiException(HttpStatusCode.LengthRequired, "length_required", "Content-Length is required.")
    if (len > max) throw ApiException(HttpStatusCode.PayloadTooLarge, "payload_too_large", "Image is too large.")
    val type = request.contentType()
    if ("${type.contentType}/${type.contentSubtype}".lowercase() !in ALLOWED) {
        throw ApiException(HttpStatusCode.UnsupportedMediaType, "unsupported_media_type", "Content-Type must be image/jpeg or image/png.")
    }
    val bytes = receive<ByteArray>()
    if (bytes.size > max) throw ApiException(HttpStatusCode.PayloadTooLarge, "payload_too_large", "Image is too large.")
    return bytes
}

private suspend fun ApplicationCall.respondImage(file: MediaFile) {
    // Wersjonowanie po stronie klienta (avatarTag/backgroundTag w URL) pozwala na długie, ale prywatne cache'owanie.
    response.header(HttpHeaders.CacheControl, "private, max-age=86400")
    response.header("Content-Security-Policy", "default-src 'none'; sandbox")
    response.header(HttpHeaders.ContentDisposition, "inline")
    respondBytes(file.bytes, ContentType.parse(file.mime))
}

fun Route.profileMediaRoutes(media: ProfileMediaService) {
    authenticate(JWT_AUTH) {
        put("/me/avatar") {
            val v = call.viewer()
            call.respond(media.upload(v, ProfileImageKind.AVATAR, call.imageBytes(ProfileImageKind.AVATAR.maxUploadBytes)).toDto())
        }
        delete("/me/avatar") { call.respond(media.remove(call.viewer(), ProfileImageKind.AVATAR).toDto()) }
        put("/me/background") {
            val v = call.viewer()
            call.respond(media.upload(v, ProfileImageKind.BACKGROUND, call.imageBytes(ProfileImageKind.BACKGROUND.maxUploadBytes)).toDto())
        }
        delete("/me/background") { call.respond(media.remove(call.viewer(), ProfileImageKind.BACKGROUND).toDto()) }

        get("/users/{id}/avatar") {
            val id = call.parameters["id"] ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "Missing user identifier.")
            call.respondImage(media.download(call.viewer(), id, ProfileImageKind.AVATAR))
        }
        get("/users/{id}/background") {
            val id = call.parameters["id"] ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "Missing user identifier.")
            call.respondImage(media.download(call.viewer(), id, ProfileImageKind.BACKGROUND))
        }
    }
}
