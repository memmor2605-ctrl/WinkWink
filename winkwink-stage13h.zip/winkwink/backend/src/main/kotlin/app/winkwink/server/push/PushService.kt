package app.winkwink.server.push

import app.winkwink.server.api.ApiException
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.slf4j.LoggerFactory
import java.time.Clock
import java.util.UUID

/** Wiadomość do odbiorcy. [preview] jest wysyłany tylko, gdy odbiorca włączył podgląd treści. */
data class PushMessage(
    val conversationId: UUID, val messageId: UUID, val group: Boolean, val groupTitle: String?,
    val senderName: String, val preview: String?, val attachmentKind: String?,
)

/** Powiadomienie społecznościowe zapisane w tabeli `notifications` (id służy do deduplikacji i oznaczania jako przeczytane). */
data class PushNotification(
    val notificationId: UUID, val type: String, val actorName: String?, val actorWinkwinkId: String?,
    val postId: UUID?, val commentId: UUID?, val communityId: UUID?,
)

/** Wejście push dla reszty backendu. Wszystko „fire and forget” — błąd push nigdy nie psuje właściwej operacji. */
interface PushGateway {
    fun message(recipient: UUID, m: PushMessage) {}
    fun notification(recipient: UUID, n: PushNotification) {}
    /** Prosi urządzenia konta o zdjęcie wyświetlonych powiadomień (przeczytane na innym urządzeniu). */
    fun dismiss(recipient: UUID, notificationId: String?, conversationId: String?, exceptSession: UUID?) {}
    /** Zdarzenie bezpieczeństwa konta: `password_changed` | `new_login`. */
    fun accountEvent(recipient: UUID, event: String, exceptSession: UUID?) {}
    suspend fun forgetSession(session: UUID) {}
    suspend fun forgetOthers(account: UUID, keepSession: UUID) {}

    object None : PushGateway
}

class PushService(
    private val store: PushStore,
    private val sender: PushSender,
    /** Czy konto ma teraz otwarte połączenie WSS (aplikacja na pierwszym planie) — wtedy push byłby duplikatem. */
    private val isOnline: (UUID) -> Boolean,
    private val clock: Clock = Clock.systemUTC(),
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO),
) : PushGateway {
    private val log = LoggerFactory.getLogger("app.winkwink.push")

    companion object {
        private val TOKEN = Regex("^[A-Za-z0-9_:.\\-]{20,4096}$")
        const val NOTIFICATION_PREVIEW_MAX = 120
    }

    suspend fun register(account: UUID, session: UUID, token: String, deviceName: String?) {
        if (!TOKEN.matches(token)) throw ApiException(HttpStatusCode.BadRequest, "validation_failed", "token: invalid")
        val name = deviceName?.trim()?.take(100)?.takeIf { it.isNotEmpty() }
        store.upsertToken(account, session, token, name, clock.instant())
    }

    suspend fun unregister(account: UUID, token: String) { store.deleteToken(account, token) } // idempotentne

    suspend fun prefs(account: UUID) = store.prefs(account)
    suspend fun setPrefs(account: UUID, messages: Boolean?, previews: Boolean?) = store.setPrefs(account, messages, previews).let { store.prefs(account) }

    override suspend fun forgetSession(session: UUID) = store.deleteBySession(session)
    override suspend fun forgetOthers(account: UUID, keepSession: UUID) = store.deleteForAccountExcept(account, keepSession)

    override fun message(recipient: UUID, m: PushMessage) = launchSend(recipient, null) {
        if (isOnline(recipient)) return@launchSend null // aplikacja na pierwszym planie dostaje wiadomość przez WSS
        val prefs = store.prefs(recipient)
        if (!prefs.messages) return@launchSend null
        val data = mutableMapOf(
            "type" to "message", "conversationId" to m.conversationId.toString(), "messageId" to m.messageId.toString(),
            "group" to m.group.toString(), "sender" to m.senderName,
        )
        m.groupTitle?.let { data["title"] = it }
        m.attachmentKind?.let { data["attachment"] = it }
        if (prefs.previews && !m.preview.isNullOrBlank()) data["preview"] = m.preview.take(NOTIFICATION_PREVIEW_MAX)
        Triple(data, "conv-${m.conversationId}", true)
    }

    override fun notification(recipient: UUID, n: PushNotification) = launchSend(recipient, null) {
        val data = mutableMapOf("type" to n.type, "notificationId" to n.notificationId.toString())
        n.actorName?.let { data["actor"] = it }
        n.actorWinkwinkId?.let { data["actorId"] = it }
        n.postId?.let { data["postId"] = it.toString() }
        n.commentId?.let { data["commentId"] = it.toString() }
        n.communityId?.let { data["communityId"] = it.toString() }
        Triple(data, "n-${n.notificationId}", false)
    }

    override fun dismiss(recipient: UUID, notificationId: String?, conversationId: String?, exceptSession: UUID?) = launchSend(recipient, exceptSession) {
        val data = mutableMapOf("type" to "dismiss")
        notificationId?.let { data["notificationId"] = it }
        conversationId?.let { data["conversationId"] = it }
        Triple(data, null, false)
    }

    override fun accountEvent(recipient: UUID, event: String, exceptSession: UUID?) = launchSend(recipient, exceptSession) {
        Triple(mapOf("type" to "account", "event" to event), "account-$event", true)
    }

    /** [build] zwraca (dane, collapseKey, priorytet) albo null = nie wysyłaj. */
    private fun launchSend(recipient: UUID, exceptSession: UUID?, build: suspend () -> Triple<Map<String, String>, String?, Boolean>?) {
        if (!sender.enabled) return
        scope.launch {
            try {
                val (data, collapse, high) = build() ?: return@launch
                for (token in store.tokens(recipient, exceptSession)) {
                    when (sender.send(token, data, collapse, high)) {
                        PushResult.InvalidToken -> store.deleteTokenValue(token) // wygasły / odinstalowana aplikacja
                        else -> Unit
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log.warn("push_failed error={}", e.javaClass.simpleName)
            }
        }
    }
}
