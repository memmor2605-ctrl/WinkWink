package app.winkwink.server.community

import kotlinx.serialization.Serializable

@Serializable
data class CommunityDto(
    val id: String,
    val name: String,
    val description: String,
    val rules: String,
    val type: String,
    val memberCount: Int,
    /** owner | admin | moderator | member albo null. */
    val myRole: String? = null,
    /** member | requested | invited | none */
    val myStatus: String = "none",
    val createdAt: String,
)

@Serializable data class CommunityListResponse(val communities: List<CommunityDto>, val nextCursor: String? = null)

@Serializable
data class PersonDto(val winkwinkId: String, val nickname: String, val displayName: String? = null, val role: String? = null, val at: String, val muted: Boolean = false)

@Serializable data class PersonListResponse(val people: List<PersonDto>, val nextCursor: String? = null)
@Serializable data class ChannelDto(val id: String, val name: String)
@Serializable data class ChannelListResponse(val channels: List<ChannelDto>)
@Serializable data class JoinResponse(val state: String)

@Serializable data class CreateCommunityRequest(val name: String, val description: String = "", val rules: String = "", val type: String = "public")
@Serializable data class UpdateCommunityRequest(val name: String? = null, val description: String? = null, val rules: String? = null, val type: String? = null)
@Serializable data class RoleRequest(val role: String)
@Serializable data class InviteRequest(val user: String)
@Serializable data class TransferOwnershipRequest(val user: String)
/** Wynik wyszukiwania osoby do zaproszenia: [invited] = zaproszenie już czeka. Członkowie są pomijani. */
@Serializable data class InviteCandidateDto(val winkwinkId: String, val nickname: String, val displayName: String? = null, val invited: Boolean = false)
@Serializable data class InviteCandidateListResponse(val candidates: List<InviteCandidateDto>)
@Serializable data class CreateChannelRequest(val name: String)

fun CommunityView.toDto() = community.toDto(myRole, myStatus)

fun CommunityRow.toDto(myRole: String? = null, myStatus: String = "none") = CommunityDto(
    id = id.toString(), name = name, description = description, rules = rules, type = type,
    memberCount = memberCount, myRole = myRole, myStatus = myStatus, createdAt = createdAt.toString(),
)

fun PersonRow.toDto() = PersonDto(winkwinkId, nickname, displayName, role, at.toString(), muted)
fun ChannelRow.toDto() = ChannelDto(id.toString(), name)
