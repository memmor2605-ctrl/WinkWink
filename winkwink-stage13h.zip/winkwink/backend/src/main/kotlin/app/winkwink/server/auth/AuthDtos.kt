package app.winkwink.server.auth

import kotlinx.serialization.Serializable

@Serializable
data class RegisterRequest(
    val email: String,
    val password: String,
    val nickname: String,
    val platform: String = "android",
    val deviceName: String? = null,
)

@Serializable
data class LoginRequest(
    val email: String,
    val password: String,
    val platform: String = "android",
    val deviceName: String? = null,
)

@Serializable
data class RefreshRequest(val refreshToken: String)

@Serializable
data class ForgotPasswordRequest(val email: String)

@Serializable
data class ResetPasswordRequest(val token: String, val newPassword: String)

@Serializable
data class ChangePasswordRequest(val currentPassword: String, val newPassword: String)

@Serializable
data class ProfileDto(
    val nickname: String,
    val winkwinkId: String,
    val bio: String?,
    val visibility: String,
)

@Serializable
data class MeResponse(val email: String, val profile: ProfileDto)

@Serializable
data class TokensDto(
    val sessionId: String,
    val accessToken: String,
    val accessExpiresAt: String,
    val refreshToken: String,
    val refreshExpiresAt: String,
)

@Serializable
data class AuthResponse(val tokens: TokensDto, val me: MeResponse)

@Serializable
data class SessionDto(
    val id: String,
    val platform: String?,
    val deviceName: String?,
    val createdAt: String,
    val lastUsedAt: String,
    val current: Boolean,
)

@Serializable
data class SessionsResponse(val sessions: List<SessionDto>)

@Serializable
data class RevokedResponse(val revoked: Int)

fun ProfileRecord.toDto() = ProfileDto(nickname, winkwinkId, bio, visibility)

fun IssuedSession.toDto() = TokensDto(
    sessionId.toString(), accessToken, accessExpiresAt.toString(), refreshToken, refreshExpiresAt.toString(),
)

fun AuthResult.toResponse() = AuthResponse(session.toDto(), MeResponse(email, profile.toDto()))

/** Potwierdzenie hasłem przy trwałym usunięciu konta. */
@kotlinx.serialization.Serializable
data class DeleteAccountRequest(val password: String)
