package app.winkwink.server.profile

import java.time.Instant
import java.util.UUID

data class UserRow(
    val accountId: UUID,
    val nickname: String,
    val winkwinkId: String,
    val displayName: String?,
    val bio: String?,
    val links: List<String>,
    val visibility: String, // public | followers | private
    val avatarObjectKey: String?,
    val backgroundObjectKey: String?,
    /** Ukrywa listy obserwujących/obserwowanych przed innymi (liczniki pozostają widoczne dla uprawnionych). */
    val hideFollowLists: Boolean = false,
)

/** Krawędź grafu (obserwujący / obserwowany / zablokowany) wraz z czasem do stronicowania kursorowego. */
data class Edge(val user: UserRow, val at: Instant)

data class PageCursor(val at: Instant, val id: UUID) {
    fun encode() = "${at}|$id"

    companion object {
        fun decode(raw: String?): PageCursor? {
            if (raw.isNullOrBlank()) return null
            val parts = raw.split('|')
            if (parts.size != 2) return null
            return runCatching { PageCursor(Instant.parse(parts[0]), UUID.fromString(parts[1])) }.getOrNull()
        }
    }
}

interface ProfileStore {
    suspend fun findByIdentifier(identifier: String): UserRow?
    suspend fun findById(accountId: UUID): UserRow?
    suspend fun updateProfile(accountId: UUID, displayName: String?, bio: String?, links: List<String>, visibility: String)

    suspend fun isBlockedEitherWay(a: UUID, b: UUID): Boolean
    suspend fun hasBlocked(blocker: UUID, blocked: UUID): Boolean

    /** @return "accepted", "pending" albo null. */
    suspend fun followState(follower: UUID, followee: UUID): String?
    suspend fun upsertFollow(follower: UUID, followee: UUID, status: String, now: Instant)
    suspend fun deleteFollow(follower: UUID, followee: UUID): Boolean
    suspend fun acceptPending(follower: UUID, followee: UUID): Boolean
    suspend fun rejectPending(follower: UUID, followee: UUID): Boolean
    suspend fun followerCount(accountId: UUID): Int
    suspend fun followingCount(accountId: UUID): Int

    suspend fun listFollowers(accountId: UUID, limit: Int, after: PageCursor?): List<Edge>
    suspend fun listFollowing(accountId: UUID, limit: Int, after: PageCursor?): List<Edge>
    suspend fun listPendingRequests(accountId: UUID, limit: Int, after: PageCursor?): List<Edge>

    /** Zapisuje blokadę i atomowo usuwa obserwowanie w obu kierunkach. */
    suspend fun addBlock(blocker: UUID, blocked: UUID, now: Instant)
    suspend fun removeBlock(blocker: UUID, blocked: UUID): Boolean
    suspend fun listBlocks(blocker: UUID, limit: Int, after: PageCursor?): List<Edge>

    suspend fun search(viewer: UUID, query: String, limit: Int): List<UserRow>

    /** Ustawia klucz obiektu avatara/tła (null = usunięcie). @return poprzedni klucz, żeby wołający mógł usunąć stary plik. */
    suspend fun setAvatarKey(accountId: UUID, key: String?): String?
    suspend fun setBackgroundKey(accountId: UUID, key: String?): String?
    suspend fun setHideFollowLists(accountId: UUID, hide: Boolean)

    /** Wyciszenie jest prywatne dla [muter]: nie zmienia widoczności [muter] dla [muted] i nigdy nie powiadamia [muted]. Idempotentne. */
    suspend fun addMute(muter: UUID, muted: UUID, now: Instant)
    suspend fun removeMute(muter: UUID, muted: UUID): Boolean
    suspend fun isMuted(muter: UUID, muted: UUID): Boolean
    suspend fun listMutes(muter: UUID, limit: Int, after: PageCursor?): List<Edge>
}
