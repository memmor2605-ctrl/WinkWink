package app.winkwink.server.feed

import app.winkwink.server.api.ApiException
import app.winkwink.server.media.ImageProcessor
import app.winkwink.server.media.InvalidImageException
import app.winkwink.server.media.MediaKeys
import app.winkwink.server.media.MediaSniffer
import app.winkwink.server.media.MediaStorage
import app.winkwink.server.media.deleteQuietly
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Clock
import java.time.Duration
import java.util.UUID

class AttachmentFile(val stored: app.winkwink.server.media.StoredObject, val mime: String, val kind: String, val fileName: String?) {
    /** Cała treść w pamięci — tylko dla testów i małych plików; trasy strumieniują przez [stored]. */
    val bytes: ByteArray get() = stored.open().use { it.readBytes() }
}

/**
 * Załączniki postów na wspólnej warstwie [MediaStorage]. Dwa kroki: (1) wysłanie pliku → identyfikator niedołączonego załącznika,
 * widocznego tylko dla właściciela; (2) dołączenie przy tworzeniu posta ([FeedService.create]).
 * Pobieranie: dostęp do pliku = dostęp do posta (te same reguły widoczności, w tym blokady i członkostwo w społeczności).
 */
class AttachmentService(
    private val extras: PostExtrasStore,
    private val feed: FeedStore,
    private val storage: MediaStorage,
    private val clock: Clock = Clock.systemUTC(),
) {
    companion object {
        const val IMAGE_MAX_BYTES = 8 * 1024 * 1024
        const val VIDEO_MAX_BYTES = 30 * 1024 * 1024
        const val DOCUMENT_MAX_BYTES = 10 * 1024 * 1024
        const val IMAGE_MAX_EDGE = 2048
        const val MAX_PENDING = 20
        private const val PURGE_BATCH = 200
        val PENDING_TTL: Duration = Duration.ofHours(24)

        fun maxBytesFor(declaredMime: String): Int? = when (MediaSniffer.declaredKind(declaredMime)) {
            "image" -> IMAGE_MAX_BYTES
            "video" -> VIDEO_MAX_BYTES
            "document" -> DOCUMENT_MAX_BYTES
            else -> null
        }

        private fun notFound() = ApiException(HttpStatusCode.NotFound, "attachment_not_found", "Attachment not found.")
    }

    suspend fun upload(viewer: UUID, raw: ByteArray, declaredMime: String, rawName: String?): AttachmentRow {
        val declared = MediaSniffer.declaredKind(declaredMime)
            ?: throw ApiException(HttpStatusCode.UnsupportedMediaType, "unsupported_media_type", "Allowed: image/jpeg, image/png, video/mp4, application/pdf.")
        if (raw.isEmpty()) throw ApiException(HttpStatusCode.BadRequest, "validation_failed", "Empty body.")
        val limit = maxBytesFor(declaredMime)!!
        if (raw.size > limit) throw ApiException(HttpStatusCode.PayloadTooLarge, "payload_too_large", "File is larger than ${limit / (1024 * 1024)} MB.")
        val (kind, _) = MediaSniffer.classify(raw)
            ?: throw ApiException(HttpStatusCode.UnsupportedMediaType, "unsupported_media_type", "File content does not match an allowed type.")
        if (kind != declared) throw ApiException(HttpStatusCode.UnsupportedMediaType, "unsupported_media_type", "Content-Type does not match the file.")
        if (extras.pendingCount(viewer) >= MAX_PENDING) {
            throw ApiException(HttpStatusCode.TooManyRequests, "too_many_pending", "Too many unattached uploads; publish or delete some first.")
        }

        var bytes = raw
        var mime = MediaSniffer.classify(raw)!!.second
        var width: Int? = null
        var height: Int? = null
        if (kind == "image") {
            val processed = try {
                withContext(Dispatchers.Default) { ImageProcessor.process(raw, IMAGE_MAX_EDGE) }
            } catch (e: InvalidImageException) {
                val status = when (e.code) {
                    "unsupported_media_type" -> HttpStatusCode.UnsupportedMediaType
                    "image_too_large" -> HttpStatusCode.PayloadTooLarge
                    else -> HttpStatusCode.BadRequest
                }
                throw ApiException(status, e.code, e.message ?: "Invalid image.")
            }
            bytes = processed.bytes
            mime = processed.mime
            MediaSniffer.dimensions(bytes)?.let { (w, h) -> width = w; height = h }
        }
        // Nazwę przechowujemy tylko dla dokumentów; zdjęcia i filmy nie mają nazwy (brak metadanych o pochodzeniu pliku).
        val name = if (kind == "document") MediaSniffer.sanitizeFileName(rawName) ?: "document.pdf" else null

        val key = MediaKeys.newKey("post")
        storage.put(key, bytes)
        val row = AttachmentRow(UUID.randomUUID(), viewer, null, 0, kind, mime, bytes.size.toLong(), key, name, width, height, clock.instant())
        try {
            extras.createAttachment(row)
        } catch (e: Throwable) {
            storage.deleteQuietly(key)
            throw e
        }
        return row
    }

    suspend fun deletePending(viewer: UUID, id: UUID) {
        val row = extras.deletePending(viewer, id) ?: throw notFound()
        storage.deleteQuietly(row.objectKey) // wiersza już nie ma; ewentualny plik zbierze rekoncyliacja magazynu
    }

    suspend fun download(viewer: UUID, id: UUID): AttachmentFile {
        val row = extras.getAttachment(id) ?: throw notFound()
        val postId = row.postId
        if (postId == null) {
            if (row.ownerId != viewer) throw notFound()
        } else if (feed.getPost(postId, viewer) == null) {
            throw notFound() // post niewidoczny, usunięty albo zablokowany — nie zdradzamy istnienia pliku
        }
        val stored = storage.open(row.objectKey) ?: throw notFound()
        return AttachmentFile(stored, row.mime, row.kind, row.fileName)
    }

    /**
     * Pliki usuniętych postów: wiersz załącznika znika z bazy, potem plik z magazynu (błąd IO → plik zbierze [MediaReconciler]).
     * Post jest usuwany logicznie (`deleted_at`), a jego pliki już wcześniej są niepobieralne (dostęp = widoczność posta).
     */
    suspend fun purgeDeletedPosts(): Int {
        var total = 0
        while (true) {
            val keys = extras.purgeForDeletedPosts(PURGE_BATCH)
            keys.forEach { storage.deleteQuietly(it) }
            total += keys.size
            if (keys.size < PURGE_BATCH) break
        }
        return total
    }

    /** Sprzątanie porzuconych (niedołączonych) wysyłek; wołać okresowo. Zwraca liczbę usuniętych plików. */
    suspend fun purgeAbandoned(): Int {
        val keys = extras.purgePending(clock.instant().minus(PENDING_TTL))
        keys.forEach { storage.deleteQuietly(it) }
        return keys.size
    }
}
