package app.winkwink.server.community

import java.time.Instant
import java.util.UUID

data class CommunityRow(
    val id: UUID,
    val name: String,
    val description: String,
    val rules: String,
    /** public | private | invite */
    val type: String,
    val ownerId: UUID,
    val createdAt: Instant,
    val memberCount: Int,
    /** Klucz stronicowania zależny od listy (czas dołączenia, zaproszenia lub utworzenia). */
    val cursorAt: Instant = createdAt,
)

/** Osoba na liście członków / próśb. [role] = null dla próśb o dołączenie. */
data class PersonRow(
    val accountId: UUID,
    val nickname: String,
    val winkwinkId: String,
    val displayName: String?,
    val role: String?,
    val at: Instant,
    /** Wyciszony członek nie może pisać w społeczności (posty i komentarze). */
    val muted: Boolean = false,
)

data class ChannelRow(val id: UUID, val communityId: UUID, val name: String, val createdAt: Instant)

interface CommunityStore {
    /** Tworzy społeczność, członkostwo właściciela i kanał domyślny w jednej transakcji. */
    suspend fun create(ownerId: UUID, name: String, description: String, rules: String, type: String, defaultChannel: String, now: Instant): UUID
    suspend fun find(id: UUID): CommunityRow?
    suspend fun nameTakenByOther(name: String, exceptId: UUID?): Boolean
    suspend fun update(id: UUID, name: String, description: String, rules: String, type: String)
    suspend fun softDelete(id: UUID, now: Instant)

    suspend fun roleOf(communityId: UUID, accountId: UUID): String?
    suspend fun addMember(communityId: UUID, accountId: UUID, role: String, now: Instant)
    suspend fun removeMember(communityId: UUID, accountId: UUID): Boolean
    suspend fun setRole(communityId: UUID, accountId: UUID, role: String)
    suspend fun members(communityId: UUID, limit: Int, after: PageCursorKey?): List<PersonRow>
    /** Atomowo: [to] zostaje właścicielem (owner_id i rola), [from] — administratorem. */
    suspend fun transferOwnership(communityId: UUID, from: UUID, to: UUID)

    suspend fun setMuted(communityId: UUID, accountId: UUID, mutedBy: UUID, muted: Boolean, now: Instant)
    suspend fun isMuted(communityId: UUID, accountId: UUID): Boolean
    suspend fun mutedAmong(communityId: UUID, accountIds: Collection<UUID>): Set<UUID>

    suspend fun hasRequest(communityId: UUID, accountId: UUID): Boolean
    suspend fun addRequest(communityId: UUID, accountId: UUID, now: Instant)
    suspend fun removeRequest(communityId: UUID, accountId: UUID): Boolean
    suspend fun requests(communityId: UUID, limit: Int, after: PageCursorKey?): List<PersonRow>

    suspend fun hasInvite(communityId: UUID, accountId: UUID): Boolean
    suspend fun addInvite(communityId: UUID, accountId: UUID, invitedBy: UUID, now: Instant)
    suspend fun removeInvite(communityId: UUID, accountId: UUID): Boolean
    suspend fun inviterOf(communityId: UUID, accountId: UUID): UUID?
    suspend fun invitesFor(accountId: UUID, limit: Int, after: PageCursorKey?): List<CommunityRow>

    suspend fun memberships(accountId: UUID, limit: Int, after: PageCursorKey?): List<CommunityRow>
    /** Społeczności public i private dopasowane po nazwie oraz „invite”, których widz jest członkiem. */
    suspend fun search(viewer: UUID, query: String, limit: Int, after: PageCursorKey?): List<CommunityRow>

    suspend fun channels(communityId: UUID): List<ChannelRow>
    suspend fun addChannel(communityId: UUID, name: String, now: Instant): UUID
    suspend fun channelNameTaken(communityId: UUID, name: String): Boolean
    suspend fun deleteChannel(communityId: UUID, channelId: UUID): Boolean
}

/** Klucz kursora: (czas, id) — taki sam kształt jak [app.winkwink.server.profile.PageCursor]. */
typealias PageCursorKey = app.winkwink.server.profile.PageCursor
