package app.winkwink.server.profile

import app.winkwink.server.notification.NotificationEvent
import app.winkwink.server.notification.NotificationTypes
import app.winkwink.server.notification.Notifier
import app.winkwink.server.api.ApiException
import io.ktor.http.HttpStatusCode
import java.net.URI
import java.time.Clock
import java.util.UUID

data class Relationship(val isSelf: Boolean, val following: String, val followedBy: Boolean)

/** [full] = false oznacza widok ograniczony (profil prywatny / tylko dla obserwujących, a widz nie obserwuje). */
data class UserView(
    val user: UserRow,
    val relationship: Relationship,
    val full: Boolean,
    val followers: Int?,
    val following: Int?,
    val muted: Boolean = false,
)

data class EdgePage(val items: List<Edge>, val nextCursor: String?)

class ProfileService(
    private val store: ProfileStore,
    private val clock: Clock = Clock.systemUTC(),
    private val notifier: Notifier = Notifier.None,
) {

    companion object {
        const val MAX_LIMIT = 50
        const val DEFAULT_LIMIT = 20
        val VISIBILITIES = setOf("public", "followers", "private")
        private fun notFound() = ApiException(HttpStatusCode.NotFound, "user_not_found", "User not found.")
        private fun bad(msg: String) = ApiException(HttpStatusCode.BadRequest, "validation_failed", msg, listOf(msg))

        fun clampLimit(raw: Int?) = (raw ?: DEFAULT_LIMIT).coerceIn(1, MAX_LIMIT)

        /** Linki: tylko https, maks. 5, do 200 znaków, z hostem. Zapobiega javascript:/data: i śledzeniu przez http. */
        fun validateLinks(links: List<String>): List<String> {
            if (links.size > 5) throw bad("links: at most 5")
            return links.map { raw ->
                val l = raw.trim()
                if (l.length > 200) throw bad("links: each link at most 200 characters")
                val uri = runCatching { URI(l) }.getOrNull()
                if (uri == null || !"https".equals(uri.scheme, true) || uri.host.isNullOrBlank()) {
                    throw bad("links: only valid https:// links are allowed")
                }
                l
            }.distinct()
        }
    }

    private suspend fun resolve(viewer: UUID, identifier: String): UserRow {
        val id = identifier.trim().removePrefix("@")
        if (id.isEmpty() || id.length > 40) throw notFound()
        val user = store.findByIdentifier(id) ?: throw notFound()
        // Blokada w którąkolwiek stronę: profil jest nieodróżnialny od nieistniejącego.
        if (user.accountId != viewer && store.isBlockedEitherWay(viewer, user.accountId)) throw notFound()
        return user
    }

    private suspend fun canSeeFull(viewer: UUID, user: UserRow): Boolean = when {
        user.accountId == viewer -> true
        user.visibility == "public" -> true
        else -> store.followState(viewer, user.accountId) == "accepted"
    }

    suspend fun view(viewer: UUID, identifier: String): UserView {
        val user = resolve(viewer, identifier)
        val self = user.accountId == viewer
        val state = if (self) null else store.followState(viewer, user.accountId)
        val followedBy = if (self) false else store.followState(user.accountId, viewer) == "accepted"
        val full = self || user.visibility == "public" || state == "accepted"
        return UserView(
            user = user,
            relationship = Relationship(self, state ?: "none", followedBy),
            full = full,
            followers = if (full) store.followerCount(user.accountId) else null,
            following = if (full) store.followingCount(user.accountId) else null,
            muted = if (self) false else store.isMuted(viewer, user.accountId),
        )
    }

    suspend fun updateMine(
        accountId: UUID, displayName: String?, bio: String?, links: List<String>?, visibility: String?, clearDisplayName: Boolean = false,
        hideFollowLists: Boolean? = null,
    ): UserView {
        val current = store.findById(accountId) ?: throw notFound()
        val newDisplay = when {
            clearDisplayName -> null
            displayName != null -> displayName.trim().also { if (it.length !in 1..50) throw bad("displayName: 1-50 characters") }
            else -> current.displayName
        }
        // bio == null → bez zmian; pusty ciąg → wyczyszczenie.
        val newBio = if (bio == null) current.bio else bio.trim().also { if (it.length > 280) throw bad("bio: at most 280 characters") }.ifEmpty { null }
        val newLinks = links?.let { validateLinks(it) } ?: current.links
        val newVis = visibility?.also { if (it !in VISIBILITIES) throw bad("visibility: public, followers or private") } ?: current.visibility
        store.updateProfile(accountId, newDisplay, newBio, newLinks, newVis)
        if (hideFollowLists != null) store.setHideFollowLists(accountId, hideFollowLists)
        // Przejście na „prywatny” nie usuwa istniejących obserwujących; oczekujące prośby pozostają do decyzji właściciela.
        return view(accountId, current.winkwinkId)
    }

    /** @return stan relacji po operacji: "accepted" albo "pending". */
    suspend fun follow(viewer: UUID, identifier: String): String {
        val target = resolve(viewer, identifier)
        if (target.accountId == viewer) throw ApiException(HttpStatusCode.BadRequest, "cannot_follow_self", "You cannot follow yourself.")
        store.followState(viewer, target.accountId)?.let { return it }
        val status = if (target.visibility == "public") "accepted" else "pending"
        store.upsertFollow(viewer, target.accountId, status, clock.instant())
        val type = if (status == "pending") NotificationTypes.FOLLOW_REQUEST else NotificationTypes.NEW_FOLLOWER
        notifier.notify(NotificationEvent(type, recipient = target.accountId, actor = viewer))
        return store.followState(viewer, target.accountId) ?: status
    }

    suspend fun unfollow(viewer: UUID, identifier: String) {
        val target = resolve(viewer, identifier)
        store.deleteFollow(viewer, target.accountId) // idempotentne
    }

    suspend fun pendingRequests(owner: UUID, limit: Int?, cursor: String?) = page(store.listPendingRequests(owner, clampLimit(limit) + 1, PageCursor.decode(cursor)), clampLimit(limit))

    suspend fun respondToRequest(owner: UUID, followerIdentifier: String, approve: Boolean) {
        val follower = store.findByIdentifier(followerIdentifier.trim().removePrefix("@")) ?: throw notFound()
        val ok = if (approve) store.acceptPending(follower.accountId, owner) else store.rejectPending(follower.accountId, owner)
        if (!ok) throw ApiException(HttpStatusCode.NotFound, "request_not_found", "No pending follow request from this user.")
    }

    private fun page(rows: List<Edge>, limit: Int): EdgePage {
        val items = rows.take(limit)
        val next = if (rows.size > limit) items.last().let { PageCursor(it.at, it.user.accountId).encode() } else null
        return EdgePage(items, next)
    }

    suspend fun followers(viewer: UUID, identifier: String, limit: Int?, cursor: String?): EdgePage {
        val user = resolve(viewer, identifier)
        requireFull(viewer, user)
        requireListsVisible(viewer, user)
        val l = clampLimit(limit)
        return page(store.listFollowers(user.accountId, l + 1, PageCursor.decode(cursor)).filterNot { hidden(viewer, it) }, l)
    }

    suspend fun following(viewer: UUID, identifier: String, limit: Int?, cursor: String?): EdgePage {
        val user = resolve(viewer, identifier)
        requireFull(viewer, user)
        requireListsVisible(viewer, user)
        val l = clampLimit(limit)
        return page(store.listFollowing(user.accountId, l + 1, PageCursor.decode(cursor)).filterNot { hidden(viewer, it) }, l)
    }

    private suspend fun hidden(viewer: UUID, e: Edge) = e.user.accountId != viewer && store.isBlockedEitherWay(viewer, e.user.accountId)

    private fun requireListsVisible(viewer: UUID, user: UserRow) {
        if (user.hideFollowLists && user.accountId != viewer) {
            throw ApiException(HttpStatusCode.Forbidden, "follow_lists_hidden", "This user keeps their follower lists private.")
        }
    }

    private suspend fun requireFull(viewer: UUID, user: UserRow) {
        if (!canSeeFull(viewer, user)) {
            throw ApiException(HttpStatusCode.Forbidden, "profile_restricted", "This profile is not visible to you.")
        }
    }

    suspend fun block(viewer: UUID, identifier: String) {
        val id = identifier.trim().removePrefix("@")
        val target = store.findByIdentifier(id) ?: throw notFound()
        if (target.accountId == viewer) throw ApiException(HttpStatusCode.BadRequest, "cannot_block_self", "You cannot block yourself.")
        store.addBlock(viewer, target.accountId, clock.instant())
    }

    suspend fun unblock(viewer: UUID, identifier: String) {
        val target = store.findByIdentifier(identifier.trim().removePrefix("@")) ?: throw notFound()
        store.removeBlock(viewer, target.accountId)
    }

    suspend fun blocked(viewer: UUID, limit: Int?, cursor: String?): EdgePage {
        val l = clampLimit(limit)
        return page(store.listBlocks(viewer, l + 1, PageCursor.decode(cursor)), l)
    }

    /**
     * Wyciszenie: prywatne, bez powiadomienia i bez efektu widocznego dla wyciszanego. Nie usuwa obserwowania.
     * Wyciszony użytkownik ma ukryte jawne posty i komentarze w widokach zbiorczych oraz powiadomienia; treści ANONIMOWE
     * nie są filtrowane (ich zniknięcie po wyciszeniu podejrzanej osoby zdradzałoby autora).
     */
    suspend fun mute(viewer: UUID, identifier: String) {
        val target = resolve(viewer, identifier)
        if (target.accountId == viewer) throw ApiException(HttpStatusCode.BadRequest, "cannot_mute_self", "You cannot mute yourself.")
        store.addMute(viewer, target.accountId, clock.instant())
    }

    suspend fun unmute(viewer: UUID, identifier: String) {
        val target = store.findByIdentifier(identifier.trim().removePrefix("@")) ?: throw notFound()
        store.removeMute(viewer, target.accountId) // idempotentne
    }

    suspend fun muted(viewer: UUID, limit: Int?, cursor: String?): EdgePage {
        val l = clampLimit(limit)
        return page(store.listMutes(viewer, l + 1, PageCursor.decode(cursor)), l)
    }

    suspend fun search(viewer: UUID, rawQuery: String, limit: Int?): List<UserRow> {
        val q = rawQuery.trim().removePrefix("@")
        if (q.length < 2) throw bad("q: at least 2 characters")
        if (q.length > 40) throw bad("q: at most 40 characters")
        return store.search(viewer, q, clampLimit(limit))
    }
}
