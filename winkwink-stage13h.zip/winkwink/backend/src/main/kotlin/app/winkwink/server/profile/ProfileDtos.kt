package app.winkwink.server.profile

import kotlinx.serialization.Serializable

/** Widok ograniczony ma bio/links/liczniki = null. Nigdy nie zawiera e-maila ani identyfikatora konta. */
@Serializable
data class UserProfileDto(
    val winkwinkId: String,
    val nickname: String,
    val displayName: String?,
    val bio: String?,
    val links: List<String>?,
    val visibility: String,
    val hasAvatar: Boolean,
    val hasBackground: Boolean,
    val restricted: Boolean,
    val followers: Int?,
    val following: Int?,
    val isSelf: Boolean,
    /** none | pending | accepted */
    val followState: String,
    val followedByThem: Boolean,
    /** Znacznik wersji obrazu (zmienia się po każdej zmianie) — do unieważniania pamięci podręcznej klienta. */
    val avatarTag: String? = null,
    val backgroundTag: String? = null,
    /** Czy ZALOGOWANY widz wyciszył tego użytkownika. Wyciszany nigdy się o tym nie dowiaduje. */
    val muted: Boolean = false,
    /** Czy właściciel ukrył listy obserwujących/obserwowanych (dla właściciela: jego własne ustawienie). */
    val followListsHidden: Boolean = false,
)

@Serializable
data class UserSummaryDto(val winkwinkId: String, val nickname: String, val displayName: String?, val hasAvatar: Boolean, val visibility: String, val avatarTag: String? = null)

@Serializable
data class UserListResponse(val users: List<UserSummaryDto>, val nextCursor: String? = null)

@Serializable
data class UpdateProfileRequest(
    val displayName: String? = null,
    val clearDisplayName: Boolean = false,
    val bio: String? = null,
    val links: List<String>? = null,
    val visibility: String? = null,
    val hideFollowLists: Boolean? = null,
)

@Serializable
data class FollowResponse(val state: String)

/** Znacznik z klucza obiektu (losowy UUID; sam w sobie nie daje dostępu do pliku — pobranie wymaga uwierzytelnienia). */
fun mediaTag(key: String?): String? = key?.substringAfterLast('/')?.takeLast(12)

fun UserRow.toSummary() = UserSummaryDto(winkwinkId, nickname, displayName, avatarObjectKey != null, visibility, mediaTag(avatarObjectKey))

fun UserView.toDto() = UserProfileDto(
    winkwinkId = user.winkwinkId,
    nickname = user.nickname,
    displayName = user.displayName,
    bio = if (full) user.bio else null,
    links = if (full) user.links else null,
    visibility = user.visibility,
    hasAvatar = user.avatarObjectKey != null,
    hasBackground = full && user.backgroundObjectKey != null,
    restricted = !full,
    followers = followers,
    following = following,
    isSelf = relationship.isSelf,
    followState = relationship.following,
    followedByThem = relationship.followedBy,
    avatarTag = mediaTag(user.avatarObjectKey),
    backgroundTag = if (full) mediaTag(user.backgroundObjectKey) else null,
    muted = muted,
    followListsHidden = user.hideFollowLists,
)

fun EdgePage.toResponse() = UserListResponse(items.map { it.user.toSummary() }, nextCursor)
