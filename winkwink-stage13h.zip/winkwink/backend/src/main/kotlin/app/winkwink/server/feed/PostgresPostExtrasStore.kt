package app.winkwink.server.feed

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.Timestamp
import java.time.Instant
import java.util.UUID
import javax.sql.DataSource

class PostgresPostExtrasStore(private val dataSource: DataSource) : PostExtrasStore {

    private suspend fun <T> tx(block: (Connection) -> T): T = withContext(Dispatchers.IO) {
        dataSource.connection.use { c ->
            c.autoCommit = false
            try { block(c).also { c.commit() } } catch (e: Throwable) { c.rollback(); throw e }
        }
    }

    private fun bind(ps: PreparedStatement, args: List<Any?>) {
        args.forEachIndexed { i, a ->
            when (a) {
                is Instant -> ps.setTimestamp(i + 1, Timestamp.from(a))
                else -> ps.setObject(i + 1, a)
            }
        }
    }

    private fun ResultSet.attachment() = AttachmentRow(
        id = getObject("id", UUID::class.java),
        ownerId = getObject("owner_id", UUID::class.java),
        postId = getObject("post_id", UUID::class.java),
        position = getInt("position"),
        kind = getString("kind"),
        mime = getString("mime"),
        sizeBytes = getLong("size_bytes"),
        objectKey = getString("object_key"),
        fileName = getString("file_name"),
        width = getInt("width").takeUnless { wasNull() },
        height = getInt("height").takeUnless { wasNull() },
        createdAt = getTimestamp("created_at").toInstant(),
    )

    private companion object {
        const val COLS = "id, owner_id, post_id, position, kind, mime, size_bytes, object_key, file_name, width, height, created_at"
        fun placeholders(n: Int) = List(n) { "?" }.joinToString(",")
    }

    override suspend fun createAttachment(row: AttachmentRow) {
        tx { c ->
            c.prepareStatement("INSERT INTO post_attachments ($COLS) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").use { ps ->
                bind(ps, listOf(row.id, row.ownerId, row.postId, row.position, row.kind, row.mime, row.sizeBytes, row.objectKey, row.fileName, row.width, row.height, row.createdAt))
                ps.executeUpdate()
            }
        }
    }

    override suspend fun getAttachment(id: UUID): AttachmentRow? = tx { c ->
        c.prepareStatement("SELECT $COLS FROM post_attachments WHERE id = ?").use { ps ->
            bind(ps, listOf(id)); ps.executeQuery().use { rs -> if (rs.next()) rs.attachment() else null }
        }
    }

    override suspend fun pendingCount(owner: UUID): Int = tx { c ->
        c.prepareStatement("SELECT count(*) FROM post_attachments WHERE owner_id = ? AND post_id IS NULL").use { ps ->
            bind(ps, listOf(owner)); ps.executeQuery().use { rs -> rs.next(); rs.getInt(1) }
        }
    }

    override suspend fun deletePending(owner: UUID, id: UUID): AttachmentRow? = tx { c ->
        c.prepareStatement("DELETE FROM post_attachments WHERE id = ? AND owner_id = ? AND post_id IS NULL RETURNING $COLS").use { ps ->
            bind(ps, listOf(id, owner)); ps.executeQuery().use { rs -> if (rs.next()) rs.attachment() else null }
        }
    }

    override suspend fun attach(owner: UUID, postId: UUID, ids: List<UUID>): Boolean = tx { c ->
        var ok = true
        ids.forEachIndexed { index, id ->
            val n = c.prepareStatement("UPDATE post_attachments SET post_id = ?, position = ? WHERE id = ? AND owner_id = ? AND post_id IS NULL").use { ps ->
                bind(ps, listOf(postId, index, id, owner)); ps.executeUpdate()
            }
            if (n != 1) ok = false
        }
        if (!ok) c.rollback()
        ok
    }

    override suspend fun forPosts(postIds: Collection<UUID>): Map<UUID, List<AttachmentRow>> {
        if (postIds.isEmpty()) return emptyMap()
        return tx { c ->
            c.prepareStatement("SELECT $COLS FROM post_attachments WHERE post_id IN (${placeholders(postIds.size)}) ORDER BY position, created_at, id").use { ps ->
                bind(ps, postIds.toList())
                ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.attachment()) } }
            }.groupBy { it.postId!! }
        }
    }

    override suspend fun setShare(postId: UUID, originalId: UUID) {
        tx { c ->
            c.prepareStatement("INSERT INTO post_shares (post_id, original_id) VALUES (?, ?) ON CONFLICT DO NOTHING").use { ps ->
                bind(ps, listOf(postId, originalId)); ps.executeUpdate()
            }
        }
    }

    override suspend fun originalsOf(postIds: Collection<UUID>): Map<UUID, UUID> {
        if (postIds.isEmpty()) return emptyMap()
        return tx { c ->
            c.prepareStatement("SELECT post_id, original_id FROM post_shares WHERE post_id IN (${placeholders(postIds.size)})").use { ps ->
                bind(ps, postIds.toList())
                ps.executeQuery().use { rs -> buildMap { while (rs.next()) put(rs.getObject(1, UUID::class.java), rs.getObject(2, UUID::class.java)) } }
            }
        }
    }

    override suspend fun publicShareCounts(originalIds: Collection<UUID>): Map<UUID, Int> {
        if (originalIds.isEmpty()) return emptyMap()
        return tx { c ->
            c.prepareStatement(
                "SELECT s.original_id, count(*) FROM post_shares s JOIN posts p ON p.id = s.post_id " +
                    "WHERE s.original_id IN (${placeholders(originalIds.size)}) AND p.deleted_at IS NULL AND p.visibility = 'public' GROUP BY s.original_id",
            ).use { ps ->
                bind(ps, originalIds.toList())
                ps.executeQuery().use { rs -> buildMap { while (rs.next()) put(rs.getObject(1, UUID::class.java), rs.getInt(2)) } }
            }
        }
    }

    override suspend fun purgePending(before: Instant): List<String> = tx { c ->
        c.prepareStatement("DELETE FROM post_attachments WHERE post_id IS NULL AND created_at < ? RETURNING object_key").use { ps ->
            bind(ps, listOf(before)); ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.getString(1)) } }
        }
    }

    override suspend fun purgeForDeletedPosts(limit: Int): List<String> = tx { c ->
        c.prepareStatement(
            "DELETE FROM post_attachments WHERE id IN (" +
                "SELECT a.id FROM post_attachments a JOIN posts p ON p.id = a.post_id WHERE p.deleted_at IS NOT NULL ORDER BY a.created_at LIMIT ?) " +
                "RETURNING object_key",
        ).use { ps ->
            bind(ps, listOf(limit)); ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.getString(1)) } }
        }
    }
}
