package app.winkwink.server.auth

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.postgresql.util.PSQLException
import java.sql.Connection
import java.sql.ResultSet
import java.sql.SQLException
import java.sql.Timestamp
import java.time.Instant
import java.util.UUID
import javax.sql.DataSource

class PostgresAuthStore(private val dataSource: DataSource) : AuthStore {

    private suspend fun <T> tx(block: (Connection) -> T): T = withContext(Dispatchers.IO) {
        dataSource.connection.use { c ->
            c.autoCommit = false
            try {
                val result = block(c)
                c.commit()
                result
            } catch (e: Throwable) {
                c.rollback()
                throw e
            }
        }
    }

    private fun ts(i: Instant) = Timestamp.from(i)

    private fun mapUnique(e: SQLException): Exception {
        if (e.sqlState == "23505") {
            val constraint = (e as? PSQLException)?.serverErrorMessage?.constraint.orEmpty()
            val field = when {
                "email" in constraint -> "email"
                "nickname" in constraint -> "nickname"
                "winkwink_id" in constraint -> "winkwink_id"
                else -> null
            }
            if (field != null) return DuplicateException(field)
        }
        return e
    }

    private fun ResultSet.account() = Account(
        getObject("id", UUID::class.java), getString("email"), getString("password_hash"), getString("status"),
    )

    override suspend fun createAccount(email: String, passwordHash: String, nickname: String, winkwinkId: String): Account =
        try {
            tx { c ->
                val id = c.prepareStatement("INSERT INTO accounts (email, password_hash) VALUES (?, ?) RETURNING id").use { ps ->
                    ps.setString(1, email)
                    ps.setString(2, passwordHash)
                    ps.executeQuery().use { rs -> rs.next(); rs.getObject(1, UUID::class.java) }
                }
                c.prepareStatement("INSERT INTO profiles (account_id, nickname, winkwink_id) VALUES (?, ?, ?)").use { ps ->
                    ps.setObject(1, id)
                    ps.setString(2, nickname)
                    ps.setString(3, winkwinkId)
                    ps.executeUpdate()
                }
                Account(id, email, passwordHash, "active")
            }
        } catch (e: SQLException) {
            throw mapUnique(e)
        }

    override suspend fun findAccountByEmail(email: String): Account? = tx { c ->
        c.prepareStatement("SELECT id, email, password_hash, status FROM accounts WHERE lower(email) = lower(?)").use { ps ->
            ps.setString(1, email)
            ps.executeQuery().use { rs -> if (rs.next()) rs.account() else null }
        }
    }

    override suspend fun findAccountById(id: UUID): Account? = tx { c ->
        c.prepareStatement("SELECT id, email, password_hash, status FROM accounts WHERE id = ?").use { ps ->
            ps.setObject(1, id)
            ps.executeQuery().use { rs -> if (rs.next()) rs.account() else null }
        }
    }

    override suspend fun findProfile(accountId: UUID): ProfileRecord? = tx { c ->
        c.prepareStatement("SELECT account_id, nickname, winkwink_id, bio, visibility FROM profiles WHERE account_id = ?").use { ps ->
            ps.setObject(1, accountId)
            ps.executeQuery().use { rs ->
                if (rs.next()) ProfileRecord(
                    rs.getObject("account_id", UUID::class.java), rs.getString("nickname"),
                    rs.getString("winkwink_id"), rs.getString("bio"), rs.getString("visibility"),
                ) else null
            }
        }
    }

    override suspend fun updatePasswordHash(accountId: UUID, passwordHash: String) {
        tx { c ->
            c.prepareStatement("UPDATE accounts SET password_hash = ? WHERE id = ?").use { ps ->
                ps.setString(1, passwordHash)
                ps.setObject(2, accountId)
                ps.executeUpdate()
            }
        }
    }

    override suspend fun createSession(
        accountId: UUID, platform: String, deviceName: String?, userAgent: String?,
        refreshHash: ByteArray, now: Instant, expiresAt: Instant,
    ): UUID = tx { c ->
        val deviceId = c.prepareStatement(
            "INSERT INTO devices (account_id, platform, name, created_at, last_seen_at) VALUES (?, ?, ?, ?, ?) RETURNING id",
        ).use { ps ->
            ps.setObject(1, accountId)
            ps.setString(2, platform)
            ps.setString(3, deviceName)
            ps.setTimestamp(4, ts(now))
            ps.setTimestamp(5, ts(now))
            ps.executeQuery().use { rs -> rs.next(); rs.getObject(1, UUID::class.java) }
        }
        c.prepareStatement(
            "INSERT INTO sessions (account_id, device_id, refresh_token_hash, user_agent, created_at, last_used_at, expires_at) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id",
        ).use { ps ->
            ps.setObject(1, accountId)
            ps.setObject(2, deviceId)
            ps.setBytes(3, refreshHash)
            ps.setString(4, userAgent)
            ps.setTimestamp(5, ts(now))
            ps.setTimestamp(6, ts(now))
            ps.setTimestamp(7, ts(expiresAt))
            ps.executeQuery().use { rs -> rs.next(); rs.getObject(1, UUID::class.java) }
        }
    }

    override suspend fun findSessionByRefreshHash(hash: ByteArray): FoundSession? = tx { c ->
        c.prepareStatement(
            "SELECT id, account_id, expires_at, revoked_at, (refresh_token_hash = ?) AS is_current FROM sessions " +
                "WHERE refresh_token_hash = ? OR previous_refresh_token_hash = ?",
        ).use { ps ->
            ps.setBytes(1, hash); ps.setBytes(2, hash); ps.setBytes(3, hash)
            ps.executeQuery().use { rs ->
                if (rs.next()) FoundSession(
                    rs.getObject("id", UUID::class.java), rs.getObject("account_id", UUID::class.java),
                    rs.getTimestamp("expires_at").toInstant(), rs.getTimestamp("revoked_at")?.toInstant(),
                    rs.getBoolean("is_current"),
                ) else null
            }
        }
    }

    override suspend fun rotateSession(
        sessionId: UUID, expectedCurrentHash: ByteArray, newHash: ByteArray, now: Instant, newExpiresAt: Instant,
    ): Boolean = tx { c ->
        val updated = c.prepareStatement(
            "UPDATE sessions SET previous_refresh_token_hash = refresh_token_hash, refresh_token_hash = ?, " +
                "last_used_at = ?, expires_at = ? WHERE id = ? AND refresh_token_hash = ? AND revoked_at IS NULL",
        ).use { ps ->
            ps.setBytes(1, newHash)
            ps.setTimestamp(2, ts(now))
            ps.setTimestamp(3, ts(newExpiresAt))
            ps.setObject(4, sessionId)
            ps.setBytes(5, expectedCurrentHash)
            ps.executeUpdate()
        }
        if (updated > 0) {
            c.prepareStatement("UPDATE devices SET last_seen_at = ? WHERE id = (SELECT device_id FROM sessions WHERE id = ?)").use { ps ->
                ps.setTimestamp(1, ts(now))
                ps.setObject(2, sessionId)
                ps.executeUpdate()
            }
        }
        updated > 0
    }

    override suspend fun isSessionActive(sessionId: UUID, accountId: UUID, now: Instant): Boolean = tx { c ->
        c.prepareStatement(
            "SELECT 1 FROM sessions s JOIN accounts a ON a.id = s.account_id " +
                "WHERE s.id = ? AND s.account_id = ? AND s.revoked_at IS NULL AND s.expires_at > ? AND a.status = 'active'",
        ).use { ps ->
            ps.setObject(1, sessionId)
            ps.setObject(2, accountId)
            ps.setTimestamp(3, ts(now))
            ps.executeQuery().use { it.next() }
        }
    }

    override suspend fun revokeSession(sessionId: UUID, accountId: UUID, now: Instant): Boolean = tx { c ->
        c.prepareStatement("UPDATE sessions SET revoked_at = ? WHERE id = ? AND account_id = ? AND revoked_at IS NULL").use { ps ->
            ps.setTimestamp(1, ts(now))
            ps.setObject(2, sessionId)
            ps.setObject(3, accountId)
            ps.executeUpdate() > 0
        }
    }

    override suspend fun revokeSessionById(sessionId: UUID, now: Instant) {
        tx { c ->
            c.prepareStatement("UPDATE sessions SET revoked_at = ? WHERE id = ? AND revoked_at IS NULL").use { ps ->
                ps.setTimestamp(1, ts(now))
                ps.setObject(2, sessionId)
                ps.executeUpdate()
            }
        }
    }

    override suspend fun revokeAllSessions(accountId: UUID, exceptSessionId: UUID?, now: Instant): Int = tx { c ->
        c.prepareStatement(
            "UPDATE sessions SET revoked_at = ? WHERE account_id = ? AND revoked_at IS NULL " +
                "AND (?::uuid IS NULL OR id <> ?::uuid)",
        ).use { ps ->
            ps.setTimestamp(1, ts(now))
            ps.setObject(2, accountId)
            ps.setObject(3, exceptSessionId)
            ps.setObject(4, exceptSessionId)
            ps.executeUpdate()
        }
    }

    override suspend fun listSessions(accountId: UUID, now: Instant): List<SessionView> = tx { c ->
        c.prepareStatement(
            "SELECT s.id, d.platform, d.name, s.created_at, s.last_used_at, s.user_agent FROM sessions s " +
                "LEFT JOIN devices d ON d.id = s.device_id " +
                "WHERE s.account_id = ? AND s.revoked_at IS NULL AND s.expires_at > ? ORDER BY s.last_used_at DESC",
        ).use { ps ->
            ps.setObject(1, accountId)
            ps.setTimestamp(2, ts(now))
            ps.executeQuery().use { rs ->
                buildList {
                    while (rs.next()) add(
                        SessionView(
                            rs.getObject("id", UUID::class.java), rs.getString("platform"), rs.getString("name"),
                            rs.getTimestamp("created_at").toInstant(), rs.getTimestamp("last_used_at").toInstant(),
                            rs.getString("user_agent"),
                        ),
                    )
                }
            }
        }
    }

    override suspend fun recordAttempt(keyHash: String, at: Instant) {
        tx { c ->
            c.prepareStatement("INSERT INTO login_attempts (key_hash, attempted_at) VALUES (?, ?)").use { ps ->
                ps.setString(1, keyHash)
                ps.setTimestamp(2, ts(at))
                ps.executeUpdate()
            }
            // Przycinanie starych wpisów, by tabela nie rosła bez końca.
            c.prepareStatement("DELETE FROM login_attempts WHERE attempted_at < ?").use { ps ->
                ps.setTimestamp(1, ts(at.minusSeconds(86_400)))
                ps.executeUpdate()
            }
        }
    }

    override suspend fun countAttempts(keyHash: String, since: Instant): Int = tx { c ->
        c.prepareStatement("SELECT count(*) FROM login_attempts WHERE key_hash = ? AND attempted_at >= ?").use { ps ->
            ps.setString(1, keyHash)
            ps.setTimestamp(2, ts(since))
            ps.executeQuery().use { rs -> rs.next(); rs.getInt(1) }
        }
    }

    override suspend fun clearAttempts(keyHash: String) {
        tx { c ->
            c.prepareStatement("DELETE FROM login_attempts WHERE key_hash = ?").use { ps ->
                ps.setString(1, keyHash)
                ps.executeUpdate()
            }
        }
    }

    override suspend fun createResetToken(accountId: UUID, tokenHash: ByteArray, now: Instant, expiresAt: Instant) {
        tx { c ->
            c.prepareStatement("UPDATE password_reset_tokens SET used_at = ? WHERE account_id = ? AND used_at IS NULL").use { ps ->
                ps.setTimestamp(1, ts(now))
                ps.setObject(2, accountId)
                ps.executeUpdate()
            }
            c.prepareStatement("INSERT INTO password_reset_tokens (account_id, token_hash, created_at, expires_at) VALUES (?, ?, ?, ?)").use { ps ->
                ps.setObject(1, accountId)
                ps.setBytes(2, tokenHash)
                ps.setTimestamp(3, ts(now))
                ps.setTimestamp(4, ts(expiresAt))
                ps.executeUpdate()
            }
        }
    }

    override suspend fun consumeResetToken(tokenHash: ByteArray, now: Instant): UUID? = tx { c ->
        c.prepareStatement(
            "UPDATE password_reset_tokens SET used_at = ? WHERE token_hash = ? AND used_at IS NULL AND expires_at > ? RETURNING account_id",
        ).use { ps ->
            ps.setTimestamp(1, ts(now))
            ps.setBytes(2, tokenHash)
            ps.setTimestamp(3, ts(now))
            ps.executeQuery().use { rs -> if (rs.next()) rs.getObject(1, UUID::class.java) else null }
        }
    }

    override suspend fun deleteAccount(accountId: UUID): Boolean = tx { c ->
        // Jedna instrukcja = jedna transakcja: wszystkie klucze obce kierujące do accounts mają ON DELETE CASCADE (V2–V16).
        c.prepareStatement("DELETE FROM accounts WHERE id = ?").use { ps -> ps.setObject(1, accountId); ps.executeUpdate() > 0 }
    }
}
