package app.winkwink.server.profile

import app.winkwink.server.api.ApiException
import app.winkwink.server.media.ImageProcessor
import app.winkwink.server.media.InvalidImageException
import app.winkwink.server.media.MediaKeys
import app.winkwink.server.media.MediaStorage
import app.winkwink.server.media.deleteQuietly
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

enum class ProfileImageKind(val category: String, val maxUploadBytes: Int, val maxEdge: Int) {
    AVATAR("avatar", 2 * 1024 * 1024, 1024),
    BACKGROUND("background", 5 * 1024 * 1024, 2048),
}

class MediaFile(val bytes: ByteArray, val mime: String)

/**
 * Avatar i zdjęcie w tle. Pliki leżą w [MediaStorage] (nie w PostgreSQL); w bazie jest tylko klucz.
 * Dostęp: avatar widzi każdy zalogowany, który może zobaczyć profil (blokada → 404); tło tylko ten, kto widzi pełny profil.
 */
class ProfileMediaService(
    private val store: ProfileStore,
    private val profiles: ProfileService,
    private val storage: MediaStorage,
) {
    companion object {
        private fun notFound() = ApiException(HttpStatusCode.NotFound, "media_not_found", "Image not found.")
    }

    suspend fun upload(viewer: UUID, kind: ProfileImageKind, raw: ByteArray): UserView {
        if (raw.isEmpty()) throw ApiException(HttpStatusCode.BadRequest, "validation_failed", "Empty body.")
        if (raw.size > kind.maxUploadBytes) {
            throw ApiException(HttpStatusCode.PayloadTooLarge, "payload_too_large", "Image is larger than ${kind.maxUploadBytes / (1024 * 1024)} MB.")
        }
        val processed = try {
            withContext(Dispatchers.Default) { ImageProcessor.process(raw, kind.maxEdge) }
        } catch (e: InvalidImageException) {
            val status = when (e.code) {
                "unsupported_media_type" -> HttpStatusCode.UnsupportedMediaType
                "image_too_large" -> HttpStatusCode.PayloadTooLarge
                else -> HttpStatusCode.BadRequest
            }
            throw ApiException(status, e.code, e.message ?: "Invalid image.")
        }
        val key = MediaKeys.newKey(kind.category)
        storage.put(key, processed.bytes)
        val previous = try {
            setKey(viewer, kind, key)
        } catch (e: Throwable) {
            storage.deleteQuietly(key) // nie zostawiamy osieroconego pliku po nieudanym zapisie rekordu
            throw e
        }
        previous?.let { storage.deleteQuietly(it) }
        return profiles.view(viewer, viewerIdentifier(viewer))
    }

    suspend fun remove(viewer: UUID, kind: ProfileImageKind): UserView {
        setKey(viewer, kind, null)?.let { storage.deleteQuietly(it) } // idempotentne
        return profiles.view(viewer, viewerIdentifier(viewer))
    }

    suspend fun download(viewer: UUID, identifier: String, kind: ProfileImageKind): MediaFile {
        val view = profiles.view(viewer, identifier) // 404 dla zablokowanych i nieistniejących
        val key = when (kind) {
            ProfileImageKind.AVATAR -> view.user.avatarObjectKey
            ProfileImageKind.BACKGROUND -> if (view.full) view.user.backgroundObjectKey else null
        } ?: throw notFound()
        val bytes = storage.get(key) ?: throw notFound()
        return MediaFile(bytes, ImageProcessor.sniff(bytes) ?: "application/octet-stream")
    }

    private suspend fun setKey(viewer: UUID, kind: ProfileImageKind, key: String?): String? = when (kind) {
        ProfileImageKind.AVATAR -> store.setAvatarKey(viewer, key)
        ProfileImageKind.BACKGROUND -> store.setBackgroundKey(viewer, key)
    }

    private suspend fun viewerIdentifier(viewer: UUID): String =
        store.findById(viewer)?.winkwinkId ?: throw ApiException(HttpStatusCode.NotFound, "user_not_found", "User not found.")
}
