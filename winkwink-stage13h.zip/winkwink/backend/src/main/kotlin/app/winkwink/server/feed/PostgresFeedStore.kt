package app.winkwink.server.feed

import app.winkwink.server.profile.PageCursor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.Timestamp
import java.time.Instant
import java.util.UUID
import javax.sql.DataSource

class PostgresFeedStore(private val dataSource: DataSource) : FeedStore {

    private suspend fun <T> tx(block: (Connection) -> T): T = withContext(Dispatchers.IO) {
        dataSource.connection.use { c ->
            c.autoCommit = false
            try { block(c).also { c.commit() } } catch (e: Throwable) { c.rollback(); throw e }
        }
    }

    private fun bind(ps: PreparedStatement, args: List<Any?>) {
        args.forEachIndexed { i, a ->
            when (a) {
                is Instant -> ps.setTimestamp(i + 1, Timestamp.from(a))
                else -> ps.setObject(i + 1, a)
            }
        }
    }

    private companion object {
        const val SELECT_POST =
            "p.id, p.author_id, ap.nickname, ap.winkwink_id, ap.display_name, ap.avatar_object_key, p.body, p.visibility, p.anonymous, p.created_at, p.edited_at, p.community_id, p.channel_id, " +
                "(SELECT count(*) FROM post_reactions r WHERE r.post_id = p.id) AS reactions, " +
                "(SELECT count(*) FROM comments c WHERE c.post_id = p.id AND c.deleted_at IS NULL) AS comments, " +
                "(SELECT r.type FROM post_reactions r WHERE r.post_id = p.id AND r.account_id = ?) AS my_reaction, " +
                "EXISTS (SELECT 1 FROM post_saves s WHERE s.post_id = p.id AND s.account_id = ?) AS saved"
        const val FROM_POST =
            "posts p JOIN profiles ap ON ap.account_id = p.author_id JOIN accounts aa ON aa.id = p.author_id AND aa.status = 'active'"
        /**
         * Wyciszenie: ukrywa jawne posty wyciszonego w widokach zbiorczych (1 placeholder = identyfikator widza, na KOŃCU fragmentu WHERE).
         * Posty anonimowe nie są filtrowane — inaczej wyciszenie podejrzanej osoby ujawniałoby autora.
         */
        const val NOT_MUTED = "(p.anonymous OR NOT EXISTS (SELECT 1 FROM user_mutes um WHERE um.muter_id = ? AND um.muted_id = p.author_id))"
        const val FOLLOWS_AUTHOR =
            "EXISTS (SELECT 1 FROM follows f WHERE f.follower_id = ? AND f.followee_id = p.author_id AND f.status = 'accepted')"

        /** Odwzorowanie [PostVisibility.canView] w SQL. Zużywa VISIBLE_VIEWER_ARGS razy identyfikator widza (kolejność placeholderów!). */
        const val VISIBLE_VIEWER_ARGS = 6
        const val VISIBLE =
            "p.deleted_at IS NULL AND NOT EXISTS (SELECT 1 FROM blocks b WHERE (b.blocker_id = ? AND b.blocked_id = p.author_id AND NOT p.anonymous) OR (b.blocker_id = p.author_id AND b.blocked_id = ?)) " +
                "AND (p.author_id = ? OR (p.visibility = 'public' AND (ap.visibility = 'public' OR $FOLLOWS_AUTHOR)) OR (p.visibility = 'followers' AND $FOLLOWS_AUTHOR) " +
                "OR (p.visibility = 'community' AND EXISTS (SELECT 1 FROM community_members m JOIN communities cm ON cm.id = m.community_id AND cm.deleted_at IS NULL WHERE m.community_id = p.community_id AND m.account_id = ?)))"
    }

    private fun ResultSet.post() = PostRow(
        id = getObject("id", UUID::class.java),
        authorId = getObject("author_id", UUID::class.java),
        authorNickname = getString("nickname"),
        authorWinkwinkId = getString("winkwink_id"),
        authorDisplayName = getString("display_name"),
        body = getString("body"),
        visibility = getString("visibility"),
        anonymous = getBoolean("anonymous"),
        createdAt = getTimestamp("created_at").toInstant(),
        editedAt = getTimestamp("edited_at")?.toInstant(),
        reactions = getInt("reactions"),
        comments = getInt("comments"),
        myReaction = getString("my_reaction"),
        saved = getBoolean("saved"),
        cursorAt = getTimestamp("cursor_at").toInstant(),
        communityId = getObject("community_id", UUID::class.java),
        channelId = getObject("channel_id", UUID::class.java),
        authorAvatarKey = getString("avatar_object_key"),
    )

    /** Kolejność argumentów odpowiada kolejności placeholderów w tekście SQL: select, joins, VISIBLE, where, cursor, limit. */
    private fun query(
        c: Connection, viewer: UUID, where: String, whereArgs: List<Any?>, limit: Int, after: PageCursor?,
        joins: String = "", joinArgs: List<Any?> = emptyList(), keyExpr: String = "p.created_at",
    ): List<PostRow> {
        val args = mutableListOf<Any?>(viewer, viewer)
        args += joinArgs
        repeat(VISIBLE_VIEWER_ARGS) { args += viewer }
        args += whereArgs
        val cursorSql = if (after != null) { args += after.at; args += after.id; "AND ($keyExpr, p.id) < (?, ?)" } else ""
        args += limit
        val sql = "SELECT $SELECT_POST, $keyExpr AS cursor_at FROM $FROM_POST $joins WHERE $VISIBLE AND ($where) $cursorSql " +
            "ORDER BY $keyExpr DESC, p.id DESC LIMIT ?"
        return c.prepareStatement(sql).use { ps -> bind(ps, args); ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.post()) } } }
    }

    override suspend fun createPost(
        authorId: UUID, body: String, visibility: String, anonymous: Boolean, now: Instant, communityId: UUID?, channelId: UUID?,
    ): UUID = tx { c ->
        c.prepareStatement(
            "INSERT INTO posts (author_id, body, visibility, anonymous, created_at, community_id, channel_id) VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id",
        ).use { ps ->
            bind(ps, listOf(authorId, body, visibility, anonymous, now, communityId, channelId))
            ps.executeQuery().use { rs -> rs.next(); rs.getObject(1, UUID::class.java) }
        }
    }

    override suspend fun getPost(id: UUID, viewer: UUID): PostRow? = tx { c ->
        query(c, viewer, "p.id = ?", listOf(id), 1, null).firstOrNull()
    }

    override suspend fun updatePostBody(id: UUID, body: String, now: Instant): Boolean = tx { c ->
        c.prepareStatement("UPDATE posts SET body = ?, edited_at = ? WHERE id = ? AND deleted_at IS NULL").use { ps ->
            bind(ps, listOf(body, now, id)); ps.executeUpdate() > 0
        }
    }

    override suspend fun deletePost(id: UUID, now: Instant): Boolean = tx { c ->
        c.prepareStatement("UPDATE posts SET deleted_at = ? WHERE id = ? AND deleted_at IS NULL").use { ps ->
            bind(ps, listOf(now, id)); ps.executeUpdate() > 0
        }
    }

    override suspend fun followingFeed(viewer: UUID, limit: Int, after: PageCursor?) = tx { c ->
        query(
            c, viewer,
            "p.anonymous = false AND p.visibility <> 'private' AND (p.author_id = ? OR EXISTS (SELECT 1 FROM follows f WHERE f.follower_id = ? AND f.followee_id = p.author_id AND f.status = 'accepted')) AND $NOT_MUTED",
            listOf(viewer, viewer, viewer), limit, after,
        )
    }

    override suspend fun discoverFeed(viewer: UUID, limit: Int, after: PageCursor?) = tx { c ->
        // Wykluczenie obserwowanych/własnych dotyczy tylko postów jawnych — anonimowe są zawsze dopuszczone,
        // inaczej zniknięcie posta z Discover zdradzałoby, że autor jest obserwowany przez widza.
        query(
            c, viewer,
            "p.visibility = 'public' AND (p.anonymous OR (p.author_id <> ? AND NOT EXISTS (SELECT 1 FROM follows f WHERE f.follower_id = ? AND f.followee_id = p.author_id))) AND $NOT_MUTED",
            listOf(viewer, viewer, viewer), limit, after,
        )
    }

    override suspend fun userPosts(viewer: UUID, authorId: UUID, limit: Int, after: PageCursor?) = tx { c ->
        query(c, viewer, "p.author_id = ? AND p.anonymous = false", listOf(authorId), limit, after)
    }

    override suspend fun communityPosts(viewer: UUID, communityId: UUID, channelId: UUID?, limit: Int, after: PageCursor?) = tx { c ->
        if (channelId == null) query(c, viewer, "p.visibility = 'community' AND p.community_id = ? AND $NOT_MUTED", listOf(communityId, viewer), limit, after)
        else query(c, viewer, "p.visibility = 'community' AND p.community_id = ? AND p.channel_id = ? AND $NOT_MUTED", listOf(communityId, channelId, viewer), limit, after)
    }

    override suspend fun communityRole(communityId: UUID, accountId: UUID): String? = tx { c ->
        c.prepareStatement(
            "SELECT m.role FROM community_members m JOIN communities cm ON cm.id = m.community_id AND cm.deleted_at IS NULL WHERE m.community_id = ? AND m.account_id = ?",
        ).use { ps -> bind(ps, listOf(communityId, accountId)); ps.executeQuery().use { rs -> if (rs.next()) rs.getString(1) else null } }
    }

    override suspend fun communityMuted(communityId: UUID, accountId: UUID): Boolean = tx { c ->
        c.prepareStatement("SELECT 1 FROM community_mutes WHERE community_id = ? AND account_id = ?").use { ps ->
            bind(ps, listOf(communityId, accountId)); ps.executeQuery().use { it.next() }
        }
    }

    override suspend fun channelInCommunity(communityId: UUID, channelId: UUID): Boolean = tx { c ->
        c.prepareStatement("SELECT 1 FROM community_channels WHERE id = ? AND community_id = ?").use { ps ->
            bind(ps, listOf(channelId, communityId)); ps.executeQuery().use { it.next() }
        }
    }

    private fun likeEscape(s: String) = s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    override suspend fun searchPosts(viewer: UUID, query: String, limit: Int, after: PageCursor?) = tx { c ->
        query(c, viewer, "p.visibility <> 'private' AND lower(p.body) LIKE ? ESCAPE '\\' AND $NOT_MUTED", listOf("%" + likeEscape(query.lowercase()) + "%", viewer), limit, after)
    }

    override suspend fun savedPosts(viewer: UUID, limit: Int, after: PageCursor?) = tx { c ->
        query(
            c, viewer, "true", emptyList(), limit, after,
            joins = "JOIN post_saves sv ON sv.post_id = p.id AND sv.account_id = ?", joinArgs = listOf(viewer), keyExpr = "sv.created_at",
        )
    }

    override suspend fun setReaction(postId: UUID, accountId: UUID, type: String, now: Instant) {
        tx { c ->
            c.prepareStatement(
                "INSERT INTO post_reactions (post_id, account_id, type, created_at) VALUES (?, ?, ?, ?) " +
                    "ON CONFLICT (post_id, account_id) DO UPDATE SET type = EXCLUDED.type",
            ).use { ps -> bind(ps, listOf(postId, accountId, type, now)); ps.executeUpdate() }
        }
    }

    override suspend fun removeReaction(postId: UUID, accountId: UUID) {
        tx { c -> c.prepareStatement("DELETE FROM post_reactions WHERE post_id = ? AND account_id = ?").use { ps -> bind(ps, listOf(postId, accountId)); ps.executeUpdate() } }
    }

    override suspend fun savePost(postId: UUID, accountId: UUID, now: Instant) {
        tx { c ->
            c.prepareStatement("INSERT INTO post_saves (account_id, post_id, created_at) VALUES (?, ?, ?) ON CONFLICT DO NOTHING").use { ps ->
                bind(ps, listOf(accountId, postId, now)); ps.executeUpdate()
            }
        }
    }

    override suspend fun unsavePost(postId: UUID, accountId: UUID) {
        tx { c -> c.prepareStatement("DELETE FROM post_saves WHERE account_id = ? AND post_id = ?").use { ps -> bind(ps, listOf(accountId, postId)); ps.executeUpdate() } }
    }

    override suspend fun createComment(postId: UUID, parentId: UUID?, authorId: UUID, body: String, now: Instant): UUID = tx { c ->
        c.prepareStatement("INSERT INTO comments (post_id, parent_id, author_id, body, created_at) VALUES (?, ?, ?, ?, ?) RETURNING id").use { ps ->
            bind(ps, listOf(postId, parentId, authorId, body, now))
            ps.executeQuery().use { rs -> rs.next(); rs.getObject(1, UUID::class.java) }
        }
    }

    private object CommentSql {
        const val SELECT_COMMENT =
            "c.id, c.post_id, c.parent_id, c.author_id, cp.nickname, cp.winkwink_id, cp.display_name, cp.avatar_object_key, c.body, c.created_at, " +
                "p.author_id AS post_author_id, p.anonymous AS post_anonymous, " +
                "(SELECT count(*) FROM comments r WHERE r.parent_id = c.id AND r.deleted_at IS NULL) AS reply_count"
        const val FROM_COMMENT =
            "comments c JOIN posts p ON p.id = c.post_id JOIN profiles cp ON cp.account_id = c.author_id JOIN accounts ca ON ca.id = c.author_id AND ca.status = 'active'"
    }

    private fun ResultSet.comment() = CommentRow(
        id = getObject("id", UUID::class.java),
        postId = getObject("post_id", UUID::class.java),
        parentId = getObject("parent_id", UUID::class.java),
        authorId = getObject("author_id", UUID::class.java),
        authorNickname = getString("nickname"),
        authorWinkwinkId = getString("winkwink_id"),
        authorDisplayName = getString("display_name"),
        body = getString("body"),
        createdAt = getTimestamp("created_at").toInstant(),
        postAuthorId = getObject("post_author_id", UUID::class.java),
        postAnonymous = getBoolean("post_anonymous"),
        replyCount = getInt("reply_count"),
        authorAvatarKey = getString("avatar_object_key"),
    )

    override suspend fun getComment(id: UUID): CommentRow? = tx { c ->
        c.prepareStatement("SELECT ${CommentSql.SELECT_COMMENT} FROM ${CommentSql.FROM_COMMENT} WHERE c.id = ? AND c.deleted_at IS NULL AND p.deleted_at IS NULL").use { ps ->
            bind(ps, listOf(id)); ps.executeQuery().use { rs -> if (rs.next()) rs.comment() else null }
        }
    }

    override suspend fun listComments(postId: UUID, parentId: UUID?, viewer: UUID, limit: Int, after: PageCursor?): List<CommentRow> = tx { c ->
        val args = mutableListOf<Any?>(postId)
        val parentSql = if (parentId == null) "c.parent_id IS NULL" else { args += parentId; "c.parent_id = ?" }
        args += viewer; args += viewer; args += viewer
        val cursorSql = if (after != null) { args += after.at; args += after.id; "AND (c.created_at, c.id) > (?, ?)" } else ""
        args += limit
        val sql = "SELECT ${CommentSql.SELECT_COMMENT} FROM ${CommentSql.FROM_COMMENT} WHERE c.post_id = ? AND c.deleted_at IS NULL AND $parentSql " +
            "AND NOT EXISTS (SELECT 1 FROM blocks b WHERE (b.blocker_id = ? AND b.blocked_id = c.author_id AND NOT (p.anonymous AND c.author_id = p.author_id)) OR (b.blocker_id = c.author_id AND b.blocked_id = ?)) " +
            "AND NOT EXISTS (SELECT 1 FROM user_mutes um WHERE um.muter_id = ? AND um.muted_id = c.author_id AND NOT (p.anonymous AND c.author_id = p.author_id)) " +
            "$cursorSql ORDER BY c.created_at ASC, c.id ASC LIMIT ?"
        c.prepareStatement(sql).use { ps -> bind(ps, args); ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.comment()) } } }
    }

    override suspend fun deleteComment(id: UUID, now: Instant): Boolean = tx { c ->
        c.prepareStatement("UPDATE comments SET deleted_at = ? WHERE (id = ? OR parent_id = ?) AND deleted_at IS NULL").use { ps ->
            bind(ps, listOf(now, id, id)); ps.executeUpdate() > 0
        }
    }
}
