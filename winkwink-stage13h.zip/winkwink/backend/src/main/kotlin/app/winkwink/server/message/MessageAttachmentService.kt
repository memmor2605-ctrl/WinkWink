package app.winkwink.server.message

import app.winkwink.server.api.ApiException
import app.winkwink.server.media.ImageProcessor
import app.winkwink.server.media.InvalidImageException
import app.winkwink.server.media.MediaKeys
import app.winkwink.server.media.MediaSniffer
import app.winkwink.server.media.MediaStorage
import app.winkwink.server.media.MessageMedia
import app.winkwink.server.media.Mp4Inspector
import app.winkwink.server.media.UploadRateLimiter
import app.winkwink.server.media.deleteQuietly
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Clock
import java.time.Duration
import java.util.UUID

class MessageAttachmentFile(val stored: app.winkwink.server.media.StoredObject, val mime: String, val kind: String, val fileName: String?) {
    /** Cała treść w pamięci — tylko dla testów i małych plików; trasy strumieniują przez [stored]. */
    val bytes: ByteArray get() = stored.open().use { it.readBytes() }
}

/**
 * Zdjęcia, dokumenty i wiadomości głosowe w rozmowach (Etap F) na wspólnej warstwie [MediaStorage].
 *
 * Dwa kroki: (1) wysłanie pliku do rozmowy → identyfikator niedołączonego załącznika, widoczny tylko dla właściciela;
 * (2) dołączenie przy wysyłaniu wiadomości ([MessageService.send]). Pobieranie: dostęp do pliku = członkostwo w rozmowie
 * (aktualne — po opuszczeniu/usunięciu z grupy dostęp znika) i wiadomość nieusunięta. Każdy odmowny powód to to samo `404`.
 */
class MessageAttachmentService(
    private val store: MessageStore,
    private val storage: MediaStorage,
    private val limiter: UploadRateLimiter = UploadRateLimiter(),
    private val clock: Clock = Clock.systemUTC(),
) {
    companion object {
        const val MAX_PENDING = 30
        val PENDING_TTL: Duration = Duration.ofHours(24)
        private const val PURGE_BATCH = 200

        private fun notFound() = ApiException(HttpStatusCode.NotFound, "attachment_not_found", "Attachment not found.")
        private fun unsupported(msg: String) = ApiException(HttpStatusCode.UnsupportedMediaType, "unsupported_media_type", msg)
    }

    suspend fun upload(viewer: UUID, conversationId: UUID, raw: ByteArray, declaredMime: String, rawName: String?): MessageAttachmentRow {
        // Członkostwo przed wszystkim innym: obcy nie dowie się nic o rozmowie ani o limitach.
        store.member(conversationId, viewer) ?: throw ApiException(HttpStatusCode.NotFound, "conversation_not_found", "Conversation not found.")
        limiter.check(viewer)
        val declared = MessageMedia.declaredKind(declaredMime)
            ?: throw unsupported("Allowed: JPEG/PNG images, PDF/Office/OpenDocument/RTF/TXT/CSV documents and MP4 (AAC) voice recordings.")
        if (raw.isEmpty()) throw ApiException(HttpStatusCode.BadRequest, "validation_failed", "Empty body.")
        val limit = MessageMedia.maxBytesFor(declaredMime)!!
        if (raw.size > limit) throw ApiException(HttpStatusCode.PayloadTooLarge, "payload_too_large", "File is larger than ${limit / (1024 * 1024)} MB.")
        if (store.pendingAttachmentCount(viewer) >= MAX_PENDING) {
            throw ApiException(HttpStatusCode.TooManyRequests, "too_many_pending", "Too many unsent uploads; send or delete some first.")
        }

        var bytes = raw
        var mime: String
        var name: String? = null
        var width: Int? = null
        var height: Int? = null
        var durationMs: Long? = null
        when (declared) {
            "image" -> {
                if (ImageProcessor.sniff(raw) == null) throw unsupported("File content is not a JPEG or PNG image.")
                val processed = try {
                    withContext(Dispatchers.Default) { ImageProcessor.process(raw, MessageMedia.IMAGE_MAX_EDGE) }
                } catch (e: InvalidImageException) {
                    val status = when (e.code) {
                        "unsupported_media_type" -> HttpStatusCode.UnsupportedMediaType
                        "image_too_large" -> HttpStatusCode.PayloadTooLarge
                        else -> HttpStatusCode.BadRequest
                    }
                    throw ApiException(status, e.code, e.message ?: "Invalid image.")
                }
                bytes = processed.bytes // zakodowane od nowa: bez EXIF/GPS i dopisanych danych
                mime = processed.mime
                MediaSniffer.dimensions(bytes)?.let { (w, h) -> width = w; height = h }
            }
            "voice" -> {
                val info = Mp4Inspector.inspect(raw)
                if (info == null || !Mp4Inspector.isAudioOnly(info)) throw unsupported("Voice messages must be audio-only MP4/M4A (AAC).")
                if (info.durationMs < MessageMedia.VOICE_MIN_MS) throw ApiException(HttpStatusCode.BadRequest, "recording_too_short", "The recording is too short.")
                if (info.durationMs > MessageMedia.VOICE_MAX_MS) throw ApiException(HttpStatusCode.PayloadTooLarge, "recording_too_long", "The recording is longer than 10 minutes.")
                mime = "audio/mp4"
                durationMs = info.durationMs
            }
            else -> {
                val type = MessageMedia.detectDocument(raw) ?: throw unsupported("This document type is not allowed (or the file is unsafe).")
                name = MessageMedia.documentFileName(rawName, type) ?: throw unsupported("This file name is not allowed.")
                mime = if (name.endsWith(".csv")) MessageMedia.CSV.mime else type.mime
            }
        }

        val key = MediaKeys.newKey("message")
        storage.put(key, bytes)
        val row = MessageAttachmentRow(
            UUID.randomUUID(), viewer, conversationId, null, 0, declared, mime, bytes.size.toLong(), key, name, width, height, durationMs, clock.instant(),
        )
        try {
            store.createAttachment(row)
        } catch (e: Throwable) {
            storage.deleteQuietly(key)
            throw e
        }
        return row
    }

    /** Usuwa niedołączony załącznik właściciela (np. gdy użytkownik wycofał plik z szkicu). */
    suspend fun deletePending(viewer: UUID, id: UUID) {
        // Najpierw znacznik w bazie (plik od razu przestaje być widoczny i pobieralny), potem plik, na końcu wiersz.
        // Gdy skasowanie pliku się nie uda, wiersz zostaje oznaczony i usunie go okresowe sprzątanie — operacja jest idempotentna.
        val row = store.tombstonePending(viewer, id, clock.instant()) ?: throw notFound()
        if (storage.deleteQuietly(row.objectKey)) store.removeAttachmentRows(listOf(row.id))
    }

    suspend fun download(viewer: UUID, id: UUID): MessageAttachmentFile {
        val row = store.attachment(id) ?: throw notFound()
        if (row.deletedAt != null) throw notFound()
        val messageId = row.messageId
        if (messageId == null) {
            if (row.ownerId != viewer) throw notFound()
        } else {
            val message = store.message(messageId)
            if (message == null || message.deleted) throw notFound()
            if (store.member(row.conversationId, viewer) == null) throw notFound() // nie-członek / osoba usunięta z grupy
        }
        val stored = storage.open(row.objectKey) ?: throw notFound()
        return MessageAttachmentFile(stored, row.mime, row.kind, row.fileName)
    }

    /**
     * Okresowe sprzątanie: pliki oznaczone do usunięcia (po usunięciu wiadomości) oraz porzucone wysyłki starsze niż [PENDING_TTL].
     * Zwraca liczbę usuniętych plików. Błąd jednego pliku nie przerywa reszty.
     */
    suspend fun purgeAbandoned(): Int {
        var total = 0
        while (true) {
            val batch = store.purgeCandidates(clock.instant().minus(PENDING_TTL), PURGE_BATCH)
            if (batch.isEmpty()) break
            val done = mutableListOf<UUID>()
            for (row in batch) {
                try {
                    storage.delete(row.objectKey)
                    done += row.id
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                }
            }
            store.removeAttachmentRows(done)
            total += done.size
            if (done.size < batch.size) break // nie kręcimy się w kółko na wierszach, których nie da się usunąć
        }
        return total
    }
}
