package app.winkwink.server.profile

import app.winkwink.server.api.ApiException
import app.winkwink.server.auth.JWT_AUTH
import app.winkwink.server.auth.UserPrincipal
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.auth.authenticate
import io.ktor.server.auth.principal
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.delete
import io.ktor.server.routing.get
import io.ktor.server.routing.patch
import io.ktor.server.routing.post

private fun ApplicationCall.viewer() =
    (principal<UserPrincipal>() ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")).accountId

private fun ApplicationCall.ident(): String =
    parameters["id"] ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "Missing user identifier.")

private fun ApplicationCall.limit(): Int? = request.queryParameters["limit"]?.let {
    it.toIntOrNull() ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "limit must be an integer.")
}

fun Route.profileRoutes(service: ProfileService) {
    authenticate(JWT_AUTH) {
        patch("/me/profile") {
            val body = call.receive<UpdateProfileRequest>()
            val view = service.updateMine(call.viewer(), body.displayName, body.bio, body.links, body.visibility, body.clearDisplayName, body.hideFollowLists)
            call.respond(view.toDto())
        }
        get("/me/blocks") {
            call.respond(service.blocked(call.viewer(), call.limit(), call.request.queryParameters["cursor"]).toResponse())
        }
        get("/me/mutes") {
            call.respond(service.muted(call.viewer(), call.limit(), call.request.queryParameters["cursor"]).toResponse())
        }
        post("/users/{id}/mute") {
            service.mute(call.viewer(), call.ident())
            call.respond(HttpStatusCode.NoContent)
        }
        delete("/users/{id}/mute") {
            service.unmute(call.viewer(), call.ident())
            call.respond(HttpStatusCode.NoContent)
        }
        get("/me/follow-requests") {
            call.respond(service.pendingRequests(call.viewer(), call.limit(), call.request.queryParameters["cursor"]).toResponse())
        }
        post("/me/follow-requests/{id}/approve") {
            service.respondToRequest(call.viewer(), call.ident(), approve = true)
            call.respond(HttpStatusCode.NoContent)
        }
        delete("/me/follow-requests/{id}") {
            service.respondToRequest(call.viewer(), call.ident(), approve = false)
            call.respond(HttpStatusCode.NoContent)
        }

        get("/users/search") {
            val q = call.request.queryParameters["q"] ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "Missing q.")
            call.respond(UserListResponse(service.search(call.viewer(), q, call.limit()).map { it.toSummary() }))
        }
        get("/users/{id}") { call.respond(service.view(call.viewer(), call.ident()).toDto()) }
        get("/users/{id}/followers") {
            call.respond(service.followers(call.viewer(), call.ident(), call.limit(), call.request.queryParameters["cursor"]).toResponse())
        }
        get("/users/{id}/following") {
            call.respond(service.following(call.viewer(), call.ident(), call.limit(), call.request.queryParameters["cursor"]).toResponse())
        }
        post("/users/{id}/follow") { call.respond(FollowResponse(service.follow(call.viewer(), call.ident()))) }
        delete("/users/{id}/follow") {
            service.unfollow(call.viewer(), call.ident())
            call.respond(HttpStatusCode.NoContent)
        }
        post("/users/{id}/block") {
            service.block(call.viewer(), call.ident())
            call.respond(HttpStatusCode.NoContent)
        }
        delete("/users/{id}/block") {
            service.unblock(call.viewer(), call.ident())
            call.respond(HttpStatusCode.NoContent)
        }
    }
}
