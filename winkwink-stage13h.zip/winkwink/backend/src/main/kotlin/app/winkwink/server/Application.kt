package app.winkwink.server

import app.winkwink.server.auth.PostgresAccountMedia
import app.winkwink.server.idempotency.Idempotency
import app.winkwink.server.push.DisabledPushSender
import app.winkwink.server.push.FcmPushSender
import app.winkwink.server.push.PostgresPushStore
import app.winkwink.server.push.PushService
import app.winkwink.server.push.pushRoutes
import app.winkwink.server.idempotency.PostgresIdempotencyStore
import app.winkwink.server.media.MediaReconciler
import app.winkwink.server.media.PostgresMediaReferences
import app.winkwink.server.plugins.configureRequestLimits
import app.winkwink.server.message.MessageAttachmentService
import app.winkwink.server.message.MessageService
import app.winkwink.server.message.messageAttachmentRoutes
import app.winkwink.server.media.UploadRateLimiter
import app.winkwink.server.message.PostgresMessageStore
import app.winkwink.server.realtime.RealtimeEvents
import app.winkwink.server.realtime.RealtimeHub
import app.winkwink.server.realtime.realtimeRoutes
import app.winkwink.server.message.messageRoutes
import app.winkwink.server.notification.NotificationService
import app.winkwink.server.notification.PostgresNotificationStore
import app.winkwink.server.notification.notificationRoutes
import app.winkwink.server.api.ApiPaths
import app.winkwink.server.auth.Argon2idPasswordHasher
import app.winkwink.server.auth.AuthService
import app.winkwink.server.auth.PostgresAuthStore
import app.winkwink.server.auth.TokenService
import app.winkwink.server.auth.UnavailableEmailSender
import app.winkwink.server.auth.authRoutes
import app.winkwink.server.community.CommunityService
import app.winkwink.server.community.PostgresCommunityStore
import app.winkwink.server.community.communityRoutes
import app.winkwink.server.config.AppConfig
import app.winkwink.server.database.DatabaseFactory
import app.winkwink.server.feed.AttachmentService
import app.winkwink.server.feed.FeedService
import app.winkwink.server.feed.PostgresPostExtrasStore
import app.winkwink.server.feed.attachmentRoutes
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Duration
import app.winkwink.server.feed.PostgresFeedStore
import app.winkwink.server.feed.feedRoutes
import app.winkwink.server.health.HealthProbe
import app.winkwink.server.health.PostgresHealthProbe
import app.winkwink.server.health.healthRoutes
import app.winkwink.server.profile.PostgresProfileStore
import app.winkwink.server.profile.ProfileService
import app.winkwink.server.profile.ProfileMediaService
import app.winkwink.server.profile.profileMediaRoutes
import app.winkwink.server.profile.profileRoutes
import app.winkwink.server.media.LocalFileMediaStorage
import app.winkwink.server.plugins.configureAuthentication
import app.winkwink.server.plugins.configureErrorHandling
import app.winkwink.server.plugins.configureObservability
import app.winkwink.server.plugins.configureSecurity
import app.winkwink.server.plugins.configureSerialization
import io.ktor.server.application.Application
import io.ktor.server.application.install
import io.ktor.server.websocket.WebSockets
import kotlin.time.Duration.Companion.seconds
import io.ktor.server.engine.embeddedServer
import io.ktor.server.engine.sslConnector
import io.ktor.server.netty.Netty
import io.ktor.server.routing.route
import io.ktor.server.routing.routing
import org.slf4j.LoggerFactory
import java.io.FileInputStream
import java.nio.file.Paths
import java.security.KeyStore
import java.time.Clock

fun main() {
    val log = LoggerFactory.getLogger("app.winkwink.server")
    val config = AppConfig.fromEnvironment()
    log.info("Starting WinkWink server in {} mode", config.environment)

    val dataSource = DatabaseFactory.createDataSource(config.database)
    if (config.database.migrateOnStart) {
        log.info("Database migrations executed: {}", DatabaseFactory.migrate(dataSource))
    }

    val clock = Clock.systemUTC()
    val mediaStorage = LocalFileMediaStorage(Paths.get(config.mediaDir)) // wymienialne na S3-compatible (interfejs MediaStorage)
    val hub = RealtimeHub()
    val fcmSender = config.fcmCredentialsFile?.let { FcmPushSender.fromFile(it) } ?: DisabledPushSender
    if (!fcmSender.enabled) LoggerFactory.getLogger("app.winkwink").info("Push notifications disabled (WINKWINK_FCM_CREDENTIALS_FILE not set or invalid)")
    // Push pomijamy, gdy konto ma otwarte WSS (aplikacja na pierwszym planie dostaje wiadomość na żywo).
    val pushService = PushService(PostgresPushStore(dataSource), fcmSender, { hub.connectionCount(it) > 0 }, clock)
    val authService = AuthService(
        store = PostgresAuthStore(dataSource),
        hasher = Argon2idPasswordHasher(),
        tokens = TokenService(config.auth, clock),
        email = UnavailableEmailSender(), // do czasu wyboru dostawcy poczty — patrz PROJECT_STATUS.md
        config = config.auth,
        clock = clock,
        accountMedia = PostgresAccountMedia(dataSource, mediaStorage),
        push = pushService,
    )

    embeddedServer(
        Netty,
        configure = {
            val tls = config.tls
            if (tls != null) {
                val keyStore = KeyStore.getInstance("PKCS12").apply {
                    FileInputStream(tls.keyStorePath).use { load(it, tls.keyStorePassword.toCharArray()) }
                }
                sslConnector(
                    keyStore = keyStore,
                    keyAlias = tls.keyAlias,
                    keyStorePassword = { tls.keyStorePassword.toCharArray() },
                    privateKeyPassword = { tls.keyPassword.toCharArray() },
                ) {
                    host = config.host
                    port = config.port
                }
            } else {
                // Zwykły port tylko dla ruchu z zaufanego reverse proxy; żądania bez X-Forwarded-Proto=https są odrzucane.
                connector {
                    host = config.host
                    port = config.port
                }
            }
        },
        module = {
            val profileStore = PostgresProfileStore(dataSource)
            val notifications = NotificationService(PostgresNotificationStore(dataSource), profileStore, clock, pushService)
            val profiles = ProfileService(profileStore, clock, notifications)
            val communities = CommunityService(PostgresCommunityStore(dataSource), profileStore, clock, notifications)
            val feedStore = PostgresFeedStore(dataSource)
            val postExtras = PostgresPostExtrasStore(dataSource)
            val feed = FeedService(feedStore, profiles, clock, notifications, postExtras)
            val attachments = AttachmentService(postExtras, feedStore, mediaStorage, clock)
            val messageStore = PostgresMessageStore(dataSource)
            val messages = MessageService(messageStore, profileStore, clock, RealtimeEvents(hub), mediaStorage, pushService)
            val messageAttachments = MessageAttachmentService(messageStore, mediaStorage, UploadRateLimiter(clock = clock), clock)
            val profileMedia = ProfileMediaService(profileStore, profiles, mediaStorage)
            val idempotency = Idempotency(PostgresIdempotencyStore(dataSource), clock)
            val reconciler = MediaReconciler(mediaStorage, PostgresMediaReferences(dataSource), clock)
            // Porzucone (niedołączone do posta) wysyłki są sprzątane co godzinę; błąd sprzątania nie przerywa pętli.
            launch {
                while (true) {
                    delay(Duration.ofHours(1).toMillis())
                    runCatching { attachments.purgeAbandoned() }
                    // Pliki wiadomości: oznaczone do usunięcia (po usunięciu wiadomości) i porzucone wysyłki.
                    runCatching { messageAttachments.purgeAbandoned() }
                    // Pliki usuniętych postów oraz wygasłe wpisy idempotencji (48 h).
                    runCatching { attachments.purgeDeletedPosts() }
                    runCatching { idempotency.purge() }
                }
            }
            // Rekoncyliacja magazynu z bazą (pliki po usuniętych kontach, nieudanych kasowaniach, awariach) — co 6 godzin.
            launch {
                while (true) {
                    delay(Duration.ofHours(6).toMillis())
                    runCatching { reconciler.reconcile() }
                }
            }
            winkwinkModule(config, PostgresHealthProbe(dataSource), authService, profiles, feed, communities, notifications, messages, profileMedia, attachments, hub, messageAttachments, idempotency, pushService, fcmSender.enabled)
        },
    ).start(wait = true)
}

fun Application.winkwinkModule(config: AppConfig, health: HealthProbe, auth: AuthService, profiles: ProfileService? = null, feed: FeedService? = null, communities: CommunityService? = null, notifications: NotificationService? = null, messages: MessageService? = null, profileMedia: ProfileMediaService? = null, attachments: AttachmentService? = null, realtime: RealtimeHub? = null, messageAttachments: MessageAttachmentService? = null, idempotency: Idempotency? = null, push: PushService? = null, pushConfigured: Boolean = false) {
    configureObservability()
    configureSecurity(config)
    configureRequestLimits()
    configureSerialization()
    configureErrorHandling()
    configureAuthentication(auth)
    install(WebSockets) {
        pingPeriod = 20.seconds
        timeout = 45.seconds
        maxFrameSize = 4096 // klient wysyła tylko krótkie ramki sterujące
    }

    routing {
        route(ApiPaths.V1) {
            healthRoutes(config, health)
            authRoutes(auth)
            profiles?.let { profileRoutes(it) }
            profileMedia?.let { profileMediaRoutes(it) }
            feed?.let { feedRoutes(it, idempotency) }
            attachments?.let { attachmentRoutes(it, idempotency) }
            communities?.let { communityRoutes(it, idempotency) }
            notifications?.let { notificationRoutes(it) }
            push?.let { pushRoutes(it, pushConfigured) }
            messages?.let { messageRoutes(it, idempotency) }
            messageAttachments?.let { messageAttachmentRoutes(it, idempotency) }
            if (realtime != null && messages != null) realtimeRoutes(realtime, messages, { sessionId, accountId -> auth.isSessionActive(sessionId, accountId) })
        }
    }
}
