package app.winkwink.server.message

import app.winkwink.server.api.ApiException
import app.winkwink.server.auth.JWT_AUTH
import app.winkwink.server.auth.UserPrincipal
import app.winkwink.server.idempotency.Idempotency
import app.winkwink.server.idempotency.respondIdempotent
import app.winkwink.server.media.MessageMedia
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.auth.authenticate
import io.ktor.server.auth.principal
import io.ktor.server.request.contentLength
import io.ktor.server.request.contentType
import io.ktor.server.request.receive
import io.ktor.server.response.header
import io.ktor.server.response.respond
import app.winkwink.server.media.respondStored
import io.ktor.server.routing.Route
import io.ktor.server.routing.delete
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import java.util.UUID

private fun ApplicationCall.viewer(): UUID =
    (principal<UserPrincipal>() ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")).accountId

private fun ApplicationCall.attachmentId(): UUID =
    runCatching { UUID.fromString(parameters["id"]) }.getOrNull()
        ?: throw ApiException(HttpStatusCode.NotFound, "attachment_not_found", "Attachment not found.")

/** Kontrakt: docs/API.md, „Etap F — multimedia w wiadomościach”. */
fun Route.messageAttachmentRoutes(service: MessageAttachmentService, idem: Idempotency? = null) {
    authenticate(JWT_AUTH) {
        // Surowe ciało = plik (bez multipartu). `conversationId` w zapytaniu wiąże plik z rozmową; Content-Length jest wymagany,
        // żeby odrzucić zbyt duży plik, zanim trafi do pamięci.
        post("/message-attachments") {
            val v = call.viewer()
            val conversationId = runCatching { UUID.fromString(call.request.queryParameters["conversationId"]) }.getOrNull()
                ?: throw ApiException(HttpStatusCode.BadRequest, "validation_failed", "conversationId: invalid id")
            val type = call.request.contentType()
            val mime = "${type.contentType}/${type.contentSubtype}".lowercase()
            val max = MessageMedia.maxBytesFor(mime)
                ?: throw ApiException(HttpStatusCode.UnsupportedMediaType, "unsupported_media_type", "This Content-Type is not allowed.")
            val len = call.request.contentLength()
                ?: throw ApiException(HttpStatusCode.LengthRequired, "length_required", "Content-Length is required.")
            if (len > max) throw ApiException(HttpStatusCode.PayloadTooLarge, "payload_too_large", "File is too large.")
            val name = call.request.queryParameters["name"]
            call.respondIdempotent(idem, v, "POST /message-attachments", HttpStatusCode.Created, fingerprint = "$conversationId|$mime|$name|${call.request.headers["Content-Length"]}") {
                service.upload(v, conversationId, call.receive<ByteArray>(), mime, name).toDto()
            }
        }
        delete("/message-attachments/{id}") {
            service.deletePending(call.viewer(), call.attachmentId())
            call.respond(HttpStatusCode.NoContent)
        }
        get("/message-attachments/{id}") {
            val file = service.download(call.viewer(), call.attachmentId())
            // Prywatna treść: cache tylko po stronie klienta; brak sniffingu; CSP z sandboxem na wypadek otwarcia w przeglądarce.
            call.response.header(HttpHeaders.CacheControl, "private, max-age=3600")
            call.response.header("X-Content-Type-Options", "nosniff")
            call.response.header("Content-Security-Policy", "default-src 'none'; sandbox")
            val disposition = if (file.kind == "document") {
                "attachment; filename*=UTF-8''" + java.net.URLEncoder.encode(file.fileName ?: "document", Charsets.UTF_8).replace("+", "%20")
            } else "inline"
            call.response.header(HttpHeaders.ContentDisposition, disposition)
            call.respondStored(file.stored, ContentType.parse(file.mime))
        }
    }
}
