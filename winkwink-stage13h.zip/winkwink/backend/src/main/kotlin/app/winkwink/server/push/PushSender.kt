package app.winkwink.server.push

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.slf4j.LoggerFactory
import java.net.URI
import java.net.URLEncoder
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.nio.file.Files
import java.nio.file.Path
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.time.Duration
import java.time.Instant
import java.util.Base64

sealed interface PushResult {
    data object Ok : PushResult
    /** Token nieważny (odinstalowana aplikacja, wygasły) — usuwamy go z bazy. */
    data object InvalidToken : PushResult
    data object Failed : PushResult
}

/** Wysyłka jednej wiadomości data-only (treść i wygląd powiadomienia buduje aplikacja, żeby szanować prywatność i język). */
interface PushSender {
    val enabled: Boolean
    suspend fun send(token: String, data: Map<String, String>, collapseKey: String?, highPriority: Boolean): PushResult
}

/** Brak konfiguracji Firebase: push jest wyłączony, reszta backendu działa normalnie. */
object DisabledPushSender : PushSender {
    override val enabled = false
    override suspend fun send(token: String, data: Map<String, String>, collapseKey: String?, highPriority: Boolean) = PushResult.Failed
}

/**
 * FCM HTTP v1 bez zewnętrznego SDK: token dostępu OAuth2 z konta serwisowego (JWT RS256 → oauth2.googleapis.com/token),
 * potem `POST https://fcm.googleapis.com/v1/projects/{id}/messages:send`. Klucz konta serwisowego leży wyłącznie na serwerze
 * (plik wskazany przez `WINKWINK_FCM_CREDENTIALS_FILE`) — nigdy w aplikacji ani w repozytorium.
 */
class FcmPushSender private constructor(
    private val projectId: String,
    private val clientEmail: String,
    private val privateKey: java.security.PrivateKey,
    private val http: HttpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build(),
) : PushSender {
    override val enabled = true
    private val log = LoggerFactory.getLogger("app.winkwink.push")
    private val json = Json { ignoreUnknownKeys = true }
    private val lock = Mutex()
    private var accessToken: String? = null
    private var accessExpiresAt: Instant = Instant.EPOCH

    companion object {
        private const val SCOPE = "https://www.googleapis.com/auth/firebase.messaging"
        private const val TOKEN_URL = "https://oauth2.googleapis.com/token"

        /** @return null, gdy plik nie istnieje lub jest niepoprawny (logujemy powód bez treści klucza). */
        fun fromFile(path: String): FcmPushSender? {
            val log = LoggerFactory.getLogger("app.winkwink.push")
            return try {
                val obj = Json.parseToJsonElement(Files.readString(Path.of(path))).jsonObject
                val pem = obj.getValue("private_key").jsonPrimitive.content
                val der = Base64.getMimeDecoder().decode(pem.replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", ""))
                val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(der))
                FcmPushSender(obj.getValue("project_id").jsonPrimitive.content, obj.getValue("client_email").jsonPrimitive.content, key)
            } catch (e: Exception) {
                log.error("FCM credentials could not be loaded ({}); push notifications are disabled", e.javaClass.simpleName)
                null
            }
        }
    }

    private fun b64(bytes: ByteArray) = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)

    private fun signedAssertion(now: Instant): String {
        val header = b64("""{"alg":"RS256","typ":"JWT"}""".toByteArray())
        val claims = buildJsonObject {
            put("iss", clientEmail); put("scope", SCOPE); put("aud", TOKEN_URL)
            put("iat", now.epochSecond); put("exp", now.epochSecond + 3600)
        }.toString()
        val input = header + "." + b64(claims.toByteArray())
        val sig = Signature.getInstance("SHA256withRSA").apply { initSign(privateKey); update(input.toByteArray()) }.sign()
        return input + "." + b64(sig)
    }

    private suspend fun token(): String? = lock.withLock {
        val now = Instant.now()
        accessToken?.let { if (now.isBefore(accessExpiresAt.minusSeconds(120))) return it }
        val body = "grant_type=" + URLEncoder.encode("urn:ietf:params:oauth:grant-type:jwt-bearer", Charsets.UTF_8) + "&assertion=" + signedAssertion(now)
        val req = HttpRequest.newBuilder(URI.create(TOKEN_URL)).timeout(Duration.ofSeconds(15))
            .header("Content-Type", "application/x-www-form-urlencoded").POST(HttpRequest.BodyPublishers.ofString(body)).build()
        val res = withContext(Dispatchers.IO) { http.send(req, HttpResponse.BodyHandlers.ofString()) }
        if (res.statusCode() != 200) { log.warn("FCM OAuth token request failed: HTTP {}", res.statusCode()); return null }
        val obj = json.parseToJsonElement(res.body()).jsonObject
        accessToken = obj["access_token"]?.jsonPrimitive?.contentOrNull
        accessExpiresAt = now.plusSeconds(obj["expires_in"]?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 3000)
        accessToken
    }

    override suspend fun send(token: String, data: Map<String, String>, collapseKey: String?, highPriority: Boolean): PushResult = try {
        val bearer = token() ?: return PushResult.Failed
        val message = buildJsonObject {
            put("message", buildJsonObject {
                put("token", token)
                put("data", JsonObject(data.mapValues { JsonPrimitive(it.value) }))
                put("android", buildJsonObject {
                    put("priority", if (highPriority) "HIGH" else "NORMAL")
                    put("ttl", "86400s")
                    if (collapseKey != null) put("collapse_key", collapseKey)
                })
            })
        }.toString()
        val req = HttpRequest.newBuilder(URI.create("https://fcm.googleapis.com/v1/projects/$projectId/messages:send"))
            .timeout(Duration.ofSeconds(15)).header("Authorization", "Bearer $bearer").header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(message)).build()
        val res = withContext(Dispatchers.IO) { http.send(req, HttpResponse.BodyHandlers.ofString()) }
        when {
            res.statusCode() in 200..299 -> PushResult.Ok
            res.statusCode() == 404 || (res.statusCode() == 400 && res.body().contains("INVALID_ARGUMENT")) || res.body().contains("UNREGISTERED") -> PushResult.InvalidToken
            res.statusCode() == 401 -> { lock.withLock { accessToken = null }; PushResult.Failed }
            else -> { log.warn("FCM send failed: HTTP {}", res.statusCode()); PushResult.Failed }
        }
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: Exception) {
        log.warn("FCM send error: {}", e.javaClass.simpleName)
        PushResult.Failed
    }
}
