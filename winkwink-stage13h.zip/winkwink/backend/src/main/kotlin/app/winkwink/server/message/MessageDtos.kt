package app.winkwink.server.message

import app.winkwink.server.profile.mediaTag
import kotlinx.serialization.Serializable

@Serializable data class PersonDto(val winkwinkId: String, val nickname: String, val displayName: String? = null, val avatarTag: String? = null)

@Serializable
data class MessageDto(
    val id: String,
    val conversationId: String,
    val sender: PersonDto,
    /** `null` dla usuniętej wiadomości. */
    val body: String? = null,
    val replyToId: String? = null,
    val createdAt: String,
    val editedAt: String? = null,
    val deleted: Boolean = false,
    val mine: Boolean = false,
    /** Tylko własne: `sent` | `delivered` | `read` (dwa ostatnie przy włączonych potwierdzeniach obu stron). */
    val status: String? = null,
    val reactions: List<ReactionDto> = emptyList(),
    /** Metadane załączników (treść pobiera się osobno, z kontrolą członkostwa). */
    val attachments: List<MessageAttachmentDto> = emptyList(),
)

@Serializable data class ReactionDto(val kind: String, val count: Int, val mine: Boolean)

/** Metadane załącznika wiadomości. Plik pobiera się osobno: `GET /message-attachments/{id}` (treść nigdy nie idzie przez WSS). */
@Serializable
data class MessageAttachmentDto(
    val id: String,
    /** `image` | `document` | `voice` */
    val kind: String,
    val mime: String,
    val sizeBytes: Long,
    /** Tylko dokumenty (zsanityzowana). */
    val fileName: String? = null,
    val width: Int? = null,
    val height: Int? = null,
    /** Tylko głosówki; liczone przez serwer. */
    val durationMs: Long? = null,
)

@Serializable
data class ConversationDto(
    val id: String,
    /** `direct` | `group` */
    val kind: String,
    val title: String? = null,
    /** Druga osoba w rozmowie 1:1. */
    val peer: PersonDto? = null,
    val memberCount: Int,
    val muted: Boolean = false,
    val archived: Boolean = false,
    val unreadCount: Int = 0,
    val myRole: String,
    val lastMessage: MessageDto? = null,
    val activityAt: String,
)

@Serializable data class ConversationListResponse(val conversations: List<ConversationDto>, val nextCursor: String? = null)
@Serializable data class MessageListResponse(val messages: List<MessageDto>, val nextCursor: String? = null)
@Serializable data class MemberDto(val person: PersonDto, val role: String, val joinedAt: String)
@Serializable data class MemberListResponse(val members: List<MemberDto>)

@Serializable data class StartDirectRequest(val user: String)
@Serializable data class CreateGroupRequest(val title: String, val members: List<String>)
/**
 * [clientId] — UUID nadany przez klienta (trwała kolejka wysyłania). Ponowienie z tym samym [clientId] zwraca już zapisaną
 * wiadomość zamiast tworzyć duplikat; brak pola = wysyłka bez ochrony przed duplikatami.
 */
@Serializable data class SendMessageRequest(val body: String = "", val replyToId: String? = null, val attachmentIds: List<String> = emptyList(), val clientId: String? = null)
/** Zmienione od `since` wiadomości (także edytowane i usunięte „nagrobki”), rosnąco po czasie zmiany. [serverTime] = punkt odniesienia kolejnej synchronizacji. */
@Serializable data class MessageChangesResponse(val messages: List<MessageDto>, val nextCursor: String? = null, val serverTime: String)
@Serializable data class EditMessageRequest(val body: String)
@Serializable data class ConversationSettingsRequest(val muted: Boolean? = null, val archived: Boolean? = null)
@Serializable data class AddMemberRequest(val user: String)
@Serializable data class SetReactionRequest(val kind: String)
@Serializable data class MemberRoleRequest(val role: String)
@Serializable data class MessageSettingsDto(val readReceipts: Boolean)

fun PersonRef.toDto() = PersonDto(winkwinkId, nickname, displayName, mediaTag(avatarKey))

fun MessageAttachmentRow.toDto() = MessageAttachmentDto(id.toString(), kind, mime, sizeBytes, fileName, width, height, durationMs)

fun MessageView.toDto() = MessageDto(
    id = row.id.toString(), conversationId = row.conversationId.toString(), sender = row.sender.toDto(),
    body = row.body, replyToId = row.replyToId?.toString(), createdAt = row.createdAt.toString(),
    editedAt = row.editedAt?.toString(), deleted = row.deleted, mine = mine, status = status,
    reactions = reactions.map { ReactionDto(it.kind, it.count, it.mine) },
    attachments = attachments.map { it.toDto() },
)

/** Podgląd ostatniej wiadomości na liście nie zawiera statusu (liczony tylko przy czytaniu rozmowy). */
fun SummaryRow.toDto(viewer: java.util.UUID) = ConversationDto(
    id = conversation.id.toString(), kind = conversation.kind, title = conversation.title, peer = peer?.toDto(),
    memberCount = memberCount, muted = muted, archived = archived, unreadCount = unread, myRole = role,
    lastMessage = last?.let { MessageView(it, it.sender.accountId == viewer, null, attachments = lastAttachments).toDto() }, activityAt = activity.toString(),
)

fun MemberRow.toDto() = MemberDto(person.toDto(), role, joinedAt.toString())
