package app.winkwink.server.realtime

import app.winkwink.server.auth.JWT_AUTH
import app.winkwink.server.auth.UserPrincipal
import app.winkwink.server.message.MessageService
import io.ktor.server.auth.authenticate
import io.ktor.server.auth.principal
import io.ktor.server.routing.Route
import io.ktor.server.websocket.webSocket
import io.ktor.websocket.CloseReason
import io.ktor.websocket.Frame
import io.ktor.websocket.close
import io.ktor.websocket.readText
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.time.Clock
import java.time.Duration
import java.util.UUID

@Serializable
private data class ClientFrame(val type: String, val conversationId: String? = null)

private val frameJson = Json { ignoreUnknownKeys = true }

/**
 * `GET /api/v1/ws` (po proxy: wss). Uwierzytelnianie: nagłówek `Authorization: Bearer` w żądaniu otwierającym
 * (token nigdy nie trafia do adresu URL ani logów). Połączenie żyje najwyżej [maxLifetime]; co [checkEvery]
 * sprawdzamy, czy sesja nadal jest aktywna — po wylogowaniu/unieważnieniu serwer zamyka połączenie.
 * Klient → serwer: `typing` (wskaźnik pisania) i `ping`. Wszystko inne (wysyłanie wiadomości, historia) idzie przez REST.
 */
fun Route.realtimeRoutes(
    hub: RealtimeHub,
    messages: MessageService,
    sessionActive: suspend (sessionId: UUID, accountId: UUID) -> Boolean,
    clock: Clock = Clock.systemUTC(),
    maxLifetime: Duration = Duration.ofMinutes(15),
    checkEvery: Duration = Duration.ofSeconds(30),
) {
    authenticate(JWT_AUTH) {
        webSocket("/ws") {
            val principal = call.principal<UserPrincipal>()
            if (principal == null) { close(CloseReason(CloseReason.Codes.VIOLATED_POLICY, "unauthorized")); return@webSocket }
            val conn = hub.connect(principal.accountId, principal.sessionId)
            val writer = launch {
                for (text in conn.outbox) send(Frame.Text(text))
                // Kolejka zamknięta przez hub (wyparte połączenie lub unieważniona sesja).
                runCatching { close(CloseReason(CloseReason.Codes.TRY_AGAIN_LATER, "closed")) }
            }
            val watchdog = launch {
                val deadline = clock.instant().plus(maxLifetime)
                while (true) {
                    delay(checkEvery.toMillis())
                    if (clock.instant().isAfter(deadline)) { close(CloseReason(CloseReason.Codes.GOING_AWAY, "reconnect")); break }
                    if (!sessionActive(principal.sessionId, principal.accountId)) { close(CloseReason(CloseReason.Codes.VIOLATED_POLICY, "session_expired")); break }
                }
            }
            try {
                conn.outbox.trySend(RealtimeEvents.encode(RealtimeEvent("hello")))
                val typingAt = HashMap<UUID, Long>()
                var windowStart = clock.millis()
                var frames = 0
                for (frame in incoming) {
                    if (frame !is Frame.Text) continue
                    val now = clock.millis()
                    if (now - windowStart > 10_000) { windowStart = now; frames = 0 }
                    if (++frames > MAX_FRAMES_PER_WINDOW) { close(CloseReason(CloseReason.Codes.VIOLATED_POLICY, "rate_limited")); break }
                    val f = runCatching { frameJson.decodeFromString<ClientFrame>(frame.readText()) }.getOrNull() ?: continue
                    when (f.type) {
                        "typing" -> {
                            val id = f.conversationId?.let { runCatching { UUID.fromString(it) }.getOrNull() } ?: continue
                            // Nie częściej niż co 2 s na rozmowę; nadmiarowe ramki są po cichu pomijane.
                            if (now - (typingAt[id] ?: 0L) < TYPING_MIN_GAP_MS) continue
                            typingAt[id] = now
                            messages.typing(principal.accountId, id)
                        }
                        "ping" -> conn.outbox.trySend("""{"type":"pong"}""")
                    }
                }
            } finally {
                writer.cancel()
                watchdog.cancel()
                hub.disconnect(conn)
            }
        }
    }
}

private const val MAX_FRAMES_PER_WINDOW = 60
private const val TYPING_MIN_GAP_MS = 2_000L
