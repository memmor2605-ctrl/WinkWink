package app.winkwink.server.auth

import app.winkwink.server.api.ApiException
import app.winkwink.server.config.AuthConfig
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.slf4j.LoggerFactory
import java.security.SecureRandom
import java.time.Clock
import java.time.Instant
import java.util.UUID

data class IssuedSession(
    val sessionId: UUID,
    val accessToken: String,
    val accessExpiresAt: Instant,
    val refreshToken: String,
    val refreshExpiresAt: Instant,
)

data class AuthResult(val session: IssuedSession, val profile: ProfileRecord, val email: String)

class AuthService(
    private val store: AuthStore,
    private val hasher: PasswordHasher,
    val tokens: TokenService,
    private val email: EmailSender,
    private val config: AuthConfig,
    private val clock: Clock = Clock.systemUTC(),
    private val random: SecureRandom = SecureRandom(),
    /** Pliki konta do usunięcia razem z kontem; `null` = konto bez plików (testy). */
    private val accountMedia: AccountMedia? = null,
    private val push: app.winkwink.server.push.PushGateway = app.winkwink.server.push.PushGateway.None,
) {
    private val log = LoggerFactory.getLogger("app.winkwink.security")

    /** Wyrównuje czas odpowiedzi dla nieistniejących kont (weryfikacja na atrapie hasha). */
    private val dummyHash: String by lazy { hasher.hash("winkwink-timing-equalizer") }

    suspend fun register(
        rawEmail: String,
        password: String,
        nickname: String,
        platform: String,
        deviceName: String?,
        userAgent: String?,
    ): AuthResult {
        val email = Validators.normalizeEmail(rawEmail)
        val problems = listOfNotNull(
            Validators.emailError(email),
            Validators.passwordError(password, email),
            Validators.nicknameError(nickname),
            Validators.platformError(platform),
            Validators.deviceNameError(deviceName),
        )
        if (problems.isNotEmpty()) throw validation(problems)

        val passwordHash = hashAsync(password)
        var attempts = 0
        while (true) {
            try {
                val account = store.createAccount(email, passwordHash, nickname, generateWinkWinkId())
                val profile = store.findProfile(account.id) ?: error("Profile missing right after registration")
                log.info("Account registered")
                return AuthResult(openSession(account.id, platform, deviceName, userAgent), profile, account.email)
            } catch (e: DuplicateException) {
                when (e.field) {
                    "email" -> throw ApiException(HttpStatusCode.Conflict, "email_taken", "This e-mail address is already registered.")
                    "nickname" -> throw ApiException(HttpStatusCode.Conflict, "nickname_taken", "This username is already taken.")
                    else -> if (++attempts >= 5) throw IllegalStateException("Could not allocate a unique WinkWink ID")
                }
            }
        }
    }

    suspend fun login(
        rawEmail: String,
        password: String,
        platform: String,
        deviceName: String?,
        userAgent: String?,
        clientIp: String,
    ): AuthResult {
        val email = Validators.normalizeEmail(rawEmail)
        val problems = listOfNotNull(Validators.platformError(platform), Validators.deviceNameError(deviceName))
        if (problems.isNotEmpty() || email.isEmpty() || password.isEmpty() || password.length > Validators.PASSWORD_MAX) {
            throw if (problems.isNotEmpty()) validation(problems) else invalidCredentials()
        }
        val emailKey = "e:" + Crypto.sha256Hex(email)
        val ipKey = "i:" + Crypto.sha256Hex(clientIp)
        enforceLockout(emailKey, ipKey)

        val account = store.findAccountByEmail(email)
        val verified = verifyAsync(password, account?.passwordHash ?: dummyHash) && account != null
        if (!verified || account == null) {
            val now = clock.instant()
            store.recordAttempt(emailKey, now)
            store.recordAttempt(ipKey, now)
            log.warn("Failed login attempt")
            throw invalidCredentials()
        }
        if (account.status != "active") {
            log.warn("Login refused for non-active account")
            throw ApiException(HttpStatusCode.Forbidden, "account_unavailable", "This account is not available.")
        }
        store.clearAttempts(emailKey)
        val profile = store.findProfile(account.id) ?: error("Profile missing for account")
        val session = openSession(account.id, platform, deviceName, userAgent)
        // Ostrzeżenie dla pozostałych urządzeń (nowa sesja nie ma jeszcze tokenu push, więc nie dostanie własnego ostrzeżenia).
        push.accountEvent(account.id, "new_login", null)
        return AuthResult(session, profile, account.email)
    }

    suspend fun refresh(refreshToken: String): IssuedSession {
        if (refreshToken.isBlank() || refreshToken.length > 200) throw invalidRefresh()
        val hash = Crypto.sha256(refreshToken)
        val found = store.findSessionByRefreshHash(hash) ?: throw invalidRefresh()
        val now = clock.instant()
        if (!found.isCurrentToken) {
            // Użyto już zrotowanego tokenu: zakładamy przejęcie i unieważniamy całą sesję.
            store.revokeSessionById(found.id, now)
            log.warn("Refresh token reuse detected; session revoked")
            throw ApiException(HttpStatusCode.Unauthorized, "refresh_token_reused", "Session was revoked. Please sign in again.")
        }
        if (found.revokedAt != null || !found.expiresAt.isAfter(now)) throw invalidRefresh()
        val account = store.findAccountById(found.accountId)
        if (account == null || account.status != "active") throw invalidRefresh()

        val newToken = Crypto.randomToken(random)
        val refreshExpires = now.plusSeconds(config.refreshTtlDays * 86_400)
        if (!store.rotateSession(found.id, hash, Crypto.sha256(newToken), now, refreshExpires)) throw invalidRefresh()
        val access = tokens.issueAccessToken(account.id, found.id)
        return IssuedSession(found.id, access.token, access.expiresAt, newToken, refreshExpires)
    }

    suspend fun isSessionActive(sessionId: UUID, accountId: UUID): Boolean =
        store.isSessionActive(sessionId, accountId, clock.instant())

    suspend fun logout(accountId: UUID, sessionId: UUID) {
        store.revokeSession(sessionId, accountId, clock.instant())
        push.forgetSession(sessionId) // to urządzenie nie dostaje już powiadomień tego konta
    }

    suspend fun me(accountId: UUID): AuthMe {
        val account = store.findAccountById(accountId) ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")
        val profile = store.findProfile(accountId) ?: error("Profile missing for account")
        return AuthMe(account.email, profile)
    }

    suspend fun listSessions(accountId: UUID): List<SessionView> = store.listSessions(accountId, clock.instant())

    suspend fun revokeSession(accountId: UUID, sessionId: UUID) {
        if (!store.revokeSession(sessionId, accountId, clock.instant())) {
            throw ApiException(HttpStatusCode.NotFound, "not_found", "Session not found.")
        }
        push.forgetSession(sessionId)
    }

    suspend fun revokeOtherSessions(accountId: UUID, currentSessionId: UUID): Int =
        store.revokeAllSessions(accountId, currentSessionId, clock.instant()).also { push.forgetOthers(accountId, currentSessionId) }

    suspend fun changePassword(accountId: UUID, currentSessionId: UUID, current: String, new: String) {
        val account = store.findAccountById(accountId) ?: throw invalidCredentials()
        val key = "e:" + Crypto.sha256Hex(account.email)
        enforceLockout(key, null)
        if (!verifyAsync(current, account.passwordHash)) {
            store.recordAttempt(key, clock.instant())
            throw ApiException(HttpStatusCode.Forbidden, "wrong_password", "The current password is incorrect.")
        }
        Validators.passwordError(new, account.email)?.let { throw validation(listOf(it)) }
        store.updatePasswordHash(accountId, hashAsync(new))
        store.clearAttempts(key)
        val revoked = store.revokeAllSessions(accountId, currentSessionId, clock.instant())
        push.accountEvent(accountId, "password_changed", currentSessionId) // zanim usuniemy tokeny pozostałych sesji
        push.forgetOthers(accountId, currentSessionId)
        log.info("Password changed; {} other sessions revoked", revoked)
    }

    /**
     * Usunięcie konta wymaga aktualnego hasła (ochrona przed przejęciem otwartej sesji). Kolejność: (1) lista kluczy plików konta,
     * (2) usunięcie konta kaskadą w jednej transakcji, (3) usunięcie plików. Błąd w kroku 3 nie cofa usunięcia konta —
     * pliki bez rekordu w bazie zbiera okresowa rekoncyliacja magazynu. Ponowienie po sukcesie → 401 (konto nie istnieje).
     */
    suspend fun deleteAccount(accountId: UUID, password: String) {
        val account = store.findAccountById(accountId) ?: throw invalidCredentials()
        val key = "e:" + Crypto.sha256Hex(account.email)
        enforceLockout(key, null)
        if (!verifyAsync(password, account.passwordHash)) {
            store.recordAttempt(key, clock.instant())
            throw ApiException(HttpStatusCode.Forbidden, "wrong_password", "The password is incorrect.")
        }
        val keys = accountMedia?.keysOf(accountId).orEmpty()
        store.deleteAccount(accountId)
        accountMedia?.deleteFiles(keys)
        log.info("Account deleted ({} media objects scheduled for removal)", keys.size)
    }

    /** Zawsze kończy się „sukcesem” dla poprawnego formatu — nie ujawnia, czy konto istnieje. */
    suspend fun requestPasswordReset(rawEmail: String) {
        val addr = Validators.normalizeEmail(rawEmail)
        Validators.emailError(addr)?.let { throw validation(listOf(it)) }
        if (!email.isConfigured) email.sendPasswordReset(addr, "") // rzuca 503 niezależnie od istnienia konta
        val now = clock.instant()
        val key = "r:" + Crypto.sha256Hex(addr)
        if (store.countAttempts(key, now.minusSeconds(3600)) >= 5) return
        store.recordAttempt(key, now)
        val account = store.findAccountByEmail(addr)?.takeIf { it.status == "active" }
        if (account == null) return // brak różnicy w odpowiedzi dla nieistniejącego konta
        val token = Crypto.randomToken(random)
        store.createResetToken(account.id, Crypto.sha256(token), now, now.plusSeconds(config.resetTtlMinutes * 60))
        email.sendPasswordReset(account.email, token)
        log.info("Password reset requested")
    }

    suspend fun resetPassword(token: String, newPassword: String) {
        if (token.isBlank() || token.length > 200) throw invalidResetToken()
        Validators.passwordError(newPassword, null)?.let { throw validation(listOf(it)) }
        val accountId = store.consumeResetToken(Crypto.sha256(token), clock.instant()) ?: throw invalidResetToken()
        store.updatePasswordHash(accountId, hashAsync(newPassword))
        store.revokeAllSessions(accountId, null, clock.instant())
        log.info("Password reset completed; all sessions revoked")
    }

    // --- pomocnicze ---

    private suspend fun openSession(accountId: UUID, platform: String, deviceName: String?, userAgent: String?): IssuedSession {
        val now = clock.instant()
        val refresh = Crypto.randomToken(random)
        val refreshExpires = now.plusSeconds(config.refreshTtlDays * 86_400)
        val sessionId = store.createSession(
            accountId, platform, deviceName, userAgent?.take(300), Crypto.sha256(refresh), now, refreshExpires,
        )
        val access = tokens.issueAccessToken(accountId, sessionId)
        return IssuedSession(sessionId, access.token, access.expiresAt, refresh, refreshExpires)
    }

    private suspend fun enforceLockout(emailKey: String, ipKey: String?) {
        val since = clock.instant().minusSeconds(config.lockoutWindowMinutes * 60)
        val locked = store.countAttempts(emailKey, since) >= config.maxFailuresPerAccount ||
            (ipKey != null && store.countAttempts(ipKey, since) >= config.maxFailuresPerIp)
        if (locked) {
            log.warn("Login blocked by brute-force protection")
            throw ApiException(
                HttpStatusCode.TooManyRequests, "too_many_attempts",
                "Too many failed attempts. Try again later.", retryAfterSeconds = config.lockoutWindowMinutes * 60,
            )
        }
    }

    private fun generateWinkWinkId(): String {
        val alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
        return "ww_" + (1..10).map { alphabet[random.nextInt(alphabet.length)] }.joinToString("")
    }

    private suspend fun hashAsync(password: String) = withContext(Dispatchers.Default) { hasher.hash(password) }
    private suspend fun verifyAsync(password: String, hash: String) = withContext(Dispatchers.Default) { hasher.verify(password, hash) }

    private fun validation(problems: List<String>) =
        ApiException(HttpStatusCode.UnprocessableEntity, "validation_failed", "Some fields are invalid.", problems)

    private fun invalidCredentials() =
        ApiException(HttpStatusCode.Unauthorized, "invalid_credentials", "Incorrect e-mail or password.")

    private fun invalidRefresh() =
        ApiException(HttpStatusCode.Unauthorized, "invalid_refresh_token", "Session expired. Please sign in again.")

    private fun invalidResetToken() =
        ApiException(HttpStatusCode.BadRequest, "invalid_or_expired_token", "The reset code is invalid or has expired.")
}

data class AuthMe(val email: String, val profile: ProfileRecord)
