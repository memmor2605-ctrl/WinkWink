package app.winkwink.server.push

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.sql.Connection
import java.sql.Timestamp
import java.time.Instant
import java.util.UUID
import javax.sql.DataSource

data class PushPrefs(val messages: Boolean, val previews: Boolean)

interface PushStore {
    /** Rejestruje albo przepisuje token na [account]/[session]. Zachowuje najwyżej [MAX_TOKENS] najnowszych tokenów konta. */
    suspend fun upsertToken(account: UUID, session: UUID?, token: String, deviceName: String?, now: Instant)
    /** Usuwa token tylko jeśli należy do [account]. */
    suspend fun deleteToken(account: UUID, token: String): Boolean
    suspend fun deleteTokenValue(token: String)
    suspend fun deleteBySession(session: UUID)
    suspend fun deleteForAccountExcept(account: UUID, keepSession: UUID)
    /** Tokeny konta z aktywnymi sesjami; [exceptSession] pomija urządzenie wykonujące akcję. */
    suspend fun tokens(account: UUID, exceptSession: UUID? = null): List<String>
    suspend fun prefs(account: UUID): PushPrefs
    suspend fun setPrefs(account: UUID, messages: Boolean?, previews: Boolean?)

    companion object { const val MAX_TOKENS = 10 }
}

class PostgresPushStore(private val dataSource: DataSource) : PushStore {
    private suspend fun <T> tx(block: (Connection) -> T): T = withContext(Dispatchers.IO) {
        dataSource.connection.use { c ->
            c.autoCommit = false
            try { val r = block(c); c.commit(); r } catch (e: Throwable) { c.rollback(); throw e }
        }
    }

    override suspend fun upsertToken(account: UUID, session: UUID?, token: String, deviceName: String?, now: Instant) = tx { c ->
        c.prepareStatement(
            "INSERT INTO push_tokens (account_id, session_id, token, device_name, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?) " +
                "ON CONFLICT (token) DO UPDATE SET account_id = EXCLUDED.account_id, session_id = EXCLUDED.session_id, " +
                "device_name = EXCLUDED.device_name, updated_at = EXCLUDED.updated_at",
        ).use { ps ->
            ps.setObject(1, account); ps.setObject(2, session); ps.setString(3, token); ps.setString(4, deviceName)
            ps.setTimestamp(5, Timestamp.from(now)); ps.setTimestamp(6, Timestamp.from(now)); ps.executeUpdate()
        }
        // Limit tokenów na konto: najstarsze (po updated_at) wypadają.
        c.prepareStatement(
            "DELETE FROM push_tokens WHERE account_id = ? AND id NOT IN " +
                "(SELECT id FROM push_tokens WHERE account_id = ? ORDER BY updated_at DESC, id LIMIT ?)",
        ).use { ps -> ps.setObject(1, account); ps.setObject(2, account); ps.setInt(3, PushStore.MAX_TOKENS); ps.executeUpdate() }
        Unit
    }

    override suspend fun deleteToken(account: UUID, token: String): Boolean = tx { c ->
        c.prepareStatement("DELETE FROM push_tokens WHERE account_id = ? AND token = ?").use { ps ->
            ps.setObject(1, account); ps.setString(2, token); ps.executeUpdate() > 0
        }
    }

    override suspend fun deleteTokenValue(token: String) = tx { c ->
        c.prepareStatement("DELETE FROM push_tokens WHERE token = ?").use { ps -> ps.setString(1, token); ps.executeUpdate() }
        Unit
    }

    override suspend fun deleteBySession(session: UUID) = tx { c ->
        c.prepareStatement("DELETE FROM push_tokens WHERE session_id = ?").use { ps -> ps.setObject(1, session); ps.executeUpdate() }
        Unit
    }

    override suspend fun deleteForAccountExcept(account: UUID, keepSession: UUID) = tx { c ->
        c.prepareStatement("DELETE FROM push_tokens WHERE account_id = ? AND (session_id IS NULL OR session_id <> ?)").use { ps ->
            ps.setObject(1, account); ps.setObject(2, keepSession); ps.executeUpdate()
        }
        Unit
    }

    override suspend fun tokens(account: UUID, exceptSession: UUID?): List<String> = tx { c ->
        c.prepareStatement(
            "SELECT t.token FROM push_tokens t LEFT JOIN sessions s ON s.id = t.session_id " +
                "WHERE t.account_id = ? AND (t.session_id IS NULL OR (s.revoked_at IS NULL AND s.expires_at > now())) " +
                "AND (?::uuid IS NULL OR t.session_id IS DISTINCT FROM ?::uuid)",
        ).use { ps ->
            ps.setObject(1, account); ps.setObject(2, exceptSession); ps.setObject(3, exceptSession)
            ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.getString(1)) } }
        }
    }

    override suspend fun prefs(account: UUID): PushPrefs = tx { c ->
        c.prepareStatement("SELECT push_messages, push_previews FROM message_settings WHERE account_id = ?").use { ps ->
            ps.setObject(1, account)
            ps.executeQuery().use { if (it.next()) PushPrefs(it.getBoolean(1), it.getBoolean(2)) else PushPrefs(true, false) }
        }
    }

    override suspend fun setPrefs(account: UUID, messages: Boolean?, previews: Boolean?) = tx { c ->
        c.prepareStatement(
            "INSERT INTO message_settings (account_id, push_messages, push_previews) VALUES (?, coalesce(?, true), coalesce(?, false)) " +
                "ON CONFLICT (account_id) DO UPDATE SET push_messages = coalesce(?, message_settings.push_messages), " +
                "push_previews = coalesce(?, message_settings.push_previews)",
        ).use { ps ->
            ps.setObject(1, account); ps.setObject(2, messages); ps.setObject(3, previews); ps.setObject(4, messages); ps.setObject(5, previews)
            ps.executeUpdate()
        }
        Unit
    }
}
