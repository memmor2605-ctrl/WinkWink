package app.winkwink.server.feed

import app.winkwink.server.api.ApiException
import app.winkwink.server.auth.JWT_AUTH
import app.winkwink.server.auth.UserPrincipal
import app.winkwink.server.idempotency.Idempotency
import app.winkwink.server.idempotency.respondIdempotent
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.auth.authenticate
import io.ktor.server.auth.principal
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.delete
import io.ktor.server.routing.get
import io.ktor.server.routing.patch
import io.ktor.server.routing.post
import io.ktor.server.routing.put
import java.util.UUID

private fun ApplicationCall.viewer(): UUID =
    (principal<UserPrincipal>() ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")).accountId

private fun ApplicationCall.limit(): Int? = request.queryParameters["limit"]?.let {
    it.toIntOrNull() ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "limit must be an integer.")
}
private fun ApplicationCall.cursor(): String? = request.queryParameters["cursor"]
private fun ApplicationCall.pid() = FeedService.postId(parameters["id"])

fun Route.feedRoutes(service: FeedService, idem: Idempotency? = null) {
    authenticate(JWT_AUTH) {
        post("/posts") {
            val b = call.receive<CreatePostRequest>()
            val v = call.viewer()
            call.respondIdempotent(idem, v, "POST /posts", HttpStatusCode.Created, fingerprint = b.toString()) {
                service.create(v, b.body, b.visibility, b.anonymous, b.communityId, b.channelId, b.attachmentIds).toDto(v)
            }
        }
        // Stałe segmenty ("search") mają pierwszeństwo przed {id} w Ktor.
        get("/posts/search") {
            val v = call.viewer()
            val q = call.request.queryParameters["q"] ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "Missing q.")
            call.respond(service.search(v, q, call.limit(), call.cursor()).toResponse(v))
        }
        post("/posts/{id}/share") {
            val v = call.viewer()
            val b = call.receive<SharePostRequest>()
            val pid = call.pid()
            call.respondIdempotent(idem, v, "POST /posts/share", HttpStatusCode.Created, fingerprint = "$pid|$b") { service.share(v, pid, b.comment, b.visibility).toDto(v) }
        }
        get("/posts/{id}") { val v = call.viewer(); call.respond(service.get(v, call.pid()).toDto(v)) }
        patch("/posts/{id}") {
            val v = call.viewer()
            call.respond(service.update(v, call.pid(), call.receive<UpdatePostRequest>().body).toDto(v))
        }
        delete("/posts/{id}") { service.delete(call.viewer(), call.pid()); call.respond(HttpStatusCode.NoContent) }

        get("/feed/following") { val v = call.viewer(); call.respond(service.followingFeed(v, call.limit(), call.cursor()).toResponse(v)) }
        get("/feed/discover") { val v = call.viewer(); call.respond(service.discover(v, call.limit(), call.cursor()).toResponse(v)) }
        get("/users/{id}/posts") {
            val v = call.viewer()
            val ident = call.parameters["id"] ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "Missing user identifier.")
            call.respond(service.userPosts(v, ident, call.limit(), call.cursor()).toResponse(v))
        }
        get("/communities/{id}/posts") {
            val v = call.viewer()
            call.respond(service.communityPosts(v, call.parameters["id"], call.request.queryParameters["channel"], call.limit(), call.cursor()).toResponse(v))
        }
        get("/me/saved") { val v = call.viewer(); call.respond(service.saved(v, call.limit(), call.cursor()).toResponse(v)) }

        put("/posts/{id}/reaction") {
            val v = call.viewer()
            call.respond(service.react(v, call.pid(), call.receive<ReactionRequest>().type).toDto(v))
        }
        delete("/posts/{id}/reaction") { val v = call.viewer(); call.respond(service.unreact(v, call.pid()).toDto(v)) }
        post("/posts/{id}/save") { service.save(call.viewer(), call.pid()); call.respond(HttpStatusCode.NoContent) }
        delete("/posts/{id}/save") { service.unsave(call.viewer(), call.pid()); call.respond(HttpStatusCode.NoContent) }

        get("/posts/{id}/comments") {
            val v = call.viewer()
            call.respond(service.comments(v, call.pid(), null, call.limit(), call.cursor()).toResponse(v))
        }
        post("/posts/{id}/comments") {
            val v = call.viewer()
            val b = call.receive<CreateCommentRequest>()
            val parent = b.parentId?.let { FeedService.commentId(it) }
            val pid = call.pid()
            call.respondIdempotent(idem, v, "POST /posts/comments", HttpStatusCode.Created, fingerprint = "$pid|$b") { service.addComment(v, pid, parent, b.body).toDto(v) }
        }
        get("/posts/{id}/comments/{commentId}/replies") {
            val v = call.viewer()
            call.respond(service.comments(v, call.pid(), FeedService.commentId(call.parameters["commentId"]), call.limit(), call.cursor()).toResponse(v))
        }
        delete("/comments/{id}") { service.deleteComment(call.viewer(), FeedService.commentId(call.parameters["id"])); call.respond(HttpStatusCode.NoContent) }
    }
}
