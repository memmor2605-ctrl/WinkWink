package app.winkwink.server.message

import app.winkwink.server.api.ApiException
import app.winkwink.server.auth.JWT_AUTH
import app.winkwink.server.auth.UserPrincipal
import app.winkwink.server.idempotency.Idempotency
import app.winkwink.server.idempotency.respondIdempotent
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.auth.authenticate
import io.ktor.server.auth.principal
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.delete
import io.ktor.server.routing.get
import io.ktor.server.routing.patch
import io.ktor.server.routing.post
import io.ktor.server.routing.put
import java.util.UUID

private fun ApplicationCall.viewer(): UUID =
    (principal<UserPrincipal>() ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")).accountId

private fun ApplicationCall.limit(): Int? = request.queryParameters["limit"]?.let {
    it.toIntOrNull() ?: throw ApiException(HttpStatusCode.BadRequest, "bad_request", "limit must be an integer.")
}

private fun ApplicationCall.uuid(name: String, code: String): UUID =
    runCatching { UUID.fromString(parameters[name]) }.getOrNull() ?: throw ApiException(HttpStatusCode.NotFound, code, "Not found.")

private fun ApplicationCall.conversationId() = uuid("id", "conversation_not_found")
private fun ApplicationCall.messageId() = uuid("id", "message_not_found")

fun Route.messageRoutes(service: MessageService, idem: Idempotency? = null) {
    authenticate(JWT_AUTH) {
        get("/conversations") {
            val q = call.request.queryParameters
            val v = call.viewer()
            val page = service.list(v, q["archived"] == "true", q["q"], call.limit(), q["cursor"])
            call.respond(ConversationListResponse(page.items.map { it.toDto(v) }, page.nextCursor))
        }
        post("/conversations/direct") {
            val v = call.viewer()
            call.respond(HttpStatusCode.OK, service.startDirect(v, call.receive<StartDirectRequest>().user).toDto(v))
        }
        post("/conversations/group") {
            val v = call.viewer(); val b = call.receive<CreateGroupRequest>()
            call.respondIdempotent(idem, v, "POST /conversations/group", HttpStatusCode.Created, fingerprint = b.toString()) { service.createGroup(v, b.title, b.members).toDto(v) }
        }
        get("/conversations/{id}") { val v = call.viewer(); call.respond(service.get(v, call.conversationId()).toDto(v)) }
        patch("/conversations/{id}/settings") {
            val v = call.viewer(); val b = call.receive<ConversationSettingsRequest>()
            call.respond(service.setFlags(v, call.conversationId(), b.muted, b.archived).toDto(v))
        }
        post("/conversations/{id}/read") { service.markRead(call.viewer(), call.conversationId()); call.respond(HttpStatusCode.NoContent) }
        get("/conversations/{id}/messages") {
            val v = call.viewer()
            val page = service.messages(v, call.conversationId(), call.limit(), call.request.queryParameters["cursor"])
            call.respond(MessageListResponse(page.items.map { it.toDto() }, page.nextCursor))
        }
        get("/conversations/{id}/messages/changes") {
            val v = call.viewer(); val q = call.request.queryParameters
            val page = service.changes(v, call.conversationId(), q["since"], call.limit(), q["cursor"])
            call.respond(MessageChangesResponse(page.items.map { it.toDto() }, page.nextCursor, page.serverTime.toString()))
        }
        post("/conversations/{id}/messages") {
            val v = call.viewer(); val b = call.receive<SendMessageRequest>()
            val reply = b.replyToId?.let { runCatching { UUID.fromString(it) }.getOrNull() ?: throw ApiException(HttpStatusCode.BadRequest, "validation_failed", "replyToId: invalid id") }
            val attachments = b.attachmentIds.map { id -> runCatching { UUID.fromString(id) }.getOrNull() ?: throw ApiException(HttpStatusCode.BadRequest, "validation_failed", "attachmentIds: invalid id") }
            val clientId = b.clientId?.let { runCatching { UUID.fromString(it) }.getOrNull() ?: throw ApiException(HttpStatusCode.BadRequest, "validation_failed", "clientId: invalid id") }
            call.respond(HttpStatusCode.Created, service.send(v, call.conversationId(), b.body, reply, attachments, clientId).toDto())
        }
        get("/conversations/{id}/members") {
            call.respond(MemberListResponse(service.members(call.viewer(), call.conversationId()).map { it.toDto() }))
        }
        post("/conversations/{id}/members") {
            val b = call.receive<AddMemberRequest>()
            call.respond(MemberListResponse(service.addMember(call.viewer(), call.conversationId(), b.user).map { it.toDto() }))
        }
        delete("/conversations/{id}/members/{user}") {
            service.removeMember(call.viewer(), call.conversationId(), call.parameters["user"].orEmpty())
            call.respond(HttpStatusCode.NoContent)
        }
        put("/conversations/{id}/members/{user}/role") {
            val b = call.receive<MemberRoleRequest>()
            call.respond(MemberListResponse(service.setMemberRole(call.viewer(), call.conversationId(), call.parameters["user"].orEmpty(), b.role).map { it.toDto() }))
        }
        get("/messages/settings") { call.respond(MessageSettingsDto(service.readReceipts(call.viewer()))) }
        put("/messages/settings") {
            val b = call.receive<MessageSettingsDto>()
            call.respond(MessageSettingsDto(service.setReadReceipts(call.viewer(), b.readReceipts)))
        }
        patch("/messages/{id}") {
            val v = call.viewer()
            call.respond(service.edit(v, call.messageId(), call.receive<EditMessageRequest>().body).toDto())
        }
        put("/messages/{id}/reaction") {
            val v = call.viewer()
            call.respond(service.react(v, call.messageId(), call.receive<SetReactionRequest>().kind).toDto())
        }
        delete("/messages/{id}/reaction") { val v = call.viewer(); call.respond(service.react(v, call.messageId(), null).toDto()) }
        delete("/messages/{id}") { service.delete(call.viewer(), call.messageId()); call.respond(HttpStatusCode.NoContent) }
    }
}
