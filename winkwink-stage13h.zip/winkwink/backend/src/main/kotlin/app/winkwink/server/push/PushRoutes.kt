package app.winkwink.server.push

import app.winkwink.server.api.ApiException
import app.winkwink.server.auth.JWT_AUTH
import app.winkwink.server.auth.UserPrincipal
import io.ktor.http.HttpStatusCode
import io.ktor.server.auth.authenticate
import io.ktor.server.auth.principal
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.delete
import io.ktor.server.routing.get
import io.ktor.server.routing.put
import kotlinx.serialization.Serializable

@Serializable data class RegisterPushTokenRequest(val token: String, val deviceName: String? = null)
@Serializable data class PushSettingsDto(val messages: Boolean? = null, val previews: Boolean? = null)
@Serializable data class PushSettingsResponse(val messages: Boolean, val previews: Boolean, val configured: Boolean)

fun Route.pushRoutes(service: PushService, configured: Boolean) {
    authenticate(JWT_AUTH) {
        // PUT = idempotentna rejestracja/odświeżenie tokenu bieżącego urządzenia (token jest przypięty do sesji).
        put("/push/token") {
            val u = call.principal<UserPrincipal>() ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")
            val b = call.receive<RegisterPushTokenRequest>()
            service.register(u.accountId, u.sessionId, b.token, b.deviceName)
            call.respond(HttpStatusCode.NoContent)
        }
        // DELETE z ciałem bywa gubione przez proxy; token idzie w nagłówku (nie w URL, żeby nie trafiał do logów dostępu).
        delete("/push/token") {
            val u = call.principal<UserPrincipal>() ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")
            val token = call.request.headers["X-Push-Token"] ?: throw ApiException(HttpStatusCode.BadRequest, "validation_failed", "X-Push-Token header: required")
            service.unregister(u.accountId, token)
            call.respond(HttpStatusCode.NoContent)
        }
        get("/push/settings") {
            val u = call.principal<UserPrincipal>() ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")
            val p = service.prefs(u.accountId)
            call.respond(PushSettingsResponse(p.messages, p.previews, configured))
        }
        put("/push/settings") {
            val u = call.principal<UserPrincipal>() ?: throw ApiException(HttpStatusCode.Unauthorized, "unauthorized", "Authentication required.")
            val b = call.receive<PushSettingsDto>()
            val p = service.setPrefs(u.accountId, b.messages, b.previews)
            call.respond(PushSettingsResponse(p.messages, p.previews, configured))
        }
    }
}
