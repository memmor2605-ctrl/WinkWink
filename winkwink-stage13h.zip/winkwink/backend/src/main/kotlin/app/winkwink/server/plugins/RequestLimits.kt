package app.winkwink.server.plugins

import app.winkwink.server.api.respondError
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.Application
import io.ktor.server.application.ApplicationCallPipeline
import io.ktor.server.request.httpMethod
import io.ktor.server.request.path

/**
 * Limity rozmiaru żądań egzekwowane PRZED odczytem ciała (po nagłówkach, więc bez pamięci na ciało, którego i tak nie przyjmiemy).
 * Zwykłe żądania JSON: [JSON_MAX_BYTES]. Wysyłanie plików: [UPLOAD_MAX_BYTES] jako sufit; dokładne limity per typ pliku
 * sprawdzają trasy i serwisy (np. zdjęcie 8 MB, film 30 MB). Ciała bez Content-Length (chunked) są odrzucane — nie da się ich ograniczyć z góry.
 */
const val JSON_MAX_BYTES = 256L * 1024
const val UPLOAD_MAX_BYTES = 40L * 1024 * 1024

private val UPLOAD_PATH = Regex(".*/(attachments|message-attachments|me/avatar|me/background)$")

fun Application.configureRequestLimits() {
    intercept(ApplicationCallPipeline.Plugins) {
        val method = call.request.httpMethod
        if (method != HttpMethod.Post && method != HttpMethod.Put && method != HttpMethod.Patch) return@intercept
        if (call.request.headers[HttpHeaders.TransferEncoding] != null) {
            call.respondError(HttpStatusCode.LengthRequired, "length_required", "Content-Length is required.")
            finish(); return@intercept
        }
        val length = call.request.headers[HttpHeaders.ContentLength]?.toLongOrNull() ?: return@intercept
        val max = if (UPLOAD_PATH.matches(call.request.path())) UPLOAD_MAX_BYTES else JSON_MAX_BYTES
        if (length > max) {
            call.respondError(HttpStatusCode.PayloadTooLarge, "payload_too_large", "The request body is too large.")
            finish()
        }
    }
}
