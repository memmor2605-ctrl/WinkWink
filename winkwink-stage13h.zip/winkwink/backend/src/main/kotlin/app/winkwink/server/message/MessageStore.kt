package app.winkwink.server.message

import app.winkwink.server.profile.PageCursor
import java.time.Instant
import java.util.UUID

data class PersonRef(val accountId: UUID, val nickname: String, val winkwinkId: String, val displayName: String?, val avatarKey: String? = null)
data class ConversationRow(val id: UUID, val kind: String, val title: String?, val createdBy: UUID, val createdAt: Instant)
data class MemberRow(
    val conversationId: UUID, val person: PersonRef, val role: String, val joinedAt: Instant,
    val lastReadAt: Instant?, val muted: Boolean, val archived: Boolean,
    /** Czy ta osoba udostępnia potwierdzenia odczytu. */
    val shareRead: Boolean,
    /** Kiedy urządzenie tej osoby ostatnio pobrało wiadomości rozmowy (REST); `null` = jeszcze nie. */
    val lastDeliveredAt: Instant? = null,
)
/** Reakcja jednej osoby na wiadomość (jedna reakcja na osobę). */
data class ReactionRow(val messageId: UUID, val account: UUID, val kind: String)
data class MessageRow(
    val id: UUID, val conversationId: UUID, val sender: PersonRef, val body: String?, val replyToId: UUID?,
    val createdAt: Instant, val editedAt: Instant?, val deleted: Boolean,
    /** Czas ostatniej zmiany (edycja, usunięcie, reakcja) — podstawa synchronizacji różnicowej; `null`, gdy zapytanie go nie zwraca. */
    val changedAt: Instant? = null,
)
data class SummaryRow(
    val conversation: ConversationRow, val role: String, val muted: Boolean, val archived: Boolean, val memberCount: Int,
    val peer: PersonRef?, val last: MessageRow?, val unread: Int, val activity: Instant,
    /** Załączniki ostatniej wiadomości (podgląd „Zdjęcie / Dokument / Wiadomość głosowa” na liście); uzupełnia [MessageService]. */
    val lastAttachments: List<MessageAttachmentRow> = emptyList(),
)

/**
 * Metadane załącznika wiadomości. Klucz obiektu i właściciel NIE trafiają do DTO (brak zgadywania ścieżek w magazynie).
 * [kind]: image | document | voice. [messageId] == null → wysłany, ale jeszcze niedołączony (widzi go tylko [ownerId]).
 * [deletedAt] != null → przeznaczony do usunięcia z magazynu; taki wiersz nigdy nie jest widoczny ani pobieralny.
 */
data class MessageAttachmentRow(
    val id: UUID, val ownerId: UUID, val conversationId: UUID, val messageId: UUID?, val position: Int,
    val kind: String, val mime: String, val sizeBytes: Long, val objectKey: String, val fileName: String?,
    val width: Int?, val height: Int?, val durationMs: Long?, val createdAt: Instant, val deletedAt: Instant? = null,
)

/** Któryś z załączników nie istnieje, należy do kogoś innego, jest z innej rozmowy albo został już użyty. */
class AttachmentsUnavailableException : RuntimeException("attachments unavailable")

interface MessageStore {
    suspend fun findDirect(directKey: String): UUID?
    /** [members]: (konto, rola). Dla 1:1 przy wyścigu zwraca istniejącą rozmowę. */
    suspend fun createConversation(kind: String, title: String?, createdBy: UUID, directKey: String?, members: List<Pair<UUID, String>>, now: Instant): UUID
    suspend fun conversation(id: UUID): ConversationRow?
    /** Tylko aktywny członek (bez osób, które opuściły rozmowę). */
    suspend fun member(conversationId: UUID, account: UUID): MemberRow?
    suspend fun members(conversationId: UUID): List<MemberRow>
    suspend fun addMember(conversationId: UUID, account: UUID, role: String, now: Instant)
    suspend fun removeMember(conversationId: UUID, account: UUID, now: Instant)
    /**
     * Wstawia wiadomość i w TEJ SAMEJ transakcji dołącza [attachmentIds] (kolejność = pozycja). Dołączyć można tylko niedołączone,
     * nieusunięte załączniki [sender]a przesłane do tej rozmowy; w przeciwnym razie [AttachmentsUnavailableException] i brak wiadomości.
     */
    suspend fun insertMessage(conversationId: UUID, sender: UUID, body: String, replyTo: UUID?, now: Instant, attachmentIds: List<UUID> = emptyList(), clientId: UUID? = null): UUID
    /** Wiadomość wysłana wcześniej z tym samym [clientId] przez [sender] (ochrona przed duplikatami przy ponowieniu); `null`, jeśli nie ma. */
    suspend fun findByClientId(sender: UUID, clientId: UUID): MessageRow? = null
    /**
     * Wiadomości rozmowy zmienione po [since] (albo po kursorze [after]), rosnąco po `(changed_at, id)`. Zawiera usunięte „nagrobki”.
     * Dokładnie jedno z [since] / [after] jest używane: kursor ma pierwszeństwo.
     */
    suspend fun changes(conversationId: UUID, since: Instant, after: PageCursor?, limit: Int): List<MessageRow> = emptyList()
    suspend fun message(id: UUID): MessageRow?
    suspend fun messages(conversationId: UUID, limit: Int, after: PageCursor?): List<MessageRow>
    suspend fun editMessage(id: UUID, body: String, now: Instant)
    /** Zwraca załączniki oznaczone do usunięcia z magazynu (wiersze zostają, dopóki [removeAttachmentRows] ich nie skasuje). */
    suspend fun deleteMessage(id: UUID, now: Instant): List<MessageAttachmentRow>
    suspend fun markRead(conversationId: UUID, account: UUID, now: Instant)
    suspend fun setFlags(conversationId: UUID, account: UUID, muted: Boolean?, archived: Boolean?)
    suspend fun summaries(viewer: UUID, archived: Boolean?, query: String?, conversationId: UUID?, limit: Int, after: PageCursor?): List<SummaryRow>
    /** [kind] == null usuwa reakcję; w przeciwnym razie ustawia lub zmienia (jedna reakcja na osobę i wiadomość). */
    suspend fun setReaction(messageId: UUID, account: UUID, kind: String?, now: Instant)
    suspend fun reactions(messageIds: List<UUID>): List<ReactionRow>
    /**
     * Oznacza wiadomości tych rozmów jako dostarczone na urządzenie [account], ale tylko tam, gdzie od ostatniego razu
     * pojawiły się cudze wiadomości. Zwraca rozmowy, w których stan faktycznie się zmienił (podstawa zdarzenia `receipt`;
     * bez tego warunku zdarzenia nakręcałyby się nawzajem).
     */
    suspend fun markDelivered(account: UUID, conversationIds: List<UUID>, now: Instant): List<UUID>
    suspend fun setRole(conversationId: UUID, account: UUID, role: String)
    suspend fun readReceipts(account: UUID): Boolean
    suspend fun setReadReceipts(account: UUID, enabled: Boolean)

    // ---- załączniki ----
    suspend fun createAttachment(row: MessageAttachmentRow)
    suspend fun attachment(id: UUID): MessageAttachmentRow?
    /** Niedołączone i nieusunięte wysyłki konta (limit liczby porzuconych plików). */
    suspend fun pendingAttachmentCount(owner: UUID): Int
    /** Oznacza niedołączony załącznik właściciela do usunięcia i zwraca jego wiersz albo null. */
    suspend fun tombstonePending(owner: UUID, id: UUID, now: Instant): MessageAttachmentRow?
    /** Tylko dołączone, nieusunięte załączniki, wg kolejności; klucz = id wiadomości. */
    suspend fun attachmentsFor(messageIds: Collection<UUID>): Map<UUID, List<MessageAttachmentRow>>
    /** Wiersze do fizycznego sprzątnięcia: oznaczone do usunięcia albo niedołączone starsze niż [pendingBefore]. */
    suspend fun purgeCandidates(pendingBefore: Instant, limit: Int): List<MessageAttachmentRow>
    suspend fun removeAttachmentRows(ids: Collection<UUID>)
}
