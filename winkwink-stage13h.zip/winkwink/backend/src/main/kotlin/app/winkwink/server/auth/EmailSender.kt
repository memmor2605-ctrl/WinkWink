package app.winkwink.server.auth

import app.winkwink.server.api.ApiException
import io.ktor.http.HttpStatusCode

interface EmailSender {
    /** false, gdy dostawca poczty nie jest skonfigurowany — endpointy resetu odpowiadają wtedy 503. */
    val isConfigured: Boolean

    /** Dostarcza użytkownikowi jednorazowy token resetu hasła. Nie wolno go logować. */
    suspend fun sendPasswordReset(toEmail: String, resetToken: String)
}

/**
 * Domyślna implementacja do czasu wyboru dostawcy poczty (otwarta decyzja techniczna w PROJECT_STATUS.md).
 * Uczciwie zgłasza niedostępność zamiast udawać wysyłkę.
 */
class UnavailableEmailSender : EmailSender {
    override val isConfigured: Boolean = false

    override suspend fun sendPasswordReset(toEmail: String, resetToken: String) {
        throw ApiException(
            HttpStatusCode.ServiceUnavailable,
            "email_delivery_unavailable",
            "Password reset is temporarily unavailable: e-mail delivery is not configured on this server.",
        )
    }
}
