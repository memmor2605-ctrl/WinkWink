package app.winkwink.server.notification

import app.winkwink.server.profile.PageCursor
import java.time.Instant
import java.util.UUID

object NotificationTypes {
    const val NEW_FOLLOWER = "new_follower"
    const val FOLLOW_REQUEST = "follow_request"
    const val REACTION = "reaction"
    const val COMMENT = "comment"
    const val REPLY = "reply"
    const val COMMUNITY_INVITE = "community_invite"
    const val COMMUNITY_INVITE_ACCEPTED = "community_invite_accepted"
    const val COMMUNITY_REQUEST_APPROVED = "community_request_approved"
    val ALL = setOf(NEW_FOLLOWER, FOLLOW_REQUEST, REACTION, COMMENT, REPLY, COMMUNITY_INVITE, COMMUNITY_INVITE_ACCEPTED, COMMUNITY_REQUEST_APPROVED)

    /** Przełącznik ustawień, który kontroluje dany typ: nowe typy zaproszeń dzielą ustawienie „community_invite”. */
    fun settingKey(type: String) = if (type == COMMUNITY_INVITE_ACCEPTED || type == COMMUNITY_REQUEST_APPROVED) COMMUNITY_INVITE else type
}

/** Zdarzenie biznesowe zgłaszane przez serwisy; [Notifier] nigdy nie przerywa akcji, która je wywołała. */
data class NotificationEvent(
    val type: String,
    val recipient: UUID,
    val actor: UUID,
    val postId: UUID? = null,
    val commentId: UUID? = null,
    val communityId: UUID? = null,
    /** Aktor jest autorem anonimowej treści: odbiorca nie może poznać jego konta (backend nadal je zna na potrzeby moderacji). */
    val actorAnonymous: Boolean = false,
)

interface Notifier {
    suspend fun notify(event: NotificationEvent)

    object None : Notifier { override suspend fun notify(event: NotificationEvent) = Unit }
}

data class NotificationRow(
    val id: UUID,
    val type: String,
    val actorNickname: String,
    val actorWinkwinkId: String,
    val actorDisplayName: String?,
    val actorHasAvatar: Boolean,
    val postId: UUID?,
    val commentId: UUID?,
    val communityId: UUID?,
    val createdAt: Instant,
    val readAt: Instant?,
    val actorAnonymous: Boolean = false,
)

interface NotificationStore {
    /** @return id nowego powiadomienia albo null, gdy zdeduplikowano. */
    suspend fun insert(event: NotificationEvent, now: Instant): UUID?

    /** Nie zwraca powiadomień o usuniętych treściach, nieaktywnych aktorach ani od osób zablokowanych w którąkolwiek stronę. */
    suspend fun list(recipient: UUID, type: String?, unreadOnly: Boolean, limit: Int, after: PageCursor?): List<NotificationRow>
    suspend fun unreadCount(recipient: UUID): Int
    suspend fun markRead(recipient: UUID, id: UUID, now: Instant): Boolean
    suspend fun markAllRead(recipient: UUID, type: String?, now: Instant)
    suspend fun disabledTypes(recipient: UUID): Set<String>
    suspend fun setDisabledTypes(recipient: UUID, types: Set<String>)
}
