package app.winkwink.server.media

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

/**
 * Reguły multimediów w wiadomościach (Etap F): dozwolone typy, limity i WALIDACJA RZECZYWISTEJ ZAWARTOŚCI.
 * Nagłówek Content-Type i rozszerzenie nadane przez klienta służą tylko do wstępnego odrzucenia; o typie decyduje zawartość.
 * Nic tu nie dekompresuje ani nie wykonuje plików — pliki archiwów (OOXML/ODF) są oglądane wyłącznie przez katalog centralny ZIP.
 */
object MessageMedia {
    const val IMAGE_MAX_BYTES = 8 * 1024 * 1024
    const val DOCUMENT_MAX_BYTES = 10 * 1024 * 1024
    const val VOICE_MAX_BYTES = 8 * 1024 * 1024
    const val TEXT_MAX_BYTES = 2 * 1024 * 1024
    const val IMAGE_MAX_EDGE = 2048
    const val MAX_IMAGES = 10
    const val MAX_DOCUMENTS = 5
    const val VOICE_MAX_MS = 10 * 60 * 1000L
    const val VOICE_MIN_MS = 300L

    private val IMAGE_MIMES = setOf("image/jpeg", "image/png")
    private val VOICE_MIMES = setOf("audio/mp4", "audio/m4a", "audio/x-m4a")
    private val DOCUMENT_MIMES = setOf(
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "application/vnd.oasis.opendocument.text",
        "application/vnd.oasis.opendocument.spreadsheet",
        "application/vnd.oasis.opendocument.presentation",
        "application/rtf", "text/rtf", "text/plain", "text/csv",
        // Klient bez rozpoznanego typu; i tak o wyniku decyduje zawartość.
        "application/octet-stream",
    )

    /** Rozszerzenia, które nigdy nie są akceptowane (ani jako końcowe, ani jako „podwójne” w środku nazwy). */
    val BLOCKED_EXTENSIONS = setOf(
        "exe", "dll", "bat", "cmd", "com", "msi", "scr", "pif", "vbs", "vbe", "js", "jse", "mjs", "wsf", "wsh", "ps1", "psm1",
        "sh", "bash", "jar", "apk", "aab", "ipa", "app", "dmg", "iso", "html", "htm", "xhtml", "svg", "xml", "php", "py", "rb",
        "pl", "lnk", "reg", "hta", "cpl", "docm", "xlsm", "pptm", "dotm", "xlam", "swf",
    )

    fun normalizeMime(mime: String) = mime.lowercase().substringBefore(';').trim()

    /** image | voice | document albo null (typ niedozwolony — np. HTML, JS, pliki wykonywalne). */
    fun declaredKind(mime: String): String? = when (normalizeMime(mime)) {
        in IMAGE_MIMES -> "image"
        in VOICE_MIMES -> "voice"
        in DOCUMENT_MIMES -> "document"
        else -> null
    }

    fun maxBytesFor(mime: String): Int? = when (declaredKind(mime)) {
        "image" -> IMAGE_MAX_BYTES
        "voice" -> VOICE_MAX_BYTES
        "document" -> DOCUMENT_MAX_BYTES
        else -> null
    }

    data class DocumentType(val mime: String, val ext: String)

    val PDF = DocumentType("application/pdf", "pdf")
    val DOCX = DocumentType("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "docx")
    val XLSX = DocumentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx")
    val PPTX = DocumentType("application/vnd.openxmlformats-officedocument.presentationml.presentation", "pptx")
    val ODT = DocumentType("application/vnd.oasis.opendocument.text", "odt")
    val ODS = DocumentType("application/vnd.oasis.opendocument.spreadsheet", "ods")
    val ODP = DocumentType("application/vnd.oasis.opendocument.presentation", "odp")
    val RTF = DocumentType("application/rtf", "rtf")
    val TXT = DocumentType("text/plain", "txt")
    val CSV = DocumentType("text/csv", "csv")

    private fun ByteArray.startsWithAscii(s: String, offset: Int = 0): Boolean {
        if (size < offset + s.length) return false
        for (i in s.indices) if (this[offset + i] != s[i].code.toByte()) return false
        return true
    }

    private fun ByteArray.containsAscii(needle: String, ignoreCase: Boolean = false, limit: Int = size): Boolean {
        val n = needle.length
        val end = minOf(size, limit) - n
        var i = 0
        while (i <= end) {
            var j = 0
            while (j < n) {
                val a = this[i + j].toInt().toChar()
                val b = needle[j]
                if (if (ignoreCase) !a.equals(b, ignoreCase = true) else a != b) break
                j++
            }
            if (j == n) return true
            i++
        }
        return false
    }

    /**
     * Rozpoznaje dokument po zawartości. null = typ niedozwolony albo plik niebezpieczny (makra, skrypty, HTML, osadzone obiekty).
     * Dozwolone: PDF, DOCX, XLSX, PPTX, ODT, ODS, ODP, RTF, TXT, CSV. Starsze formaty OLE (.doc/.xls/.ppt) i pliki z makrami są odrzucane.
     */
    fun detectDocument(b: ByteArray): DocumentType? {
        if (b.isEmpty()) return null
        if (b.startsWithAscii("%PDF-")) {
            // Heurystyka: PDF z uruchamianiem programów lub JavaScriptem nie jest przyjmowany.
            if (b.containsAscii("/Launch") || b.containsAscii("/JavaScript")) return null
            return PDF
        }
        if (b.size >= 4 && b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte() && b[2].toInt() == 3 && b[3].toInt() == 4) return detectZipDocument(b)
        if (b.startsWithAscii("{\\rtf")) {
            // Osadzone obiekty OLE w RTF to klasyczny wektor ataku.
            if (b.containsAscii("\\objdata", ignoreCase = true) || b.containsAscii("\\objemb", ignoreCase = true) || b.containsAscii("\\objlink", ignoreCase = true)) return null
            return RTF
        }
        return if (isSafePlainText(b)) TXT else null
    }

    private fun detectZipDocument(b: ByteArray): DocumentType? {
        val entries = ZipDirectory.entries(b) ?: return null
        val names = entries.map { it.name }
        for (n in names) {
            val lower = n.lowercase()
            if (n.startsWith("/") || n.contains("..") || n.contains('\\')) return null
            if (lower.endsWith("vbaproject.bin")) return null // makra
            val ext = lower.substringAfterLast('.', "")
            if (ext in BLOCKED_EXTENSIONS - setOf("xml")) return null // pliki wykonywalne i skrypty w paczce (xml jest normalny w OOXML/ODF)
        }
        val set = names.toSet()
        if ("[Content_Types].xml" in set) {
            return when {
                "word/document.xml" in set -> DOCX
                "xl/workbook.xml" in set -> XLSX
                "ppt/presentation.xml" in set -> PPTX
                else -> null
            }
        }
        if ("META-INF/manifest.xml" in set && "mimetype" in set) {
            // Makra i skrypty ODF.
            if (names.any { it.startsWith("Basic/") || it.startsWith("Scripts/") || it.startsWith("Dialogs/") }) return null
            val declared = ZipDirectory.readStored(b, entries.first { it.name == "mimetype" }, 100)?.toString(Charsets.US_ASCII)?.trim() ?: return null
            return when (declared) {
                ODT.mime -> ODT
                ODS.mime -> ODS
                ODP.mime -> ODP
                else -> null
            }
        }
        return null
    }

    /** Czysty tekst UTF-8 bez znaków sterujących, który nie wygląda na HTML/SVG/XML ani skrypt. */
    fun isSafePlainText(b: ByteArray): Boolean {
        if (b.isEmpty() || b.size > TEXT_MAX_BYTES) return false
        val text = try {
            Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b)).toString()
        } catch (e: CharacterCodingException) {
            return false
        }
        if (text.any { it == '\u0000' || (it.isISOControl() && it != '\n' && it != '\r' && it != '\t') }) return false
        val head = text.trimStart('\uFEFF').trimStart().take(4096).lowercase()
        if (head.startsWith("<") || head.startsWith("#!")) return false
        if (head.contains("<script") || head.contains("<html") || head.contains("<!doctype") || head.contains("<svg")) return false
        return true
    }

    /**
     * Nazwa do wyświetlania i nagłówka pobierania: bez ścieżek i znaków sterujących (MediaSniffer.sanitizeFileName),
     * z rozszerzeniem wymuszonym z wykrytego typu. Zwraca null, gdy w nazwie występuje zakazane rozszerzenie
     * (np. „raport.exe.pdf”) — takie pliki są odrzucane, a nie „naprawiane”.
     */
    fun documentFileName(raw: String?, type: DocumentType): String? {
        val base = MediaSniffer.sanitizeFileName(raw) ?: "document"
        val parts = base.split('.')
        if (parts.drop(1).any { it.lowercase() in BLOCKED_EXTENSIONS }) return null
        val declaredExt = parts.drop(1).lastOrNull()?.lowercase()
        val effective = if (type == TXT && declaredExt == "csv") CSV else type
        val stem = (if (parts.size > 1) parts.dropLast(1).joinToString(".") else base).trim().ifEmpty { "document" }
        val ext = "." + effective.ext
        return stem.take(100 - ext.length) + ext
    }
}

/** Nagłówki rozpoznanych, bezpiecznych ISO-BMFF (MP4/M4A). */
data class Mp4Info(val handlers: Set<String>, val durationMs: Long)

/**
 * Minimalny, bezpieczny parser kontenera MP4 do walidacji wiadomości głosowych: sprawdza, że plik jest kontenerem ISO-BMFF
 * zawierającym WYŁĄCZNIE ścieżki dźwiękowe (`soun`), i liczy czas trwania z `mvhd`. Wszystkie odczyty są sprawdzane względem granic
 * bufora, głębokość i liczba pudełek są ograniczone.
 */
object Mp4Inspector {
    private const val MAX_BOXES = 10_000
    private val CONTAINERS = setOf("moov", "trak", "mdia")

    private fun u32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 0xFF) shl 24) or ((b[o + 1].toLong() and 0xFF) shl 16) or ((b[o + 2].toLong() and 0xFF) shl 8) or (b[o + 3].toLong() and 0xFF)

    private fun u64(b: ByteArray, o: Int): Long = (u32(b, o) shl 32) or u32(b, o + 4)
    private fun type(b: ByteArray, o: Int) = String(b, o, 4, Charsets.ISO_8859_1)

    fun inspect(b: ByteArray): Mp4Info? {
        if (b.size < 16 || type(b, 4) != "ftyp") return null
        val handlers = mutableSetOf<String>()
        var timescale = 0L
        var duration = 0L
        var seenMoov = false
        var boxes = 0

        fun walk(start: Int, end: Int, depth: Int): Boolean {
            var o = start
            while (o + 8 <= end) {
                if (++boxes > MAX_BOXES) return false
                var size = u32(b, o)
                val t = type(b, o + 4)
                var header = 8
                if (size == 1L) {
                    if (o + 16 > end) return false
                    size = u64(b, o + 8); header = 16
                } else if (size == 0L) {
                    size = (end - o).toLong()
                }
                if (size < header || o + size > end) return false
                val bodyStart = o + header
                val bodyEnd = (o + size).toInt()
                when {
                    t == "moov" -> seenMoov = true
                }
                if (t in CONTAINERS && depth < 4) {
                    if (!walk(bodyStart, bodyEnd, depth + 1)) return false
                } else if (t == "mvhd" && bodyEnd - bodyStart >= 20) {
                    val version = b[bodyStart].toInt()
                    if (version == 1) {
                        if (bodyEnd - bodyStart < 32) return false
                        timescale = u32(b, bodyStart + 20); duration = u64(b, bodyStart + 24)
                    } else {
                        timescale = u32(b, bodyStart + 12); duration = u32(b, bodyStart + 16)
                    }
                } else if (t == "hdlr" && bodyEnd - bodyStart >= 12) {
                    handlers += type(b, bodyStart + 8)
                }
                o = bodyEnd
            }
            return true
        }

        if (!walk(0, b.size, 0) || !seenMoov || timescale <= 0L) return null
        val ms = if (duration <= 0) 0L else duration * 1000L / timescale
        return Mp4Info(handlers, ms)
    }

    /** Czysty dźwięk: co najmniej jedna ścieżka, wszystkie `soun`. */
    fun isAudioOnly(info: Mp4Info) = info.handlers.isNotEmpty() && info.handlers.all { it == "soun" }
}

data class ZipEntryInfo(val name: String, val method: Int, val compressedSize: Long, val uncompressedSize: Long, val localHeaderOffset: Long)

/** Odczyt katalogu centralnego ZIP bez dekompresji (odporny na „bomby”); zip64 i archiwa wielodyskowe są odrzucane. */
object ZipDirectory {
    private const val MAX_ENTRIES = 5000
    private const val MAX_TOTAL_UNCOMPRESSED = 500L * 1024 * 1024

    private fun u16(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun u32(b: ByteArray, o: Int): Long =
        (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

    fun entries(b: ByteArray): List<ZipEntryInfo>? {
        if (b.size < 22) return null
        // EOCD: sygnatura 0x06054b50 w ostatnich 64 KB + 22 B.
        var eocd = -1
        var i = b.size - 22
        val lowest = maxOf(0, b.size - 22 - 65535)
        while (i >= lowest) {
            if (b[i].toInt() == 0x50 && b[i + 1].toInt() == 0x4B && b[i + 2].toInt() == 5 && b[i + 3].toInt() == 6) { eocd = i; break }
            i--
        }
        if (eocd < 0) return null
        val disk = u16(b, eocd + 4); val cdDisk = u16(b, eocd + 6)
        val count = u16(b, eocd + 10)
        val cdSize = u32(b, eocd + 12); val cdOffset = u32(b, eocd + 16)
        if (disk != 0 || cdDisk != 0 || count == 0xFFFF || cdOffset == 0xFFFFFFFFL || cdSize == 0xFFFFFFFFL) return null
        if (count == 0 || count > MAX_ENTRIES || cdOffset + cdSize > b.size) return null
        val out = ArrayList<ZipEntryInfo>(count)
        var o = cdOffset.toInt()
        val end = (cdOffset + cdSize).toInt()
        var total = 0L
        repeat(count) {
            if (o + 46 > end || u32(b, o) != 0x02014b50L) return null
            val method = u16(b, o + 10)
            val comp = u32(b, o + 20); val uncomp = u32(b, o + 24)
            val nameLen = u16(b, o + 28); val extraLen = u16(b, o + 30); val commentLen = u16(b, o + 32)
            val local = u32(b, o + 42)
            if (comp == 0xFFFFFFFFL || uncomp == 0xFFFFFFFFL || local == 0xFFFFFFFFL) return null
            if (o + 46 + nameLen + extraLen + commentLen > end) return null
            out += ZipEntryInfo(String(b, o + 46, nameLen, Charsets.UTF_8), method, comp, uncomp, local)
            total += uncomp
            if (total > MAX_TOTAL_UNCOMPRESSED) return null
            o += 46 + nameLen + extraLen + commentLen
        }
        return out
    }

    /** Czyta wpis zapisany bez kompresji (np. `mimetype` w ODF), maks. [limit] bajtów; null, gdy wpis jest skompresowany/uszkodzony. */
    fun readStored(b: ByteArray, e: ZipEntryInfo, limit: Int): ByteArray? {
        if (e.method != 0 || e.uncompressedSize > limit || e.compressedSize != e.uncompressedSize) return null
        val o = e.localHeaderOffset.toInt()
        if (o < 0 || o + 30 > b.size || u32(b, o) != 0x04034b50L) return null
        val start = o + 30 + u16(b, o + 26) + u16(b, o + 28)
        val end = start + e.uncompressedSize.toInt()
        if (start < 0 || end > b.size) return null
        return b.copyOfRange(start, end)
    }
}
