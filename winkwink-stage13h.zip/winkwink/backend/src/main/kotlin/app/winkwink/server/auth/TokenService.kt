package app.winkwink.server.auth

import app.winkwink.server.config.AuthConfig
import com.auth0.jwt.JWT
import com.auth0.jwt.JWTVerifier
import com.auth0.jwt.algorithms.Algorithm
import java.time.Clock
import java.time.Instant
import java.util.Date
import java.util.UUID

data class AccessToken(val token: String, val expiresAt: Instant)

/** Krótkotrwałe access tokeny JWT (HS256, biblioteka java-jwt). Sekret pochodzi wyłącznie ze zmiennej środowiskowej. */
class TokenService(private val config: AuthConfig, private val clock: Clock) {
    private val algorithm = Algorithm.HMAC256(config.jwtSecret)

    val verifier: JWTVerifier = JWT.require(algorithm)
        .withIssuer(config.issuer)
        .withAudience(AUDIENCE)
        .build()

    fun issueAccessToken(accountId: UUID, sessionId: UUID): AccessToken {
        val now = clock.instant()
        val expires = now.plusSeconds(config.accessTtlSeconds)
        val token = JWT.create()
            .withIssuer(config.issuer)
            .withAudience(AUDIENCE)
            .withSubject(accountId.toString())
            .withClaim(CLAIM_SESSION, sessionId.toString())
            .withJWTId(UUID.randomUUID().toString())
            .withIssuedAt(Date.from(now))
            .withExpiresAt(Date.from(expires))
            .sign(algorithm)
        return AccessToken(token, expires)
    }

    companion object {
        const val AUDIENCE = "winkwink-api"
        const val CLAIM_SESSION = "sid"
    }
}
