-- Etap F: multimedia w wiadomościach (zdjęcia, dokumenty, wiadomości głosowe).
-- Pliki leżą w MediaStorage (dysk / S3-compatible), NIE w PostgreSQL; tu są tylko metadane i klucz obiektu.

-- 1) Wiadomość z załącznikami może mieć pustą treść (egzekwuje MessageService: pusta treść tylko z załącznikiem).
--    Usuwamy dotychczasowy CHECK 1..4000 (nazwa nadana automatycznie, więc szukamy po definicji) i dodajemy górny limit.
DO $$
DECLARE c record;
BEGIN
    FOR c IN SELECT conname FROM pg_constraint
             WHERE conrelid = 'messages'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) LIKE '%char_length(body)%'
    LOOP
        EXECUTE format('ALTER TABLE messages DROP CONSTRAINT %I', c.conname);
    END LOOP;
END $$;
ALTER TABLE messages ADD CONSTRAINT messages_body_length_check CHECK (char_length(body) <= 4000);

-- 2) Załączniki wiadomości.
CREATE TABLE message_attachments (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id        uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    -- Rozmowa, do której plik został wysłany. Załącznik można dołączyć tylko do wiadomości w tej rozmowie.
    conversation_id uuid        NOT NULL REFERENCES conversations (id) ON DELETE CASCADE,
    -- NULL = przesłany, ale jeszcze niedołączony do wiadomości (widzi go tylko właściciel).
    message_id      uuid        REFERENCES messages (id) ON DELETE CASCADE,
    position        integer     NOT NULL DEFAULT 0,
    kind            text        NOT NULL CHECK (kind IN ('image', 'document', 'voice')),
    mime            text        NOT NULL,
    size_bytes      bigint      NOT NULL CHECK (size_bytes > 0),
    object_key      text        NOT NULL UNIQUE,
    -- Zsanityzowana nazwa wyłącznie dla dokumentów; zdjęcia i głosówki jej nie mają.
    file_name       text,
    width           integer,
    height          integer,
    -- Czas trwania liczony przez serwer z kontenera MP4 (nie ufamy wartości od klienta); tylko dla głosówek.
    duration_ms     bigint,
    created_at      timestamptz NOT NULL DEFAULT now(),
    -- Znacznik do usunięcia: plik jest kasowany z magazynu, a wiersz znika dopiero po tym (sprzątanie okresowe ponawia błędy).
    deleted_at      timestamptz,
    CHECK (kind = 'voice' OR duration_ms IS NULL),
    CHECK (kind = 'image' OR (width IS NULL AND height IS NULL))
);
CREATE INDEX message_attachments_message_idx ON message_attachments (message_id, position) WHERE message_id IS NOT NULL;
CREATE INDEX message_attachments_pending_idx ON message_attachments (owner_id, created_at) WHERE message_id IS NULL AND deleted_at IS NULL;
CREATE INDEX message_attachments_deleted_idx ON message_attachments (deleted_at) WHERE deleted_at IS NOT NULL;
