-- Etap A: wyciszanie użytkowników (prywatne dla wyciszającego, bez powiadamiania wyciszanego)
-- oraz ustawienie ukrywania list obserwujących/obserwowanych.
CREATE TABLE user_mutes (
    muter_id   uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    muted_id   uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (muter_id, muted_id),
    CHECK (muter_id <> muted_id)
);
CREATE INDEX user_mutes_muter_idx ON user_mutes (muter_id, created_at DESC, muted_id DESC);

ALTER TABLE profiles ADD COLUMN hide_follow_lists boolean NOT NULL DEFAULT false;
