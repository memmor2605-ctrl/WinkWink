-- Etap 3: posty, komentarze, reakcje, zapisy. Autor anonimowego posta jest znany tylko backendowi (author_id).
CREATE TABLE posts (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    author_id  uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    body       text        NOT NULL CHECK (char_length(body) BETWEEN 1 AND 5000),
    visibility text        NOT NULL CHECK (visibility IN ('public', 'followers', 'private')),
    anonymous  boolean     NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now(),
    edited_at  timestamptz,
    deleted_at timestamptz,
    -- Anonimowość ma sens tylko dla treści publicznych (inaczej krąg odbiorców zdradzałby autora).
    CHECK (NOT anonymous OR visibility = 'public')
);
CREATE INDEX posts_public_feed_idx ON posts (created_at DESC, id DESC) WHERE deleted_at IS NULL AND visibility = 'public';
CREATE INDEX posts_author_idx ON posts (author_id, created_at DESC, id DESC) WHERE deleted_at IS NULL;

CREATE TABLE post_reactions (
    post_id    uuid        NOT NULL REFERENCES posts (id) ON DELETE CASCADE,
    account_id uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    type       text        NOT NULL CHECK (type IN ('like', 'love', 'laugh', 'wow', 'sad')),
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (post_id, account_id)
);

CREATE TABLE post_saves (
    account_id uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    post_id    uuid        NOT NULL REFERENCES posts (id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (account_id, post_id)
);
CREATE INDEX post_saves_account_idx ON post_saves (account_id, created_at DESC, post_id DESC);

-- parent_id: tylko jeden poziom odpowiedzi (egzekwowane w serwisie).
CREATE TABLE comments (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    post_id    uuid        NOT NULL REFERENCES posts (id) ON DELETE CASCADE,
    parent_id  uuid        REFERENCES comments (id) ON DELETE CASCADE,
    author_id  uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    body       text        NOT NULL CHECK (char_length(body) BETWEEN 1 AND 2000),
    created_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);
CREATE INDEX comments_post_idx ON comments (post_id, parent_id, created_at, id) WHERE deleted_at IS NULL;
