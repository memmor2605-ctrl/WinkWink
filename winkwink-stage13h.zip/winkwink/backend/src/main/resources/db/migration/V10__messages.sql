-- Etap 5 (część 1): rozmowy 1:1 i grupowe, wiadomości tekstowe.
-- UWAGA: treść wiadomości jest w tej wersji czytelna dla serwera. To NIE jest E2EE (patrz docs/API.md, „Etap 5”).
CREATE TABLE conversations (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    kind       text        NOT NULL CHECK (kind IN ('direct', 'group')),
    title      text        CHECK (title IS NULL OR char_length(title) BETWEEN 1 AND 80),
    created_by uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    -- Klucz rozmowy 1:1: mniejsze_id|większe_id; gwarantuje jedną rozmowę na parę.
    direct_key text        UNIQUE,
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK ((kind = 'direct') = (direct_key IS NOT NULL)),
    CHECK ((kind = 'group') = (title IS NOT NULL))
);

CREATE TABLE conversation_members (
    conversation_id uuid        NOT NULL REFERENCES conversations (id) ON DELETE CASCADE,
    account_id      uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    role            text        NOT NULL CHECK (role IN ('owner', 'admin', 'member')),
    joined_at       timestamptz NOT NULL DEFAULT now(),
    left_at         timestamptz,
    last_read_at    timestamptz,
    muted           boolean     NOT NULL DEFAULT false,
    archived        boolean     NOT NULL DEFAULT false,
    PRIMARY KEY (conversation_id, account_id)
);
CREATE INDEX conversation_members_account_idx ON conversation_members (account_id) WHERE left_at IS NULL;

CREATE TABLE messages (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id uuid        NOT NULL REFERENCES conversations (id) ON DELETE CASCADE,
    sender_id       uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    body            text        NOT NULL,
    reply_to_id     uuid        REFERENCES messages (id) ON DELETE SET NULL,
    created_at      timestamptz NOT NULL DEFAULT now(),
    edited_at       timestamptz,
    deleted_at      timestamptz,
    CHECK (deleted_at IS NOT NULL OR char_length(body) BETWEEN 1 AND 4000)
);
CREATE INDEX messages_conversation_idx ON messages (conversation_id, created_at DESC, id DESC);

-- Prywatność potwierdzeń odczytu: wyłączenie oznacza, że nie widzisz też cudzych.
CREATE TABLE message_settings (
    account_id    uuid PRIMARY KEY REFERENCES accounts (id) ON DELETE CASCADE,
    read_receipts boolean NOT NULL DEFAULT true
);
