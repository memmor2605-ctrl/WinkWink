-- Wspólna funkcja utrzymująca kolumnę updated_at we wszystkich tabelach.
CREATE FUNCTION set_updated_at() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;
