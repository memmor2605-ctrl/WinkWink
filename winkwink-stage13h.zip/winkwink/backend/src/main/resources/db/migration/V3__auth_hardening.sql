-- Rotacja refresh tokenów z wykrywaniem ponownego użycia + metadane urządzenia.
ALTER TABLE sessions
    ADD COLUMN previous_refresh_token_hash bytea,
    ADD COLUMN user_agent text CHECK (char_length(user_agent) <= 300);
CREATE INDEX sessions_previous_hash_idx ON sessions (previous_refresh_token_hash)
    WHERE previous_refresh_token_hash IS NOT NULL;

-- Próby logowania / resetu: klucz to hash SHA-256 (bez danych osobowych w tabeli).
CREATE TABLE login_attempts (
    id           bigserial PRIMARY KEY,
    key_hash     text        NOT NULL CHECK (char_length(key_hash) BETWEEN 3 AND 80),
    attempted_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX login_attempts_key_time_idx ON login_attempts (key_hash, attempted_at DESC);
CREATE INDEX login_attempts_time_idx ON login_attempts (attempted_at);

-- Tokeny resetu hasła: jednorazowe, krótkotrwałe, przechowywane wyłącznie jako hash.
CREATE TABLE password_reset_tokens (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    token_hash bytea       NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    used_at    timestamptz,
    CHECK (expires_at > created_at)
);
CREATE UNIQUE INDEX password_reset_token_hash_uq ON password_reset_tokens (token_hash);
CREATE INDEX password_reset_account_idx ON password_reset_tokens (account_id) WHERE used_at IS NULL;
