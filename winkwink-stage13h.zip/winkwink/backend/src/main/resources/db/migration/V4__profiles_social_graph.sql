-- Etap 2: rozszerzony profil, graf obserwowania, blokady.
ALTER TABLE profiles
    ADD COLUMN display_name          text CHECK (display_name IS NULL OR char_length(display_name) BETWEEN 1 AND 50),
    ADD COLUMN background_object_key text,
    ADD COLUMN links                 text[] NOT NULL DEFAULT '{}' CHECK (cardinality(links) <= 5);

-- WinkWink ID jest niezmienny: zmiana jest odrzucana na poziomie bazy.
CREATE FUNCTION profiles_forbid_winkwink_id_change() RETURNS trigger AS $$
BEGIN
    IF NEW.winkwink_id IS DISTINCT FROM OLD.winkwink_id THEN
        RAISE EXCEPTION 'winkwink_id is immutable';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER profiles_winkwink_id_immutable BEFORE UPDATE ON profiles
    FOR EACH ROW EXECUTE FUNCTION profiles_forbid_winkwink_id_change();

CREATE TABLE follows (
    follower_id uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    followee_id uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    status      text        NOT NULL CHECK (status IN ('pending', 'accepted')),
    created_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (follower_id, followee_id),
    CHECK (follower_id <> followee_id)
);
CREATE INDEX follows_followee_idx ON follows (followee_id, status, created_at DESC, follower_id DESC);
CREATE INDEX follows_follower_idx ON follows (follower_id, status, created_at DESC, followee_id DESC);

CREATE TABLE blocks (
    blocker_id uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    blocked_id uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (blocker_id, blocked_id),
    CHECK (blocker_id <> blocked_id)
);
CREATE INDEX blocks_blocked_idx ON blocks (blocked_id);
CREATE INDEX blocks_blocker_idx ON blocks (blocker_id, created_at DESC, blocked_id DESC);
CREATE INDEX profiles_display_name_idx ON profiles (lower(display_name) text_pattern_ops);
CREATE INDEX profiles_nickname_prefix_idx ON profiles (lower(nickname) text_pattern_ops);
