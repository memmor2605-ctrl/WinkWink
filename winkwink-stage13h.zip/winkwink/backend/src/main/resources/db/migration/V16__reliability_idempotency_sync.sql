-- Stage 13G: niezawodność, idempotencja, synchronizacja różnicowa, indeksy kluczy obcych.
-- Zmiany wyłącznie addytywne (brak usuwania / zmiany istniejących danych).

-- 1) Idempotentne ponawianie żądań. Klucz jest przypisany do konta (jeden klucz u dwóch kont to dwie różne operacje).
--    Wiersz bez completed_at = operacja w toku; po zakończeniu przechowujemy status i treść odpowiedzi do odtworzenia.
--    Wpisy starsze niż 48 h są usuwane okresowo (IdempotencyService.purge).
CREATE TABLE idempotency_keys (
    account_id   uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    key          text        NOT NULL CHECK (char_length(key) BETWEEN 8 AND 100),
    scope        text        NOT NULL CHECK (char_length(scope) BETWEEN 1 AND 100),
    created_at   timestamptz NOT NULL DEFAULT now(),
    completed_at timestamptz,
    status       integer,
    response     text,
    PRIMARY KEY (account_id, key),
    CHECK ((completed_at IS NULL) = (response IS NULL))
);
CREATE INDEX idempotency_keys_created_idx ON idempotency_keys (created_at);

-- 2) Wiadomości: identyfikator nadany przez klienta (trwała kolejka wysyłania) + znacznik ostatniej zmiany (synchronizacja różnicowa).
--    client_id: ponowione wysłanie tej samej wiadomości zwraca istniejący wiersz zamiast tworzyć duplikat.
ALTER TABLE messages ADD COLUMN client_id uuid;
ALTER TABLE messages ADD COLUMN changed_at timestamptz;
UPDATE messages SET changed_at = greatest(created_at, coalesce(edited_at, created_at), coalesce(deleted_at, created_at)) WHERE changed_at IS NULL;
ALTER TABLE messages ALTER COLUMN changed_at SET DEFAULT now();
ALTER TABLE messages ALTER COLUMN changed_at SET NOT NULL;
CREATE UNIQUE INDEX messages_client_uq ON messages (sender_id, client_id) WHERE client_id IS NOT NULL;
CREATE INDEX messages_changes_idx ON messages (conversation_id, changed_at, id);

-- 3) Indeksy dla kluczy obcych używanych przez kaskadowe usuwanie i filtrowanie (bez nich DELETE konta skanuje całe tabele).
CREATE INDEX IF NOT EXISTS messages_sender_idx ON messages (sender_id);
CREATE INDEX IF NOT EXISTS messages_reply_idx ON messages (reply_to_id) WHERE reply_to_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS message_attachments_conversation_idx ON message_attachments (conversation_id);
CREATE INDEX IF NOT EXISTS message_attachments_owner_idx ON message_attachments (owner_id);
CREATE INDEX IF NOT EXISTS message_reactions_account_idx ON message_reactions (account_id);
CREATE INDEX IF NOT EXISTS conversations_created_by_idx ON conversations (created_by);
CREATE INDEX IF NOT EXISTS post_attachments_owner_idx ON post_attachments (owner_id);
CREATE INDEX IF NOT EXISTS post_reactions_account_idx ON post_reactions (account_id);
CREATE INDEX IF NOT EXISTS comments_author_idx ON comments (author_id);
CREATE INDEX IF NOT EXISTS comments_parent_idx ON comments (parent_id) WHERE parent_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS notifications_actor_idx ON notifications (actor_id);
-- Sprzątanie plików po usuniętych postach (AttachmentService.purgeDeletedPosts) i rekoncyliacja magazynu po kluczu obiektu.
CREATE INDEX IF NOT EXISTS posts_deleted_idx ON posts (deleted_at) WHERE deleted_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS profiles_avatar_key_idx ON profiles (avatar_object_key) WHERE avatar_object_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS profiles_background_key_idx ON profiles (background_object_key) WHERE background_object_key IS NOT NULL;
