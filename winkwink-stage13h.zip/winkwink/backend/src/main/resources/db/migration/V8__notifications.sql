-- Etap 6: powiadomienia powiązane z rzeczywistymi zdarzeniami backendu.
-- Powiadomienie nie zawiera treści (ani posta, ani komentarza) — tylko typ, aktora i identyfikatory.
CREATE TABLE notifications (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    recipient_id uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    type         text        NOT NULL CHECK (type IN ('new_follower', 'follow_request', 'reaction', 'comment', 'reply', 'community_invite')),
    actor_id     uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    post_id      uuid        REFERENCES posts (id) ON DELETE CASCADE,
    comment_id   uuid        REFERENCES comments (id) ON DELETE CASCADE,
    community_id uuid        REFERENCES communities (id) ON DELETE CASCADE,
    created_at   timestamptz NOT NULL DEFAULT now(),
    read_at      timestamptz,
    CHECK (recipient_id <> actor_id),
    CHECK ((type IN ('reaction', 'comment', 'reply')) = (post_id IS NOT NULL)),
    CHECK ((type IN ('comment', 'reply')) = (comment_id IS NOT NULL)),
    CHECK ((type = 'community_invite') = (community_id IS NOT NULL))
);
CREATE INDEX notifications_recipient_idx ON notifications (recipient_id, created_at DESC, id DESC);
CREATE INDEX notifications_unread_idx ON notifications (recipient_id) WHERE read_at IS NULL;
-- Ochrona przed spamem: powtarzane reakcje / obserwowanie / zaproszenia tej samej osoby nie tworzą kolejnych powiadomień.
CREATE UNIQUE INDEX notifications_dedupe_uq ON notifications
    (recipient_id, actor_id, type, coalesce(post_id, community_id, '00000000-0000-0000-0000-000000000000'::uuid))
    WHERE type IN ('reaction', 'new_follower', 'follow_request', 'community_invite');

CREATE TABLE notification_settings (
    account_id     uuid PRIMARY KEY REFERENCES accounts (id) ON DELETE CASCADE,
    disabled_types text[] NOT NULL DEFAULT '{}'
);
