-- Etap C: wyciszanie członków społeczności (blokada pisania) i nowe typy powiadomień o zaproszeniach.

CREATE TABLE community_mutes (
    community_id uuid        NOT NULL REFERENCES communities (id) ON DELETE CASCADE,
    account_id   uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    muted_by     uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    created_at   timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (community_id, account_id)
);

-- Powiadomienia: community_invite_accepted (do zapraszającego) i community_request_approved (do proszącego o dołączenie).
-- Oba dotyczą społeczności, więc wymagają community_id i nie mają post_id/comment_id.
DO $$
DECLARE c record;
BEGIN
    FOR c IN SELECT conname FROM pg_constraint
             WHERE conrelid = 'notifications'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) LIKE '%community_invite%'
    LOOP
        EXECUTE format('ALTER TABLE notifications DROP CONSTRAINT %I', c.conname);
    END LOOP;
END $$;
ALTER TABLE notifications ADD CONSTRAINT notifications_type_check CHECK (type IN
    ('new_follower', 'follow_request', 'reaction', 'comment', 'reply', 'community_invite', 'community_invite_accepted', 'community_request_approved'));
ALTER TABLE notifications ADD CONSTRAINT notifications_community_check CHECK
    ((type IN ('community_invite', 'community_invite_accepted', 'community_request_approved')) = (community_id IS NOT NULL));
