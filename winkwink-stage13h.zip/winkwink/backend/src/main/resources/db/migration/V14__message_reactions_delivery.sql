-- Etap D: reakcje na wiadomości (jedna na osobę) i znacznik dostarczenia (pobrania przez REST/WSS) na członkostwie.
CREATE TABLE message_reactions (
    message_id uuid        NOT NULL REFERENCES messages (id) ON DELETE CASCADE,
    account_id uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    kind       text        NOT NULL CHECK (kind IN ('like', 'love', 'laugh', 'wow', 'sad', 'thanks')),
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (message_id, account_id)
);

ALTER TABLE conversation_members ADD COLUMN last_delivered_at timestamptz;
