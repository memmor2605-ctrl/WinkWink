-- Konto = prywatna tożsamość techniczna. Nigdy nie jest ujawniane innym użytkownikom.
CREATE TABLE accounts (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email         text        NOT NULL CHECK (char_length(email) BETWEEN 3 AND 254),
    password_hash text        NOT NULL,
    status        text        NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'deleted')),
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX accounts_email_lower_uq ON accounts (lower(email));
CREATE TRIGGER accounts_set_updated_at BEFORE UPDATE ON accounts
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Profil = publiczny alias i WinkWink ID (osobno od konta).
CREATE TABLE profiles (
    account_id         uuid PRIMARY KEY REFERENCES accounts (id) ON DELETE CASCADE,
    nickname           text        NOT NULL CHECK (nickname ~ '^[A-Za-z0-9_.]{3,30}$'),
    winkwink_id        text        NOT NULL CHECK (winkwink_id ~ '^ww_[a-z0-9]{10}$'),
    bio                text        CHECK (char_length(bio) <= 280),
    avatar_object_key  text,
    visibility         text        NOT NULL DEFAULT 'public' CHECK (visibility IN ('public', 'followers', 'private')),
    created_at         timestamptz NOT NULL DEFAULT now(),
    updated_at         timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX profiles_nickname_lower_uq ON profiles (lower(nickname));
CREATE UNIQUE INDEX profiles_winkwink_id_uq ON profiles (winkwink_id);
CREATE TRIGGER profiles_set_updated_at BEFORE UPDATE ON profiles
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE devices (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id   uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    platform     text        NOT NULL CHECK (platform IN ('android', 'ios', 'web')),
    name         text        CHECK (char_length(name) <= 100),
    push_token   text,
    created_at   timestamptz NOT NULL DEFAULT now(),
    last_seen_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX devices_account_idx ON devices (account_id);

-- Sesje: przechowujemy wyłącznie hash tokenu odświeżającego, nigdy sam token.
CREATE TABLE sessions (
    id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id         uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    device_id          uuid        REFERENCES devices (id) ON DELETE CASCADE,
    refresh_token_hash bytea       NOT NULL,
    created_at         timestamptz NOT NULL DEFAULT now(),
    last_used_at       timestamptz NOT NULL DEFAULT now(),
    expires_at         timestamptz NOT NULL,
    revoked_at         timestamptz,
    CHECK (expires_at > created_at)
);
CREATE UNIQUE INDEX sessions_token_hash_uq ON sessions (refresh_token_hash);
CREATE INDEX sessions_account_idx ON sessions (account_id) WHERE revoked_at IS NULL;
