-- Powiadomienie o odpowiedzi od autora anonimowego posta nie może ujawniać jego konta odbiorcy.
-- Backend nadal przechowuje actor_id (moderacja, zgłoszenia); flaga tylko ukrywa aktora w odpowiedzi API.
ALTER TABLE notifications ADD COLUMN actor_anonymous boolean NOT NULL DEFAULT false;
