-- Stage 13H: powiadomienia push (FCM) i odcisk żądania w idempotencji.

-- 1) Idempotencja: odcisk treści żądania (ten sam klucz + inna treść = błąd, nie odtworzenie cudzej odpowiedzi).
ALTER TABLE idempotency_keys ADD COLUMN fingerprint text NOT NULL DEFAULT '';

-- 2) Tokeny FCM: jeden token = jedno urządzenie/instalacja. Token jest globalnie unikalny — po zalogowaniu innego konta na tym
--    samym telefonie rekord jest PRZEPISYWANY na nowe konto (stare konto przestaje dostawać powiadomienia na to urządzenie).
--    Usunięcie sesji (ON DELETE CASCADE) lub konta usuwa token; unieważnione sesje są dodatkowo odfiltrowywane przy wysyłce.
CREATE TABLE push_tokens (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id    uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    session_id    uuid        REFERENCES sessions (id) ON DELETE CASCADE,
    token         text        NOT NULL CHECK (char_length(token) BETWEEN 20 AND 4096),
    platform      text        NOT NULL DEFAULT 'android' CHECK (platform IN ('android')),
    device_name   text        CHECK (device_name IS NULL OR char_length(device_name) <= 100),
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX push_tokens_token_uq ON push_tokens (token);
CREATE INDEX push_tokens_account_idx ON push_tokens (account_id);
CREATE INDEX push_tokens_session_idx ON push_tokens (session_id) WHERE session_id IS NOT NULL;

-- 3) Ustawienia push dla wiadomości. Domyślnie treść wiadomości NIE jest wysyłana do powiadomienia (prywatność ekranu blokady).
--    Powiadomienia społecznościowe używają istniejących ustawień typów (notification_settings).
ALTER TABLE message_settings ADD COLUMN push_messages boolean NOT NULL DEFAULT true;
ALTER TABLE message_settings ADD COLUMN push_previews boolean NOT NULL DEFAULT false;
