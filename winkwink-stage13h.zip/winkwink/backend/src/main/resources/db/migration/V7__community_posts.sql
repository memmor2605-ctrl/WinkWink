-- Etap 4 (część 2): publikowanie w kanałach społeczności (widoczność 'community').
-- Usuwamy wszystkie CHECK-i posts odwołujące się do visibility (nazwy nadane automatycznie) i dodajemy je od nowa.
DO $$
DECLARE c record;
BEGIN
    FOR c IN SELECT conname FROM pg_constraint
             WHERE conrelid = 'posts'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) LIKE '%visibility%'
    LOOP
        EXECUTE format('ALTER TABLE posts DROP CONSTRAINT %I', c.conname);
    END LOOP;
END $$;

-- Kanał musi należeć do wskazanej społeczności — egzekwowane kluczem złożonym.
ALTER TABLE community_channels ADD CONSTRAINT community_channels_id_community_uq UNIQUE (id, community_id);

ALTER TABLE posts ADD COLUMN community_id uuid REFERENCES communities (id) ON DELETE CASCADE;
ALTER TABLE posts ADD COLUMN channel_id   uuid;
-- Uwaga: usunięcie kanału usuwa (twardo) jego posty, komentarze, reakcje i zapisy. Interfejs musi to potwierdzać.
ALTER TABLE posts ADD CONSTRAINT posts_channel_fk
    FOREIGN KEY (channel_id, community_id) REFERENCES community_channels (id, community_id) ON DELETE CASCADE;

ALTER TABLE posts ADD CONSTRAINT posts_visibility_check
    CHECK (visibility IN ('public', 'followers', 'private', 'community'));
-- community_id i channel_id są ustawione wtedy i tylko wtedy, gdy visibility = 'community'.
ALTER TABLE posts ADD CONSTRAINT posts_community_scope_check
    CHECK ((visibility = 'community' AND community_id IS NOT NULL AND channel_id IS NOT NULL)
        OR (visibility <> 'community' AND community_id IS NULL AND channel_id IS NULL));
-- Anonimowość nadal tylko dla treści publicznych (zatem nigdy w społecznościach).
ALTER TABLE posts ADD CONSTRAINT posts_anonymous_public_check
    CHECK (NOT anonymous OR visibility = 'public');

CREATE INDEX posts_community_idx ON posts (community_id, channel_id, created_at DESC, id DESC)
    WHERE deleted_at IS NULL AND community_id IS NOT NULL;
