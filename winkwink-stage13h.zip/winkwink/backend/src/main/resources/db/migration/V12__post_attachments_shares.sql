-- Etap B: załączniki postów (zdjęcia, galerie, filmy, dokumenty) i udostępnianie postów.
-- Pliki leżą w MediaStorage (nie w PostgreSQL); tu są tylko metadane i klucz obiektu.

-- Post może mieć pustą treść, jeśli ma załączniki albo jest udostępnieniem (egzekwuje serwis).
-- Usuwamy automatycznie nazwane CHECK-i długości body i dodajemy górny limit.
DO $$
DECLARE c record;
BEGIN
    FOR c IN SELECT conname FROM pg_constraint
             WHERE conrelid = 'posts'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) LIKE '%char_length(body)%'
    LOOP
        EXECUTE format('ALTER TABLE posts DROP CONSTRAINT %I', c.conname);
    END LOOP;
END $$;
ALTER TABLE posts ADD CONSTRAINT posts_body_length_check CHECK (char_length(body) <= 5000);

CREATE TABLE post_attachments (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id   uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    -- NULL = przesłany, ale jeszcze nie dołączony do posta (widzi go tylko właściciel).
    post_id    uuid        REFERENCES posts (id) ON DELETE CASCADE,
    position   integer     NOT NULL DEFAULT 0,
    kind       text        NOT NULL CHECK (kind IN ('image', 'video', 'document')),
    mime       text        NOT NULL,
    size_bytes bigint      NOT NULL CHECK (size_bytes > 0),
    object_key text        NOT NULL UNIQUE,
    -- Nazwa wyłącznie dla dokumentów (zsanityzowana); obrazy i filmy jej nie mają.
    file_name  text,
    width      integer,
    height     integer,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX post_attachments_post_idx ON post_attachments (post_id, position);
CREATE INDEX post_attachments_pending_idx ON post_attachments (owner_id, created_at) WHERE post_id IS NULL;

-- Udostępnienie = zwykły post (własna widoczność, komentarze, reakcje) wskazujący oryginał.
CREATE TABLE post_shares (
    post_id     uuid PRIMARY KEY REFERENCES posts (id) ON DELETE CASCADE,
    original_id uuid NOT NULL REFERENCES posts (id) ON DELETE CASCADE
);
CREATE INDEX post_shares_original_idx ON post_shares (original_id);
