-- Etap 4 (część 1): społeczności, członkostwo z rolami, prośby o dołączenie, zaproszenia, kanały.
-- Typy: public (wolne dołączanie), private (widoczna, dołączanie za zgodą), invite (ukryta, tylko na zaproszenie).
CREATE TABLE communities (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name        text        NOT NULL CHECK (char_length(name) BETWEEN 3 AND 50),
    description text        NOT NULL DEFAULT '' CHECK (char_length(description) <= 500),
    rules       text        NOT NULL DEFAULT '' CHECK (char_length(rules) <= 2000),
    type        text        NOT NULL CHECK (type IN ('public', 'private', 'invite')),
    owner_id    uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    created_at  timestamptz NOT NULL DEFAULT now(),
    deleted_at  timestamptz
);
CREATE UNIQUE INDEX communities_name_uidx ON communities (lower(name)) WHERE deleted_at IS NULL;

CREATE TABLE community_members (
    community_id uuid        NOT NULL REFERENCES communities (id) ON DELETE CASCADE,
    account_id   uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    role         text        NOT NULL CHECK (role IN ('owner', 'admin', 'moderator', 'member')),
    joined_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (community_id, account_id)
);
-- Dokładnie jeden właściciel na społeczność.
CREATE UNIQUE INDEX community_one_owner_uidx ON community_members (community_id) WHERE role = 'owner';
CREATE INDEX community_members_account_idx ON community_members (account_id, joined_at DESC, community_id DESC);
CREATE INDEX community_members_list_idx ON community_members (community_id, joined_at DESC, account_id DESC);

CREATE TABLE community_join_requests (
    community_id uuid        NOT NULL REFERENCES communities (id) ON DELETE CASCADE,
    account_id   uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    created_at   timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (community_id, account_id)
);
CREATE INDEX community_requests_list_idx ON community_join_requests (community_id, created_at DESC, account_id DESC);

CREATE TABLE community_invites (
    community_id uuid        NOT NULL REFERENCES communities (id) ON DELETE CASCADE,
    account_id   uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    invited_by   uuid        NOT NULL REFERENCES accounts (id) ON DELETE CASCADE,
    created_at   timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (community_id, account_id)
);
CREATE INDEX community_invites_account_idx ON community_invites (account_id, created_at DESC, community_id DESC);

CREATE TABLE community_channels (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    community_id uuid        NOT NULL REFERENCES communities (id) ON DELETE CASCADE,
    name         text        NOT NULL CHECK (char_length(name) BETWEEN 2 AND 30),
    created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX community_channels_name_uidx ON community_channels (community_id, lower(name));
