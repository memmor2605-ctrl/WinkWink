package app.winkwink.server.feed

import app.winkwink.server.api.ApiException
import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.profile.ProfileService
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.test.runTest
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class FeedServiceTest {
    private val graph = InMemoryProfileStore()
    private val clock = object : Clock() {
        var t: Instant = Instant.parse("2026-11-21T12:00:00Z")
        override fun getZone() = ZoneOffset.UTC
        override fun withZone(zone: java.time.ZoneId?) = this
        override fun instant(): Instant { t = t.plusSeconds(1); return t } // każdy odczyt = nowa sekunda → deterministyczna kolejność
    }
    private val profiles = ProfileService(graph, clock)
    private val service = FeedService(InMemoryFeedStore(graph), profiles, clock)
    private val alice = graph.seed("alice")
    private val bob = graph.seed("bob")
    private val carol = graph.seed("carol")
    private val priv = graph.seed("private_pat", visibility = "private")

    private suspend fun assertApi(status: HttpStatusCode, code: String, block: suspend () -> Unit) {
        val e = assertFailsWith<ApiException> { block() }
        assertEquals(status, e.status); assertEquals(code, e.code)
    }

    @Test fun `validation of posts`() = runTest {
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { service.create(alice.accountId, "   ", "public", false) }
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { service.create(alice.accountId, "x".repeat(5001), "public", false) }
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { service.create(alice.accountId, "hi", "everyone", false) }
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { service.create(alice.accountId, "hi", "followers", true) }
    }

    @Test fun `private and followers visibility`() = runTest {
        val priv1 = service.create(alice.accountId, "secret", "private", false)
        val fol = service.create(alice.accountId, "for followers", "followers", false)
        assertApi(HttpStatusCode.NotFound, "post_not_found") { service.get(bob.accountId, priv1.id) }
        assertApi(HttpStatusCode.NotFound, "post_not_found") { service.get(bob.accountId, fol.id) }
        assertNotNull(service.get(alice.accountId, priv1.id))
        profiles.follow(bob.accountId, "alice")
        assertNotNull(service.get(bob.accountId, fol.id))
        assertApi(HttpStatusCode.NotFound, "post_not_found") { service.get(bob.accountId, priv1.id) }
    }

    @Test fun `public post of a private profile needs an accepted follow`() = runTest {
        val post = service.create(priv.accountId, "hello", "public", false)
        assertApi(HttpStatusCode.NotFound, "post_not_found") { service.get(bob.accountId, post.id) }
        profiles.follow(bob.accountId, "private_pat")
        assertApi(HttpStatusCode.NotFound, "post_not_found") { service.get(bob.accountId, post.id) } // pending
        profiles.respondToRequest(priv.accountId, "bob", approve = true)
        assertNotNull(service.get(bob.accountId, post.id))
    }

    @Test fun `only the author edits and deletes`() = runTest {
        val p = service.create(alice.accountId, "v1", "public", false)
        assertApi(HttpStatusCode.Forbidden, "forbidden") { service.update(bob.accountId, p.id, "hacked") }
        assertApi(HttpStatusCode.Forbidden, "forbidden") { service.delete(bob.accountId, p.id) }
        val edited = service.update(alice.accountId, p.id, "v2")
        assertEquals("v2", edited.body); assertNotNull(edited.editedAt)
        service.delete(alice.accountId, p.id)
        assertApi(HttpStatusCode.NotFound, "post_not_found") { service.get(alice.accountId, p.id) }
    }

    @Test fun `following feed shows followed authors newest first with pagination`() = runTest {
        profiles.follow(alice.accountId, "bob")
        val ids = (1..5).map { service.create(bob.accountId, "post $it", "public", false).id }
        service.create(carol.accountId, "not followed", "public", false)
        val p1 = service.followingFeed(alice.accountId, 2, null)
        assertEquals(listOf(ids[4], ids[3]), p1.items.map { it.id })
        val p2 = service.followingFeed(alice.accountId, 2, p1.nextCursor)
        assertEquals(listOf(ids[2], ids[1]), p2.items.map { it.id })
        val p3 = service.followingFeed(alice.accountId, 2, p2.nextCursor)
        assertEquals(listOf(ids[0]), p3.items.map { it.id }); assertNull(p3.nextCursor)
    }

    @Test fun `discover excludes followed and own non-anonymous posts but not anonymous ones`() = runTest {
        profiles.follow(alice.accountId, "bob")
        service.create(bob.accountId, "bob open", "public", false)
        val bobAnon = service.create(bob.accountId, "bob anon", "public", true)
        val carolPost = service.create(carol.accountId, "carol open", "public", false)
        val own = service.create(alice.accountId, "alice open", "public", false)
        val ids = service.discover(alice.accountId, 20, null).items.map { it.id }
        assertTrue(carolPost.id in ids); assertTrue(bobAnon.id in ids)
        assertTrue(own.id !in ids); assertEquals(2, ids.size)
    }

    @Test fun `anonymous posts hide the author everywhere but the owner can manage them`() = runTest {
        profiles.follow(bob.accountId, "alice")
        val anon = service.create(alice.accountId, "confession", "public", true)
        val dtoForBob = service.get(bob.accountId, anon.id).toDto(bob.accountId)
        assertNull(dtoForBob.author); assertTrue(dtoForBob.anonymous); assertTrue(!dtoForBob.mine)
        val dtoForOwner = service.get(alice.accountId, anon.id).toDto(alice.accountId)
        assertNull(dtoForOwner.author); assertTrue(dtoForOwner.mine)
        assertTrue(service.followingFeed(bob.accountId, 20, null).items.isEmpty())          // nie w Following
        assertTrue(service.userPosts(bob.accountId, "alice", 20, null).items.isEmpty())     // nie na profilu
        assertTrue(service.discover(carol.accountId, 20, null).items.any { it.id == anon.id })
        service.update(alice.accountId, anon.id, "edited"); service.delete(alice.accountId, anon.id)
    }

    @Test fun `comment by the author of an anonymous post stays anonymous`() = runTest {
        val anon = service.create(alice.accountId, "q", "public", true)
        service.addComment(alice.accountId, anon.id, null, "op here")
        service.addComment(bob.accountId, anon.id, null, "hi")
        val list = service.comments(carol.accountId, anon.id, null, 20, null).items.map { it.toDto(carol.accountId) }
        assertEquals(listOf(true, false), list.map { it.authorHidden })
        assertNull(list[0].author); assertEquals("bob", list[1].author?.nickname)
    }

    @Test fun `comments replies and deletion rules`() = runTest {
        val post = service.create(alice.accountId, "p", "public", false)
        val c = service.addComment(bob.accountId, post.id, null, "top")
        val r = service.addComment(carol.accountId, post.id, c.id, "reply")
        assertApi(HttpStatusCode.BadRequest, "invalid_parent") { service.addComment(alice.accountId, post.id, r.id, "nested") }
        assertEquals(1, service.comments(alice.accountId, post.id, null, 20, null).items.single().replyCount)
        assertEquals(1, service.comments(alice.accountId, post.id, c.id, 20, null).items.size)
        assertEquals(2, service.get(alice.accountId, post.id).comments)
        assertApi(HttpStatusCode.Forbidden, "forbidden") { service.deleteComment(carol.accountId, c.id) }
        service.deleteComment(alice.accountId, c.id) // autor posta moderuje
        assertEquals(0, service.get(alice.accountId, post.id).comments) // odpowiedzi znikają razem z komentarzem
    }

    @Test fun `comment on invisible post is not found`() = runTest {
        val post = service.create(alice.accountId, "mine", "private", false)
        assertApi(HttpStatusCode.NotFound, "post_not_found") { service.addComment(bob.accountId, post.id, null, "hi") }
    }

    @Test fun `reactions replace and count and saves list`() = runTest {
        val post = service.create(alice.accountId, "p", "public", false)
        service.react(bob.accountId, post.id, "like"); service.react(carol.accountId, post.id, "love")
        val again = service.react(bob.accountId, post.id, "wow")
        assertEquals(2, again.reactions); assertEquals("wow", again.myReaction)
        assertEquals(1, service.unreact(bob.accountId, post.id).reactions)
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { service.react(bob.accountId, post.id, "angry") }
        service.save(bob.accountId, post.id); service.save(bob.accountId, post.id)
        assertEquals(listOf(post.id), service.saved(bob.accountId, 20, null).items.map { it.id })
        service.unsave(bob.accountId, post.id)
        assertTrue(service.saved(bob.accountId, 20, null).items.isEmpty())
    }

    @Test fun `blocking hides posts and comments both ways`() = runTest {
        val post = service.create(alice.accountId, "p", "public", false)
        service.addComment(bob.accountId, post.id, null, "from bob")
        profiles.block(alice.accountId, "bob")
        assertApi(HttpStatusCode.NotFound, "post_not_found") { service.get(bob.accountId, post.id) }
        assertTrue(service.comments(alice.accountId, post.id, null, 20, null).items.isEmpty())
    }

    @Test fun `search needs 3 chars and skips private posts`() = runTest {
        service.create(alice.accountId, "kotlin is fun", "public", false)
        service.create(alice.accountId, "kotlin secret", "private", false)
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { service.search(bob.accountId, "ko", null, null) }
        assertEquals(1, service.search(bob.accountId, "KOTLIN", null, null).items.size)
    }

    @Test fun `viewer blocking the author of an anonymous post does not hide it, so blocking cannot unmask the author`() = runTest {
        val post = service.create(alice.accountId, "anon", "public", true)
        service.addComment(alice.accountId, post.id, null, "own comment")
        profiles.block(bob.accountId, "alice")
        assertNotNull(service.get(bob.accountId, post.id))
        assertEquals(1, service.comments(bob.accountId, post.id, null, 20, null).items.size)
    }

    @Test fun `author blocking a viewer still hides the anonymous post from that viewer`() = runTest {
        val post = service.create(alice.accountId, "anon", "public", true)
        profiles.block(alice.accountId, "bob")
        assertApi(HttpStatusCode.NotFound, "post_not_found") { service.get(bob.accountId, post.id) }
    }

    // ---- wyciszanie (Etap A) ----

    @Test fun `muted users disappear from following, discover and search but not from their profile`() = runTest {
        profiles.follow(alice.accountId, "bob")
        service.create(bob.accountId, "widoczny post bobb", "public", false)
        assertEquals(1, service.followingFeed(alice.accountId, null, null).items.size)
        profiles.mute(alice.accountId, "bob")
        assertTrue(service.followingFeed(alice.accountId, null, null).items.isEmpty())
        assertTrue(service.discover(alice.accountId, null, null).items.isEmpty())
        assertTrue(service.search(alice.accountId, "widoczny", null, null).items.isEmpty())
        // jawne wejście na profil nadal pokazuje posty — wyciszenie nie jest blokadą
        assertEquals(1, service.userPosts(alice.accountId, "bob", null, null).items.size)
        // inni widzowie i sam autor bez zmian
        assertEquals(1, service.search(carol.accountId, "widoczny", null, null).items.size)
        profiles.unmute(alice.accountId, "bob")
        assertEquals(1, service.followingFeed(alice.accountId, null, null).items.size)
    }

    @Test fun `muting the author of an anonymous post does not hide it, so muting cannot unmask the author`() = runTest {
        val post = service.create(bob.accountId, "anonimowy sekret", "public", true)
        val before = service.discover(carol.accountId, null, null).items.map { it.id }
        profiles.mute(carol.accountId, "bob")
        assertEquals(before, service.discover(carol.accountId, null, null).items.map { it.id })
        assertTrue(post.id in service.discover(carol.accountId, null, null).items.map { it.id })
    }

    @Test fun `muted commenters are hidden except the anonymous post author`() = runTest {
        val open = service.create(alice.accountId, "otwarty", "public", false)
        service.addComment(bob.accountId, open.id, null, "komentarz boba")
        profiles.mute(carol.accountId, "bob")
        assertTrue(service.comments(carol.accountId, open.id, null, null, null).items.isEmpty())
        assertEquals(1, service.comments(alice.accountId, open.id, null, null, null).items.size)

        val anon = service.create(bob.accountId, "anon", "public", true)
        service.addComment(bob.accountId, anon.id, null, "autor pod własnym anonimowym postem")
        val visible = service.comments(carol.accountId, anon.id, null, null, null).items
        assertEquals(1, visible.size)
        assertNull(visible.single().toDto(carol.accountId).author)
    }

    @Test fun `author avatar is exposed for named posts and never for anonymous ones`() = runTest {
        graph.setAvatarKey(bob.accountId, "avatar/11111111-2222-3333-4444-555555555555")
        val named = service.create(bob.accountId, "jawny", "public", false)
        val anon = service.create(bob.accountId, "anonimowy", "public", true)
        val namedDto = named.toDto(alice.accountId)
        assertTrue(namedDto.author!!.hasAvatar); assertNotNull(namedDto.author!!.avatarTag)
        assertNull(service.get(alice.accountId, anon.id).toDto(alice.accountId).author)
    }
}
