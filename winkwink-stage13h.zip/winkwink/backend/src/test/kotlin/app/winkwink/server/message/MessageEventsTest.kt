package app.winkwink.server.message

import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.realtime.MessageEvents
import app.winkwink.server.realtime.RealtimeEvent
import kotlinx.coroutines.test.runTest
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import java.util.UUID
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

class MessageEventsTest {
    private class Recorder : MessageEvents {
        val log = mutableListOf<Pair<Set<UUID>, RealtimeEvent>>()
        override suspend fun publish(recipients: Collection<UUID>, event: RealtimeEvent) { log += recipients.toSet() to event }
        fun of(type: String) = log.filter { it.second.type == type }
        fun clear() = log.clear()
    }

    private val graph = InMemoryProfileStore()
    private val clock = object : Clock() {
        var t: Instant = Instant.parse("2026-11-24T12:00:00Z")
        override fun getZone() = ZoneOffset.UTC
        override fun withZone(zone: java.time.ZoneId?) = this
        override fun instant(): Instant { t = t.plusSeconds(1); return t }
    }
    private val rec = Recorder()
    private val service = MessageService(InMemoryMessageStore(graph), graph, clock, rec)
    private val alice = graph.seed("alice")
    private val bob = graph.seed("bobby")
    private val carol = graph.seed("carol")

    private suspend fun direct() = service.startDirect(alice.accountId, "bobby").conversation.id

    @Test fun `creating a direct chat notifies both once and reopening does not`() = runTest {
        direct(); direct()
        val created = rec.of("conversation.new")
        assertEquals(1, created.size)
        assertEquals(setOf(alice.accountId, bob.accountId), created.single().first)
    }

    @Test fun `new message goes to all members including senders other devices and names the sender`() = runTest {
        val g = service.createGroup(alice.accountId, "Ekipa", listOf("bobby", "carol")).conversation.id
        rec.clear()
        val m = service.send(alice.accountId, g, "tajna treść", null).row.id
        val e = rec.of("message.new").single()
        assertEquals(setOf(alice.accountId, bob.accountId, carol.accountId), e.first)
        assertEquals(m.toString(), e.second.messageId); assertEquals("alice", e.second.actor?.nickname)
        // zdarzenie nie niesie treści
        assertTrue(rec.log.none { it.second.toString().contains("tajna") })
    }

    @Test fun `edit delete and reaction emit updates to the conversation`() = runTest {
        val id = direct(); val m = service.send(alice.accountId, id, "a", null).row.id
        rec.clear()
        service.edit(alice.accountId, m, "b"); service.react(bob.accountId, m, "like"); service.delete(alice.accountId, m)
        assertEquals(listOf("message.updated", "message.updated", "message.deleted"), rec.log.map { it.second.type })
    }

    @Test fun `delivery and read emit receipts but repeated fetches do not ping pong`() = runTest {
        val id = direct(); service.send(alice.accountId, id, "a", null)
        rec.clear()
        service.messages(bob.accountId, id, null, null)
        assertEquals(1, rec.of("receipt").size) // pierwsze pobranie zmienia stan dostarczenia
        rec.clear()
        service.messages(bob.accountId, id, null, null); service.list(bob.accountId, false, null, null, null)
        assertTrue(rec.of("receipt").isEmpty()) // nic nowego do dostarczenia
        service.markRead(bob.accountId, id)
        assertEquals(1, rec.of("receipt").size)
        // nadawca pobierający własne wiadomości nie generuje zdarzeń
        rec.clear(); service.messages(alice.accountId, id, null, null)
        assertTrue(rec.of("receipt").isEmpty())
    }

    @Test fun `settings changes sync only the own devices`() = runTest {
        val id = direct(); rec.clear()
        service.setFlags(bob.accountId, id, muted = true, archived = null)
        assertEquals(setOf(bob.accountId), rec.of("conversation.updated").single().first)
    }

    @Test fun `membership changes reach the removed member too`() = runTest {
        val g = service.createGroup(alice.accountId, "Ekipa", listOf("bobby")).conversation.id
        rec.clear()
        service.addMember(alice.accountId, g, "carol")
        assertEquals(3, rec.of("member.changed").single().first.size)
        rec.clear()
        service.removeMember(alice.accountId, g, "carol")
        assertTrue(carolIn(rec.of("member.changed").single().first))
    }

    private fun carolIn(set: Set<UUID>) = carol.accountId in set

    @Test fun `typing respects receipt privacy and blocks`() = runTest {
        val id = direct(); rec.clear()
        service.typing(alice.accountId, id)
        val e = rec.of("typing").single()
        assertEquals(setOf(bob.accountId), e.first); assertEquals("alice", e.second.actor?.nickname)
        rec.clear()
        service.setReadReceipts(alice.accountId, false)
        service.typing(alice.accountId, id) // piszący wyłączył potwierdzenia → nic nie wysyła
        assertTrue(rec.log.isEmpty())
        service.setReadReceipts(alice.accountId, true); service.setReadReceipts(bob.accountId, false)
        service.typing(alice.accountId, id) // odbiorca wyłączył → nic nie dostaje
        assertTrue(rec.log.isEmpty())
        service.setReadReceipts(bob.accountId, true)
        graph.addBlock(bob.accountId, alice.accountId, Instant.now())
        service.typing(alice.accountId, id)
        assertTrue(rec.log.isEmpty())
    }

    @Test fun `typing from a non member or unknown conversation is ignored silently`() = runTest {
        val id = direct(); rec.clear()
        service.typing(carol.accountId, id)
        service.typing(alice.accountId, UUID.randomUUID())
        assertTrue(rec.log.isEmpty())
        assertNull(rec.log.firstOrNull())
    }

    @Test fun `a failing event sink never breaks the operation`() = runTest {
        val broken = MessageService(InMemoryMessageStore(graph), graph, clock, MessageEvents { _, _ -> error("boom") })
        val id = broken.startDirect(alice.accountId, "bobby").conversation.id
        assertEquals("ok", broken.send(alice.accountId, id, "ok", null).row.body)
    }
}
