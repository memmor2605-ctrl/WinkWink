package app.winkwink.server.notification

import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.profile.PageCursor
import java.time.Instant
import java.util.UUID

class InMemoryNotificationStore(private val profiles: InMemoryProfileStore) : NotificationStore {
    private data class N(val id: UUID, val event: NotificationEvent, val at: Instant, var readAt: Instant? = null)

    private val rows = mutableListOf<N>()
    private val disabled = mutableMapOf<UUID, Set<String>>()
    var failOnInsert = false
    private val dedupeTypes = setOf(NotificationTypes.REACTION, NotificationTypes.NEW_FOLLOWER, NotificationTypes.FOLLOW_REQUEST, NotificationTypes.COMMUNITY_INVITE)

    @Synchronized override suspend fun insert(event: NotificationEvent, now: Instant): UUID? {
        if (failOnInsert) error("db down")
        if (event.type in dedupeTypes && rows.any {
                it.event.recipient == event.recipient && it.event.actor == event.actor && it.event.type == event.type &&
                    it.event.postId == event.postId && it.event.communityId == event.communityId
            }
        ) return null
        val n = N(UUID.randomUUID(), event, now); rows += n; return n.id
    }

    private suspend fun visible(recipient: UUID) = rows.filter {
        it.event.recipient == recipient &&
            !(if (it.event.actorAnonymous) profiles.hasBlocked(it.event.actor, recipient) else profiles.isBlockedEitherWay(recipient, it.event.actor))
    }

    override suspend fun list(recipient: UUID, type: String?, unreadOnly: Boolean, limit: Int, after: PageCursor?): List<NotificationRow> =
        visible(recipient)
            .filter { (type == null || it.event.type == type) && (!unreadOnly || it.readAt == null) }
            .sortedWith(compareByDescending<N> { it.at }.thenByDescending { it.id })
            .filter { after == null || it.at < after.at || (it.at == after.at && it.id < after.id) }
            .take(limit)
            .map {
                val actor = profiles.findById(it.event.actor)!!
                NotificationRow(it.id, it.event.type, actor.nickname, actor.winkwinkId, actor.displayName, false, it.event.postId, it.event.commentId, it.event.communityId, it.at, it.readAt, it.event.actorAnonymous)
            }

    override suspend fun unreadCount(recipient: UUID) = visible(recipient).count { it.readAt == null }

    @Synchronized override suspend fun markRead(recipient: UUID, id: UUID, now: Instant): Boolean {
        val n = rows.firstOrNull { it.id == id && it.event.recipient == recipient } ?: return false
        if (n.readAt == null) n.readAt = now
        return true
    }

    @Synchronized override suspend fun markAllRead(recipient: UUID, type: String?, now: Instant) {
        rows.filter { it.event.recipient == recipient && it.readAt == null && (type == null || it.event.type == type) }.forEach { it.readAt = now }
    }

    override suspend fun disabledTypes(recipient: UUID) = disabled[recipient] ?: emptySet()
    override suspend fun setDisabledTypes(recipient: UUID, types: Set<String>) { disabled[recipient] = types }
}
