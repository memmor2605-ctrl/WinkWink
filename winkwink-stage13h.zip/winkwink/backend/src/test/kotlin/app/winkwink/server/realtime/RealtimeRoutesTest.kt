package app.winkwink.server.realtime

import app.winkwink.server.auth.TestAuth
import app.winkwink.server.auth.testAppConfig
import app.winkwink.server.health.DatabaseHealth
import app.winkwink.server.health.HealthProbe
import app.winkwink.server.message.InMemoryMessageStore
import app.winkwink.server.message.MessageService
import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.winkwinkModule
import io.ktor.client.plugins.websocket.WebSockets
import io.ktor.client.plugins.websocket.webSocket
import io.ktor.client.request.header
import io.ktor.client.request.request
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.server.testing.testApplication
import io.ktor.websocket.Frame
import io.ktor.websocket.readText
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.test.Test
import kotlin.test.assertEquals

/** Testy WSS: uwierzytelnianie uchwytu, hello, zdarzenia dla członków, wskaźnik pisania. Wymagają prawdziwego uruchomienia Ktor test host. */
class RealtimeRoutesTest {
    private val probe = HealthProbe { DatabaseHealth("up", 1, "5") }
    private val auth = TestAuth()
    private val graph = InMemoryProfileStore()
    private val hub = RealtimeHub()
    private val messages = MessageService(InMemoryMessageStore(graph), graph, events = RealtimeEvents(hub))

    private fun user(nick: String): String = runBlocking {
        val r = auth.service.register("$nick@example.com", "correct-horse-battery", nick, "android", null, null)
        graph.seed(nick, id = r.profile.accountId)
        r.session.accessToken
    }

    private fun accountOf(nick: String) = runBlocking { graph.findByIdentifier(nick)!!.accountId }

    private fun type(frame: Frame) = Json.parseToJsonElement((frame as Frame.Text).readText()).jsonObject.getValue("type").jsonPrimitive.content

    @Test fun `handshake without a token is rejected`() = testApplication {
        application { winkwinkModule(testAppConfig(), probe, auth.service, messages = messages, realtime = hub) }
        val r = client.request("/api/v1/ws") { header("X-Forwarded-Proto", "https") }
        assertEquals(HttpStatusCode.Unauthorized, r.status)
    }

    @Test fun `authenticated client gets hello then events about its conversations and typing`() = testApplication {
        application { winkwinkModule(testAppConfig(), probe, auth.service, messages = messages, realtime = hub) }
        val ws = createClient { install(WebSockets) }
        val alice = user("alice"); val bob = user("bobby")
        val id = messages.startDirect(accountOf("alice"), "bobby").conversation.id
        ws.webSocket("/api/v1/ws", request = { header("X-Forwarded-Proto", "https"); header(HttpHeaders.Authorization, "Bearer $bob") }) {
            assertEquals("hello", withTimeout(5_000) { type(incoming.receive()) })
            messages.send(accountOf("alice"), id, "hej", null)
            assertEquals("message.new", withTimeout(5_000) { type(incoming.receive()) })
            // Alice (drugie połączenie) pisze — Bob dostaje wskaźnik
            ws.webSocket("/api/v1/ws", request = { header("X-Forwarded-Proto", "https"); header(HttpHeaders.Authorization, "Bearer $alice") }) {
                withTimeout(5_000) { incoming.receive() } // hello
                send(Frame.Text("""{"type":"typing","conversationId":"$id"}"""))
            }
            assertEquals("typing", withTimeout(5_000) { type(incoming.receive()) })
        }
    }
}
