package app.winkwink.server.auth

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotEquals
import kotlin.test.assertTrue

class PasswordHasherTest {
    private val hasher = Argon2idPasswordHasher(memoryKb = 64, iterations = 1, parallelism = 1)

    @Test
    fun `hash verifies only the right password`() {
        val h = hasher.hash("correct horse battery")
        assertTrue(hasher.verify("correct horse battery", h))
        assertFalse(hasher.verify("correct horse batterY", h))
    }

    @Test
    fun `hashes are salted and use argon2id format`() {
        val a = hasher.hash("same-password-1")
        val b = hasher.hash("same-password-1")
        assertNotEquals(a, b)
        assertTrue(a.startsWith("\$argon2id\$v=19\$m=64,t=1,p=1\$"))
        assertEquals(6, a.split('$').size)
    }

    @Test
    fun `malformed or hostile hashes are rejected without throwing`() {
        assertFalse(hasher.verify("x", "plaintext"))
        assertFalse(hasher.verify("x", "\$argon2id\$v=19\$m=99999999,t=1,p=1\$AAAA\$BBBB"))
        assertFalse(hasher.verify("x", "\$argon2id\$v=19\$m=64,t=1,p=1\$!!!\$???"))
    }

    @Test
    fun `hash does not contain the password`() {
        assertFalse(hasher.hash("SuperSecretPassword!").contains("SuperSecret"))
    }
}
