package app.winkwink.server.community

import app.winkwink.server.profile.ProfileStore
import java.time.Instant
import java.util.UUID

/** Implementacja w pamięci wyłącznie do testów logiki serwisu (nie do produkcji). */
class InMemoryCommunityStore(private val users: ProfileStore) : CommunityStore {
    private class C(val id: UUID, var name: String, var description: String, var rules: String, var type: String, val ownerId: UUID, val createdAt: Instant, var deleted: Boolean = false)
    private class M(val communityId: UUID, val accountId: UUID, var role: String, val at: Instant)
    private class Link(val communityId: UUID, val accountId: UUID, val at: Instant)

    private val communities = mutableListOf<C>()
    private val members = mutableListOf<M>()
    private val requests = mutableListOf<Link>()
    private val invites = mutableListOf<Link>()
    private val channels = mutableListOf<ChannelRow>()
    private val mutes = mutableSetOf<Pair<UUID, UUID>>()
    private val inviters = mutableMapOf<Pair<UUID, UUID>, UUID>()

    private fun row(c: C, cursorAt: Instant = c.createdAt) = CommunityRow(
        c.id, c.name, c.description, c.rules, c.type, c.ownerId, c.createdAt, members.count { it.communityId == c.id }, cursorAt,
    )
    private fun live(id: UUID) = communities.firstOrNull { it.id == id && !it.deleted }

    @Synchronized override suspend fun create(ownerId: UUID, name: String, description: String, rules: String, type: String, defaultChannel: String, now: Instant): UUID {
        val c = C(UUID.randomUUID(), name, description, rules, type, ownerId, now)
        communities += c
        members += M(c.id, ownerId, "owner", now)
        channels += ChannelRow(UUID.randomUUID(), c.id, defaultChannel, now)
        return c.id
    }
    @Synchronized override suspend fun find(id: UUID) = live(id)?.let { row(it) }
    @Synchronized override suspend fun nameTakenByOther(name: String, exceptId: UUID?) =
        communities.any { !it.deleted && it.name.equals(name, true) && it.id != exceptId }
    @Synchronized override suspend fun update(id: UUID, name: String, description: String, rules: String, type: String) {
        live(id)?.let { it.name = name; it.description = description; it.rules = rules; it.type = type }
    }
    @Synchronized override suspend fun softDelete(id: UUID, now: Instant) { live(id)?.deleted = true }

    @Synchronized override suspend fun roleOf(communityId: UUID, accountId: UUID) =
        members.firstOrNull { it.communityId == communityId && it.accountId == accountId }?.role
    @Synchronized override suspend fun addMember(communityId: UUID, accountId: UUID, role: String, now: Instant) {
        if (members.none { it.communityId == communityId && it.accountId == accountId }) members += M(communityId, accountId, role, now)
    }
    @Synchronized override suspend fun removeMember(communityId: UUID, accountId: UUID) =
        members.removeIf { it.communityId == communityId && it.accountId == accountId && it.role != "owner" }
    @Synchronized override suspend fun setRole(communityId: UUID, accountId: UUID, role: String) {
        members.firstOrNull { it.communityId == communityId && it.accountId == accountId && it.role != "owner" }?.role = role
    }

    @Synchronized override suspend fun transferOwnership(communityId: UUID, from: UUID, to: UUID) {
        members.firstOrNull { it.communityId == communityId && it.accountId == from }?.role = "admin"
        members.firstOrNull { it.communityId == communityId && it.accountId == to }?.role = "owner"
        communities.firstOrNull { it.id == communityId }?.let { c ->
            communities[communities.indexOf(c)] = C(c.id, c.name, c.description, c.rules, c.type, to, c.createdAt, c.deleted)
        }
        mutes.remove(communityId to to)
    }
    @Synchronized override suspend fun setMuted(communityId: UUID, accountId: UUID, mutedBy: UUID, muted: Boolean, now: Instant) {
        if (muted) mutes += communityId to accountId else mutes -= communityId to accountId
    }
    @Synchronized override suspend fun isMuted(communityId: UUID, accountId: UUID) = (communityId to accountId) in mutes
    @Synchronized override suspend fun mutedAmong(communityId: UUID, accountIds: Collection<UUID>) = accountIds.filter { (communityId to it) in mutes }.toSet()
    @Synchronized override suspend fun inviterOf(communityId: UUID, accountId: UUID) = inviters[communityId to accountId]

    private suspend fun person(accountId: UUID, role: String?, at: Instant): PersonRow {
        val u = users.findById(accountId)!!
        return PersonRow(accountId, u.nickname, u.winkwinkId, u.displayName, role, at)
    }
    private fun <T> pageAfter(list: List<T>, cursor: app.winkwink.server.profile.PageCursor?, at: (T) -> Instant, id: (T) -> UUID): List<T> =
        list.sortedWith(compareByDescending<T> { at(it) }.thenByDescending { id(it) })
            .filter { cursor == null || at(it) < cursor.at || (at(it) == cursor.at && id(it) < cursor.id) }

    override suspend fun members(communityId: UUID, limit: Int, after: PageCursorKey?): List<PersonRow> {
        val ms = synchronized(this) { members.filter { it.communityId == communityId } }
        return pageAfter(ms, after, { it.at }, { it.accountId }).take(limit).map { person(it.accountId, it.role, it.at) }
    }
    override suspend fun requests(communityId: UUID, limit: Int, after: PageCursorKey?): List<PersonRow> {
        val rs = synchronized(this) { requests.filter { it.communityId == communityId } }
        return pageAfter(rs, after, { it.at }, { it.accountId }).take(limit).map { person(it.accountId, null, it.at) }
    }

    @Synchronized override suspend fun hasRequest(communityId: UUID, accountId: UUID) = requests.any { it.communityId == communityId && it.accountId == accountId }
    @Synchronized override suspend fun addRequest(communityId: UUID, accountId: UUID, now: Instant) { if (!hasRequestSync(communityId, accountId)) requests += Link(communityId, accountId, now) }
    private fun hasRequestSync(c: UUID, a: UUID) = requests.any { it.communityId == c && it.accountId == a }
    @Synchronized override suspend fun removeRequest(communityId: UUID, accountId: UUID) = requests.removeIf { it.communityId == communityId && it.accountId == accountId }

    @Synchronized override suspend fun hasInvite(communityId: UUID, accountId: UUID) = invites.any { it.communityId == communityId && it.accountId == accountId }
    @Synchronized override suspend fun addInvite(communityId: UUID, accountId: UUID, invitedBy: UUID, now: Instant) {
        if (invites.none { it.communityId == communityId && it.accountId == accountId }) { invites += Link(communityId, accountId, now); inviters[communityId to accountId] = invitedBy }
    }
    @Synchronized override suspend fun removeInvite(communityId: UUID, accountId: UUID) = invites.removeIf { it.communityId == communityId && it.accountId == accountId }

    @Synchronized override suspend fun invitesFor(accountId: UUID, limit: Int, after: PageCursorKey?): List<CommunityRow> =
        pageAfter(invites.filter { it.accountId == accountId && live(it.communityId) != null }, after, { it.at }, { it.communityId })
            .take(limit).map { row(live(it.communityId)!!, it.at) }

    @Synchronized override suspend fun memberships(accountId: UUID, limit: Int, after: PageCursorKey?): List<CommunityRow> =
        pageAfter(members.filter { it.accountId == accountId && live(it.communityId) != null }, after, { it.at }, { it.communityId })
            .take(limit).map { row(live(it.communityId)!!, it.at) }

    @Synchronized override suspend fun search(viewer: UUID, query: String, limit: Int, after: PageCursorKey?): List<CommunityRow> {
        val visible = communities.filter {
            !it.deleted && it.name.contains(query, true) &&
                (it.type != "invite" || members.any { m -> m.communityId == it.id && m.accountId == viewer })
        }
        return pageAfter(visible, after, { it.createdAt }, { it.id }).take(limit).map { row(it) }
    }

    @Synchronized override suspend fun channels(communityId: UUID) = channels.filter { it.communityId == communityId }.sortedBy { it.createdAt }
    @Synchronized override suspend fun addChannel(communityId: UUID, name: String, now: Instant): UUID {
        val id = UUID.randomUUID(); channels += ChannelRow(id, communityId, name, now); return id
    }
    @Synchronized override suspend fun channelNameTaken(communityId: UUID, name: String) = channels.any { it.communityId == communityId && it.name.equals(name, true) }
    @Synchronized override suspend fun deleteChannel(communityId: UUID, channelId: UUID) = channels.removeIf { it.communityId == communityId && it.id == channelId }
}
