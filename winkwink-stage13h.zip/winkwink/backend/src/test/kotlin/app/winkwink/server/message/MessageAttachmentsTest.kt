package app.winkwink.server.message

import app.winkwink.server.api.ApiException
import app.winkwink.server.media.InMemoryMediaStorage
import app.winkwink.server.media.TestMedia
import app.winkwink.server.media.UploadRateLimiter
import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.realtime.MessageEvents
import app.winkwink.server.realtime.RealtimeEvent
import app.winkwink.server.realtime.RealtimeEvents
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.test.runTest
import java.time.Clock
import java.time.Duration
import java.time.Instant
import java.time.ZoneOffset
import java.util.UUID
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** Etap F: załączniki wiadomości — walidacja, powiązanie z wiadomością, kontrola dostępu i sprzątanie plików. */
class MessageAttachmentsTest {
    private val graph = InMemoryProfileStore()
    private val clock = object : Clock() {
        var t: Instant = Instant.parse("2026-11-25T12:00:00Z")
        override fun getZone() = ZoneOffset.UTC
        override fun withZone(zone: java.time.ZoneId?) = this
        override fun instant(): Instant { t = t.plusSeconds(1); return t }
    }
    private val store = InMemoryMessageStore(graph)
    private val storage = InMemoryMediaStorage()
    private val messages = MessageService(store, graph, clock, media = storage)
    private val attachments = MessageAttachmentService(store, storage, UploadRateLimiter(perMinute = 10_000, perHour = 100_000, clock = clock), clock)
    private val alice = graph.seed("alice")
    private val bob = graph.seed("bobby")
    private val carol = graph.seed("carol")

    private suspend fun direct(a: UUID, other: String) = messages.startDirect(a, other).conversation.id
    private suspend fun upload(who: UUID, conv: UUID, bytes: ByteArray, mime: String, name: String? = null) = attachments.upload(who, conv, bytes, mime, name)
    private suspend fun status(block: suspend () -> Unit): HttpStatusCode =
        try { block(); throw AssertionError("expected ApiException") } catch (e: ApiException) { e.status }

    // ---- zdjęcia ----

    @Test fun `image upload is re-encoded and stored outside the database`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        val row = upload(alice.accountId, conv, TestMedia.png(120, 80), "image/png")
        assertEquals("image", row.kind)
        assertEquals(120, row.width); assertEquals(80, row.height)
        assertNull(row.fileName); assertNull(row.durationMs); assertNull(row.messageId)
        assertTrue(row.objectKey.startsWith("message/"))
        assertEquals(1, storage.files.size)
        assertEquals(row.sizeBytes, storage.files.getValue(row.objectKey).size.toLong())
    }

    @Test fun `gallery of images is sent as one message and visible to both members`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        val ids = (1..3).map { upload(alice.accountId, conv, TestMedia.png(10 * it, 10 * it), "image/png").id }
        val sent = messages.send(alice.accountId, conv, "", null, ids)
        assertEquals("", sent.row.body)
        assertEquals(ids, sent.attachments.map { it.id })
        val seenByBob = messages.messages(bob.accountId, conv, null, null).items.single()
        assertEquals(ids, seenByBob.attachments.map { it.id })
        assertEquals("image", seenByBob.attachments.first().kind)
        // Podgląd na liście rozmów.
        val preview = messages.list(bob.accountId, false, null, null, null).items.single()
        assertNotNull(preview.last)
        assertEquals(3, preview.lastAttachments.size)
    }

    @Test fun `message needs text or an attachment`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        assertEquals(HttpStatusCode.BadRequest, assertFailsWith<ApiException> { messages.send(alice.accountId, conv, "  ", null, emptyList()) }.status)
    }

    // ---- reguły łączenia ----

    @Test fun `attachments cannot be borrowed reused or moved between conversations`() = runTest {
        val ab = direct(alice.accountId, "bobby"); val ac = direct(alice.accountId, "carol")
        val mine = upload(alice.accountId, ab, TestMedia.png(), "image/png").id
        // Cudzy załącznik i załącznik z innej rozmowy: ten sam błąd (nie zdradzamy istnienia).
        assertEquals("attachments_unavailable", assertFailsWith<ApiException> { messages.send(bob.accountId, ab, "x", null, listOf(mine)) }.code)
        assertEquals("attachments_unavailable", assertFailsWith<ApiException> { messages.send(alice.accountId, ac, "x", null, listOf(mine)) }.code)
        assertEquals("attachments_unavailable", assertFailsWith<ApiException> { messages.send(alice.accountId, ab, "x", null, listOf(UUID.randomUUID())) }.code)
        messages.send(alice.accountId, ab, "pierwsza", null, listOf(mine))
        assertEquals(HttpStatusCode.Conflict, assertFailsWith<ApiException> { messages.send(alice.accountId, ab, "druga", null, listOf(mine)) }.status)
        // Nieudana wysyłka nie zostawia wiadomości.
        assertEquals(1, messages.messages(alice.accountId, ab, null, null).items.size)
    }

    @Test fun `one kind per message and per kind limits`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        val img = upload(alice.accountId, conv, TestMedia.png(), "image/png").id
        val doc = upload(alice.accountId, conv, TestMedia.pdf(), "application/pdf", "a.pdf").id
        assertEquals(HttpStatusCode.BadRequest, assertFailsWith<ApiException> { messages.send(alice.accountId, conv, "", null, listOf(img, doc)) }.status)
        assertEquals(HttpStatusCode.BadRequest, assertFailsWith<ApiException> { messages.send(alice.accountId, conv, "", null, listOf(img, img)) }.status)
        val many = (1..11).map { upload(alice.accountId, conv, TestMedia.png(), "image/png").id }
        assertEquals(HttpStatusCode.BadRequest, assertFailsWith<ApiException> { messages.send(alice.accountId, conv, "", null, many) }.status)
        assertEquals(10, messages.send(alice.accountId, conv, "", null, many.take(10)).attachments.size)
        val docs = (1..6).map { upload(alice.accountId, conv, TestMedia.pdf(), "application/pdf", "d$it.pdf").id }
        assertEquals(HttpStatusCode.BadRequest, assertFailsWith<ApiException> { messages.send(alice.accountId, conv, "", null, docs) }.status)
    }

    // ---- walidacja zawartości ----

    @Test fun `declared type must match real content`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        // Plik wykonywalny udający obraz / dokument.
        val exe = byteArrayOf(0x4D, 0x5A, 0x90.toByte(), 0, 3, 0, 0, 0)
        assertEquals(HttpStatusCode.UnsupportedMediaType, assertFailsWith<ApiException> { upload(alice.accountId, conv, exe, "image/jpeg") }.status)
        assertEquals(HttpStatusCode.UnsupportedMediaType, assertFailsWith<ApiException> { upload(alice.accountId, conv, exe, "application/pdf", "faktura.pdf") }.status)
        assertEquals(HttpStatusCode.UnsupportedMediaType, assertFailsWith<ApiException> { upload(alice.accountId, conv, exe, "application/octet-stream", "x.bin") }.status)
        // HTML pod pozorem tekstu, SVG, JS — odrzucone już po deklarowanym typie albo po zawartości.
        assertEquals(HttpStatusCode.UnsupportedMediaType, assertFailsWith<ApiException> { upload(alice.accountId, conv, "<html></html>".toByteArray(), "text/html") }.status)
        assertEquals(HttpStatusCode.UnsupportedMediaType, assertFailsWith<ApiException> { upload(alice.accountId, conv, "<html><script>x</script></html>".toByteArray(), "text/plain", "a.txt") }.status)
        assertEquals(HttpStatusCode.UnsupportedMediaType, assertFailsWith<ApiException> { upload(alice.accountId, conv, "alert(1)".toByteArray(), "application/javascript", "a.js") }.status)
        // PDF w obrazie i obraz w PDF.
        assertEquals(HttpStatusCode.UnsupportedMediaType, assertFailsWith<ApiException> { upload(alice.accountId, conv, TestMedia.pdf(), "image/png") }.status)
        assertEquals(HttpStatusCode.UnsupportedMediaType, assertFailsWith<ApiException> { upload(alice.accountId, conv, TestMedia.png(), "application/pdf", "a.pdf") }.status)
        assertEquals(0, storage.files.size)
    }

    @Test fun `corrupt image and oversize payload are rejected`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        val broken = TestMedia.png().copyOf(40) // sygnatura PNG, ale ucięty obraz
        assertTrue(assertFailsWith<ApiException> { upload(alice.accountId, conv, broken, "image/png") }.status.value in setOf(400, 415))
        assertEquals(HttpStatusCode.PayloadTooLarge, assertFailsWith<ApiException> { upload(alice.accountId, conv, ByteArray(9 * 1024 * 1024) { 1 }, "image/png") }.status)
        assertEquals(HttpStatusCode.PayloadTooLarge, assertFailsWith<ApiException> { upload(alice.accountId, conv, ByteArray(11 * 1024 * 1024) { 1 }, "application/pdf", "a.pdf") }.status)
        assertEquals(HttpStatusCode.BadRequest, assertFailsWith<ApiException> { upload(alice.accountId, conv, ByteArray(0), "image/png") }.status)
        assertEquals(0, storage.files.size)
    }

    // ---- dokumenty ----

    @Test fun `documents keep a safe name and the real mime`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        val pdf = upload(alice.accountId, conv, TestMedia.pdf(), "application/pdf", "../../Raport kwartalny.pdf")
        assertEquals("document", pdf.kind); assertEquals("application/pdf", pdf.mime); assertEquals("Raport kwartalny.pdf", pdf.fileName)
        val docx = upload(alice.accountId, conv, TestMedia.docx(), "application/octet-stream", "umowa.bin")
        assertEquals("umowa.docx", docx.fileName)
        assertTrue(docx.mime.endsWith("wordprocessingml.document"))
        val csv = upload(alice.accountId, conv, "a,b\n1,2\n".toByteArray(), "text/csv", "dane.csv")
        assertEquals("text/csv", csv.mime); assertEquals("dane.csv", csv.fileName)
        assertEquals("book.xlsx", upload(alice.accountId, conv, TestMedia.xlsx(), "application/octet-stream", "book").fileName)
        assertEquals("odt", upload(alice.accountId, conv, TestMedia.odt(), "application/vnd.oasis.opendocument.text", "x.odt").fileName!!.substringAfterLast('.'))
    }

    @Test fun `unsafe documents are refused`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        listOf(
            Triple(TestMedia.docx(mapOf("word/vbaProject.bin" to "x")), "application/octet-stream", "makro.docx"),
            Triple(TestMedia.pdf(), "application/pdf", "raport.exe.pdf"),
            Triple(TestMedia.pdf("/JavaScript "), "application/pdf", "ok.pdf"),
            Triple("{\\rtf1{\\*\\objdata 00}}".toByteArray(), "application/rtf", "a.rtf"),
        ).forEach { (bytes, mime, name) ->
            assertEquals(HttpStatusCode.UnsupportedMediaType, assertFailsWith<ApiException> { upload(alice.accountId, conv, bytes, mime, name) }.status, name)
        }
        assertEquals(0, storage.files.size)
    }

    // ---- głosówki ----

    @Test fun `voice message is audio only with server derived duration and no text`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        val v = upload(alice.accountId, conv, TestMedia.mp4(durationMs = 4200), "audio/mp4", "voice.m4a")
        assertEquals("voice", v.kind); assertEquals(4200L, v.durationMs); assertNull(v.fileName); assertEquals("audio/mp4", v.mime)
        assertEquals(HttpStatusCode.BadRequest, assertFailsWith<ApiException> { messages.send(alice.accountId, conv, "podpis", null, listOf(v.id)) }.status)
        val sent = messages.send(alice.accountId, conv, "", null, listOf(v.id))
        assertEquals(4200L, sent.attachments.single().durationMs)
        // Głosówki nie są edytowalne.
        assertEquals(HttpStatusCode.BadRequest, assertFailsWith<ApiException> { messages.edit(alice.accountId, sent.row.id, "x") }.status)
    }

    @Test fun `voice rejects video too short and too long recordings`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        assertEquals(HttpStatusCode.UnsupportedMediaType, assertFailsWith<ApiException> { upload(alice.accountId, conv, TestMedia.mp4(handler = "vide"), "audio/mp4") }.status)
        assertEquals(HttpStatusCode.UnsupportedMediaType, assertFailsWith<ApiException> { upload(alice.accountId, conv, TestMedia.png(), "audio/mp4") }.status)
        assertEquals("recording_too_short", assertFailsWith<ApiException> { upload(alice.accountId, conv, TestMedia.mp4(durationMs = 100), "audio/mp4") }.code)
        assertEquals("recording_too_long", assertFailsWith<ApiException> { upload(alice.accountId, conv, TestMedia.mp4(durationMs = 11 * 60 * 1000L), "audio/mp4") }.code)
    }

    // ---- dostęp ----

    @Test fun `only conversation members can download and only after the message exists`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        val a = upload(alice.accountId, conv, TestMedia.png(), "image/png")
        // Niedołączony: tylko właściciel.
        assertNotNull(attachments.download(alice.accountId, a.id))
        assertEquals(HttpStatusCode.NotFound, status { attachments.download(bob.accountId, a.id) })
        messages.send(alice.accountId, conv, "", null, listOf(a.id))
        assertTrue(attachments.download(bob.accountId, a.id).bytes.isNotEmpty())
        assertEquals(HttpStatusCode.NotFound, status { attachments.download(carol.accountId, a.id) })
        assertEquals(HttpStatusCode.NotFound, status { attachments.download(carol.accountId, UUID.randomUUID()) })
    }

    @Test fun `upload requires membership`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        assertEquals(HttpStatusCode.NotFound, assertFailsWith<ApiException> { upload(carol.accountId, conv, TestMedia.png(), "image/png") }.status)
        assertEquals(0, storage.files.size)
    }

    @Test fun `member removed from a group loses access to its files`() = runTest {
        val g = messages.createGroup(alice.accountId, "Grupa", listOf("bobby", "carol")).conversation.id
        val a = upload(alice.accountId, g, TestMedia.pdf(), "application/pdf", "plan.pdf")
        messages.send(alice.accountId, g, "", null, listOf(a.id))
        assertNotNull(attachments.download(carol.accountId, a.id))
        messages.removeMember(alice.accountId, g, "carol")
        assertEquals(HttpStatusCode.NotFound, status { attachments.download(carol.accountId, a.id) })
        assertNotNull(attachments.download(bob.accountId, a.id))
    }

    // ---- usuwanie ----

    @Test fun `deleting a message removes its files and rows`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        val ids = (1..2).map { upload(alice.accountId, conv, TestMedia.png(), "image/png").id }
        val sent = messages.send(alice.accountId, conv, "", null, ids)
        assertEquals(2, storage.files.size)
        messages.delete(alice.accountId, sent.row.id)
        assertEquals(0, storage.files.size)
        assertEquals(0, store.allAttachments().size)
        assertEquals(HttpStatusCode.NotFound, status { attachments.download(bob.accountId, ids.first()) })
        assertTrue(messages.messages(bob.accountId, conv, null, null).items.single().attachments.isEmpty())
    }

    @Test fun `group admin deleting a message also removes the files`() = runTest {
        val g = messages.createGroup(alice.accountId, "Grupa", listOf("bobby")).conversation.id
        val a = upload(bob.accountId, g, TestMedia.mp4(), "audio/mp4")
        val sent = messages.send(bob.accountId, g, "", null, listOf(a.id))
        messages.delete(alice.accountId, sent.row.id) // właściciel grupy
        assertEquals(0, storage.files.size)
    }

    @Test fun `tombstoned rows are retried by the periodic cleanup`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        val a = upload(alice.accountId, conv, TestMedia.png(), "image/png")
        val sent = messages.send(alice.accountId, conv, "", null, listOf(a.id))
        // Symulacja: wiadomość usunięta w bazie, ale serwis nie zdążył skasować pliku (np. awaria procesu).
        store.deleteMessage(sent.row.id, clock.instant())
        assertEquals(1, storage.files.size)
        assertEquals(1, attachments.purgeAbandoned())
        assertEquals(0, storage.files.size)
        assertEquals(0, store.allAttachments().size)
    }

    @Test fun `abandoned uploads expire and sent ones are kept`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        val kept = upload(alice.accountId, conv, TestMedia.png(), "image/png")
        messages.send(alice.accountId, conv, "", null, listOf(kept.id))
        upload(alice.accountId, conv, TestMedia.png(), "image/png")
        assertEquals(0, attachments.purgeAbandoned()) // świeże
        clock.t = clock.t.plus(Duration.ofHours(25))
        assertEquals(1, attachments.purgeAbandoned())
        assertEquals(1, storage.files.size)
        assertNotNull(attachments.download(bob.accountId, kept.id))
    }

    @Test fun `owner can withdraw a pending upload but not a sent one`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        val p = upload(alice.accountId, conv, TestMedia.png(), "image/png")
        assertEquals(HttpStatusCode.NotFound, status { attachments.deletePending(bob.accountId, p.id) })
        attachments.deletePending(alice.accountId, p.id)
        assertEquals(0, storage.files.size); assertEquals(0, store.allAttachments().size)
        val s = upload(alice.accountId, conv, TestMedia.png(), "image/png")
        messages.send(alice.accountId, conv, "", null, listOf(s.id))
        assertEquals(HttpStatusCode.NotFound, status { attachments.deletePending(alice.accountId, s.id) })
        assertEquals(1, storage.files.size)
    }

    @Test fun `too many pending uploads are refused`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        repeat(MessageAttachmentService.MAX_PENDING) { upload(alice.accountId, conv, TestMedia.png(8, 8), "image/png") }
        assertEquals(HttpStatusCode.TooManyRequests, assertFailsWith<ApiException> { upload(alice.accountId, conv, TestMedia.png(8, 8), "image/png") }.status)
    }

    @Test fun `upload rate limit is enforced per account`() = runTest {
        val limited = MessageAttachmentService(store, storage, UploadRateLimiter(perMinute = 2, perHour = 100, clock = Clock.fixed(Instant.parse("2026-11-25T12:00:00Z"), ZoneOffset.UTC)), clock)
        val conv = direct(alice.accountId, "bobby")
        repeat(2) { limited.upload(alice.accountId, conv, TestMedia.png(8, 8), "image/png", null) }
        val e = assertFailsWith<ApiException> { limited.upload(alice.accountId, conv, TestMedia.png(8, 8), "image/png", null) }
        assertEquals(HttpStatusCode.TooManyRequests, e.status)
        assertEquals("upload_rate_limited", e.code)
        limited.upload(bob.accountId, conv, TestMedia.png(8, 8), "image/png", null) // inne konto
    }

    // ---- edycja podpisu ----

    @Test fun `caption of a photo message may be cleared but a plain message may not`() = runTest {
        val conv = direct(alice.accountId, "bobby")
        val a = upload(alice.accountId, conv, TestMedia.png(), "image/png")
        val withPhoto = messages.send(alice.accountId, conv, "podpis", null, listOf(a.id))
        assertEquals("", messages.edit(alice.accountId, withPhoto.row.id, "  ").row.body)
        val plain = messages.send(alice.accountId, conv, "tekst", null)
        assertEquals(HttpStatusCode.BadRequest, assertFailsWith<ApiException> { messages.edit(alice.accountId, plain.row.id, " ") }.status)
    }

    // ---- WSS ----

    @Test fun `media messages produce ordinary events that carry no file data`() = runTest {
        val log = mutableListOf<Pair<Set<UUID>, RealtimeEvent>>()
        val rec = object : MessageEvents {
            override suspend fun publish(recipients: Collection<UUID>, event: RealtimeEvent) { log += recipients.toSet() to event }
        }
        val service = MessageService(store, graph, clock, rec, storage)
        val conv = direct(alice.accountId, "bobby")
        val doc = upload(alice.accountId, conv, TestMedia.pdf(), "application/pdf", "tajny-raport.pdf")
        val sent = service.send(alice.accountId, conv, "", null, listOf(doc.id))
        val created = log.single { it.second.type == "message.new" }
        assertEquals(setOf(alice.accountId, bob.accountId), created.first)
        val json = RealtimeEvents.encode(created.second)
        assertTrue(json.contains(sent.row.id.toString()))
        // Zdarzenie wskazuje wiadomość, a nie plik: ani nazwa, ani id załącznika, ani bajty nie przechodzą przez WSS.
        assertTrue(!json.contains("tajny-raport") && !json.contains(doc.id.toString()) && !json.contains("%PDF"), json)
        log.clear()
        service.delete(alice.accountId, sent.row.id)
        assertEquals(1, log.count { it.second.type == "message.deleted" })
    }
}
