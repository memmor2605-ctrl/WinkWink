package app.winkwink.server.feed

import app.winkwink.server.api.ApiException
import app.winkwink.server.community.CommunityService
import app.winkwink.server.community.InMemoryCommunityStore
import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.profile.ProfileService
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.test.runTest
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import java.util.UUID
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

/** Publikowanie w kanałach społeczności: widoczność "community", uprawnienia i usuwanie przez moderatorów. */
class CommunityPostsTest {
    private val graph = InMemoryProfileStore()
    private val clock = object : Clock() {
        var t: Instant = Instant.parse("2026-11-21T12:00:00Z")
        override fun getZone() = ZoneOffset.UTC
        override fun withZone(zone: java.time.ZoneId?) = this
        override fun instant(): Instant { t = t.plusSeconds(1); return t }
    }
    private val communityStore = InMemoryCommunityStore(graph)
    private val communities = CommunityService(communityStore, graph, clock)
    private val feed = FeedService(InMemoryFeedStore(graph, communityStore), ProfileService(graph, clock), clock)

    private val owner = graph.seed("owner")
    private val mod = graph.seed("moda")
    private val member = graph.seed("maria")
    private val other = graph.seed("marek")
    private val outsider = graph.seed("olek")

    private suspend fun assertApi(status: HttpStatusCode, code: String, block: suspend () -> Unit) {
        val e = assertFailsWith<ApiException> { block() }
        assertEquals(status, e.status); assertEquals(code, e.code)
    }

    private class Setup(val communityId: UUID, val general: UUID, val offtopic: UUID)

    private suspend fun setup(): Setup {
        val cid = communities.create(owner.accountId, "Rowery", "", "", "public").community.id
        communities.join(mod.accountId, cid); communities.join(member.accountId, cid); communities.join(other.accountId, cid)
        communities.setRole(owner.accountId, cid, mod.nickname, "moderator")
        val general = communities.channels(owner.accountId, cid).first().id
        val offtopic = communities.createChannel(owner.accountId, cid, "offtopic").id
        return Setup(cid, general, offtopic)
    }

    private suspend fun post(by: UUID, s: Setup, channel: UUID = s.general, body: String = "hej") =
        feed.create(by, body, "community", false, s.communityId.toString(), channel.toString())

    @Test fun `only members can post to a community`() = runTest {
        val s = setup()
        assertApi(HttpStatusCode.NotFound, "community_not_found") { post(outsider.accountId, s) }
        val p = post(member.accountId, s)
        assertEquals("community", p.visibility)
        assertEquals(s.communityId, p.communityId)
        assertEquals(s.general, p.channelId)
    }

    @Test fun `channel must belong to the community`() = runTest {
        val s = setup()
        val otherCommunity = communities.create(outsider.accountId, "Inne", "", "", "public").community.id
        val foreignChannel = communities.channels(outsider.accountId, otherCommunity).first().id
        assertApi(HttpStatusCode.NotFound, "channel_not_found") { post(member.accountId, s, channel = foreignChannel) }
        assertApi(HttpStatusCode.NotFound, "channel_not_found") { post(member.accountId, s, channel = UUID.randomUUID()) }
    }

    @Test fun `community post validation`() = runTest {
        val s = setup()
        val bad = HttpStatusCode.BadRequest
        assertApi(bad, "validation_failed") { feed.create(member.accountId, "x", "community", false) }
        assertApi(bad, "validation_failed") { feed.create(member.accountId, "x", "community", true, s.communityId.toString(), s.general.toString()) }
        assertApi(bad, "validation_failed") { feed.create(member.accountId, "x", "public", false, s.communityId.toString(), s.general.toString()) }
        assertApi(HttpStatusCode.NotFound, "community_not_found") { feed.create(member.accountId, "x", "community", false, "nie-uuid", s.general.toString()) }
    }

    @Test fun `non members cannot see or react to community posts`() = runTest {
        val s = setup()
        val p = post(member.accountId, s)
        assertEquals(p.id, feed.get(other.accountId, p.id).id)
        assertApi(HttpStatusCode.NotFound, "post_not_found") { feed.get(outsider.accountId, p.id) }
        assertApi(HttpStatusCode.NotFound, "post_not_found") { feed.react(outsider.accountId, p.id, "like") }
        assertApi(HttpStatusCode.NotFound, "post_not_found") { feed.addComment(outsider.accountId, p.id, null, "hej") }
        assertTrue(feed.discover(outsider.accountId, null, null).items.none { it.id == p.id })
        assertTrue(feed.search(outsider.accountId, "hej", null, null).items.isEmpty())
    }

    @Test fun `members can comment and react`() = runTest {
        val s = setup()
        val p = post(member.accountId, s)
        feed.react(other.accountId, p.id, "love")
        feed.addComment(other.accountId, p.id, null, "super")
        val reloaded = feed.get(member.accountId, p.id)
        assertEquals(1, reloaded.reactions); assertEquals(1, reloaded.comments)
    }

    @Test fun `community listing requires membership and filters by channel`() = runTest {
        val s = setup()
        val a = post(member.accountId, s, s.general, "w general")
        val b = post(other.accountId, s, s.offtopic, "w offtopic")
        assertApi(HttpStatusCode.NotFound, "community_not_found") { feed.communityPosts(outsider.accountId, s.communityId.toString(), null, null, null) }
        assertEquals(setOf(a.id, b.id), feed.communityPosts(member.accountId, s.communityId.toString(), null, null, null).items.map { it.id }.toSet())
        assertEquals(listOf(b.id), feed.communityPosts(member.accountId, s.communityId.toString(), s.offtopic.toString(), null, null).items.map { it.id })
        assertApi(HttpStatusCode.NotFound, "channel_not_found") { feed.communityPosts(member.accountId, s.communityId.toString(), UUID.randomUUID().toString(), null, null) }
    }

    @Test fun `community listing paginates`() = runTest {
        val s = setup()
        val ids = (1..5).map { post(member.accountId, s, body = "p$it").id }
        val first = feed.communityPosts(member.accountId, s.communityId.toString(), null, 2, null)
        assertEquals(ids.reversed().take(2), first.items.map { it.id })
        val second = feed.communityPosts(member.accountId, s.communityId.toString(), null, 2, first.nextCursor)
        assertEquals(ids.reversed().drop(2).take(2), second.items.map { it.id })
    }

    @Test fun `moderator may delete other members posts but a plain member may not`() = runTest {
        val s = setup()
        val p = post(member.accountId, s)
        assertApi(HttpStatusCode.Forbidden, "forbidden") { feed.delete(other.accountId, p.id) }
        feed.delete(mod.accountId, p.id)
        assertApi(HttpStatusCode.NotFound, "post_not_found") { feed.get(member.accountId, p.id) }
    }

    @Test fun `moderator of one community cannot delete posts of another`() = runTest {
        setup()
        val otherCid = communities.create(outsider.accountId, "Inne", "", "", "public").community.id
        communities.join(member.accountId, otherCid)
        val otherChannel = communities.channels(outsider.accountId, otherCid).first().id
        val p = feed.create(member.accountId, "x", "community", false, otherCid.toString(), otherChannel.toString())
        communities.join(mod.accountId, otherCid)
        assertApi(HttpStatusCode.Forbidden, "forbidden") { feed.delete(mod.accountId, p.id) }
    }

    @Test fun `public posts are not deletable by community moderators`() = runTest {
        setup()
        val p = feed.create(member.accountId, "publiczny", "public", false)
        assertApi(HttpStatusCode.Forbidden, "forbidden") { feed.delete(mod.accountId, p.id) }
    }

    @Test fun `leaving the community revokes access`() = runTest {
        val s = setup()
        val p = post(owner.accountId, s)
        assertEquals(p.id, feed.get(member.accountId, p.id).id)
        communities.leave(member.accountId, s.communityId)
        assertApi(HttpStatusCode.NotFound, "post_not_found") { feed.get(member.accountId, p.id) }
        assertApi(HttpStatusCode.NotFound, "community_not_found") { feed.communityPosts(member.accountId, s.communityId.toString(), null, null, null) }
    }

    @Test fun `author keeps access to own post after leaving`() = runTest {
        val s = setup()
        val p = post(member.accountId, s)
        communities.leave(member.accountId, s.communityId)
        assertEquals(p.id, feed.get(member.accountId, p.id).id)
    }

    @Test fun `deleting the community hides its posts from members`() = runTest {
        val s = setup()
        val p = post(member.accountId, s)
        communities.delete(owner.accountId, s.communityId)
        assertApi(HttpStatusCode.NotFound, "post_not_found") { feed.get(other.accountId, p.id) }
    }

    @Test fun `blocking hides community posts both ways`() = runTest {
        val s = setup()
        val p = post(member.accountId, s)
        graph.addBlock(other.accountId, member.accountId, clock.instant())
        assertApi(HttpStatusCode.NotFound, "post_not_found") { feed.get(other.accountId, p.id) }
        assertTrue(feed.communityPosts(other.accountId, s.communityId.toString(), null, null, null).items.none { it.id == p.id })
    }

    @Test fun `community posts are never anonymous in responses`() = runTest {
        val s = setup()
        val dto = post(member.accountId, s).toDto(other.accountId)
        assertEquals(false, dto.anonymous)
        assertEquals(s.communityId.toString(), dto.communityId)
    }
}
