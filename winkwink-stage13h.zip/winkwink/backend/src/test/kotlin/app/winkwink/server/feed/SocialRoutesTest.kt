package app.winkwink.server.feed

import app.winkwink.server.auth.TestAuth
import app.winkwink.server.auth.testAppConfig
import app.winkwink.server.health.DatabaseHealth
import app.winkwink.server.health.HealthProbe
import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.profile.ProfileService
import app.winkwink.server.winkwinkModule
import io.ktor.client.HttpClient
import io.ktor.client.request.header
import io.ktor.client.request.request
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.server.testing.ApplicationTestBuilder
import io.ktor.server.testing.testApplication
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

/** Testy HTTP całego stosu (routing, uwierzytelnianie JWT, serializacja) na magazynach w pamięci. */
class SocialRoutesTest {
    private val probe = HealthProbe { DatabaseHealth("up", 1, "5") }
    private val auth = TestAuth()
    private val graph = InMemoryProfileStore()
    private val profiles = ProfileService(graph)
    private val feed = FeedService(InMemoryFeedStore(graph), profiles)

    /** Rejestruje konto w serwisie auth i tworzy odpowiadający mu wpis w grafie profili. */
    private fun user(nick: String): String = runBlocking {
        val r = auth.service.register("$nick@example.com", "correct-horse-battery", nick, "android", null, null)
        graph.seed(nick, id = r.profile.accountId)
        r.session.accessToken
    }

    private fun run(block: suspend ApplicationTestBuilder.() -> Unit) = testApplication {
        application { winkwinkModule(testAppConfig(), probe, auth.service, profiles, feed) }
        block()
    }

    private suspend fun HttpClient.call(method: HttpMethod, path: String, token: String?, body: String? = null): HttpResponse =
        request("/api/v1$path") {
            this.method = method
            header("X-Forwarded-Proto", "https")
            token?.let { header(HttpHeaders.Authorization, "Bearer $it") }
            if (body != null) { header(HttpHeaders.ContentType, ContentType.Application.Json.toString()); setBody(body) }
        }

    private fun str(body: String, vararg path: String): String {
        var el = Json.parseToJsonElement(body)
        for (p in path.dropLast(1)) el = el.jsonObject.getValue(p)
        return el.jsonObject.getValue(path.last()).jsonPrimitive.content
    }

    @Test fun `all social routes reject anonymous callers`() = run {
        for ((m, p) in listOf(
            HttpMethod.Get to "/users/bob", HttpMethod.Get to "/users/search?q=bo", HttpMethod.Post to "/users/bob/follow",
            HttpMethod.Get to "/feed/discover", HttpMethod.Get to "/feed/following", HttpMethod.Post to "/posts",
            HttpMethod.Get to "/posts/search?q=abc", HttpMethod.Get to "/me/saved", HttpMethod.Get to "/me/blocks",
        )) assertEquals(HttpStatusCode.Unauthorized, client.call(m, p, null).status, "$m $p")
    }

    @Test fun `follow and profile over http`() = run {
        val a = user("alice"); user("bob")
        val f = client.call(HttpMethod.Post, "/users/bob/follow", a)
        assertEquals(HttpStatusCode.OK, f.status); assertEquals("accepted", str(f.bodyAsText(), "state"))
        val p = client.call(HttpMethod.Get, "/users/bob", a).bodyAsText()
        assertEquals("1", str(p, "followers")); assertEquals("accepted", str(p, "followState"))
        assertEquals(HttpStatusCode.NotFound, client.call(HttpMethod.Get, "/users/nobody", a).status)
        assertEquals(HttpStatusCode.BadRequest, client.call(HttpMethod.Post, "/users/alice/follow", a).status)
    }

    @Test fun `bio can be set and cleared over http`() = run {
        val a = user("alice")
        val set = client.call(HttpMethod.Patch, "/me/profile", a, """{"bio":"hello","links":["https://a.example"]}""")
        assertEquals(HttpStatusCode.OK, set.status); assertEquals("hello", str(set.bodyAsText(), "bio"))
        val cleared = client.call(HttpMethod.Patch, "/me/profile", a, """{"bio":""}""").bodyAsText()
        assertEquals("null", str(cleared, "bio"))
        assertEquals(HttpStatusCode.BadRequest, client.call(HttpMethod.Patch, "/me/profile", a, """{"links":["http://x.example"]}""").status)
    }

    @Test fun `anonymous post never reveals its author over http`() = run {
        val a = user("alice"); val b = user("bob")
        val created = client.call(HttpMethod.Post, "/posts", a, """{"body":"my secret","visibility":"public","anonymous":true}""")
        assertEquals(HttpStatusCode.Created, created.status)
        val body = created.bodyAsText()
        assertEquals("null", str(body, "author")); assertEquals("true", str(body, "mine"))
        assertFalse(body.contains("alice", ignoreCase = true))
        val id = str(body, "id")
        val seen = client.call(HttpMethod.Get, "/posts/$id", b).bodyAsText()
        assertFalse(seen.contains("alice", ignoreCase = true)); assertEquals("false", str(seen, "mine"))
        val discover = client.call(HttpMethod.Get, "/feed/discover", b).bodyAsText()
        assertTrue(discover.contains(id)); assertFalse(discover.contains("alice", ignoreCase = true))
    }

    @Test fun `routing keeps search separate from post id and bad ids are 404`() = run {
        val a = user("alice")
        assertEquals(HttpStatusCode.OK, client.call(HttpMethod.Get, "/posts/search?q=abc", a).status)
        val bad = client.call(HttpMethod.Get, "/posts/not-a-uuid", a)
        assertEquals(HttpStatusCode.NotFound, bad.status); assertTrue(bad.bodyAsText().contains("post_not_found"))
        assertEquals(HttpStatusCode.BadRequest, client.call(HttpMethod.Get, "/posts/search?q=ab", a).status)
        assertEquals(HttpStatusCode.BadRequest, client.call(HttpMethod.Get, "/feed/discover?limit=abc", a).status)
    }

    @Test fun `comment flow over http`() = run {
        val a = user("alice"); val b = user("bob")
        val post = str(client.call(HttpMethod.Post, "/posts", a, """{"body":"hello"}""").bodyAsText(), "id")
        val c = client.call(HttpMethod.Post, "/posts/$post/comments", b, """{"body":"nice"}""")
        assertEquals(HttpStatusCode.Created, c.status)
        val cid = str(c.bodyAsText(), "id")
        assertEquals(HttpStatusCode.Created, client.call(HttpMethod.Post, "/posts/$post/comments", a, """{"body":"thanks","parentId":"$cid"}""").status)
        assertTrue(client.call(HttpMethod.Get, "/posts/$post/comments/$cid/replies", b).bodyAsText().contains("thanks"))
        assertEquals(HttpStatusCode.NoContent, client.call(HttpMethod.Delete, "/comments/$cid", a).status)
        assertEquals("0", str(client.call(HttpMethod.Get, "/posts/$post", a).bodyAsText(), "comments"))
    }
}
