package app.winkwink.server.community

import app.winkwink.server.api.ApiException
import app.winkwink.server.profile.InMemoryProfileStore
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.runBlocking
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import java.util.UUID
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

class CommunityServiceTest {
    private val profiles = InMemoryProfileStore()
    private val store = InMemoryCommunityStore(profiles)
    private val service = CommunityService(store, profiles, Clock.fixed(Instant.parse("2026-11-21T12:00:00Z"), ZoneOffset.UTC))

    private val owner = profiles.seed("owner")
    private val admin = profiles.seed("adam")
    private val mod = profiles.seed("moda")
    private val member = profiles.seed("maria")
    private val outsider = profiles.seed("olek")

    private fun <T> run(block: suspend () -> T): T = runBlocking { block() }
    private fun fails(status: HttpStatusCode, code: String? = null, block: suspend () -> Unit) {
        val e = assertFailsWith<ApiException> { runBlocking { block() } }
        assertEquals(status, e.status)
        if (code != null) assertEquals(code, e.code)
    }

    /** Społeczność z wszystkimi rolami: owner, admin, mod, member. */
    private fun populated(type: String = "public"): UUID {
        val id = run { service.create(owner.accountId, "Kotlin Fans", "", "", type) }.community.id
        run {
            store.addMember(id, admin.accountId, "admin", Instant.EPOCH)
            store.addMember(id, mod.accountId, "moderator", Instant.EPOCH)
            store.addMember(id, member.accountId, "member", Instant.EPOCH)
        }
        return id
    }

    @Test fun createMakesCallerOwnerWithDefaultChannel() {
        val v = run { service.create(owner.accountId, "  Rowery  ", "Opis", "Zasady", "private") }
        assertEquals("Rowery", v.community.name); assertEquals("owner", v.myRole); assertEquals("member", v.myStatus); assertEquals(1, v.community.memberCount)
        assertEquals(listOf("general"), run { service.channels(owner.accountId, v.community.id) }.map { it.name })
    }

    @Test fun createValidatesInput() {
        fails(HttpStatusCode.BadRequest) { service.create(owner.accountId, "ab", "", "", "public") }
        fails(HttpStatusCode.BadRequest) { service.create(owner.accountId, "Dobra nazwa", "", "", "secret") }
        fails(HttpStatusCode.BadRequest) { service.create(owner.accountId, "Dobra nazwa", "x".repeat(501), "", "public") }
        fails(HttpStatusCode.BadRequest) { service.create(owner.accountId, "Dobra nazwa", "", "x".repeat(2001), "public") }
    }

    @Test fun duplicateNameIsConflictCaseInsensitive() {
        run { service.create(owner.accountId, "Rowery", "", "", "public") }
        fails(HttpStatusCode.Conflict, "community_name_taken") { service.create(admin.accountId, "rowery", "", "", "public") }
    }

    @Test fun publicJoinIsImmediateAndDuplicateRejected() {
        val id = populated()
        assertEquals("member", run { service.join(outsider.accountId, id) })
        assertEquals("member", run { service.view(outsider.accountId, id) }.myRole)
        fails(HttpStatusCode.Conflict, "already_member") { service.join(outsider.accountId, id) }
    }

    @Test fun privateJoinRequiresApprovalByModerator() {
        val id = populated("private")
        assertEquals("requested", run { service.join(outsider.accountId, id) })
        assertEquals("requested", run { service.view(outsider.accountId, id) }.myStatus)
        fails(HttpStatusCode.Conflict, "already_requested") { service.join(outsider.accountId, id) }
        fails(HttpStatusCode.Forbidden) { service.requests(member.accountId, id, null, null) }
        assertEquals(1, run { service.requests(mod.accountId, id, null, null) }.items.size)
        run { service.decideRequest(mod.accountId, id, "olek", approve = true) }
        assertEquals("member", run { service.view(outsider.accountId, id) }.myRole)
        assertTrue(run { service.requests(mod.accountId, id, null, null) }.items.isEmpty())
    }

    @Test fun rejectedRequestDoesNotAddMember() {
        val id = populated("private")
        run { service.join(outsider.accountId, id) }
        run { service.decideRequest(owner.accountId, id, "olek", approve = false) }
        assertNull(run { service.view(outsider.accountId, id) }.myRole)
    }

    @Test fun inviteOnlyCommunityIsInvisibleWithoutInvitation() {
        val id = populated("invite")
        fails(HttpStatusCode.NotFound, "community_not_found") { service.view(outsider.accountId, id) }
        fails(HttpStatusCode.NotFound, "community_not_found") { service.join(outsider.accountId, id) }
        fails(HttpStatusCode.NotFound, "community_not_found") { service.channels(outsider.accountId, id) }
        assertTrue(run { service.search(outsider.accountId, "Kotlin", null, null) }.items.isEmpty())
        assertEquals(1, run { service.search(member.accountId, "Kotlin", null, null) }.items.size)
    }

    @Test fun invitationLetsUserSeeAndAccept() {
        val id = populated("invite")
        run { service.invite(mod.accountId, id, "olek") }
        run { service.invite(mod.accountId, id, "olek") } // idempotentnie
        assertEquals("invited", run { service.view(outsider.accountId, id) }.myStatus)
        assertEquals(1, run { service.myInvites(outsider.accountId, null, null) }.items.size)
        run { service.respondToInvite(outsider.accountId, id, accept = true) }
        assertEquals("member", run { service.view(outsider.accountId, id) }.myRole)
        assertTrue(run { service.myInvites(outsider.accountId, null, null) }.items.isEmpty())
    }

    @Test fun declinedInvitationLeavesCommunityHidden() {
        val id = populated("invite")
        run { service.invite(owner.accountId, id, "olek") }
        run { service.respondToInvite(outsider.accountId, id, accept = false) }
        fails(HttpStatusCode.NotFound) { service.view(outsider.accountId, id) }
        fails(HttpStatusCode.NotFound, "invitation_not_found") { service.respondToInvite(outsider.accountId, id, true) }
    }

    @Test fun plainMemberCannotInviteAndMemberCannotBeInvited() {
        val id = populated()
        fails(HttpStatusCode.Forbidden) { service.invite(member.accountId, id, "olek") }
        fails(HttpStatusCode.Conflict, "already_member") { service.invite(mod.accountId, id, "maria") }
    }

    @Test fun blockedUserCannotBeInvited() {
        val id = populated()
        run { profiles.addBlock(outsider.accountId, mod.accountId, Instant.EPOCH) }
        fails(HttpStatusCode.NotFound, "user_not_found") { service.invite(mod.accountId, id, "olek") }
    }

    @Test fun ownerCannotLeaveButMemberCan() {
        val id = populated()
        fails(HttpStatusCode.Conflict, "owner_cannot_leave") { service.leave(owner.accountId, id) }
        run { service.leave(member.accountId, id) }
        assertNull(run { service.view(member.accountId, id) }.myRole)
        fails(HttpStatusCode.NotFound, "not_member") { service.leave(member.accountId, id) }
    }

    @Test fun onlyOwnerAssignsRolesAndNotOwnerRole() {
        val id = populated()
        fails(HttpStatusCode.Forbidden) { service.setRole(admin.accountId, id, "maria", "moderator") }
        run { service.setRole(owner.accountId, id, "maria", "moderator") }
        assertEquals("moderator", run { service.view(member.accountId, id) }.myRole)
        fails(HttpStatusCode.BadRequest) { service.setRole(owner.accountId, id, "maria", "owner") }
        fails(HttpStatusCode.BadRequest) { service.setRole(owner.accountId, id, "owner", "admin") }
        fails(HttpStatusCode.NotFound, "not_member") { service.setRole(owner.accountId, id, "olek", "admin") }
    }

    @Test fun removalRequiresHigherRank() {
        val id = populated()
        fails(HttpStatusCode.Forbidden) { service.removeMember(member.accountId, id, "moda") }
        fails(HttpStatusCode.Forbidden) { service.removeMember(mod.accountId, id, "adam") }
        fails(HttpStatusCode.Forbidden) { service.removeMember(admin.accountId, id, "owner") }
        fails(HttpStatusCode.BadRequest) { service.removeMember(mod.accountId, id, "moda") } // własne członkostwo: użyj leave
        run { service.removeMember(mod.accountId, id, "maria") }
        assertNull(run { service.view(member.accountId, id) }.myRole)
        run { service.removeMember(owner.accountId, id, "adam") }
        assertNull(run { service.view(admin.accountId, id) }.myRole)
    }

    @Test fun updateRulesAndTypePermissions() {
        val id = populated()
        fails(HttpStatusCode.Forbidden) { service.update(mod.accountId, id, null, "x", null, null) }
        val v = run { service.update(admin.accountId, id, null, "Nowy opis", "Zasada 1", null) }
        assertEquals("Nowy opis", v.community.description); assertEquals("Zasada 1", v.community.rules); assertEquals("Kotlin Fans", v.community.name)
        fails(HttpStatusCode.Forbidden) { service.update(admin.accountId, id, null, null, null, "private") }
        assertEquals("private", run { service.update(owner.accountId, id, null, null, null, "private") }.community.type)
    }

    @Test fun renameToExistingNameIsRejectedButSameNameAllowed() {
        val id = populated()
        run { service.create(outsider.accountId, "Inna", "", "", "public") }
        fails(HttpStatusCode.Conflict, "community_name_taken") { service.update(owner.accountId, id, "inna", null, null, null) }
        assertEquals("kotlin fans", run { service.update(owner.accountId, id, "kotlin fans", null, null, null) }.community.name)
    }

    @Test fun onlyOwnerCanDeleteAndDeletedIsGone() {
        val id = populated()
        fails(HttpStatusCode.Forbidden) { service.delete(admin.accountId, id) }
        run { service.delete(owner.accountId, id) }
        fails(HttpStatusCode.NotFound) { service.view(owner.accountId, id) }
        assertTrue(run { service.mine(owner.accountId, null, null) }.items.isEmpty())
    }

    @Test fun membersListHiddenFromOutsidersOfNonPublic() {
        val pub = populated()
        assertEquals(4, run { service.members(outsider.accountId, pub, null, null) }.items.size)
        val priv = run { service.create(owner.accountId, "Prywatna", "", "", "private") }.community.id
        fails(HttpStatusCode.Forbidden) { service.members(outsider.accountId, priv, null, null) }
    }

    @Test fun membersPaginateWithCursor() {
        val id = populated()
        val p1 = run { service.members(owner.accountId, id, 2, null) }
        assertEquals(2, p1.items.size); assertTrue(p1.nextCursor != null)
        val p2 = run { service.members(owner.accountId, id, 2, p1.nextCursor) }
        assertEquals(2, p2.items.size)
        assertTrue((p1.items + p2.items).map { it.accountId }.toSet().size == 4)
    }

    @Test fun searchMatchesSubstringAndRequiresTwoChars() {
        populated()
        assertEquals(1, run { service.search(outsider.accountId, "kotl", null, null) }.items.size)
        fails(HttpStatusCode.BadRequest) { service.search(outsider.accountId, "k", null, null) }
        assertFalse(run { service.search(outsider.accountId, "zzz", null, null) }.items.isNotEmpty())
    }

    @Test fun channelRulesAdminOnlyUniqueAndKeepOne() {
        val id = populated()
        fails(HttpStatusCode.Forbidden) { service.createChannel(mod.accountId, id, "offtopic") }
        val ch = run { service.createChannel(admin.accountId, id, "Off-topic") }
        fails(HttpStatusCode.Conflict, "channel_name_taken") { service.createChannel(admin.accountId, id, "off-TOPIC") }
        fails(HttpStatusCode.BadRequest) { service.createChannel(admin.accountId, id, "x") }
        run { service.deleteChannel(admin.accountId, id, ch.id) }
        val last = run { service.channels(owner.accountId, id) }.single()
        fails(HttpStatusCode.Conflict, "last_channel") { service.deleteChannel(owner.accountId, id, last.id) }
        fails(HttpStatusCode.NotFound, "channel_not_found") { service.deleteChannel(owner.accountId, id, UUID.randomUUID()) }
    }

    @Test fun invalidIdIsNotFound() {
        fails(HttpStatusCode.NotFound) { CommunityService.communityId("nope").let { } }
    }
}
