package app.winkwink.server

import app.winkwink.server.auth.TestAuth
import app.winkwink.server.auth.testAppConfig
import app.winkwink.server.health.DatabaseHealth
import app.winkwink.server.health.HealthProbe
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpStatusCode
import io.ktor.server.testing.testApplication
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class HealthRoutesTest {
    private val config = testAppConfig()
    private val auth = TestAuth().service

    private fun probe(result: DatabaseHealth) = HealthProbe { result }

    @Test
    fun `health is ok when database is up`() = testApplication {
        application { winkwinkModule(config, auth = auth, health = probe(DatabaseHealth("up", 3, "2"))) }
        val response = client.get("/api/v1/health") { header("X-Forwarded-Proto", "https") }
        assertEquals(HttpStatusCode.OK, response.status)
        assertTrue(response.bodyAsText().contains("\"status\":\"ok\""))
    }

    @Test
    fun `health is 503 when database is down`() = testApplication {
        application { winkwinkModule(config, auth = auth, health = probe(DatabaseHealth("down"))) }
        val response = client.get("/api/v1/health") { header("X-Forwarded-Proto", "https") }
        assertEquals(HttpStatusCode.ServiceUnavailable, response.status)
        assertTrue(response.bodyAsText().contains("\"status\":\"degraded\""))
    }

    @Test
    fun `plain http is rejected`() = testApplication {
        application { winkwinkModule(config, auth = auth, health = probe(DatabaseHealth("up", 1, "2"))) }
        val response = client.get("/api/v1/health")
        assertEquals(HttpStatusCode.Forbidden, response.status)
        assertTrue(response.bodyAsText().contains("https_required"))
    }

    @Test
    fun `unknown route returns json 404`() = testApplication {
        application { winkwinkModule(config, auth = auth, health = probe(DatabaseHealth("up", 1, "2"))) }
        val response = client.get("/api/v1/nope") { header("X-Forwarded-Proto", "https") }
        assertEquals(HttpStatusCode.NotFound, response.status)
        assertTrue(response.bodyAsText().contains("not_found"))
    }
}
