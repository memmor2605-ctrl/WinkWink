package app.winkwink.server.auth

import app.winkwink.server.winkwinkModule
import app.winkwink.server.health.DatabaseHealth
import app.winkwink.server.health.HealthProbe
import io.ktor.client.HttpClient
import io.ktor.client.request.delete
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.server.testing.ApplicationTestBuilder
import io.ktor.server.testing.testApplication
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class AuthRoutesTest {
    private val probe = HealthProbe { DatabaseHealth("up", 1, "3") }

    private fun setup(t: TestAuth, block: suspend ApplicationTestBuilder.() -> Unit) = testApplication {
        application { winkwinkModule(testAppConfig(), probe, t.service) }
        block()
    }

    private suspend fun HttpClient.json(path: String, body: String, token: String? = null): HttpResponse =
        post("/api/v1$path") {
            header("X-Forwarded-Proto", "https")
            header(HttpHeaders.ContentType, ContentType.Application.Json.toString())
            token?.let { header(HttpHeaders.Authorization, "Bearer $it") }
            setBody(body)
        }

    private suspend fun HttpClient.getAuth(path: String, token: String?): HttpResponse = get("/api/v1$path") {
        header("X-Forwarded-Proto", "https")
        token?.let { header(HttpHeaders.Authorization, "Bearer $it") }
    }

    private fun field(body: String, vararg path: String): String {
        var el = Json.parseToJsonElement(body)
        for (p in path.dropLast(1)) el = el.jsonObject.getValue(p)
        return el.jsonObject.getValue(path.last()).jsonPrimitive.content
    }

    private val registerBody =
        """{"email":"ala@example.com","password":"correct-horse-battery","nickname":"ala","deviceName":"Pixel"}"""

    @Test
    fun `protected endpoints reject anonymous and garbage tokens`() = setup(TestAuth()) {
        assertEquals(HttpStatusCode.Unauthorized, client.getAuth("/me", null).status)
        assertEquals(HttpStatusCode.Unauthorized, client.getAuth("/me", "not.a.jwt").status)
        assertEquals(HttpStatusCode.Unauthorized, client.getAuth("/me/sessions", null).status)
        assertTrue(client.getAuth("/me", null).bodyAsText().contains("unauthorized"))
    }

    @Test
    fun `register then me then logout invalidates token immediately`() = setup(TestAuth()) {
        val reg = client.json("/auth/register", registerBody)
        assertEquals(HttpStatusCode.Created, reg.status)
        val body = reg.bodyAsText()
        val access = field(body, "tokens", "accessToken")
        assertFalse(body.contains("password"))

        val me = client.getAuth("/me", access)
        assertEquals(HttpStatusCode.OK, me.status)
        assertEquals("ala", field(me.bodyAsText(), "profile", "nickname"))

        assertEquals(HttpStatusCode.NoContent, client.json("/auth/logout", "{}", access).status)
        assertEquals(HttpStatusCode.Unauthorized, client.getAuth("/me", access).status)
    }

    @Test
    fun `login refresh flow and session listing`() = setup(TestAuth()) {
        client.json("/auth/register", registerBody)
        val login = client.json("/auth/login", """{"email":"ala@example.com","password":"correct-horse-battery"}""")
        assertEquals(HttpStatusCode.OK, login.status)
        val refresh = field(login.bodyAsText(), "tokens", "refreshToken")
        val access = field(login.bodyAsText(), "tokens", "accessToken")

        val sessions = client.getAuth("/me/sessions", access).bodyAsText()
        assertTrue(sessions.contains("\"current\":true"))

        val rotated = client.json("/auth/refresh", """{"refreshToken":"$refresh"}""")
        assertEquals(HttpStatusCode.OK, rotated.status)
        assertEquals(HttpStatusCode.Unauthorized, client.json("/auth/refresh", """{"refreshToken":"$refresh"}""").status)
    }

    @Test
    fun `wrong password gives 401 and lockout gives 429 with Retry-After`() = setup(TestAuth()) {
        client.json("/auth/register", registerBody)
        val bad = """{"email":"ala@example.com","password":"wrong-password-1"}"""
        repeat(5) { assertEquals(HttpStatusCode.Unauthorized, client.json("/auth/login", bad).status) }
        val locked = client.json("/auth/login", """{"email":"ala@example.com","password":"correct-horse-battery"}""")
        assertEquals(HttpStatusCode.TooManyRequests, locked.status)
        assertEquals("900", locked.headers[HttpHeaders.RetryAfter])
    }

    @Test
    fun `validation errors are 422 and malformed bodies are 400`() = setup(TestAuth()) {
        val invalid = client.json("/auth/register", """{"email":"x","password":"y","nickname":"z"}""")
        assertEquals(HttpStatusCode.UnprocessableEntity, invalid.status)
        assertTrue(invalid.bodyAsText().contains("validation_failed"))
        assertEquals(HttpStatusCode.BadRequest, client.json("/auth/register", "{not json").status)
        assertEquals(HttpStatusCode.BadRequest, client.json("/auth/register", """{"email":"a@b.co","password":"long-enough-1","nickname":"abc","admin":true}""").status)
    }

    @Test
    fun `non https requests never reach auth`() = setup(TestAuth()) {
        val r = client.post("/api/v1/auth/login") {
            header(HttpHeaders.ContentType, ContentType.Application.Json.toString())
            setBody("""{"email":"a@b.co","password":"x"}""")
        }
        assertEquals(HttpStatusCode.Forbidden, r.status)
    }

    @Test
    fun `password reset endpoint reports unavailable mail with 503`() = setup(TestAuth(email = CapturingEmailSender(isConfigured = false))) {
        assertEquals(HttpStatusCode.ServiceUnavailable, client.json("/auth/password/forgot", """{"email":"ala@example.com"}""").status)
    }

    @Test
    fun `revoking a foreign or malformed session id is rejected`() = setup(TestAuth()) {
        val access = field(client.json("/auth/register", registerBody).bodyAsText(), "tokens", "accessToken")
        val r1 = client.delete("/api/v1/me/sessions/not-a-uuid") {
            header("X-Forwarded-Proto", "https"); header(HttpHeaders.Authorization, "Bearer $access")
        }
        assertEquals(HttpStatusCode.BadRequest, r1.status)
        val r2 = client.delete("/api/v1/me/sessions/00000000-0000-0000-0000-000000000000") {
            header("X-Forwarded-Proto", "https"); header(HttpHeaders.Authorization, "Bearer $access")
        }
        assertEquals(HttpStatusCode.NotFound, r2.status)
    }
}
