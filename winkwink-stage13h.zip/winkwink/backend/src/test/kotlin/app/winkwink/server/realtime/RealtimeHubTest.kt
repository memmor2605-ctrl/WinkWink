package app.winkwink.server.realtime

import kotlinx.coroutines.channels.ClosedReceiveChannelException
import kotlinx.coroutines.runBlocking
import java.util.UUID
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class RealtimeHubTest {
    private val a = UUID.randomUUID()
    private val b = UUID.randomUUID()

    @Test fun `publish reaches every connection of the addressed accounts only`() = runBlocking {
        val hub = RealtimeHub()
        val a1 = hub.connect(a, UUID.randomUUID()); val a2 = hub.connect(a, UUID.randomUUID()); val b1 = hub.connect(b, UUID.randomUUID())
        hub.publish(listOf(a, a), "x") // duplikat konta nie dubluje zdarzenia
        assertEquals("x", a1.outbox.tryReceive().getOrNull()); assertEquals("x", a2.outbox.tryReceive().getOrNull())
        assertEquals(null, a1.outbox.tryReceive().getOrNull())
        assertEquals(null, b1.outbox.tryReceive().getOrNull())
    }

    @Test fun `disconnect removes the connection and closes its outbox`() = runBlocking {
        val hub = RealtimeHub()
        val c = hub.connect(a, UUID.randomUUID())
        hub.disconnect(c)
        assertEquals(0, hub.connectionCount(a))
        assertTrue(c.outbox.isClosedForSend)
        hub.publish(listOf(a), "ignored") // brak odbiorców — bez błędu
    }

    @Test fun `the oldest connection is evicted beyond the per account limit`() = runBlocking {
        val hub = RealtimeHub(maxPerAccount = 2)
        val first = hub.connect(a, UUID.randomUUID()); hub.connect(a, UUID.randomUUID()); hub.connect(a, UUID.randomUUID())
        assertEquals(2, hub.connectionCount(a))
        assertTrue(first.outbox.isClosedForSend)
    }

    @Test fun `slow client drops oldest events instead of blocking`() = runBlocking {
        val hub = RealtimeHub()
        val c = hub.connect(a, UUID.randomUUID())
        repeat(200) { hub.publish(listOf(a), "e$it") }
        var count = 0
        while (c.outbox.tryReceive().getOrNull() != null) count++
        assertEquals(64, count)
    }

    @Test fun `disconnecting a session closes only that session`() = runBlocking {
        val hub = RealtimeHub()
        val s1 = UUID.randomUUID()
        val c1 = hub.connect(a, s1); val c2 = hub.connect(a, UUID.randomUUID())
        hub.disconnectSession(s1)
        assertTrue(c1.outbox.isClosedForSend); assertTrue(!c2.outbox.isClosedForSend)
    }

    @Test fun `events are encoded without nulls and without content`() {
        val json = RealtimeEvents.encode(RealtimeEvent("message.new", "c1", "m1"))
        assertEquals("""{"type":"message.new","conversationId":"c1","messageId":"m1"}""", json)
        assertFailsWith<ClosedReceiveChannelException> { runBlocking { RealtimeHub().connect(a, b).also { it.outbox.close() }.outbox.receive() } }
    }
}
