package app.winkwink.server.database

import app.winkwink.server.auth.PostgresAuthStore
import app.winkwink.server.feed.PostgresFeedStore
import app.winkwink.server.message.AttachmentsUnavailableException
import app.winkwink.server.message.MessageAttachmentRow
import app.winkwink.server.message.PostgresMessageStore
import app.winkwink.server.notification.NotificationEvent
import app.winkwink.server.notification.NotificationTypes
import app.winkwink.server.notification.PostgresNotificationStore
import app.winkwink.server.profile.PageCursor
import app.winkwink.server.profile.PostgresProfileStore
import kotlinx.coroutines.runBlocking
import org.flywaydb.core.Flyway
import org.junit.jupiter.api.Assumptions.assumeTrue
import org.postgresql.ds.PGSimpleDataSource
import java.sql.SQLException
import java.time.Instant
import java.util.UUID
import javax.sql.DataSource
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * Testy na PRAWDZIWYM PostgreSQL (migracje V1–V15 + zapytania magazynów).
 *
 * Uruchamiane tylko, gdy ustawiono WINKWINK_TEST_DATABASE_URL (np. jdbc:postgresql://localhost:5432/winkwink_test);
 * opcjonalnie WINKWINK_TEST_DATABASE_USER / WINKWINK_TEST_DATABASE_PASSWORD. Bez zmiennej testy są POMINIĘTE
 * (raportowane jako „skipped”, nie „passed”). UWAGA: każdy test czyści schemat (flyway clean) — używaj wyłącznie
 * osobnej bazy; nazwa bazy musi zawierać „test”, inaczej test odmówi pracy.
 */
class PostgresIntegrationTest {

    private fun freshDb(): DataSource {
        val url = System.getenv("WINKWINK_TEST_DATABASE_URL")
        assumeTrue(!url.isNullOrBlank(), "WINKWINK_TEST_DATABASE_URL not set — PostgreSQL integration tests skipped")
        val dbName = url!!.substringAfterLast('/').substringBefore('?')
        check(dbName.contains("test")) { "Refusing to wipe database '$dbName': its name must contain 'test'." }
        val ds = PGSimpleDataSource()
        ds.setUrl(url)
        ds.setUser(System.getenv("WINKWINK_TEST_DATABASE_USER") ?: "postgres")
        ds.setPassword(System.getenv("WINKWINK_TEST_DATABASE_PASSWORD") ?: "")
        val flyway = Flyway.configure().dataSource(ds).locations("classpath:db/migration").cleanDisabled(false).load()
        flyway.clean()
        flyway.migrate()
        return ds
    }

    /** Konto + profil wstawione bezpośrednio SQL-em (nick: małe litery/cyfry, aby pasował do ograniczeń winkwink_id). */
    private fun DataSource.account(nick: String): UUID = connection.use { c ->
        val id = c.prepareStatement("INSERT INTO accounts (email, password_hash) VALUES (?, 'x') RETURNING id").use { ps ->
            ps.setString(1, "$nick@example.test")
            ps.executeQuery().use { it.next(); it.getObject(1, UUID::class.java) }
        }
        c.prepareStatement("INSERT INTO profiles (account_id, nickname, winkwink_id) VALUES (?, ?, ?)").use { ps ->
            ps.setObject(1, id)
            ps.setString(2, nick)
            ps.setString(3, "ww_" + nick.padEnd(10, 'x').take(10))
            ps.executeUpdate()
        }
        id
    }

    private fun DataSource.execute(sql: String) = connection.use { c -> c.createStatement().use { it.execute(sql) } }

    @Test fun `migrations V1 to V15 apply on an empty database and the schema constraints hold`() {
        val ds = freshDb()
        val info = Flyway.configure().dataSource(ds).locations("classpath:db/migration").load().info()
        assertEquals("15", info.current().version.version)
        assertEquals(15, info.applied().size)
        val alice = ds.account("alice")
        // V7: widoczność 'community' wymaga społeczności i kanału; anonimowość tylko dla publicznych.
        assertFailsWith<SQLException> {
            ds.execute("INSERT INTO posts (author_id, body, visibility) VALUES ('$alice', 'x', 'community')")
        }
        assertFailsWith<SQLException> {
            ds.execute("INSERT INTO posts (author_id, body, visibility, anonymous) VALUES ('$alice', 'x', 'followers', true)")
        }
        ds.execute("INSERT INTO posts (author_id, body, visibility, anonymous) VALUES ('$alice', 'x', 'public', true)")
        // V3/V4: WinkWink ID jest niezmienny.
        assertFailsWith<SQLException> { ds.execute("UPDATE profiles SET winkwink_id = 'ww_zzzzzzzzzz' WHERE account_id = '$alice'") }
    }

    @Test fun `refresh token rotation keeps the previous hash and rejects a stale rotation`() {
        val ds = freshDb()
        val store = PostgresAuthStore(ds)
        runBlocking {
            val now = Instant.now()
            val account = store.createAccount("rot@example.test", "hash", "rotuser", "ww_rotuserxxx")
            val h1 = ByteArray(32) { 1 }; val h2 = ByteArray(32) { 2 }; val h3 = ByteArray(32) { 3 }
            val session = store.createSession(account.id, "android", "Pixel", "ua", h1, now, now.plusSeconds(3600))
            assertTrue(assertNotNull(store.findSessionByRefreshHash(h1)).isCurrentToken)
            assertTrue(store.rotateSession(session, h1, h2, now, now.plusSeconds(7200)))
            assertTrue(assertNotNull(store.findSessionByRefreshHash(h2)).isCurrentToken)
            // Stary token nadal jest rozpoznawany, ale jako zrotowany (sygnał ponownego użycia).
            assertFalse(assertNotNull(store.findSessionByRefreshHash(h1)).isCurrentToken)
            // Druga rotacja z już nieaktualnym tokenem nie przechodzi (atomowość WHERE refresh_token_hash = ?).
            assertFalse(store.rotateSession(session, h1, h3, now, now.plusSeconds(7200)))
            store.revokeSessionById(session, now)
            assertNotNull(store.findSessionByRefreshHash(h2)).also { assertNotNull(it.revokedAt) }
            assertFalse(store.isSessionActive(session, account.id, now))
        }
    }

    @Test fun `anonymous authors cannot be unmasked by blocking, but their own blocks still apply`() {
        val ds = freshDb()
        val alice = ds.account("alice"); val bobby = ds.account("bobby")
        val feed = PostgresFeedStore(ds); val notes = PostgresNotificationStore(ds); val profiles = PostgresProfileStore(ds)
        runBlocking {
            val now = Instant.now()
            val anon = feed.createPost(alice, "sekret", "public", true, now, null, null)
            val open = feed.createPost(alice, "jawny", "public", false, now, null, null)
            val comment = feed.createComment(anon, null, bobby, "hej", now)
            val reply = feed.createComment(anon, comment, alice, "odp", now)
            notes.insert(NotificationEvent(NotificationTypes.REPLY, bobby, alice, postId = anon, commentId = reply, actorAnonymous = true), now)

            profiles.addBlock(bobby, alice, now) // widz blokuje podejrzaną osobę
            assertNotNull(feed.getPost(anon, bobby), "anonimowy post nie może zniknąć po blokadzie widza")
            assertNull(feed.getPost(open, bobby), "post jawny znika po blokadzie (zachowanie bez zmian)")
            assertEquals(1, feed.listComments(anon, comment, bobby, 10, null).count { it.authorId == alice })
            assertEquals(1, notes.list(bobby, null, false, 10, null).size, "anonimowe powiadomienie nie może zniknąć po blokadzie odbiorcy")
            assertEquals(1, notes.unreadCount(bobby))

            profiles.addBlock(alice, bobby, now) // autor blokuje widza → treść ukryta
            assertNull(feed.getPost(anon, bobby))
            assertEquals(0, notes.list(bobby, null, false, 10, null).size)
        }
    }

    @Test fun `message store queries run on PostgreSQL`() {
        val ds = freshDb()
        val a = ds.account("alice"); val b = ds.account("bobby")
        val store = PostgresMessageStore(ds)
        runBlocking {
            val now = Instant.now()
            val key = listOf(a, b).map { it.toString() }.sorted().joinToString("|")
            val id1 = store.createConversation("direct", null, a, key, listOf(a to "member", b to "member"), now)
            val id2 = store.createConversation("direct", null, b, key, listOf(b to "member", a to "member"), now)
            assertEquals(id1, id2, "jedna rozmowa 1:1 na parę (ON CONFLICT direct_key)")
            assertEquals(2, store.members(id1).size)

            store.insertMessage(id1, a, "hej", null, now)
            val forB = store.summaries(b, false, null, null, 10, null).single()
            assertEquals(1, forB.unread)
            assertEquals("alice", forB.peer?.nickname)
            assertEquals("hej", forB.last?.body)
            assertEquals(0, store.summaries(a, false, null, null, 10, null).single().unread)
            assertEquals(1, store.summaries(b, false, "ali", null, 10, null).size) // filtr + placeholdery
            assertEquals(0, store.summaries(b, true, null, null, 10, null).size)   // archiwum
            assertEquals(1, store.summaries(b, false, null, null, 10, PageCursor(now.plusSeconds(3600), UUID.randomUUID())).size) // kursor

            store.markRead(id1, b, now.plusSeconds(1))
            assertEquals(0, store.summaries(b, false, null, null, 10, null).single().unread)

            val m = store.insertMessage(id1, a, "tajne", null, now.plusSeconds(2))
            store.deleteMessage(m, now.plusSeconds(3))
            assertTrue(assertNotNull(store.message(m)).deleted)
            assertNull(store.message(m)!!.body, "usunięta wiadomość nie oddaje treści")
            assertEquals(2, store.messages(id1, 10, null).size)

            val g = store.createConversation("group", "Ekipa", a, null, listOf(a to "owner", b to "member"), now)
            store.removeMember(g, b, now)
            assertNull(store.member(g, b))
            store.addMember(g, b, "member", now.plusSeconds(1))
            assertNotNull(store.member(g, b))
        }
    }

    @Test fun `message attachments attach atomically and are cleaned up on PostgreSQL`() {
        val ds = freshDb()
        val a = ds.account("alice"); val b = ds.account("bobby"); val c = ds.account("carol")
        val store = PostgresMessageStore(ds)
        runBlocking {
            val now = Instant.now()
            val key = listOf(a, b).map { it.toString() }.sorted().joinToString("|")
            val conv = store.createConversation("direct", null, a, key, listOf(a to "member", b to "member"), now)
            val other = store.createConversation("direct", null, a, listOf(a, c).map { it.toString() }.sorted().joinToString("|"), listOf(a to "member", c to "member"), now)
            fun att(owner: UUID, conversation: UUID, kind: String = "image", at: Instant = now) = MessageAttachmentRow(
                UUID.randomUUID(), owner, conversation, null, 0, kind, if (kind == "voice") "audio/mp4" else "image/jpeg", 1234,
                "message/" + UUID.randomUUID(), null, if (kind == "image") 10 else null, if (kind == "image") 10 else null,
                if (kind == "voice") 2500L else null, at,
            )
            val a1 = att(a, conv); val a2 = att(a, conv); val v = att(a, conv, "voice"); val foreign = att(a, other)
            listOf(a1, a2, v, foreign).forEach { store.createAttachment(it) }
            assertEquals(4, store.pendingAttachmentCount(a))

            // V15: pusta treść wiadomości jest dozwolona (zdjęcia bez podpisu), przekroczenie 4000 znaków nie.
            assertFailsWith<AttachmentsUnavailableException> { store.insertMessage(conv, a, "", null, now, listOf(a1.id, foreign.id)) }
            assertEquals(0, store.messages(conv, 10, null).size, "nieudane dołączenie wycofuje też wiadomość")
            assertFailsWith<AttachmentsUnavailableException> { store.insertMessage(conv, b, "", null, now, listOf(a1.id)) } // cudzy załącznik
            val m = store.insertMessage(conv, a, "", null, now, listOf(a2.id, a1.id))
            assertEquals(listOf(a2.id, a1.id), store.attachmentsFor(listOf(m)).getValue(m).map { it.id }, "kolejność = pozycja")
            assertFailsWith<AttachmentsUnavailableException> { store.insertMessage(conv, a, "x", null, now, listOf(a1.id)) } // już użyty
            assertEquals(2, store.pendingAttachmentCount(a))

            // Wiersze CHECK: czas trwania tylko dla głosówek, wymiary tylko dla zdjęć.
            assertFailsWith<SQLException> { store.createAttachment(att(a, conv).copy(durationMs = 5)) }
            assertFailsWith<SQLException> { store.createAttachment(att(a, conv, "voice").copy(width = 5)) }

            // Wycofanie niedołączonego: tylko właściciel, wiersz zostaje do usunięcia pliku.
            assertNull(store.tombstonePending(b, v.id, now))
            assertNotNull(store.tombstonePending(a, v.id, now))
            assertEquals(1, store.purgeCandidates(now.minusSeconds(3600), 10).count { it.id == v.id })
            store.removeAttachmentRows(listOf(v.id))
            assertNull(store.attachment(v.id))

            // Porzucone starsze niż próg.
            val old = att(a, conv, at = now.minusSeconds(48 * 3600)).also { store.createAttachment(it) }
            assertTrue(store.purgeCandidates(now.minusSeconds(24 * 3600), 10).any { it.id == old.id })
            assertFalse(store.purgeCandidates(now.minusSeconds(24 * 3600), 10).any { it.id == foreign.id })

            // Usunięcie wiadomości oznacza załączniki; znikają z widoku, ale wiersze czekają na usunięcie plików.
            val removed = store.deleteMessage(m, now.plusSeconds(1))
            assertEquals(setOf(a1.id, a2.id), removed.map { it.id }.toSet())
            assertTrue(store.attachmentsFor(listOf(m)).isEmpty())
            assertEquals(2, store.purgeCandidates(now.minusSeconds(3600), 10).count { it.deletedAt != null })
            store.removeAttachmentRows(removed.map { it.id })
            assertNull(store.attachment(a1.id))

            assertFailsWith<SQLException> { store.insertMessage(conv, a, "x".repeat(4001), null, now) }
        }
    }

    @Test fun `notification mark read is idempotent for the owner and invisible for others`() {
        val ds = freshDb()
        val a = ds.account("alice"); val b = ds.account("bobby"); val c = ds.account("carol")
        val notes = PostgresNotificationStore(ds)
        runBlocking {
            val now = Instant.now()
            val id = assertNotNull(notes.insert(NotificationEvent(NotificationTypes.NEW_FOLLOWER, a, b), now))
            assertNull(notes.insert(NotificationEvent(NotificationTypes.NEW_FOLLOWER, a, b), now), "deduplikacja indeksem unikalnym")
            assertFalse(notes.markRead(c, id, now), "cudze powiadomienie")
            assertEquals(1, notes.unreadCount(a))
            assertTrue(notes.markRead(a, id, now))
            assertTrue(notes.markRead(a, id, now), "idempotentne")
            assertEquals(0, notes.unreadCount(a))
        }
    }
}
