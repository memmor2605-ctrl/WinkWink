package app.winkwink.server.media

/** Magazyn w pamięci wyłącznie do testów. */
class InMemoryMediaStorage : MediaStorage {
    val files = mutableMapOf<String, ByteArray>()
    @Synchronized override suspend fun put(key: String, bytes: ByteArray) { require(MediaKeys.isValid(key)); files[key] = bytes }
    @Synchronized override suspend fun get(key: String): ByteArray? = files[key]
    @Synchronized override suspend fun delete(key: String) { files.remove(key) }
}
