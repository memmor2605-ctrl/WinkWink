package app.winkwink.server.media

import kotlinx.coroutines.test.runTest
import java.nio.file.Files
import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

class MediaStorageTest {
    @Test fun `generated keys are valid and unique`() {
        val a = MediaKeys.newKey("avatar"); val b = MediaKeys.newKey("avatar")
        assertTrue(MediaKeys.isValid(a)); assertTrue(a != b)
    }

    @Test fun `traversal and malformed keys are rejected`() = runTest {
        val s = LocalFileMediaStorage(Files.createTempDirectory("ww-media"))
        for (bad in listOf("../etc/passwd", "avatar/../../x", "/abs/path", "avatar/not-a-uuid", "", "AVATAR/" + java.util.UUID.randomUUID())) {
            assertFailsWith<IllegalArgumentException>(bad) { s.get(bad) }
            assertFailsWith<IllegalArgumentException>(bad) { s.put(bad, byteArrayOf(1)) }
        }
        assertFalse(MediaKeys.isValid("avatar/../x"))
    }

    @Test fun `put get overwrite delete round trip`() = runTest {
        val s = LocalFileMediaStorage(Files.createTempDirectory("ww-media"))
        val key = MediaKeys.newKey("background")
        assertNull(s.get(key))
        s.put(key, byteArrayOf(1, 2, 3))
        assertContentEquals(byteArrayOf(1, 2, 3), s.get(key))
        s.put(key, byteArrayOf(9))
        assertContentEquals(byteArrayOf(9), s.get(key))
        s.delete(key); s.delete(key) // idempotentne
        assertNull(s.get(key))
    }
}
