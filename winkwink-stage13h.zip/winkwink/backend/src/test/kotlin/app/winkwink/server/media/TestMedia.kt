package app.winkwink.server.media

import java.awt.image.BufferedImage
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import javax.imageio.ImageIO

/** Syntetyczne pliki do testów walidacji zawartości (bez plików binarnych w repozytorium). */
object TestMedia {
    private fun box(type: String, body: ByteArray): ByteArray =
        ByteBuffer.allocate(8 + body.size).putInt(8 + body.size).put(type.toByteArray(Charsets.ISO_8859_1)).put(body).array()

    /** Minimalny kontener MP4/M4A: ftyp + moov(mvhd + trak(mdia(hdlr))). [handler] `soun` = dźwięk, `vide` = wideo. */
    fun mp4(handler: String = "soun", durationMs: Long = 2000, timescale: Int = 1000, brand: String = "M4A "): ByteArray {
        val ftyp = box("ftyp", brand.toByteArray(Charsets.ISO_8859_1) + ByteArray(4) + brand.toByteArray(Charsets.ISO_8859_1))
        val mvhdBody = ByteBuffer.allocate(100).putInt(0).putInt(0).putInt(0).putInt(timescale).putInt((durationMs * timescale / 1000).toInt()).array()
        val hdlrBody = ByteBuffer.allocate(25).putInt(0).putInt(0).put(handler.toByteArray(Charsets.ISO_8859_1)).array()
        val moov = box("moov", box("mvhd", mvhdBody) + box("trak", box("mdia", box("hdlr", hdlrBody))))
        return ftyp + moov
    }

    fun png(w: Int = 64, h: Int = 48): ByteArray {
        val img = BufferedImage(w, h, BufferedImage.TYPE_INT_RGB)
        for (x in 0 until w) for (y in 0 until h) img.setRGB(x, y, (x * 4) shl 16 or (y * 5) shl 8)
        return ByteArrayOutputStream().also { ImageIO.write(img, "png", it) }.toByteArray()
    }

    fun pdf(extra: String = ""): ByteArray = "%PDF-1.4\n1 0 obj\n<< /Type /Catalog $extra>>\nendobj\ntrailer\n<< /Root 1 0 R >>\n%%EOF\n".toByteArray()

    /** ZIP z podanymi wpisami (skompresowanymi); [stored] to wpisy zapisane bez kompresji (np. `mimetype` w ODF). */
    fun zip(entries: Map<String, String>, stored: Map<String, String> = emptyMap()): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z ->
            stored.forEach { (name, text) ->
                val data = text.toByteArray()
                val e = ZipEntry(name)
                e.method = ZipEntry.STORED
                e.size = data.size.toLong(); e.compressedSize = data.size.toLong()
                e.crc = CRC32().also { it.update(data) }.value
                z.putNextEntry(e); z.write(data); z.closeEntry()
            }
            entries.forEach { (name, text) -> z.putNextEntry(ZipEntry(name)); z.write(text.toByteArray()); z.closeEntry() }
        }
        return out.toByteArray()
    }

    fun docx(extra: Map<String, String> = emptyMap()) =
        zip(mapOf("[Content_Types].xml" to "<Types/>", "word/document.xml" to "<w:document/>") + extra)

    fun xlsx() = zip(mapOf("[Content_Types].xml" to "<Types/>", "xl/workbook.xml" to "<workbook/>"))
    fun pptx() = zip(mapOf("[Content_Types].xml" to "<Types/>", "ppt/presentation.xml" to "<p/>"))
    fun odt(mimetype: String = "application/vnd.oasis.opendocument.text", extra: Map<String, String> = emptyMap()) =
        zip(mapOf("META-INF/manifest.xml" to "<manifest/>", "content.xml" to "<c/>") + extra, stored = mapOf("mimetype" to mimetype))
}
