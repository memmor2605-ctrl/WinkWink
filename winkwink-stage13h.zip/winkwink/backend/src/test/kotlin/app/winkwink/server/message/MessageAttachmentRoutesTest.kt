package app.winkwink.server.message

import app.winkwink.server.auth.TestAuth
import app.winkwink.server.auth.testAppConfig
import app.winkwink.server.health.DatabaseHealth
import app.winkwink.server.health.HealthProbe
import app.winkwink.server.media.InMemoryMediaStorage
import app.winkwink.server.media.TestMedia
import app.winkwink.server.media.UploadRateLimiter
import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.winkwinkModule
import io.ktor.client.HttpClient
import io.ktor.client.request.header
import io.ktor.client.request.request
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsBytes
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.server.testing.ApplicationTestBuilder
import io.ktor.server.testing.testApplication
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

/** HTTP: wysyłanie, pobieranie i usuwanie plików wiadomości (kontrakt JSON, nagłówki, kody błędów, izolacja kont). */
class MessageAttachmentRoutesTest {
    private val probe = HealthProbe { DatabaseHealth("up", 1, "5") }
    private val auth = TestAuth()
    private val graph = InMemoryProfileStore()
    private val store = InMemoryMessageStore(graph)
    private val storage = InMemoryMediaStorage()
    private val messages = MessageService(store, graph, media = storage)
    private val attachments = MessageAttachmentService(store, storage, UploadRateLimiter(perMinute = 1000, perHour = 10000))

    private fun user(nick: String): String = runBlocking {
        val r = auth.service.register("$nick@example.com", "correct-horse-battery", nick, "android", null, null)
        graph.seed(nick, id = r.profile.accountId)
        r.session.accessToken
    }

    private fun run(block: suspend ApplicationTestBuilder.() -> Unit) = testApplication {
        application { winkwinkModule(testAppConfig(), probe, auth.service, messages = messages, messageAttachments = attachments) }
        block()
    }

    private suspend fun HttpClient.json(method: HttpMethod, path: String, token: String?, body: String? = null): HttpResponse =
        request("/api/v1$path") {
            this.method = method
            header("X-Forwarded-Proto", "https")
            token?.let { header(HttpHeaders.Authorization, "Bearer $it") }
            if (body != null) { header(HttpHeaders.ContentType, ContentType.Application.Json.toString()); setBody(body) }
        }

    private suspend fun HttpClient.upload(token: String?, conv: String, mime: String, bytes: ByteArray, name: String? = null): HttpResponse =
        request("/api/v1/message-attachments?conversationId=$conv" + (name?.let { "&name=" + java.net.URLEncoder.encode(it, "UTF-8") } ?: "")) {
            method = HttpMethod.Post
            header("X-Forwarded-Proto", "https")
            token?.let { header(HttpHeaders.Authorization, "Bearer $it") }
            header(HttpHeaders.ContentType, mime)
            setBody(bytes)
        }

    private fun field(json: String, name: String) = Json.parseToJsonElement(json).jsonObject.getValue(name).jsonPrimitive.content

    private suspend fun ApplicationTestBuilder.conversation(a: String): String =
        field(client.json(HttpMethod.Post, "/conversations/direct", a, """{"user":"bobby"}""").bodyAsText(), "id")

    @Test fun `routes reject anonymous callers`() = run {
        val id = "00000000-0000-0000-0000-000000000001"
        assertEquals(HttpStatusCode.Unauthorized, client.upload(null, id, "image/png", TestMedia.png()).status)
        assertEquals(HttpStatusCode.Unauthorized, client.json(HttpMethod.Get, "/message-attachments/$id", null).status)
        assertEquals(HttpStatusCode.Unauthorized, client.json(HttpMethod.Delete, "/message-attachments/$id", null).status)
    }

    @Test fun `photo flow upload send list download`() = run {
        val alice = user("alice"); val bob = user("bobby"); val carol = user("carol")
        val conv = conversation(alice)
        val up = client.upload(alice, conv, "image/png", TestMedia.png(90, 60))
        assertEquals(HttpStatusCode.Created, up.status)
        val upBody = up.bodyAsText()
        assertFalse(upBody.contains("objectKey") || upBody.contains("message/"), "klucz obiektu nie wycieka do klienta")
        val id = field(upBody, "id")
        assertEquals("image", field(upBody, "kind"))

        val sent = client.json(HttpMethod.Post, "/conversations/$conv/messages", alice, """{"attachmentIds":["$id"]}""")
        assertEquals(HttpStatusCode.Created, sent.status)
        val att = Json.parseToJsonElement(sent.bodyAsText()).jsonObject.getValue("attachments").jsonArray.single().jsonObject
        assertEquals(id, att.getValue("id").jsonPrimitive.content)

        val list = client.json(HttpMethod.Get, "/conversations/$conv/messages", bob).bodyAsText()
        assertTrue(list.contains(id))

        val file = client.json(HttpMethod.Get, "/message-attachments/$id", bob)
        assertEquals(HttpStatusCode.OK, file.status)
        assertEquals("nosniff", file.headers["X-Content-Type-Options"])
        assertTrue(file.headers[HttpHeaders.ContentDisposition]!!.startsWith("inline"))
        assertTrue(file.bodyAsBytes().size > 8)

        assertEquals(HttpStatusCode.NotFound, client.json(HttpMethod.Get, "/message-attachments/$id", carol).status)
        assertEquals(HttpStatusCode.NotFound, client.json(HttpMethod.Get, "/message-attachments/not-a-uuid", bob).status)
    }

    @Test fun `document is served as an attachment with a safe name`() = run {
        val alice = user("alice"); val bob = user("bobby")
        val conv = conversation(alice)
        val id = field(client.upload(alice, conv, "application/pdf", TestMedia.pdf(), "../Umowa 2026.pdf").bodyAsText(), "id")
        client.json(HttpMethod.Post, "/conversations/$conv/messages", alice, """{"body":"plik","attachmentIds":["$id"]}""")
        val file = client.json(HttpMethod.Get, "/message-attachments/$id", bob)
        assertEquals(ContentType.Application.Pdf.toString(), file.headers[HttpHeaders.ContentType])
        val cd = file.headers[HttpHeaders.ContentDisposition]!!
        assertTrue(cd.startsWith("attachment;") && cd.contains("Umowa%202026.pdf"), cd)
        assertEquals("default-src 'none'; sandbox", file.headers["Content-Security-Policy"])
    }

    @Test fun `forbidden and broken uploads get precise errors`() = run {
        val alice = user("alice"); val bob = user("bobby"); val carol = user("carol")
        val conv = conversation(alice)
        assertEquals(HttpStatusCode.NotFound, client.upload(carol, conv, "image/png", TestMedia.png()).status)
        assertEquals(HttpStatusCode.UnsupportedMediaType, client.upload(alice, conv, "text/html", "<html/>".toByteArray()).status)
        assertEquals(HttpStatusCode.UnsupportedMediaType, client.upload(alice, conv, "application/x-msdownload", byteArrayOf(0x4D, 0x5A)).status)
        assertEquals(HttpStatusCode.UnsupportedMediaType, client.upload(alice, conv, "application/pdf", byteArrayOf(0x4D, 0x5A, 1, 2, 3, 4), "faktura.pdf").status)
        assertEquals(HttpStatusCode.BadRequest, client.json(HttpMethod.Post, "/message-attachments?conversationId=nope", alice).status)
        assertEquals(HttpStatusCode.UnsupportedMediaType, client.upload(alice, conv, "audio/mp4", TestMedia.mp4(handler = "vide")).status)
        assertEquals(0, storage.files.size)
        // Cudzy nie może dołączyć ani usunąć pliku.
        val id = field(client.upload(alice, conv, "image/png", TestMedia.png()).bodyAsText(), "id")
        assertEquals(HttpStatusCode.Conflict, client.json(HttpMethod.Post, "/conversations/$conv/messages", bob, """{"attachmentIds":["$id"]}""").status)
        assertEquals(HttpStatusCode.NotFound, client.json(HttpMethod.Delete, "/message-attachments/$id", bob).status)
        assertEquals(HttpStatusCode.NoContent, client.json(HttpMethod.Delete, "/message-attachments/$id", alice).status)
        assertEquals(0, storage.files.size)
    }

    @Test fun `voice message round trip and deletion removes the file`() = run {
        val alice = user("alice"); val bob = user("bobby")
        val conv = conversation(alice)
        val up = client.upload(alice, conv, "audio/mp4", TestMedia.mp4(durationMs = 3500), "voice.m4a")
        assertEquals(HttpStatusCode.Created, up.status)
        assertEquals("3500", field(up.bodyAsText(), "durationMs"))
        val id = field(up.bodyAsText(), "id")
        val msg = field(client.json(HttpMethod.Post, "/conversations/$conv/messages", alice, """{"attachmentIds":["$id"]}""").bodyAsText(), "id")
        assertEquals("audio/mp4", client.json(HttpMethod.Get, "/message-attachments/$id", bob).headers[HttpHeaders.ContentType])
        // Odbiorca nie może usunąć cudzej wiadomości; autor może — plik znika.
        assertEquals(HttpStatusCode.Forbidden, client.json(HttpMethod.Delete, "/messages/$msg", bob).status)
        assertEquals(HttpStatusCode.NoContent, client.json(HttpMethod.Delete, "/messages/$msg", alice).status)
        assertEquals(HttpStatusCode.NotFound, client.json(HttpMethod.Get, "/message-attachments/$id", bob).status)
        assertEquals(0, storage.files.size)
    }
}
