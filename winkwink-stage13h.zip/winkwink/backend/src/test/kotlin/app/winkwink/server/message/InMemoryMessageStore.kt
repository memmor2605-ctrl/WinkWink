package app.winkwink.server.message

import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.profile.PageCursor
import java.time.Instant
import java.util.UUID

class InMemoryMessageStore(private val profiles: InMemoryProfileStore) : MessageStore {
    private class Conv(val row: ConversationRow, val directKey: String?)
    private class Mem(val conv: UUID, val account: UUID, var role: String, var joinedAt: Instant, var leftAt: Instant? = null, var lastRead: Instant? = null, var muted: Boolean = false, var archived: Boolean = false, var lastDelivered: Instant? = null)
    private class Msg(val id: UUID, val conv: UUID, val sender: UUID, var body: String, val replyTo: UUID?, val at: Instant, var editedAt: Instant? = null, var deletedAt: Instant? = null, val clientId: UUID? = null, var changedAt: Instant = at)

    private val convs = mutableListOf<Conv>()
    private val mems = mutableListOf<Mem>()
    private val msgs = mutableListOf<Msg>()
    private val receipts = mutableMapOf<UUID, Boolean>()
    private val reacts = mutableListOf<ReactionRow>()
    private val atts = mutableListOf<MessageAttachmentRow>()

    private suspend fun person(id: UUID) = profiles.findById(id)!!.let { PersonRef(it.accountId, it.nickname, it.winkwinkId, it.displayName, it.avatarObjectKey) }
    private suspend fun Msg.toRow() = MessageRow(id, conv, person(sender), if (deletedAt != null) null else body, replyTo, at, editedAt, deletedAt != null, changedAt)
    private suspend fun Mem.toRow() = MemberRow(conv, person(account), role, joinedAt, lastRead, muted, archived, receipts[account] ?: true, lastDelivered)

    @Synchronized override suspend fun findDirect(directKey: String) = convs.firstOrNull { it.directKey == directKey }?.row?.id

    @Synchronized override suspend fun createConversation(kind: String, title: String?, createdBy: UUID, directKey: String?, members: List<Pair<UUID, String>>, now: Instant): UUID {
        convs.firstOrNull { directKey != null && it.directKey == directKey }?.let { return it.row.id }
        val id = UUID.randomUUID()
        convs += Conv(ConversationRow(id, kind, title, createdBy, now), directKey)
        members.forEach { (a, r) -> mems += Mem(id, a, r, now) }
        return id
    }

    @Synchronized override suspend fun conversation(id: UUID) = convs.firstOrNull { it.row.id == id }?.row
    @Synchronized override suspend fun member(conversationId: UUID, account: UUID) =
        mems.firstOrNull { it.conv == conversationId && it.account == account && it.leftAt == null }?.toRow()
    @Synchronized override suspend fun members(conversationId: UUID) =
        mems.filter { it.conv == conversationId && it.leftAt == null }.sortedBy { it.joinedAt }.map { it.toRow() }

    @Synchronized override suspend fun addMember(conversationId: UUID, account: UUID, role: String, now: Instant) {
        val ex = mems.firstOrNull { it.conv == conversationId && it.account == account }
        if (ex == null) mems += Mem(conversationId, account, role, now) else { ex.leftAt = null; ex.role = role; ex.joinedAt = now; ex.lastRead = null; ex.lastDelivered = null }
    }

    @Synchronized override suspend fun removeMember(conversationId: UUID, account: UUID, now: Instant) {
        mems.firstOrNull { it.conv == conversationId && it.account == account && it.leftAt == null }?.leftAt = now
    }

    @Synchronized override suspend fun insertMessage(conversationId: UUID, sender: UUID, body: String, replyTo: UUID?, now: Instant, attachmentIds: List<UUID>, clientId: UUID?): UUID {
        if (clientId != null) msgs.firstOrNull { it.sender == sender && it.clientId == clientId }?.let { return it.id }
        // Jak w Postgresie: wszystko albo nic.
        val claimed = attachmentIds.map { id ->
            atts.firstOrNull { it.id == id && it.ownerId == sender && it.conversationId == conversationId && it.messageId == null && it.deletedAt == null }
                ?: throw AttachmentsUnavailableException()
        }
        if (claimed.map { it.id }.toSet().size != claimed.size) throw AttachmentsUnavailableException()
        val m = Msg(UUID.randomUUID(), conversationId, sender, body, replyTo, now, clientId = clientId); msgs += m
        claimed.forEachIndexed { i, a -> atts[atts.indexOfFirst { it.id == a.id }] = a.copy(messageId = m.id, position = i) }
        return m.id
    }

    @Synchronized override suspend fun findByClientId(sender: UUID, clientId: UUID) =
        msgs.firstOrNull { it.sender == sender && it.clientId == clientId }?.toRow()

    @Synchronized override suspend fun changes(conversationId: UUID, since: Instant, after: PageCursor?, limit: Int) =
        msgs.filter { it.conv == conversationId }
            .sortedWith(compareBy<Msg> { it.changedAt }.thenBy { it.id })
            .filter { if (after != null) it.changedAt > after.at || (it.changedAt == after.at && it.id > after.id) else it.changedAt > since }
            .take(limit).map { it.toRow() }

    @Synchronized override suspend fun message(id: UUID) = msgs.firstOrNull { it.id == id }?.toRow()

    @Synchronized override suspend fun messages(conversationId: UUID, limit: Int, after: PageCursor?) =
        msgs.filter { it.conv == conversationId }
            .sortedWith(compareByDescending<Msg> { it.at }.thenByDescending { it.id })
            .filter { after == null || it.at < after.at || (it.at == after.at && it.id < after.id) }
            .take(limit).map { it.toRow() }

    @Synchronized override suspend fun editMessage(id: UUID, body: String, now: Instant) {
        msgs.firstOrNull { it.id == id && it.deletedAt == null }?.let { it.body = body; it.editedAt = now; it.changedAt = now }
    }

    @Synchronized override suspend fun deleteMessage(id: UUID, now: Instant): List<MessageAttachmentRow> {
        msgs.firstOrNull { it.id == id && it.deletedAt == null }?.let { it.body = ""; it.deletedAt = now; it.changedAt = now }
        reacts.removeAll { it.messageId == id }
        val out = mutableListOf<MessageAttachmentRow>()
        atts.forEachIndexed { i, a -> if (a.messageId == id) { val t = a.copy(deletedAt = a.deletedAt ?: now); atts[i] = t; out += t } }
        return out
    }

    @Synchronized override suspend fun markRead(conversationId: UUID, account: UUID, now: Instant) {
        mems.firstOrNull { it.conv == conversationId && it.account == account && it.leftAt == null }?.let { it.lastRead = now; it.lastDelivered = maxOf(it.lastDelivered ?: now, now) }
    }

    @Synchronized override suspend fun setFlags(conversationId: UUID, account: UUID, muted: Boolean?, archived: Boolean?) {
        mems.firstOrNull { it.conv == conversationId && it.account == account && it.leftAt == null }?.let { m ->
            muted?.let { m.muted = it }; archived?.let { m.archived = it }
        }
    }

    @Synchronized override suspend fun summaries(viewer: UUID, archived: Boolean?, query: String?, conversationId: UUID?, limit: Int, after: PageCursor?): List<SummaryRow> {
        val rows = mems.filter { it.account == viewer && it.leftAt == null && (archived == null || it.archived == archived) && (conversationId == null || it.conv == conversationId) }.mapNotNull { m ->
            val c = convs.first { it.row.id == m.conv }.row
            val peer = if (c.kind == "direct") mems.firstOrNull { it.conv == c.id && it.account != viewer }?.let { person(it.account) } else null
            if (query != null) {
                val hit = listOfNotNull(c.title, peer?.nickname, peer?.displayName).any { it.contains(query, ignoreCase = true) }
                if (!hit) return@mapNotNull null
            }
            val last = msgs.filter { it.conv == c.id }.maxWithOrNull(compareBy<Msg> { it.at }.thenBy { it.id })
            val unread = msgs.count { it.conv == c.id && it.deletedAt == null && it.sender != viewer && (m.lastRead == null || it.at > m.lastRead!!) }
            SummaryRow(c, m.role, m.muted, m.archived, mems.count { it.conv == c.id && it.leftAt == null }, peer, last?.toRow(), unread, last?.at ?: c.createdAt)
        }
        return rows.sortedWith(compareByDescending<SummaryRow> { it.activity }.thenByDescending { it.conversation.id })
            .filter { after == null || it.activity < after.at || (it.activity == after.at && it.conversation.id < after.id) }
            .take(limit)
    }

    @Synchronized override suspend fun setReaction(messageId: UUID, account: UUID, kind: String?, now: Instant) {
        reacts.removeAll { it.messageId == messageId && it.account == account }
        if (kind != null) reacts += ReactionRow(messageId, account, kind)
        msgs.firstOrNull { it.id == messageId }?.changedAt = now
    }

    @Synchronized override suspend fun reactions(messageIds: List<UUID>) = reacts.filter { it.messageId in messageIds }

    @Synchronized override suspend fun markDelivered(account: UUID, conversationIds: List<UUID>, now: Instant): List<UUID> =
        mems.filter { it.account == account && it.leftAt == null && it.conv in conversationIds }.filter { m ->
            msgs.any { it.conv == m.conv && it.sender != account && (m.lastDelivered == null || it.at > m.lastDelivered!!) }
        }.onEach { it.lastDelivered = now }.map { it.conv }

    @Synchronized override suspend fun setRole(conversationId: UUID, account: UUID, role: String) {
        mems.firstOrNull { it.conv == conversationId && it.account == account && it.leftAt == null }?.role = role
    }

    @Synchronized override suspend fun readReceipts(account: UUID) = receipts[account] ?: true
    @Synchronized override suspend fun setReadReceipts(account: UUID, enabled: Boolean) { receipts[account] = enabled }

    // ---- załączniki ----
    @Synchronized override suspend fun createAttachment(row: MessageAttachmentRow) { atts += row }
    @Synchronized override suspend fun attachment(id: UUID) = atts.firstOrNull { it.id == id }
    @Synchronized override suspend fun pendingAttachmentCount(owner: UUID) = atts.count { it.ownerId == owner && it.messageId == null && it.deletedAt == null }
    @Synchronized override suspend fun tombstonePending(owner: UUID, id: UUID, now: Instant): MessageAttachmentRow? {
        val i = atts.indexOfFirst { it.id == id && it.ownerId == owner && it.messageId == null && it.deletedAt == null }
        if (i < 0) return null
        atts[i] = atts[i].copy(deletedAt = now); return atts[i]
    }
    @Synchronized override suspend fun attachmentsFor(messageIds: Collection<UUID>): Map<UUID, List<MessageAttachmentRow>> =
        atts.filter { it.messageId in messageIds && it.deletedAt == null }.sortedBy { it.position }.groupBy { it.messageId!! }
    @Synchronized override suspend fun purgeCandidates(pendingBefore: Instant, limit: Int): List<MessageAttachmentRow> =
        atts.filter { it.deletedAt != null || (it.messageId == null && it.createdAt < pendingBefore) }.sortedBy { it.createdAt }.take(limit)
    @Synchronized override suspend fun removeAttachmentRows(ids: Collection<UUID>) { atts.removeAll { it.id in ids } }
    /** Tylko testy: wszystkie wiersze załączników (także oznaczone do usunięcia). */
    @Synchronized fun allAttachments(): List<MessageAttachmentRow> = atts.toList()
}
