package app.winkwink.server

import app.winkwink.server.config.AppConfig
import app.winkwink.server.config.ConfigException
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class AppConfigTest {
    private val base = mapOf(
        "WINKWINK_DB_URL" to "jdbc:postgresql://localhost:5432/winkwink",
        "WINKWINK_DB_USER" to "u",
        "WINKWINK_DB_PASSWORD" to "p",
        "WINKWINK_JWT_SECRET" to "0123456789abcdef0123456789abcdef-test-only",
    )

    @Test
    fun `refuses to start without any HTTPS setup`() {
        assertFailsWith<ConfigException> { AppConfig.fromEnvironment(base) }
    }

    @Test
    fun `accepts proxy mode`() {
        val config = AppConfig.fromEnvironment(base + ("WINKWINK_TRUST_PROXY" to "true"))
        assertEquals(8080, config.port)
    }

    @Test
    fun `production requires sslmode on database url`() {
        assertFailsWith<ConfigException> {
            AppConfig.fromEnvironment(base + mapOf("WINKWINK_TRUST_PROXY" to "true", "WINKWINK_ENV" to "production"))
        }
    }

    @Test
    fun `jwt secret is required and must be long enough`() {
        val noSecret = base - "WINKWINK_JWT_SECRET"
        assertFailsWith<ConfigException> { AppConfig.fromEnvironment(noSecret + ("WINKWINK_TRUST_PROXY" to "true")) }
        assertFailsWith<ConfigException> {
            AppConfig.fromEnvironment(base + mapOf("WINKWINK_TRUST_PROXY" to "true", "WINKWINK_JWT_SECRET" to "short"))
        }
    }

    @Test
    fun `secrets are not printed`() {
        val config = AppConfig.fromEnvironment(base + ("WINKWINK_TRUST_PROXY" to "true"))
        assert(!config.toString().contains("password=p"))
        assert(!config.toString().contains("0123456789abcdef"))
    }
}
