package app.winkwink.server.feed

import java.time.Instant
import java.util.UUID

/** Implementacja w pamięci wyłącznie do testów. Nie modeluje usuwania postów (jak [InMemoryFeedStore] — usunięcie jest znacznikiem). */
class InMemoryPostExtrasStore(private val publicPostIds: (UUID) -> Boolean = { true }) : PostExtrasStore {
    private val rows = mutableMapOf<UUID, AttachmentRow>()
    private val shares = mutableMapOf<UUID, UUID>()

    @Synchronized override suspend fun createAttachment(row: AttachmentRow) { rows[row.id] = row }
    @Synchronized override suspend fun getAttachment(id: UUID) = rows[id]
    @Synchronized override suspend fun pendingCount(owner: UUID) = rows.values.count { it.ownerId == owner && it.postId == null }
    @Synchronized override suspend fun deletePending(owner: UUID, id: UUID): AttachmentRow? {
        val r = rows[id] ?: return null
        if (r.ownerId != owner || r.postId != null) return null
        rows.remove(id); return r
    }
    @Synchronized override suspend fun attach(owner: UUID, postId: UUID, ids: List<UUID>): Boolean {
        if (ids.any { id -> rows[id]?.let { it.ownerId == owner && it.postId == null } != true }) return false
        ids.forEachIndexed { i, id -> rows[id] = rows[id]!!.copy(postId = postId, position = i) }
        return true
    }
    @Synchronized override suspend fun forPosts(postIds: Collection<UUID>): Map<UUID, List<AttachmentRow>> =
        rows.values.filter { it.postId in postIds }.sortedBy { it.position }.groupBy { it.postId!! }
    @Synchronized override suspend fun setShare(postId: UUID, originalId: UUID) { shares[postId] = originalId }
    @Synchronized override suspend fun originalsOf(postIds: Collection<UUID>): Map<UUID, UUID> = shares.filterKeys { it in postIds }
    @Synchronized override suspend fun publicShareCounts(originalIds: Collection<UUID>): Map<UUID, Int> =
        shares.entries.filter { it.value in originalIds && publicPostIds(it.key) }.groupingBy { it.value }.eachCount()
    @Synchronized override suspend fun purgePending(before: Instant): List<String> {
        val old = rows.values.filter { it.postId == null && it.createdAt < before }
        old.forEach { rows.remove(it.id) }
        return old.map { it.objectKey }
    }
}
