package app.winkwink.server.auth

import app.winkwink.server.api.ApiException
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.test.runTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNotEquals
import kotlin.test.assertTrue

class AuthServiceTest {
    private val t = TestAuth()
    private val s = t.service
    private val pw = "correct-horse-battery"

    private suspend fun register(email: String = "ala@example.com", nick: String = "ala") =
        s.register(email, pw, nick, "android", "Pixel", "UA/1.0")

    private suspend fun code(block: suspend () -> Unit): String =
        assertFailsWith<ApiException> { block() }.code

    @Test
    fun `register creates account profile and session with stable winkwink id`() = runTest {
        val r = register("  Ala@Example.com ")
        assertEquals("ala@example.com", r.email)
        assertTrue(Regex("^ww_[a-z0-9]{10}$").matches(r.profile.winkwinkId))
        assertEquals("public", r.profile.visibility)
        assertTrue(s.isSessionActive(r.session.sessionId, r.profile.accountId))
        val again = s.login("ala@example.com", pw, "android", null, null, "1.1.1.1")
        assertEquals(r.profile.winkwinkId, again.profile.winkwinkId)
    }

    @Test
    fun `register rejects duplicates and invalid input`() = runTest {
        register()
        assertEquals("email_taken", code { register("ALA@example.com", "other") })
        assertEquals("nickname_taken", code { register("b@example.com", "ALA") })
        val e = assertFailsWith<ApiException> { s.register("bad", "short", "x", "toaster", null, null) }
        assertEquals(HttpStatusCode.UnprocessableEntity, e.status)
        assertTrue(e.details!!.size >= 4)
    }

    @Test
    fun `login failure is generic for unknown user and wrong password`() = runTest {
        register()
        assertEquals("invalid_credentials", code { s.login("ala@example.com", "wrong-password-1", "android", null, null, "1.1.1.1") })
        assertEquals("invalid_credentials", code { s.login("nobody@example.com", "wrong-password-1", "android", null, null, "1.1.1.1") })
    }

    @Test
    fun `brute force lockout blocks even the correct password then expires`() = runTest {
        register()
        repeat(5) { assertEquals("invalid_credentials", code { s.login("ala@example.com", "bad-password-xx", "android", null, null, "2.2.2.$it") }) }
        val e = assertFailsWith<ApiException> { s.login("ala@example.com", pw, "android", null, null, "9.9.9.9") }
        assertEquals(HttpStatusCode.TooManyRequests, e.status)
        assertTrue((e.retryAfterSeconds ?: 0) > 0)
        t.clock.advanceSeconds(16 * 60)
        s.login("ala@example.com", pw, "android", null, null, "9.9.9.9")
    }

    @Test
    fun `ip based lockout protects against credential stuffing`() = runTest {
        repeat(30) { i -> code { s.login("u$i@example.com", "bad-password-xx", "android", null, null, "6.6.6.6") } }
        val e = assertFailsWith<ApiException> { s.login("fresh@example.com", pw, "android", null, null, "6.6.6.6") }
        assertEquals("too_many_attempts", e.code)
    }

    @Test
    fun `suspended account cannot log in or use existing session`() = runTest {
        val r = register()
        t.store.setStatus(r.profile.accountId, "suspended")
        assertEquals("account_unavailable", code { s.login("ala@example.com", pw, "android", null, null, "1.1.1.1") })
        assertFalse(s.isSessionActive(r.session.sessionId, r.profile.accountId))
        assertEquals("invalid_refresh_token", code { s.refresh(r.session.refreshToken) })
    }

    @Test
    fun `refresh rotates tokens and detects reuse`() = runTest {
        val r = register()
        val second = s.refresh(r.session.refreshToken)
        assertNotEquals(r.session.refreshToken, second.refreshToken)
        assertEquals(r.session.sessionId, second.sessionId)
        // ponowne użycie starego tokenu = podejrzenie kradzieży, sesja unieważniona
        assertEquals("refresh_token_reused", code { s.refresh(r.session.refreshToken) })
        assertFalse(s.isSessionActive(r.session.sessionId, r.profile.accountId))
        assertEquals("invalid_refresh_token", code { s.refresh(second.refreshToken) })
    }

    @Test
    fun `refresh fails for expired sessions and garbage`() = runTest {
        val r = register()
        assertEquals("invalid_refresh_token", code { s.refresh("garbage") })
        assertEquals("invalid_refresh_token", code { s.refresh("") })
        t.clock.advanceSeconds(31L * 86_400)
        assertEquals("invalid_refresh_token", code { s.refresh(r.session.refreshToken) })
    }

    @Test
    fun `logout revokes only the current session`() = runTest {
        val a = register()
        val b = s.login("ala@example.com", pw, "android", "Tablet", null, "1.1.1.1")
        s.logout(a.profile.accountId, a.session.sessionId)
        assertFalse(s.isSessionActive(a.session.sessionId, a.profile.accountId))
        assertTrue(s.isSessionActive(b.session.sessionId, a.profile.accountId))
    }

    @Test
    fun `session management cannot touch other accounts`() = runTest {
        val a = register()
        val b = register("bob@example.com", "bob")
        assertEquals("not_found", code { s.revokeSession(b.profile.accountId, a.session.sessionId) })
        assertEquals(1, s.listSessions(a.profile.accountId).size)
        s.login("ala@example.com", pw, "android", "Tablet", null, "1.1.1.1")
        assertEquals(1, s.revokeOtherSessions(a.profile.accountId, a.session.sessionId))
        assertEquals(1, s.listSessions(a.profile.accountId).size)
    }

    @Test
    fun `change password requires current password and revokes other sessions`() = runTest {
        val a = register()
        val other = s.login("ala@example.com", pw, "android", "Tablet", null, "1.1.1.1")
        assertEquals("wrong_password", code { s.changePassword(a.profile.accountId, a.session.sessionId, "nope-nope-nope", "new-password-123") })
        assertEquals("validation_failed", code { s.changePassword(a.profile.accountId, a.session.sessionId, pw, "short") })
        s.changePassword(a.profile.accountId, a.session.sessionId, pw, "new-password-123")
        assertTrue(s.isSessionActive(a.session.sessionId, a.profile.accountId))
        assertFalse(s.isSessionActive(other.session.sessionId, a.profile.accountId))
        assertEquals("invalid_credentials", code { s.login("ala@example.com", pw, "android", null, null, "1.1.1.1") })
        s.login("ala@example.com", "new-password-123", "android", null, null, "1.1.1.1")
    }

    @Test
    fun `password reset is single use expires and revokes sessions`() = runTest {
        val a = register()
        s.requestPasswordReset("ALA@example.com")
        val (to, token) = t.email.sent.single()
        assertEquals("ala@example.com", to)
        s.resetPassword(token, "brand-new-password")
        assertFalse(s.isSessionActive(a.session.sessionId, a.profile.accountId))
        s.login("ala@example.com", "brand-new-password", "android", null, null, "1.1.1.1")
        assertEquals("invalid_or_expired_token", code { s.resetPassword(token, "another-password-1") })
    }

    @Test
    fun `reset token expires and unknown account leaks nothing`() = runTest {
        register()
        s.requestPasswordReset("ala@example.com")
        val token = t.email.sent.single().second
        t.clock.advanceSeconds(61 * 60)
        assertEquals("invalid_or_expired_token", code { s.resetPassword(token, "brand-new-password") })
        s.requestPasswordReset("ghost@example.com") // brak wyjątku i brak maila
        assertEquals(1, t.email.sent.size)
    }

    @Test
    fun `reset requests are throttled per address`() = runTest {
        register()
        repeat(8) { s.requestPasswordReset("ala@example.com") }
        assertEquals(5, t.email.sent.size)
    }

    @Test
    fun `reset reports unavailable mail delivery honestly`() = runTest {
        val unconfigured = TestAuth(email = CapturingEmailSender(isConfigured = false))
        assertEquals("email_delivery_unavailable", assertFailsWith<ApiException> { unconfigured.service.requestPasswordReset("a@example.com") }.code)
    }
}
