package app.winkwink.server.message

import app.winkwink.server.auth.TestAuth
import app.winkwink.server.auth.testAppConfig
import app.winkwink.server.health.DatabaseHealth
import app.winkwink.server.health.HealthProbe
import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.winkwinkModule
import io.ktor.client.HttpClient
import io.ktor.client.request.header
import io.ktor.client.request.request
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.server.testing.ApplicationTestBuilder
import io.ktor.server.testing.testApplication
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

/** Testy HTTP wiadomości: uwierzytelnianie, kontrakt JSON, izolacja między kontami. */
class MessageRoutesTest {
    private val probe = HealthProbe { DatabaseHealth("up", 1, "5") }
    private val auth = TestAuth()
    private val graph = InMemoryProfileStore()
    private val messages = MessageService(InMemoryMessageStore(graph), graph)

    private fun user(nick: String): String = runBlocking {
        val r = auth.service.register("$nick@example.com", "correct-horse-battery", nick, "android", null, null)
        graph.seed(nick, id = r.profile.accountId)
        r.session.accessToken
    }

    private fun run(block: suspend ApplicationTestBuilder.() -> Unit) = testApplication {
        application { winkwinkModule(testAppConfig(), probe, auth.service, messages = messages) }
        block()
    }

    private suspend fun HttpClient.call(method: HttpMethod, path: String, token: String?, body: String? = null): HttpResponse =
        request("/api/v1$path") {
            this.method = method
            header("X-Forwarded-Proto", "https")
            token?.let { header(HttpHeaders.Authorization, "Bearer $it") }
            if (body != null) { header(HttpHeaders.ContentType, ContentType.Application.Json.toString()); setBody(body) }
        }

    private fun field(json: String, name: String) = Json.parseToJsonElement(json).jsonObject.getValue(name).jsonPrimitive.content

    @Test fun `all message routes reject anonymous callers`() = run {
        listOf(
            HttpMethod.Get to "/conversations", HttpMethod.Post to "/conversations/direct", HttpMethod.Post to "/conversations/group",
            HttpMethod.Get to "/conversations/00000000-0000-0000-0000-000000000001/messages", HttpMethod.Get to "/messages/settings",
            HttpMethod.Patch to "/messages/00000000-0000-0000-0000-000000000001",
        ).forEach { (m, p) -> assertEquals(HttpStatusCode.Unauthorized, client.call(m, p, null).status, "$m $p") }
    }

    @Test fun `direct chat flow over http`() = run {
        val alice = user("alice"); val bob = user("bobby")
        val conv = client.call(HttpMethod.Post, "/conversations/direct", alice, """{"user":"bobby"}""")
        assertEquals(HttpStatusCode.OK, conv.status)
        val id = field(conv.bodyAsText(), "id")
        val sent = client.call(HttpMethod.Post, "/conversations/$id/messages", alice, """{"body":"cześć"}""")
        assertEquals(HttpStatusCode.Created, sent.status)
        assertEquals("sent", field(sent.bodyAsText(), "status"))
        val list = client.call(HttpMethod.Get, "/conversations", bob).bodyAsText()
        val item = Json.parseToJsonElement(list).jsonObject.getValue("conversations").jsonArray.single().jsonObject
        assertEquals("1", item.getValue("unreadCount").jsonPrimitive.content)
        assertEquals("alice", item.getValue("peer").jsonObject.getValue("nickname").jsonPrimitive.content)
        assertEquals(HttpStatusCode.NoContent, client.call(HttpMethod.Post, "/conversations/$id/read", bob).status)
        assertTrue(client.call(HttpMethod.Get, "/conversations/$id/messages", alice).bodyAsText().contains("\"status\":\"read\""))
    }

    @Test fun `strangers get 404 and never see message content`() = run {
        val alice = user("alice"); user("bobby"); val carol = user("carol")
        val id = field(client.call(HttpMethod.Post, "/conversations/direct", alice, """{"user":"bobby"}""").bodyAsText(), "id")
        client.call(HttpMethod.Post, "/conversations/$id/messages", alice, """{"body":"tajne"}""")
        val r = client.call(HttpMethod.Get, "/conversations/$id/messages", carol)
        assertEquals(HttpStatusCode.NotFound, r.status)
        assertFalse(r.bodyAsText().contains("tajne"))
        assertEquals(HttpStatusCode.NotFound, client.call(HttpMethod.Post, "/conversations/$id/messages", carol, """{"body":"x"}""").status)
        assertEquals(HttpStatusCode.NotFound, client.call(HttpMethod.Get, "/conversations/not-a-uuid/messages", carol).status)
    }

    @Test fun `edit, delete and settings over http`() = run {
        val alice = user("alice"); val bob = user("bobby")
        val id = field(client.call(HttpMethod.Post, "/conversations/direct", alice, """{"user":"bobby"}""").bodyAsText(), "id")
        val mid = field(client.call(HttpMethod.Post, "/conversations/$id/messages", alice, """{"body":"liter"}""").bodyAsText(), "id")
        assertEquals(HttpStatusCode.Forbidden, client.call(HttpMethod.Patch, "/messages/$mid", bob, """{"body":"x"}""").status)
        assertEquals("poprawka", field(client.call(HttpMethod.Patch, "/messages/$mid", alice, """{"body":"poprawka"}""").bodyAsText(), "body"))
        assertEquals(HttpStatusCode.NoContent, client.call(HttpMethod.Delete, "/messages/$mid", alice).status)
        assertFalse(client.call(HttpMethod.Get, "/conversations/$id/messages", bob).bodyAsText().contains("poprawka"))
        assertEquals("true", field(client.call(HttpMethod.Patch, "/conversations/$id/settings", bob, """{"muted":true}""").bodyAsText(), "muted"))
        assertEquals("false", field(client.call(HttpMethod.Put, "/messages/settings", bob, """{"readReceipts":false}""").bodyAsText(), "readReceipts"))
    }

    @Test fun `group flow over http`() = run {
        val alice = user("alice"); val bob = user("bobby"); user("carol")
        val g = client.call(HttpMethod.Post, "/conversations/group", alice, """{"title":"Ekipa","members":["bobby"]}""")
        assertEquals(HttpStatusCode.Created, g.status)
        val id = field(g.bodyAsText(), "id")
        assertEquals(HttpStatusCode.Forbidden, client.call(HttpMethod.Post, "/conversations/$id/members", bob, """{"user":"carol"}""").status)
        assertEquals(HttpStatusCode.OK, client.call(HttpMethod.Post, "/conversations/$id/members", alice, """{"user":"carol"}""").status)
        assertEquals(HttpStatusCode.NoContent, client.call(HttpMethod.Delete, "/conversations/$id/members/carol", alice).status)
        assertEquals(HttpStatusCode.Conflict, client.call(HttpMethod.Delete, "/conversations/$id/members/alice", alice).status)
    }

    @Test fun `reactions and delivered status over http`() = run {
        val alice = user("alice"); val bob = user("bobby"); val carol = user("carol")
        val id = field(client.call(HttpMethod.Post, "/conversations/direct", alice, """{"user":"bobby"}""").bodyAsText(), "id")
        val mid = field(client.call(HttpMethod.Post, "/conversations/$id/messages", alice, """{"body":"hej"}""").bodyAsText(), "id")
        assertEquals(HttpStatusCode.BadRequest, client.call(HttpMethod.Put, "/messages/$mid/reaction", bob, """{"kind":"nope"}""").status)
        assertEquals(HttpStatusCode.NotFound, client.call(HttpMethod.Put, "/messages/$mid/reaction", carol, """{"kind":"like"}""").status)
        val reacted = client.call(HttpMethod.Put, "/messages/$mid/reaction", bob, """{"kind":"love"}""")
        assertEquals(HttpStatusCode.OK, reacted.status)
        val first = Json.parseToJsonElement(reacted.bodyAsText()).jsonObject.getValue("reactions").jsonArray.single().jsonObject
        assertEquals("love", first.getValue("kind").jsonPrimitive.content)
        assertEquals("true", first.getValue("mine").jsonPrimitive.content)
        // autor widzi reakcję, ale nie jako własną
        assertTrue(client.call(HttpMethod.Get, "/conversations/$id/messages", alice).bodyAsText().contains("\"mine\":false"))
        // Bob pobrał wiadomości → autor widzi „delivered”
        assertEquals(HttpStatusCode.OK, client.call(HttpMethod.Get, "/conversations/$id/messages", bob).status)
        assertTrue(client.call(HttpMethod.Get, "/conversations/$id/messages", alice).bodyAsText().contains("\"status\":\"delivered\""))
        assertEquals(HttpStatusCode.OK, client.call(HttpMethod.Delete, "/messages/$mid/reaction", bob).status)
        assertFalse(client.call(HttpMethod.Get, "/conversations/$id/messages", alice).bodyAsText().contains("\"kind\":\"love\""))
    }

    @Test fun `member roles over http`() = run {
        val alice = user("alice"); val bob = user("bobby"); user("carol")
        val id = field(client.call(HttpMethod.Post, "/conversations/group", alice, """{"title":"Ekipa","members":["bobby"]}""").bodyAsText(), "id")
        assertEquals(HttpStatusCode.Forbidden, client.call(HttpMethod.Put, "/conversations/$id/members/bobby/role", bob, """{"role":"admin"}""").status)
        assertEquals(HttpStatusCode.BadRequest, client.call(HttpMethod.Put, "/conversations/$id/members/bobby/role", alice, """{"role":"owner"}""").status)
        val ok = client.call(HttpMethod.Put, "/conversations/$id/members/bobby/role", alice, """{"role":"admin"}""")
        assertEquals(HttpStatusCode.OK, ok.status)
        assertTrue(ok.bodyAsText().contains("\"role\":\"admin\""))
        assertEquals(HttpStatusCode.OK, client.call(HttpMethod.Post, "/conversations/$id/members", bob, """{"user":"carol"}""").status)
    }
}
