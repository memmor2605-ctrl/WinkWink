package app.winkwink.server.message

import app.winkwink.server.api.ApiException
import app.winkwink.server.profile.InMemoryProfileStore
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.test.runTest
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

class MessageServiceTest {
    private val graph = InMemoryProfileStore()
    private val clock = object : Clock() {
        var t: Instant = Instant.parse("2026-11-22T12:00:00Z")
        override fun getZone() = ZoneOffset.UTC
        override fun withZone(zone: java.time.ZoneId?) = this
        override fun instant(): Instant { t = t.plusSeconds(1); return t }
    }
    private val service = MessageService(InMemoryMessageStore(graph), graph, clock)
    private val alice = graph.seed("alice")
    private val bob = graph.seed("bobby")
    private val carol = graph.seed("carol")
    private val dave = graph.seed("dave")

    private suspend fun direct(a: java.util.UUID, other: String) = service.startDirect(a, other).conversation.id

    @Test fun `direct conversation is created once per pair regardless of who starts`() = runTest {
        val a = direct(alice.accountId, "bobby"); val b = direct(bob.accountId, "alice")
        assertEquals(a, b)
        assertEquals("bobby", service.get(alice.accountId, a).peer?.nickname)
        assertEquals("alice", service.get(bob.accountId, a).peer?.nickname)
    }

    @Test fun `cannot message yourself, unknown users or blocked users`() = runTest {
        assertEquals(HttpStatusCode.BadRequest, assertFailsWith<ApiException> { service.startDirect(alice.accountId, "alice") }.status)
        assertEquals(HttpStatusCode.NotFound, assertFailsWith<ApiException> { service.startDirect(alice.accountId, "nobody") }.status)
        graph.addBlock(bob.accountId, alice.accountId, Instant.now())
        assertEquals(HttpStatusCode.Forbidden, assertFailsWith<ApiException> { service.startDirect(alice.accountId, "bobby") }.status)
    }

    @Test fun `sending validates body and non members get 404`() = runTest {
        val id = direct(alice.accountId, "bobby")
        assertFailsWith<ApiException> { service.send(alice.accountId, id, "   ", null) }
        assertFailsWith<ApiException> { service.send(alice.accountId, id, "x".repeat(MessageService.BODY_MAX + 1), null) }
        assertEquals(HttpStatusCode.NotFound, assertFailsWith<ApiException> { service.send(carol.accountId, id, "hej", null) }.status)
        assertEquals(HttpStatusCode.NotFound, assertFailsWith<ApiException> { service.messages(carol.accountId, id, null, null) }.status)
        assertEquals("hej", service.send(alice.accountId, id, "  hej ", null).row.body)
    }

    @Test fun `blocking after the conversation exists stops sending`() = runTest {
        val id = direct(alice.accountId, "bobby")
        service.send(alice.accountId, id, "hej", null)
        graph.addBlock(alice.accountId, bob.accountId, Instant.now())
        assertEquals(HttpStatusCode.Forbidden, assertFailsWith<ApiException> { service.send(bob.accountId, id, "halo", null) }.status)
    }

    @Test fun `reply must point to a live message of the same conversation`() = runTest {
        val id = direct(alice.accountId, "bobby"); val other = direct(alice.accountId, "carol")
        val m = service.send(alice.accountId, id, "pierwsza", null)
        assertEquals(m.row.id, service.send(bob.accountId, id, "odp", m.row.id).row.replyToId)
        assertFailsWith<ApiException> { service.send(alice.accountId, other, "odp", m.row.id) }
        service.delete(alice.accountId, m.row.id)
        assertFailsWith<ApiException> { service.send(bob.accountId, id, "odp2", m.row.id) }
    }

    @Test fun `only the author edits, and edit marks the message edited`() = runTest {
        val id = direct(alice.accountId, "bobby")
        val m = service.send(alice.accountId, id, "liter", null)
        assertEquals(HttpStatusCode.Forbidden, assertFailsWith<ApiException> { service.edit(bob.accountId, m.row.id, "x") }.status)
        val e = service.edit(alice.accountId, m.row.id, "literówka")
        assertEquals("literówka", e.row.body); assertTrue(e.row.editedAt != null)
    }

    @Test fun `deleted message hides its body and cannot be edited`() = runTest {
        val id = direct(alice.accountId, "bobby")
        val m = service.send(alice.accountId, id, "sekret", null)
        service.delete(alice.accountId, m.row.id)
        val listed = service.messages(bob.accountId, id, null, null).items.single()
        assertTrue(listed.row.deleted); assertNull(listed.row.body)
        assertEquals(HttpStatusCode.NotFound, assertFailsWith<ApiException> { service.edit(alice.accountId, m.row.id, "x") }.status)
    }

    @Test fun `in a direct chat only the author may delete`() = runTest {
        val id = direct(alice.accountId, "bobby")
        val m = service.send(alice.accountId, id, "hej", null)
        assertEquals(HttpStatusCode.Forbidden, assertFailsWith<ApiException> { service.delete(bob.accountId, m.row.id) }.status)
    }

    @Test fun `unread count and read status follow markRead`() = runTest {
        val id = direct(alice.accountId, "bobby")
        service.send(alice.accountId, id, "1", null); service.send(alice.accountId, id, "2", null)
        assertEquals(2, service.get(bob.accountId, id).unread)
        assertEquals(0, service.get(alice.accountId, id).unread)
        assertEquals("sent", service.messages(alice.accountId, id, null, null).items.first().status)
        service.markRead(bob.accountId, id)
        assertEquals(0, service.get(bob.accountId, id).unread)
        assertEquals("read", service.messages(alice.accountId, id, null, null).items.first().status)
    }

    @Test fun `read receipts can be turned off by the reader`() = runTest {
        val id = direct(alice.accountId, "bobby")
        service.send(alice.accountId, id, "1", null)
        service.setReadReceipts(bob.accountId, false)
        service.markRead(bob.accountId, id)
        assertEquals("sent", service.messages(alice.accountId, id, null, null).items.single().status)
        // wyłączenie potwierdzeń oznacza też brak widoku cudzych
        service.setReadReceipts(bob.accountId, true); service.setReadReceipts(alice.accountId, false)
        assertEquals("sent", service.messages(alice.accountId, id, null, null).items.single().status)
        assertTrue(service.readReceipts(bob.accountId)); assertFalse(service.readReceipts(alice.accountId))
    }

    @Test fun `conversation list is ordered by activity, paged, searchable and archivable`() = runTest {
        val ab = direct(alice.accountId, "bobby"); val ac = direct(alice.accountId, "carol")
        service.send(alice.accountId, ab, "stara", null)
        service.send(alice.accountId, ac, "nowa", null)
        val all = service.list(alice.accountId, false, null, 1, null)
        assertEquals(ac, all.items.single().conversation.id)
        assertEquals(ab, service.list(alice.accountId, false, null, 1, all.nextCursor).items.single().conversation.id)
        assertEquals(listOf(ab), service.list(alice.accountId, false, "BOB", null, null).items.map { it.conversation.id })
        service.setFlags(alice.accountId, ab, muted = true, archived = true)
        assertEquals(listOf(ac), service.list(alice.accountId, false, null, null, null).items.map { it.conversation.id })
        val archived = service.list(alice.accountId, true, null, null, null).items.single()
        assertEquals(ab, archived.conversation.id); assertTrue(archived.muted)
        assertFalse(service.get(bob.accountId, ab).muted)
    }

    @Test fun `group creation validates members and makes the creator owner`() = runTest {
        assertFailsWith<ApiException> { service.createGroup(alice.accountId, "Ekipa", emptyList()) }
        assertFailsWith<ApiException> { service.createGroup(alice.accountId, " ", listOf("bobby")) }
        graph.addBlock(carol.accountId, alice.accountId, Instant.now())
        assertEquals(HttpStatusCode.Forbidden, assertFailsWith<ApiException> { service.createGroup(alice.accountId, "Ekipa", listOf("bobby", "carol")) }.status)
        val g = service.createGroup(alice.accountId, "Ekipa", listOf("bobby", "bobby", "alice"))
        assertEquals("owner", g.role); assertEquals(2, g.memberCount)
    }

    @Test fun `group membership is managed only by the owner and left members lose access`() = runTest {
        val g = service.createGroup(alice.accountId, "Ekipa", listOf("bobby")).conversation.id
        assertEquals(HttpStatusCode.Forbidden, assertFailsWith<ApiException> { service.addMember(bob.accountId, g, "carol") }.status)
        assertEquals(3, service.addMember(alice.accountId, g, "carol").size)
        assertEquals(3, service.addMember(alice.accountId, g, "carol").size)
        assertEquals(HttpStatusCode.Forbidden, assertFailsWith<ApiException> { service.removeMember(bob.accountId, g, "alice") }.status)
        assertEquals(HttpStatusCode.Conflict, assertFailsWith<ApiException> { service.removeMember(alice.accountId, g, "alice") }.status)
        service.removeMember(bob.accountId, g, "bobby") // opuszczenie
        assertEquals(HttpStatusCode.NotFound, assertFailsWith<ApiException> { service.messages(bob.accountId, g, null, null) }.status)
        service.removeMember(alice.accountId, g, "carol")
        assertEquals(1, service.members(alice.accountId, g).size)
    }

    @Test fun `group admin actions are rejected on direct chats and group owner can delete others messages`() = runTest {
        val d = direct(alice.accountId, "bobby")
        assertEquals("not_a_group", assertFailsWith<ApiException> { service.addMember(alice.accountId, d, "carol") }.code)
        val g = service.createGroup(alice.accountId, "Ekipa", listOf("bobby")).conversation.id
        val m = service.send(bob.accountId, g, "hej", null)
        service.delete(alice.accountId, m.row.id)
        assertTrue(service.messages(alice.accountId, g, null, null).items.single().row.deleted)
    }

    @Test fun `non members cannot tell an existing foreign message from a missing one`() = runTest {
        val id = direct(alice.accountId, "bobby")
        val mid = service.send(alice.accountId, id, "tajne", null).row.id
        val foreign = assertFailsWith<ApiException> { service.edit(carol.accountId, mid, "x") }
        val missing = assertFailsWith<ApiException> { service.edit(carol.accountId, java.util.UUID.randomUUID(), "x") }
        assertEquals(HttpStatusCode.NotFound, foreign.status)
        assertEquals(missing.code, foreign.code)
        assertEquals(missing.code, assertFailsWith<ApiException> { service.delete(carol.accountId, mid) }.code)
    }

    @Test fun `status becomes delivered after the recipient fetches and read after markRead`() = runTest {
        val id = direct(alice.accountId, "bobby")
        service.send(alice.accountId, id, "1", null)
        assertEquals("sent", service.messages(alice.accountId, id, null, null).items.single().status)
        service.list(bob.accountId, false, null, null, null) // urządzenie Boba pobrało listę rozmów
        assertEquals("delivered", service.messages(alice.accountId, id, null, null).items.single().status)
        service.send(alice.accountId, id, "2", null)
        assertEquals("sent", service.messages(alice.accountId, id, null, null).items.first().status)
        service.markRead(bob.accountId, id)
        assertEquals("read", service.messages(alice.accountId, id, null, null).items.first().status)
    }

    @Test fun `delivered is hidden when the recipient does not share receipts`() = runTest {
        val id = direct(alice.accountId, "bobby")
        service.send(alice.accountId, id, "1", null)
        service.setReadReceipts(bob.accountId, false)
        service.messages(bob.accountId, id, null, null)
        assertEquals("sent", service.messages(alice.accountId, id, null, null).items.single().status)
    }

    @Test fun `reactions are one per person, aggregated and mine is only the viewers`() = runTest {
        val g = service.createGroup(alice.accountId, "Ekipa", listOf("bobby", "carol")).conversation.id
        val m = service.send(alice.accountId, g, "hej", null).row.id
        service.react(bob.accountId, m, "like"); service.react(carol.accountId, m, "like"); service.react(alice.accountId, m, "love")
        val seen = service.react(bob.accountId, m, "like")
        assertEquals(listOf(ReactionSummary("like", 2, true), ReactionSummary("love", 1, false)), seen.reactions)
        service.react(bob.accountId, m, "laugh") // zmiana, nie dodatkowa reakcja
        val after = service.messages(bob.accountId, g, null, null).items.single().reactions
        assertEquals(listOf(ReactionSummary("like", 1, false), ReactionSummary("laugh", 1, true), ReactionSummary("love", 1, false)).sortedWith(compareByDescending<ReactionSummary> { it.count }.thenBy { it.kind }), after)
        service.react(bob.accountId, m, null)
        assertEquals(2, service.messages(bob.accountId, g, null, null).items.single().reactions.size)
    }

    @Test fun `reaction validation, access and deleted messages`() = runTest {
        val id = direct(alice.accountId, "bobby")
        val m = service.send(alice.accountId, id, "hej", null).row.id
        assertEquals("validation_failed", assertFailsWith<ApiException> { service.react(bob.accountId, m, "<script>") }.code)
        assertEquals("message_not_found", assertFailsWith<ApiException> { service.react(carol.accountId, m, "like") }.code)
        service.react(bob.accountId, m, "like")
        graph.addBlock(bob.accountId, alice.accountId, Instant.now())
        assertEquals("user_unavailable", assertFailsWith<ApiException> { service.react(bob.accountId, m, "wow") }.code)
        service.react(bob.accountId, m, null) // cofnięcie reakcji nadal możliwe
        service.delete(alice.accountId, m)
        assertEquals("message_not_found", assertFailsWith<ApiException> { service.react(bob.accountId, m, "like") }.code)
        assertTrue(service.messages(alice.accountId, id, null, null).items.single().reactions.isEmpty())
    }

    @Test fun `only the owner changes member roles and admins can then add members`() = runTest {
        val g = service.createGroup(alice.accountId, "Ekipa", listOf("bobby", "carol")).conversation.id
        assertEquals(HttpStatusCode.Forbidden, assertFailsWith<ApiException> { service.setMemberRole(bob.accountId, g, "carol", "admin") }.status)
        assertEquals("validation_failed", assertFailsWith<ApiException> { service.setMemberRole(alice.accountId, g, "carol", "owner") }.code)
        assertEquals(HttpStatusCode.Forbidden, assertFailsWith<ApiException> { service.setMemberRole(alice.accountId, g, "alice", "member") }.status)
        val members = service.setMemberRole(alice.accountId, g, "bobby", "admin")
        assertEquals("admin", members.first { it.person.nickname == "bobby" }.role)
        assertEquals(4, service.addMember(bob.accountId, g, "dave").size)
        service.setMemberRole(alice.accountId, g, "bobby", "member")
        assertEquals(HttpStatusCode.Forbidden, assertFailsWith<ApiException> { service.addMember(bob.accountId, g, "dave") }.status)
        val d = direct(alice.accountId, "bobby")
        assertEquals("not_a_group", assertFailsWith<ApiException> { service.setMemberRole(alice.accountId, d, "bobby", "admin") }.code)
    }
}
