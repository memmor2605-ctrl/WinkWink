package app.winkwink.server.auth

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

class ValidatorsTest {
    @Test
    fun `email validation`() {
        assertNull(Validators.emailError("ala@example.com"))
        assertNull(Validators.emailError("a.b+tag@sub.example.pl"))
        listOf("", "plain", "a@b", "a@@b.com", "a b@c.com", "a..b@c.com", "@c.com").forEach {
            assertNotNull(Validators.emailError(it), "should reject '$it'")
        }
        assertNotNull(Validators.emailError("a".repeat(250) + "@x.com"))
    }

    @Test
    fun `email is trimmed and lowercased`() {
        assertEquals("ala@example.com", Validators.normalizeEmail("  Ala@Example.COM "))
    }

    @Test
    fun `nickname matches database constraint`() {
        assertNull(Validators.nicknameError("ala_01.x"))
        listOf("ab", "a".repeat(31), "ala kot", "ala-kot", "żółw123").forEach {
            assertNotNull(Validators.nicknameError(it), "should reject '$it'")
        }
    }

    @Test
    fun `password rules`() {
        assertNull(Validators.passwordError("long-enough-pass", "a@b.com"))
        assertNotNull(Validators.passwordError("short", null))
        assertNotNull(Validators.passwordError("a".repeat(129), null))
        assertNotNull(Validators.passwordError("aaaaaaaaaaaa", null))
        assertNotNull(Validators.passwordError("ala@example.com", "ala@example.com"))
        assertNotNull(Validators.passwordError("          ", null))
    }
}
