package app.winkwink.server.profile

import java.time.Instant
import java.util.UUID

/** Implementacja w pamięci wyłącznie do testów logiki serwisu/tras (nie do produkcji). */
class InMemoryProfileStore : ProfileStore {
    private val users = mutableMapOf<UUID, UserRow>()
    private class F(val follower: UUID, val followee: UUID, var status: String, val at: Instant)
    private val follows = mutableListOf<F>()
    private val blocks = mutableListOf<Triple<UUID, UUID, Instant>>()

    fun seed(nickname: String, visibility: String = "public", id: UUID = UUID.randomUUID()): UserRow {
        val u = UserRow(id, nickname, "ww_" + nickname.lowercase().padEnd(10, 'x').take(10), null, null, emptyList(), visibility, null, null)
        users[id] = u
        return u
    }

    @Synchronized override suspend fun findByIdentifier(identifier: String) =
        users.values.firstOrNull { it.winkwinkId == identifier.lowercase() || it.nickname.equals(identifier, true) }

    @Synchronized override suspend fun findById(accountId: UUID) = users[accountId]

    @Synchronized override suspend fun updateProfile(accountId: UUID, displayName: String?, bio: String?, links: List<String>, visibility: String) {
        users[accountId] = users.getValue(accountId).copy(displayName = displayName, bio = bio, links = links, visibility = visibility)
    }

    @Synchronized override suspend fun isBlockedEitherWay(a: UUID, b: UUID) =
        blocks.any { (x, y, _) -> (x == a && y == b) || (x == b && y == a) }

    @Synchronized override suspend fun hasBlocked(blocker: UUID, blocked: UUID) = blocks.any { it.first == blocker && it.second == blocked }
    @Synchronized override suspend fun followState(follower: UUID, followee: UUID) =
        follows.firstOrNull { it.follower == follower && it.followee == followee }?.status

    @Synchronized override suspend fun upsertFollow(follower: UUID, followee: UUID, status: String, now: Instant) {
        if (follows.none { it.follower == follower && it.followee == followee }) follows += F(follower, followee, status, now)
    }

    @Synchronized override suspend fun deleteFollow(follower: UUID, followee: UUID) =
        follows.removeIf { it.follower == follower && it.followee == followee }

    @Synchronized override suspend fun acceptPending(follower: UUID, followee: UUID): Boolean {
        val f = follows.firstOrNull { it.follower == follower && it.followee == followee && it.status == "pending" } ?: return false
        f.status = "accepted"; return true
    }

    @Synchronized override suspend fun rejectPending(follower: UUID, followee: UUID) =
        follows.removeIf { it.follower == follower && it.followee == followee && it.status == "pending" }

    @Synchronized override suspend fun followerCount(accountId: UUID) = follows.count { it.followee == accountId && it.status == "accepted" }
    @Synchronized override suspend fun followingCount(accountId: UUID) = follows.count { it.follower == accountId && it.status == "accepted" }

    private fun page(rows: List<Pair<UUID, Instant>>, limit: Int, after: PageCursor?): List<Edge> =
        rows.sortedWith(compareByDescending<Pair<UUID, Instant>> { it.second }.thenByDescending { it.first })
            .filter { after == null || it.second < after.at || (it.second == after.at && it.first < after.id) }
            .take(limit).mapNotNull { (id, at) -> users[id]?.let { Edge(it, at) } }

    @Synchronized override suspend fun listFollowers(accountId: UUID, limit: Int, after: PageCursor?) =
        page(follows.filter { it.followee == accountId && it.status == "accepted" }.map { it.follower to it.at }, limit, after)

    @Synchronized override suspend fun listFollowing(accountId: UUID, limit: Int, after: PageCursor?) =
        page(follows.filter { it.follower == accountId && it.status == "accepted" }.map { it.followee to it.at }, limit, after)

    @Synchronized override suspend fun listPendingRequests(accountId: UUID, limit: Int, after: PageCursor?) =
        page(follows.filter { it.followee == accountId && it.status == "pending" }.map { it.follower to it.at }, limit, after)

    @Synchronized override suspend fun addBlock(blocker: UUID, blocked: UUID, now: Instant) {
        if (blocks.none { it.first == blocker && it.second == blocked }) blocks += Triple(blocker, blocked, now)
        follows.removeIf { (it.follower == blocker && it.followee == blocked) || (it.follower == blocked && it.followee == blocker) }
    }

    @Synchronized override suspend fun removeBlock(blocker: UUID, blocked: UUID) = blocks.removeIf { it.first == blocker && it.second == blocked }
    @Synchronized override suspend fun listBlocks(blocker: UUID, limit: Int, after: PageCursor?) =
        page(blocks.filter { it.first == blocker }.map { it.second to it.third }, limit, after)

    @Synchronized override suspend fun search(viewer: UUID, query: String, limit: Int) =
        users.values.filter { it.accountId != viewer && !isBlockedSync(viewer, it.accountId) && it.nickname.startsWith(query, true) }
            .sortedBy { it.nickname.lowercase() }.take(limit)

    private fun isBlockedSync(a: UUID, b: UUID) = blocks.any { (x, y, _) -> (x == a && y == b) || (x == b && y == a) }

    private val mutes = mutableListOf<Triple<UUID, UUID, Instant>>()

    @Synchronized override suspend fun setAvatarKey(accountId: UUID, key: String?): String? {
        val u = users.getValue(accountId); users[accountId] = u.copy(avatarObjectKey = key); return u.avatarObjectKey
    }

    @Synchronized override suspend fun setBackgroundKey(accountId: UUID, key: String?): String? {
        val u = users.getValue(accountId); users[accountId] = u.copy(backgroundObjectKey = key); return u.backgroundObjectKey
    }

    @Synchronized override suspend fun setHideFollowLists(accountId: UUID, hide: Boolean) {
        users[accountId] = users.getValue(accountId).copy(hideFollowLists = hide)
    }

    @Synchronized override suspend fun addMute(muter: UUID, muted: UUID, now: Instant) {
        if (mutes.none { it.first == muter && it.second == muted }) mutes += Triple(muter, muted, now)
    }

    @Synchronized override suspend fun removeMute(muter: UUID, muted: UUID) = mutes.removeIf { it.first == muter && it.second == muted }
    @Synchronized override suspend fun isMuted(muter: UUID, muted: UUID) = mutes.any { it.first == muter && it.second == muted }
    @Synchronized override suspend fun listMutes(muter: UUID, limit: Int, after: PageCursor?) =
        page(mutes.filter { it.first == muter }.map { it.second to it.third }, limit, after)
}
