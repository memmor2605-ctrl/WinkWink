package app.winkwink.server.profile

import app.winkwink.server.api.ApiException
import app.winkwink.server.media.InMemoryMediaStorage
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.test.runTest
import java.awt.image.BufferedImage
import java.io.ByteArrayOutputStream
import javax.imageio.ImageIO
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class ProfileMediaAndMuteTest {
    private val store = InMemoryProfileStore()
    private val service = ProfileService(store)
    private val storage = InMemoryMediaStorage()
    private val media = ProfileMediaService(store, service, storage)
    private val alice = store.seed("alice")
    private val bob = store.seed("bob")
    private val priv = store.seed("private_pat", visibility = "private")

    private fun jpeg(w: Int = 50, h: Int = 50) =
        ByteArrayOutputStream().also { ImageIO.write(BufferedImage(w, h, BufferedImage.TYPE_INT_RGB), "jpg", it) }.toByteArray()

    private suspend fun assertApi(status: HttpStatusCode, code: String, block: suspend () -> Unit) {
        val e = assertFailsWith<ApiException> { block() }
        assertEquals(status, e.status); assertEquals(code, e.code)
    }

    // ---- avatar / tło ----

    @Test fun `upload stores file outside the database and sets key`() = runTest {
        val view = media.upload(alice.accountId, ProfileImageKind.AVATAR, jpeg())
        assertNotNull(view.user.avatarObjectKey)
        assertEquals(1, storage.files.size)
        assertTrue(view.toDto().hasAvatar)
        assertNotNull(view.toDto().avatarTag)
    }

    @Test fun `replacing avatar deletes the previous file`() = runTest {
        media.upload(alice.accountId, ProfileImageKind.AVATAR, jpeg())
        val first = storage.files.keys.single()
        media.upload(alice.accountId, ProfileImageKind.AVATAR, jpeg(60, 60))
        assertEquals(1, storage.files.size)
        assertFalse(first in storage.files)
    }

    @Test fun `remove deletes file and is idempotent`() = runTest {
        media.upload(alice.accountId, ProfileImageKind.AVATAR, jpeg())
        val v = media.remove(alice.accountId, ProfileImageKind.AVATAR)
        assertNull(v.user.avatarObjectKey); assertTrue(storage.files.isEmpty())
        media.remove(alice.accountId, ProfileImageKind.AVATAR)
    }

    @Test fun `rejects non image, oversized and empty uploads`() = runTest {
        assertApi(HttpStatusCode.UnsupportedMediaType, "unsupported_media_type") { media.upload(alice.accountId, ProfileImageKind.AVATAR, "x".repeat(100).toByteArray()) }
        assertApi(HttpStatusCode.PayloadTooLarge, "payload_too_large") { media.upload(alice.accountId, ProfileImageKind.AVATAR, ByteArray(3 * 1024 * 1024)) }
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { media.upload(alice.accountId, ProfileImageKind.AVATAR, ByteArray(0)) }
        assertTrue(storage.files.isEmpty())
    }

    @Test fun `avatar downloadable by other users even for private profile`() = runTest {
        media.upload(priv.accountId, ProfileImageKind.AVATAR, jpeg())
        val f = media.download(alice.accountId, "private_pat", ProfileImageKind.AVATAR)
        assertEquals("image/jpeg", f.mime)
    }

    @Test fun `background of private profile is hidden from non followers but visible to approved follower and owner`() = runTest {
        media.upload(priv.accountId, ProfileImageKind.BACKGROUND, jpeg(200, 100))
        assertApi(HttpStatusCode.NotFound, "media_not_found") { media.download(alice.accountId, "private_pat", ProfileImageKind.BACKGROUND) }
        store.upsertFollow(alice.accountId, priv.accountId, "accepted", java.time.Instant.now())
        assertNotNull(media.download(alice.accountId, "private_pat", ProfileImageKind.BACKGROUND))
        assertNotNull(media.download(priv.accountId, "private_pat", ProfileImageKind.BACKGROUND))
    }

    @Test fun `pending follower does not see private background`() = runTest {
        media.upload(priv.accountId, ProfileImageKind.BACKGROUND, jpeg())
        store.upsertFollow(alice.accountId, priv.accountId, "pending", java.time.Instant.now())
        assertApi(HttpStatusCode.NotFound, "media_not_found") { media.download(alice.accountId, "private_pat", ProfileImageKind.BACKGROUND) }
    }

    @Test fun `blocked user cannot download avatar and gets not found`() = runTest {
        media.upload(bob.accountId, ProfileImageKind.AVATAR, jpeg())
        store.addBlock(bob.accountId, alice.accountId, java.time.Instant.now())
        assertApi(HttpStatusCode.NotFound, "user_not_found") { media.download(alice.accountId, "bob", ProfileImageKind.AVATAR) }
    }

    @Test fun `user without avatar gets not found`() = runTest {
        assertApi(HttpStatusCode.NotFound, "media_not_found") { media.download(alice.accountId, "bob", ProfileImageKind.AVATAR) }
    }

    @Test fun `restricted view does not expose background tag`() = runTest {
        media.upload(priv.accountId, ProfileImageKind.BACKGROUND, jpeg())
        val dto = service.view(alice.accountId, "private_pat").toDto()
        assertFalse(dto.hasBackground); assertNull(dto.backgroundTag)
    }

    // ---- wyciszanie ----

    @Test fun `mute is private idempotent and listed`() = runTest {
        service.mute(alice.accountId, "bob"); service.mute(alice.accountId, "bob")
        assertEquals(listOf("bob"), service.muted(alice.accountId, null, null).items.map { it.user.nickname })
        assertTrue(service.view(alice.accountId, "bob").muted)
        // wyciszany nie widzi żadnego śladu
        assertFalse(service.view(bob.accountId, "alice").muted)
        assertEquals(0, service.muted(bob.accountId, null, null).items.size)
    }

    @Test fun `unmute restores and does not block or unfollow`() = runTest {
        service.follow(alice.accountId, "bob")
        service.mute(alice.accountId, "bob")
        assertEquals("accepted", service.view(alice.accountId, "bob").relationship.following)
        service.unmute(alice.accountId, "bob"); service.unmute(alice.accountId, "bob")
        assertFalse(service.view(alice.accountId, "bob").muted)
        assertFalse(store.hasBlocked(alice.accountId, bob.accountId))
    }

    @Test fun `cannot mute self or missing user`() = runTest {
        assertApi(HttpStatusCode.BadRequest, "cannot_mute_self") { service.mute(alice.accountId, "alice") }
        assertApi(HttpStatusCode.NotFound, "user_not_found") { service.mute(alice.accountId, "nobody") }
    }

    @Test fun `muting does not give the muted user any signal in follow flows`() = runTest {
        service.mute(alice.accountId, "bob")
        assertEquals("accepted", service.follow(bob.accountId, "alice")) // nadal może obserwować i widzieć profil
        assertFalse(service.view(bob.accountId, "alice").restricted())
    }

    // ---- ukrywanie list ----

    @Test fun `hidden follow lists are forbidden for others but visible for owner`() = runTest {
        service.follow(alice.accountId, "bob")
        service.updateMine(bob.accountId, null, null, null, null, hideFollowLists = true)
        assertApi(HttpStatusCode.Forbidden, "follow_lists_hidden") { service.followers(alice.accountId, "bob", null, null) }
        assertApi(HttpStatusCode.Forbidden, "follow_lists_hidden") { service.following(alice.accountId, "bob", null, null) }
        assertEquals(1, service.followers(bob.accountId, "bob", null, null).items.size)
        assertTrue(service.view(bob.accountId, "bob").toDto().followListsHidden)
        service.updateMine(bob.accountId, null, null, null, null, hideFollowLists = false)
        assertEquals(1, service.followers(alice.accountId, "bob", null, null).items.size)
    }

    private fun UserView.restricted() = !full
}
