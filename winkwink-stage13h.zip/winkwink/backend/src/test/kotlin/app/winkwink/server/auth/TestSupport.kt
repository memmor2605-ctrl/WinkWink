package app.winkwink.server.auth

import app.winkwink.server.config.AppConfig
import app.winkwink.server.config.AuthConfig
import app.winkwink.server.config.DatabaseConfig
import app.winkwink.server.config.Environment
import java.time.Clock
import java.time.Instant
import java.time.ZoneId
import java.util.UUID

class MutableClock(var now: Instant = Instant.parse("2026-11-21T12:00:00Z")) : Clock() {
    override fun getZone(): ZoneId = ZoneId.of("UTC")
    override fun withZone(zone: ZoneId?): Clock = this
    override fun instant(): Instant = now
    fun advanceSeconds(s: Long) { now = now.plusSeconds(s) }
}

class CapturingEmailSender(override val isConfigured: Boolean = true) : EmailSender {
    val sent = mutableListOf<Pair<String, String>>()
    override suspend fun sendPasswordReset(toEmail: String, resetToken: String) {
        if (!isConfigured) UnavailableEmailSender().sendPasswordReset(toEmail, resetToken)
        sent += toEmail to resetToken
    }
}

val testAuthConfig = AuthConfig(
    jwtSecret = "unit-test-secret-unit-test-secret-1234",
    authRateLimitPerMinute = 10_000,
)

fun testAppConfig() = AppConfig(
    environment = Environment.DEVELOPMENT,
    host = "127.0.0.1",
    port = 8080,
    tls = null,
    trustProxy = true,
    database = DatabaseConfig("jdbc:postgresql://localhost/test", "u", "p", 2, false),
    rateLimitPerMinute = 10_000,
    auth = testAuthConfig,
)

class TestAuth(
    val clock: MutableClock = MutableClock(),
    val store: InMemoryAuthStore = InMemoryAuthStore(),
    val email: CapturingEmailSender = CapturingEmailSender(),
) {
    // Lekkie parametry Argon2 wyłącznie na potrzeby szybkich testów.
    val service = AuthService(
        store = store,
        hasher = Argon2idPasswordHasher(memoryKb = 64, iterations = 1, parallelism = 1),
        tokens = TokenService(testAuthConfig, clock),
        email = email,
        config = testAuthConfig,
        clock = clock,
    )
}

private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

/** Implementacja w pamięci — tylko do testów logiki serwisu i tras (nie do produkcji). */
class InMemoryAuthStore : AuthStore {
    private class Sess(
        val id: UUID, val accountId: UUID, var hash: String, var prev: String?, val created: Instant,
        var lastUsed: Instant, var expires: Instant, var revoked: Instant?, val platform: String,
        val device: String?, val ua: String?,
    )

    private val accounts = mutableMapOf<UUID, Account>()
    private val profiles = mutableMapOf<UUID, ProfileRecord>()
    private val sessions = mutableMapOf<UUID, Sess>()
    private val attempts = mutableListOf<Pair<String, Instant>>()
    private class Reset(val accountId: UUID, val expires: Instant, var used: Boolean)
    private val resets = mutableMapOf<String, Reset>()

    @Synchronized override suspend fun createAccount(email: String, passwordHash: String, nickname: String, winkwinkId: String): Account {
        if (accounts.values.any { it.email.equals(email, true) }) throw DuplicateException("email")
        if (profiles.values.any { it.nickname.equals(nickname, true) }) throw DuplicateException("nickname")
        if (profiles.values.any { it.winkwinkId == winkwinkId }) throw DuplicateException("winkwink_id")
        val acc = Account(UUID.randomUUID(), email, passwordHash, "active")
        accounts[acc.id] = acc
        profiles[acc.id] = ProfileRecord(acc.id, nickname, winkwinkId, null, "public")
        return acc
    }

    @Synchronized override suspend fun findAccountByEmail(email: String) = accounts.values.firstOrNull { it.email.equals(email, true) }
    @Synchronized override suspend fun findAccountById(id: UUID) = accounts[id]
    @Synchronized override suspend fun findProfile(accountId: UUID) = profiles[accountId]
    @Synchronized override suspend fun updatePasswordHash(accountId: UUID, passwordHash: String) {
        accounts[accountId] = accounts.getValue(accountId).copy(passwordHash = passwordHash)
    }

    fun setStatus(accountId: UUID, status: String) {
        accounts[accountId] = accounts.getValue(accountId).copy(status = status)
    }

    @Synchronized override suspend fun createSession(
        accountId: UUID, platform: String, deviceName: String?, userAgent: String?,
        refreshHash: ByteArray, now: Instant, expiresAt: Instant,
    ): UUID {
        val id = UUID.randomUUID()
        sessions[id] = Sess(id, accountId, hex(refreshHash), null, now, now, expiresAt, null, platform, deviceName, userAgent)
        return id
    }

    @Synchronized override suspend fun findSessionByRefreshHash(hash: ByteArray): FoundSession? {
        val h = hex(hash)
        val s = sessions.values.firstOrNull { it.hash == h || it.prev == h } ?: return null
        return FoundSession(s.id, s.accountId, s.expires, s.revoked, s.hash == h)
    }

    @Synchronized override suspend fun rotateSession(
        sessionId: UUID, expectedCurrentHash: ByteArray, newHash: ByteArray, now: Instant, newExpiresAt: Instant,
    ): Boolean {
        val s = sessions[sessionId] ?: return false
        if (s.hash != hex(expectedCurrentHash) || s.revoked != null) return false
        s.prev = s.hash; s.hash = hex(newHash); s.lastUsed = now; s.expires = newExpiresAt
        return true
    }

    @Synchronized override suspend fun isSessionActive(sessionId: UUID, accountId: UUID, now: Instant): Boolean {
        val s = sessions[sessionId] ?: return false
        return s.accountId == accountId && s.revoked == null && s.expires.isAfter(now) && accounts[accountId]?.status == "active"
    }

    @Synchronized override suspend fun revokeSession(sessionId: UUID, accountId: UUID, now: Instant): Boolean {
        val s = sessions[sessionId] ?: return false
        if (s.accountId != accountId || s.revoked != null) return false
        s.revoked = now
        return true
    }

    @Synchronized override suspend fun revokeSessionById(sessionId: UUID, now: Instant) {
        sessions[sessionId]?.let { if (it.revoked == null) it.revoked = now }
    }

    @Synchronized override suspend fun revokeAllSessions(accountId: UUID, exceptSessionId: UUID?, now: Instant): Int {
        val targets = sessions.values.filter { it.accountId == accountId && it.revoked == null && it.id != exceptSessionId }
        targets.forEach { it.revoked = now }
        return targets.size
    }

    @Synchronized override suspend fun listSessions(accountId: UUID, now: Instant) =
        sessions.values.filter { it.accountId == accountId && it.revoked == null && it.expires.isAfter(now) }
            .map { SessionView(it.id, it.platform, it.device, it.created, it.lastUsed, it.ua) }

    @Synchronized override suspend fun recordAttempt(keyHash: String, at: Instant) { attempts += keyHash to at }
    @Synchronized override suspend fun countAttempts(keyHash: String, since: Instant) =
        attempts.count { it.first == keyHash && !it.second.isBefore(since) }
    @Synchronized override suspend fun clearAttempts(keyHash: String) { attempts.removeAll { it.first == keyHash } }

    @Synchronized override suspend fun createResetToken(accountId: UUID, tokenHash: ByteArray, now: Instant, expiresAt: Instant) {
        resets.values.filter { it.accountId == accountId }.forEach { it.used = true }
        resets[hex(tokenHash)] = Reset(accountId, expiresAt, false)
    }

    @Synchronized override suspend fun consumeResetToken(tokenHash: ByteArray, now: Instant): UUID? {
        val r = resets[hex(tokenHash)] ?: return null
        if (r.used || !r.expires.isAfter(now)) return null
        r.used = true
        return r.accountId
    }
}
