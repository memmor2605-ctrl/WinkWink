package app.winkwink.server.community

import app.winkwink.server.api.ApiException
import app.winkwink.server.feed.FeedService
import app.winkwink.server.feed.InMemoryFeedStore
import app.winkwink.server.notification.NotificationEvent
import app.winkwink.server.notification.NotificationTypes
import app.winkwink.server.notification.Notifier
import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.profile.ProfileService
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.runBlocking
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import java.util.UUID
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertTrue

/** Etap C: przekazanie własności, wyszukiwanie do zaproszeń, powiadomienia o zaproszeniach, wyciszanie. Napisane, niewykonane. */
class CommunityManagementTest {
    private val profiles = InMemoryProfileStore()
    private val store = InMemoryCommunityStore(profiles)
    private val events = mutableListOf<NotificationEvent>()
    private val notifier = object : Notifier { override suspend fun notify(event: NotificationEvent) { events += event } }
    private val clock = Clock.fixed(Instant.parse("2026-11-24T12:00:00Z"), ZoneOffset.UTC)
    private val service = CommunityService(store, profiles, clock, notifier)
    private val feed = FeedService(InMemoryFeedStore(profiles, store), ProfileService(profiles, clock), clock)

    private val owner = profiles.seed("owner")
    private val admin = profiles.seed("adam")
    private val mod = profiles.seed("moda")
    private val member = profiles.seed("maria")
    private val other = profiles.seed("marek")
    private val outsider = profiles.seed("olek")

    private fun <T> run(block: suspend () -> T): T = runBlocking { block() }
    private fun fails(status: HttpStatusCode, code: String? = null, block: suspend () -> Unit) {
        val e = assertFailsWith<ApiException> { runBlocking { block() } }
        assertEquals(status, e.status); if (code != null) assertEquals(code, e.code)
    }

    private fun populated(type: String = "public"): UUID {
        val id = run { service.create(owner.accountId, "Kotlin Fans", "", "", type) }.community.id
        run {
            store.addMember(id, admin.accountId, "admin", Instant.EPOCH)
            store.addMember(id, mod.accountId, "moderator", Instant.EPOCH)
            store.addMember(id, member.accountId, "member", Instant.EPOCH)
            store.addMember(id, other.accountId, "member", Instant.EPOCH)
        }
        return id
    }

    // ---------- przekazanie własności ----------

    @Test fun ownerTransfersOwnershipAndBecomesAdmin() {
        val id = populated()
        run { service.transferOwnership(owner.accountId, id, "maria") }
        assertEquals("owner", run { store.roleOf(id, member.accountId) })
        assertEquals("admin", run { store.roleOf(id, owner.accountId) })
        assertEquals(member.accountId, run { store.find(id) }!!.ownerId)
        // Nowy właściciel ma pełną kontrolę, dawny nie może już usunąć społeczności.
        fails(HttpStatusCode.Forbidden) { service.delete(owner.accountId, id) }
        run { service.delete(member.accountId, id) }
    }

    @Test fun onlyOwnerCanTransferAndOnlyToMember() {
        val id = populated()
        for (actor in listOf(admin, mod, member)) fails(HttpStatusCode.Forbidden) { service.transferOwnership(actor.accountId, id, "maria") }
        fails(HttpStatusCode.NotFound, "not_member") { service.transferOwnership(owner.accountId, id, "olek") }
        fails(HttpStatusCode.BadRequest) { service.transferOwnership(owner.accountId, id, "owner") }
        fails(HttpStatusCode.NotFound, "user_not_found") { service.transferOwnership(owner.accountId, id, "nobody") }
    }

    @Test fun exactlyOneOwnerAfterTransfer() {
        val id = populated()
        run { service.transferOwnership(owner.accountId, id, "adam") }
        val roles = listOf(owner, admin, mod, member, other).map { run { store.roleOf(id, it.accountId) } }
        assertEquals(1, roles.count { it == "owner" })
    }

    // ---------- wyszukiwanie do zaproszeń ----------

    @Test fun inviteCandidatesExcludeMembersAndMarkInvited() {
        val id = populated("invite")
        run { service.invite(mod.accountId, id, "olek") }
        val byPrefix = run { service.inviteCandidates(mod.accountId, id, "ol") }
        assertEquals(listOf("olek" to true), byPrefix.map { it.first.nickname to it.second })
        // Członkowie nie występują w wynikach.
        assertTrue(run { service.inviteCandidates(mod.accountId, id, "mar") }.none { it.first.nickname == "maria" || it.first.nickname == "marek" })
    }

    @Test fun inviteCandidatesRequireModeratorAndQueryLength() {
        val id = populated()
        fails(HttpStatusCode.Forbidden) { service.inviteCandidates(member.accountId, id, "ol") }
        fails(HttpStatusCode.NotFound) { service.inviteCandidates(outsider.accountId, UUID.randomUUID(), "ol") }
        fails(HttpStatusCode.BadRequest) { service.inviteCandidates(mod.accountId, id, "o") }
    }

    @Test fun blockedUsersAreNotOfferedAsCandidates() {
        val id = populated()
        run { profiles.addBlock(outsider.accountId, mod.accountId, Instant.EPOCH) }
        assertTrue(run { service.inviteCandidates(mod.accountId, id, "ol") }.isEmpty())
    }

    // ---------- powiadomienia o zaproszeniach ----------

    @Test fun acceptingInviteNotifiesInviter() {
        val id = populated("invite")
        run { service.invite(mod.accountId, id, "olek") }
        assertEquals(NotificationTypes.COMMUNITY_INVITE, events.last().type)
        run { service.respondToInvite(outsider.accountId, id, true) }
        val e = events.last()
        assertEquals(NotificationTypes.COMMUNITY_INVITE_ACCEPTED, e.type)
        assertEquals(mod.accountId, e.recipient); assertEquals(outsider.accountId, e.actor); assertEquals(id, e.communityId)
    }

    @Test fun decliningInviteDoesNotNotify() {
        val id = populated("invite")
        run { service.invite(mod.accountId, id, "olek") }
        val before = events.size
        run { service.respondToInvite(outsider.accountId, id, false) }
        assertEquals(before, events.size)
    }

    @Test fun approvingRequestNotifiesRequester() {
        val id = populated("private")
        run { service.join(outsider.accountId, id) }
        run { service.decideRequest(mod.accountId, id, "olek", true) }
        val e = events.last()
        assertEquals(NotificationTypes.COMMUNITY_REQUEST_APPROVED, e.type); assertEquals(outsider.accountId, e.recipient)
        val before = events.size
        val other2 = profiles.seed("ola")
        run { service.join(other2.accountId, id) }
        run { service.decideRequest(mod.accountId, id, "ola", false) }
        assertEquals(before, events.size)
    }

    // ---------- wyciszanie ----------

    @Test fun mutingFollowsRankRules() {
        val id = populated()
        run { service.setMuted(mod.accountId, id, "maria", true) }
        fails(HttpStatusCode.Forbidden) { service.setMuted(mod.accountId, id, "adam", true) }   // wyżej w randze
        fails(HttpStatusCode.Forbidden) { service.setMuted(mod.accountId, id, "owner", true) }
        fails(HttpStatusCode.Forbidden) { service.setMuted(member.accountId, id, "marek", true) } // zwykły członek
        fails(HttpStatusCode.Forbidden) { service.setMuted(mod.accountId, id, "moda", true) }    // równy / sam siebie
        fails(HttpStatusCode.NotFound, "not_member") { service.setMuted(mod.accountId, id, "olek", true) }
        run { service.setMuted(owner.accountId, id, "adam", true) }
    }

    @Test fun mutedFlagIsVisibleOnlyToModerators() {
        val id = populated()
        run { service.setMuted(mod.accountId, id, "maria", true) }
        val forMod = run { service.members(mod.accountId, id, 50, null) }.items.first { it.nickname == "maria" }
        assertTrue(forMod.muted)
        val forMember = run { service.members(other.accountId, id, 50, null) }.items.first { it.nickname == "maria" }
        assertFalse(forMember.muted)
    }

    @Test fun mutedMemberCannotPostOrCommentInCommunityButCanReadAndUnmute() {
        val id = populated()
        val channel = run { service.channels(owner.accountId, id) }.first().id.toString()
        val post = run { feed.create(owner.accountId, "hello", "community", false, id.toString(), channel) }
        run { service.setMuted(mod.accountId, id, "maria", true) }
        fails(HttpStatusCode.Forbidden, "muted_in_community") { feed.create(member.accountId, "x", "community", false, id.toString(), channel) }
        fails(HttpStatusCode.Forbidden, "muted_in_community") { feed.addComment(member.accountId, post.id, null, "hi") }
        run { feed.get(member.accountId, post.id) } // czytanie dozwolone
        // Wyciszenie dotyczy tylko tej społeczności — zwykły post publiczny nadal działa.
        run { feed.create(member.accountId, "public post", "public", false) }
        run { service.setMuted(mod.accountId, id, "maria", false) }
        run { feed.create(member.accountId, "x", "community", false, id.toString(), channel) }
    }
}
