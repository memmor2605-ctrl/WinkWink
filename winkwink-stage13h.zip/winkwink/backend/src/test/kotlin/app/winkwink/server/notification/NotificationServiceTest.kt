package app.winkwink.server.notification

import app.winkwink.server.api.ApiException
import app.winkwink.server.community.CommunityService
import app.winkwink.server.community.InMemoryCommunityStore
import app.winkwink.server.feed.FeedService
import app.winkwink.server.feed.InMemoryFeedStore
import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.profile.ProfileService
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.test.runTest
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** Powiadomienia wywoływane rzeczywistymi zdarzeniami serwisów (follow, reakcje, komentarze, zaproszenia). */
class NotificationServiceTest {
    private val graph = InMemoryProfileStore()
    private val clock = object : Clock() {
        var t: Instant = Instant.parse("2026-11-21T12:00:00Z")
        override fun getZone() = ZoneOffset.UTC
        override fun withZone(zone: java.time.ZoneId?) = this
        override fun instant(): Instant { t = t.plusSeconds(1); return t }
    }
    private val store = InMemoryNotificationStore(graph)
    private val notifications = NotificationService(store, graph, clock)
    private val profiles = ProfileService(graph, clock, notifications)
    private val communityStore = InMemoryCommunityStore(graph)
    private val communities = CommunityService(communityStore, graph, clock, notifications)
    private val feed = FeedService(InMemoryFeedStore(graph, communityStore), profiles, clock, notifications)

    private val alice = graph.seed("alice")
    private val bob = graph.seed("bobby")
    private val carol = graph.seed("carol")
    private val privateDan = graph.seed("dan", visibility = "private")

    private suspend fun inbox(u: java.util.UUID, type: String? = null, unread: Boolean = false) = notifications.list(u, type, unread, 50, null)

    @Test fun `following a public profile notifies as new follower, a private one as request`() = runTest {
        profiles.follow(bob.accountId, alice.nickname)
        profiles.follow(bob.accountId, privateDan.nickname)
        assertEquals(listOf(NotificationTypes.NEW_FOLLOWER), inbox(alice.accountId).items.map { it.type })
        assertEquals(listOf(NotificationTypes.FOLLOW_REQUEST), inbox(privateDan.accountId).items.map { it.type })
        assertEquals(bob.winkwinkId, inbox(alice.accountId).items.single().actorWinkwinkId)
    }

    @Test fun `refollowing does not spam`() = runTest {
        profiles.follow(bob.accountId, alice.nickname)
        profiles.unfollow(bob.accountId, alice.nickname)
        profiles.follow(bob.accountId, alice.nickname)
        assertEquals(1, inbox(alice.accountId).items.size)
    }

    @Test fun `reaction notifies the author but never yourself`() = runTest {
        val post = feed.create(alice.accountId, "hej", "public", false)
        feed.react(alice.accountId, post.id, "like")
        assertTrue(inbox(alice.accountId).items.isEmpty())
        feed.react(bob.accountId, post.id, "like")
        feed.react(bob.accountId, post.id, "love") // zmiana reakcji nie tworzy drugiego powiadomienia
        val n = inbox(alice.accountId).items.single()
        assertEquals(NotificationTypes.REACTION, n.type); assertEquals(post.id, n.postId)
    }

    @Test fun `anonymous post author is notified and only the reactor is named`() = runTest {
        val post = feed.create(alice.accountId, "sekret", "public", true)
        feed.react(bob.accountId, post.id, "like")
        val n = inbox(alice.accountId).items.single()
        assertEquals(bob.nickname, n.actorNickname)
        assertTrue(inbox(bob.accountId).items.isEmpty()) // reagujący nie dowiaduje się niczego o autorze
        assertTrue(inbox(carol.accountId).items.isEmpty())
    }

    @Test fun `comment notifies post author and reply notifies parent author plus post author`() = runTest {
        val post = feed.create(alice.accountId, "post", "public", false)
        val c1 = feed.addComment(bob.accountId, post.id, null, "komentarz")
        assertEquals(listOf(NotificationTypes.COMMENT), inbox(alice.accountId).items.map { it.type })
        feed.addComment(carol.accountId, post.id, c1.id, "odpowiedź")
        assertEquals(listOf(NotificationTypes.REPLY), inbox(bob.accountId).items.map { it.type })
        assertEquals(2, inbox(alice.accountId, NotificationTypes.COMMENT).items.size)
    }

    @Test fun `reply by someone to the post author's own comment gives a single reply notification`() = runTest {
        val post = feed.create(alice.accountId, "post", "public", false)
        val c1 = feed.addComment(alice.accountId, post.id, null, "mój komentarz")
        feed.addComment(bob.accountId, post.id, c1.id, "odp")
        assertEquals(listOf(NotificationTypes.REPLY), inbox(alice.accountId).items.map { it.type })
    }

    @Test fun `no notifications between blocked users`() = runTest {
        val post = feed.create(alice.accountId, "post", "public", false)
        graph.addBlock(alice.accountId, bob.accountId, clock.instant())
        assertFailsWith<ApiException> { feed.react(bob.accountId, post.id, "like") } // zablokowany nie widzi posta
        profiles.follow(carol.accountId, alice.nickname)
        assertEquals(1, inbox(alice.accountId).items.size)
    }

    @Test fun `blocking later hides existing notifications from that actor`() = runTest {
        profiles.follow(bob.accountId, alice.nickname)
        assertEquals(1, inbox(alice.accountId).items.size)
        graph.addBlock(alice.accountId, bob.accountId, clock.instant())
        assertTrue(inbox(alice.accountId).items.isEmpty()); assertEquals(0, notifications.unreadCount(alice.accountId))
    }

    @Test fun `disabled types are not delivered and settings update partially`() = runTest {
        assertTrue(notifications.settings(alice.accountId).values.all { it })
        notifications.updateSettings(alice.accountId, mapOf(NotificationTypes.NEW_FOLLOWER to false))
        profiles.follow(bob.accountId, alice.nickname)
        assertTrue(inbox(alice.accountId).items.isEmpty())
        val after = notifications.updateSettings(alice.accountId, mapOf(NotificationTypes.REACTION to false))
        assertEquals(false, after[NotificationTypes.NEW_FOLLOWER]); assertEquals(false, after[NotificationTypes.REACTION]); assertEquals(true, after[NotificationTypes.COMMENT])
        notifications.updateSettings(alice.accountId, mapOf(NotificationTypes.NEW_FOLLOWER to true))
        profiles.unfollow(bob.accountId, alice.nickname); profiles.follow(bob.accountId, alice.nickname)
        assertEquals(1, inbox(alice.accountId).items.size)
    }

    @Test fun `unknown types are rejected`() = runTest {
        val e = assertFailsWith<ApiException> { notifications.updateSettings(alice.accountId, mapOf("spam" to true)) }
        assertEquals(HttpStatusCode.BadRequest, e.status)
        assertFailsWith<ApiException> { notifications.list(alice.accountId, "spam", false, null, null) }
        assertFailsWith<ApiException> { notifications.markAllRead(alice.accountId, "spam") }
    }

    @Test fun `community invite notifies the invitee`() = runTest {
        val cid = communities.create(alice.accountId, "Rowery", "", "", "invite").community.id
        communities.invite(alice.accountId, cid, bob.nickname)
        val n = inbox(bob.accountId).items.single()
        assertEquals(NotificationTypes.COMMUNITY_INVITE, n.type); assertEquals(cid, n.communityId); assertEquals(alice.nickname, n.actorNickname)
        communities.invite(alice.accountId, cid, bob.nickname) // idempotentne
        assertEquals(1, inbox(bob.accountId).items.size)
    }

    @Test fun `read state, filters and unread count`() = runTest {
        profiles.follow(bob.accountId, alice.nickname)
        val post = feed.create(alice.accountId, "p", "public", false)
        feed.react(carol.accountId, post.id, "like")
        assertEquals(2, notifications.unreadCount(alice.accountId))
        val first = inbox(alice.accountId).items.first()
        notifications.markRead(alice.accountId, first.id)
        notifications.markRead(alice.accountId, first.id) // idempotentne
        assertEquals(1, notifications.unreadCount(alice.accountId))
        assertEquals(1, inbox(alice.accountId, unread = true).items.size)
        assertEquals(1, inbox(alice.accountId, NotificationTypes.NEW_FOLLOWER).items.size)
        notifications.markAllRead(alice.accountId, null)
        assertEquals(0, notifications.unreadCount(alice.accountId))
        assertEquals(2, inbox(alice.accountId).items.size)
    }

    @Test fun `marking someone else's notification is a 404 and changes nothing`() = runTest {
        profiles.follow(bob.accountId, alice.nickname)
        val id = inbox(alice.accountId).items.single().id
        val e = assertFailsWith<ApiException> { notifications.markRead(carol.accountId, id) }
        assertEquals(HttpStatusCode.NotFound, e.status)
        assertEquals(1, notifications.unreadCount(alice.accountId))
        assertFailsWith<ApiException> { notifications.markRead(alice.accountId, java.util.UUID.randomUUID()) }
    }

    @Test fun `markAllRead by type leaves other types unread`() = runTest {
        profiles.follow(bob.accountId, alice.nickname)
        val post = feed.create(alice.accountId, "p", "public", false)
        feed.react(carol.accountId, post.id, "like")
        notifications.markAllRead(alice.accountId, NotificationTypes.REACTION)
        assertEquals(listOf(NotificationTypes.NEW_FOLLOWER), inbox(alice.accountId, unread = true).items.map { it.type })
    }

    @Test fun `listing paginates newest first`() = runTest {
        val post = feed.create(alice.accountId, "p", "public", false)
        val others = listOf(bob, carol, privateDan)
        others.forEach { feed.react(it.accountId, post.id, "like") }
        val first = notifications.list(alice.accountId, null, false, 2, null)
        assertEquals(2, first.items.size); assertNotNull(first.nextCursor)
        val second = notifications.list(alice.accountId, null, false, 2, first.nextCursor)
        assertEquals(1, second.items.size); assertNull(second.nextCursor)
        assertEquals(others.reversed().map { it.nickname }, (first.items + second.items).map { it.actorNickname })
    }

    @Test fun `a failing notification store never breaks the user action`() = runTest {
        store.failOnInsert = true
        val post = feed.create(alice.accountId, "p", "public", false)
        assertEquals(1, feed.react(bob.accountId, post.id, "like").reactions)
        assertEquals("accepted", profiles.follow(bob.accountId, alice.nickname))
        assertEquals(0, notifications.unreadCount(alice.accountId))
    }

    @Test fun `anonymous reply is delivered even if the recipient blocked the unknown author`() = runTest {
        val post = feed.create(alice.accountId, "sekret", "public", true)
        val c = feed.addComment(bob.accountId, post.id, null, "hej")
        profiles.block(bob.accountId, alice.nickname)
        feed.addComment(alice.accountId, post.id, c.id, "odp")
        val item = inbox(bob.accountId).items.single()
        assertEquals(NotificationTypes.REPLY, item.type)
        assertTrue(item.actorAnonymous)
        assertEquals(1, notifications.unreadCount(bob.accountId))
    }

    @Test fun `anonymous reply is not delivered if the author blocked the recipient`() = runTest {
        val post = feed.create(alice.accountId, "sekret", "public", true)
        val c = feed.addComment(bob.accountId, post.id, null, "hej")
        profiles.block(alice.accountId, bob.nickname)
        feed.addComment(alice.accountId, post.id, c.id, "odp")
        assertTrue(inbox(bob.accountId).items.isEmpty())
    }

    @Test fun `muted actor produces no notification but anonymous events are never filtered`() = runTest {
        graph.addMute(alice.accountId, bob.accountId, Instant.now())
        profiles.follow(bob.accountId, alice.nickname)
        assertTrue(inbox(alice.accountId).items.isEmpty())
        // zdarzenie anonimowe (autor anonimowego posta odpowiada na komentarz): wyciszenie nie może zdradzić autora
        val post = feed.create(bob.accountId, "anon", "public", true)
        val comment = feed.addComment(alice.accountId, post.id, null, "pytanie")
        feed.addComment(bob.accountId, post.id, comment.id, "odpowiedź autora")
        assertEquals(NotificationTypes.REPLY, inbox(alice.accountId).items.single { it.type == NotificationTypes.REPLY }.type)
    }
}
