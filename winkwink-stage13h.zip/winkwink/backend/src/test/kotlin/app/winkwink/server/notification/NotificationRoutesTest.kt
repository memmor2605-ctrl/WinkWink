package app.winkwink.server.notification

import app.winkwink.server.auth.TestAuth
import app.winkwink.server.auth.testAppConfig
import app.winkwink.server.feed.FeedService
import app.winkwink.server.feed.InMemoryFeedStore
import app.winkwink.server.health.DatabaseHealth
import app.winkwink.server.health.HealthProbe
import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.profile.ProfileService
import app.winkwink.server.winkwinkModule
import io.ktor.client.HttpClient
import io.ktor.client.request.header
import io.ktor.client.request.request
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.server.testing.ApplicationTestBuilder
import io.ktor.server.testing.testApplication
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

/** Testy HTTP powiadomień: uwierzytelnianie, kontrakt JSON, izolacja między kontami. */
class NotificationRoutesTest {
    private val probe = HealthProbe { DatabaseHealth("up", 1, "5") }
    private val auth = TestAuth()
    private val graph = InMemoryProfileStore()
    private val notifications = NotificationService(InMemoryNotificationStore(graph), graph)
    private val profiles = ProfileService(graph, notifier = notifications)
    private val feed = FeedService(InMemoryFeedStore(graph), profiles, notifier = notifications)

    private fun user(nick: String): String = runBlocking {
        val r = auth.service.register("$nick@example.com", "correct-horse-battery", nick, "android", null, null)
        graph.seed(nick, id = r.profile.accountId)
        r.session.accessToken
    }

    private fun run(block: suspend ApplicationTestBuilder.() -> Unit) = testApplication {
        application { winkwinkModule(testAppConfig(), probe, auth.service, profiles, feed, null, notifications) }
        block()
    }

    private suspend fun HttpClient.call(method: HttpMethod, path: String, token: String?, body: String? = null): HttpResponse =
        request("/api/v1$path") {
            this.method = method
            header("X-Forwarded-Proto", "https")
            token?.let { header(HttpHeaders.Authorization, "Bearer $it") }
            if (body != null) { header(HttpHeaders.ContentType, ContentType.Application.Json.toString()); setBody(body) }
        }

    @Test fun `all notification routes reject anonymous callers`() = run {
        for ((m, p) in listOf(
            HttpMethod.Get to "/notifications", HttpMethod.Get to "/notifications/unread-count", HttpMethod.Post to "/notifications/read-all",
            HttpMethod.Get to "/notifications/settings", HttpMethod.Put to "/notifications/settings",
            HttpMethod.Post to "/notifications/00000000-0000-0000-0000-000000000000/read",
        )) assertEquals(HttpStatusCode.Unauthorized, client.call(m, p, null).status, "$m $p")
    }

    @Test fun `follow produces a notification visible only to the followed user`() = run {
        val alice = user("alice"); val bob = user("bobby")
        client.call(HttpMethod.Post, "/users/alice/follow", bob)
        val mine = Json.parseToJsonElement(client.call(HttpMethod.Get, "/notifications", alice).bodyAsText()).jsonObject
        val item = mine.getValue("notifications").jsonArray.single().jsonObject
        assertEquals("new_follower", item.getValue("type").jsonPrimitive.content)
        assertEquals("bobby", item.getValue("actor").jsonObject.getValue("nickname").jsonPrimitive.content)
        assertEquals("false", item.getValue("read").jsonPrimitive.content)
        assertEquals("1", mine.getValue("unreadCount").jsonPrimitive.content)
        val theirs = client.call(HttpMethod.Get, "/notifications", bob).bodyAsText()
        assertFalse(theirs.contains("new_follower"))
    }

    @Test fun `mark read, read all and unread count over http`() = run {
        val alice = user("alice"); val bob = user("bobby"); val carol = user("carol")
        client.call(HttpMethod.Post, "/users/alice/follow", bob); client.call(HttpMethod.Post, "/users/alice/follow", carol)
        val list = Json.parseToJsonElement(client.call(HttpMethod.Get, "/notifications", alice).bodyAsText()).jsonObject
        val id = list.getValue("notifications").jsonArray.first().jsonObject.getValue("id").jsonPrimitive.content
        assertEquals(HttpStatusCode.NoContent, client.call(HttpMethod.Post, "/notifications/$id/read", alice).status)
        assertEquals(HttpStatusCode.NotFound, client.call(HttpMethod.Post, "/notifications/$id/read", bob).status)
        assertEquals(HttpStatusCode.NotFound, client.call(HttpMethod.Post, "/notifications/nie-uuid/read", alice).status)
        assertTrue(client.call(HttpMethod.Get, "/notifications/unread-count", alice).bodyAsText().contains("1"))
        assertEquals(HttpStatusCode.NoContent, client.call(HttpMethod.Post, "/notifications/read-all", alice).status)
        assertTrue(client.call(HttpMethod.Get, "/notifications/unread-count", alice).bodyAsText().contains("0"))
    }

    @Test fun `settings round trip and validation over http`() = run {
        val alice = user("alice")
        val initial = client.call(HttpMethod.Get, "/notifications/settings", alice).bodyAsText()
        assertTrue(initial.contains("\"reaction\":true"))
        val changed = client.call(HttpMethod.Put, "/notifications/settings", alice, """{"types":{"reaction":false}}""")
        assertEquals(HttpStatusCode.OK, changed.status); assertTrue(changed.bodyAsText().contains("\"reaction\":false"))
        assertEquals(HttpStatusCode.BadRequest, client.call(HttpMethod.Put, "/notifications/settings", alice, """{"types":{"spam":true}}""").status)
        assertEquals(HttpStatusCode.BadRequest, client.call(HttpMethod.Get, "/notifications?type=spam", alice).status)
        assertEquals(HttpStatusCode.BadRequest, client.call(HttpMethod.Get, "/notifications?limit=abc", alice).status)
    }

    @Test fun `anonymous post reaction notifies the author without exposing authorship to others`() = run {
        val alice = user("alice"); val bob = user("bobby")
        val created = client.call(HttpMethod.Post, "/posts", alice, """{"body":"sekret","visibility":"public","anonymous":true}""").bodyAsText()
        val id = Json.parseToJsonElement(created).jsonObject.getValue("id").jsonPrimitive.content
        client.call(HttpMethod.Put, "/posts/$id/reaction", bob, """{"type":"like"}""")
        assertTrue(client.call(HttpMethod.Get, "/notifications", alice).bodyAsText().contains("\"reaction\""))
        val bobInbox = client.call(HttpMethod.Get, "/notifications", bob).bodyAsText()
        assertFalse(bobInbox.contains("alice", ignoreCase = true))
    }

    @Test fun `reply from the author of an anonymous post does not reveal the author account`() = run {
        val alice = user("alice"); val bob = user("bobby")
        val post = client.call(HttpMethod.Post, "/posts", alice, """{"body":"sekret","visibility":"public","anonymous":true}""").bodyAsText()
        val postId = Json.parseToJsonElement(post).jsonObject.getValue("id").jsonPrimitive.content
        val comment = client.call(HttpMethod.Post, "/posts/$postId/comments", bob, """{"body":"hej"}""").bodyAsText()
        val commentId = Json.parseToJsonElement(comment).jsonObject.getValue("id").jsonPrimitive.content
        client.call(HttpMethod.Post, "/posts/$postId/comments", alice, """{"body":"odp","parentId":"$commentId"}""")
        val inbox = client.call(HttpMethod.Get, "/notifications", bob).bodyAsText()
        val item = Json.parseToJsonElement(inbox).jsonObject.getValue("notifications").jsonArray.single().jsonObject
        assertEquals("reply", item.getValue("type").jsonPrimitive.content)
        assertEquals("true", item.getValue("actorAnonymous").jsonPrimitive.content)
        assertFalse(item.containsKey("actor"))
        assertFalse(inbox.contains("alice", ignoreCase = true))
    }
}
