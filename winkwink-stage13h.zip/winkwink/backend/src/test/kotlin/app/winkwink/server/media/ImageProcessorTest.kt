package app.winkwink.server.media

import java.awt.image.BufferedImage
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import javax.imageio.ImageIO
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class ImageProcessorTest {
    private fun png(w: Int, h: Int, alpha: Boolean = false): ByteArray {
        val img = BufferedImage(w, h, if (alpha) BufferedImage.TYPE_INT_ARGB else BufferedImage.TYPE_INT_RGB)
        return ByteArrayOutputStream().also { ImageIO.write(img, "png", it) }.toByteArray()
    }

    private fun jpeg(w: Int, h: Int): ByteArray {
        val img = BufferedImage(w, h, BufferedImage.TYPE_INT_RGB)
        return ByteArrayOutputStream().also { ImageIO.write(img, "jpg", it) }.toByteArray()
    }

    @Test fun `sniff recognises jpeg and png only`() {
        assertEquals("image/jpeg", ImageProcessor.sniff(jpeg(4, 4)))
        assertEquals("image/png", ImageProcessor.sniff(png(4, 4)))
        assertEquals(null, ImageProcessor.sniff("GIF89a....".toByteArray()))
        assertEquals(null, ImageProcessor.sniff("<svg xmlns='http://www.w3.org/2000/svg'/>".toByteArray()))
        assertEquals(null, ImageProcessor.sniff(byteArrayOf()))
    }

    @Test fun `non images and spoofed content are rejected`() {
        assertEquals("unsupported_media_type", assertFailsWith<InvalidImageException> { ImageProcessor.process("hello".toByteArray(), 100) }.code)
        // poprawna sygnatura PNG, ale uszkodzona zawartość
        val broken = png(8, 8).copyOf(40)
        assertEquals("invalid_image", assertFailsWith<InvalidImageException> { ImageProcessor.process(broken, 100) }.code)
    }

    @Test fun `large images are scaled down to max edge`() {
        val out = ImageProcessor.process(jpeg(400, 200), 100)
        val img = ImageIO.read(ByteArrayInputStream(out.bytes))
        assertEquals("image/jpeg", out.mime)
        assertEquals(100, img.width); assertEquals(50, img.height)
    }

    @Test fun `small images are not enlarged and png with alpha stays png`() {
        val out = ImageProcessor.process(png(20, 10, alpha = true), 100)
        val img = ImageIO.read(ByteArrayInputStream(out.bytes))
        assertEquals("image/png", out.mime)
        assertEquals(20, img.width); assertTrue(img.colorModel.hasAlpha())
    }

    @Test fun `opaque png becomes jpeg`() {
        assertEquals("image/jpeg", ImageProcessor.process(png(10, 10), 100).mime)
    }
}
