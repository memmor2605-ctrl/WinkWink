package app.winkwink.server.feed

import app.winkwink.server.community.CommunityStore
import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.profile.PageCursor
import java.time.Instant
import java.util.UUID

/** Implementacja w pamięci wyłącznie do testów; reguły widoczności z [PostVisibility] (te same, co w SQL Postgresa). */
class InMemoryFeedStore(
    private val profiles: InMemoryProfileStore,
    private val communities: CommunityStore? = null,
) : FeedStore {
    private class P(val id: UUID, val author: UUID, var body: String, val visibility: String, val anonymous: Boolean, val at: Instant, var edited: Instant?, var deleted: Boolean = false, val communityId: UUID? = null, val channelId: UUID? = null)
    private class C(val id: UUID, val post: UUID, val parent: UUID?, val author: UUID, val body: String, val at: Instant, var deleted: Boolean = false)
    private val posts = mutableListOf<P>()
    private val comments = mutableListOf<C>()
    private val reactions = mutableMapOf<Pair<UUID, UUID>, String>()
    private val saves = mutableMapOf<Pair<UUID, UUID>, Instant>() // (account, post) -> at

    @Synchronized override suspend fun createPost(
        authorId: UUID, body: String, visibility: String, anonymous: Boolean, now: Instant, communityId: UUID?, channelId: UUID?,
    ): UUID {
        val p = P(UUID.randomUUID(), authorId, body, visibility, anonymous, now, null, communityId = communityId, channelId = channelId)
        posts += p; return p.id
    }

    override suspend fun communityRole(communityId: UUID, accountId: UUID): String? {
        val store = communities ?: return null
        return if (store.find(communityId) == null) null else store.roleOf(communityId, accountId)
    }

    override suspend fun communityMuted(communityId: UUID, accountId: UUID): Boolean = communities?.isMuted(communityId, accountId) ?: false

    override suspend fun channelInCommunity(communityId: UUID, channelId: UUID): Boolean =
        communities?.channels(communityId)?.any { it.id == channelId } ?: false

    override suspend fun communityPosts(viewer: UUID, communityId: UUID, channelId: UUID?, limit: Int, after: PageCursor?) =
        list(viewer, limit, after) { !muted(viewer, it) && it.visibility == "community" && it.communityId == communityId && (channelId == null || it.channelId == channelId) }

    private suspend fun canView(viewer: UUID, p: P): Boolean {
        if (p.deleted) return false
        val author = profiles.findById(p.author) ?: return false
        return PostVisibility.canView(
            viewer, p.author, p.visibility, author.visibility,
            profiles.followState(viewer, p.author) == "accepted",
            if (p.anonymous) profiles.hasBlocked(p.author, viewer) else profiles.isBlockedEitherWay(viewer, p.author),
            viewerIsCommunityMember = p.communityId?.let { communityRole(it, viewer) != null } ?: false,
        )
    }

    private suspend fun row(viewer: UUID, p: P, cursorAt: Instant = p.at): PostRow {
        val a = profiles.findById(p.author)!!
        return PostRow(
            p.id, p.author, a.nickname, a.winkwinkId, a.displayName, p.body, p.visibility, p.anonymous, p.at, p.edited,
            reactions.count { it.key.first == p.id }, comments.count { it.post == p.id && !it.deleted },
            reactions[p.id to viewer], saves.containsKey(viewer to p.id), cursorAt, p.communityId, p.channelId, a.avatarObjectKey,
        )
    }

    private suspend fun list(viewer: UUID, limit: Int, after: PageCursor?, keyOf: (P) -> Instant? = { it.at }, filter: suspend (P) -> Boolean): List<PostRow> {
        val out = mutableListOf<Pair<P, Instant>>()
        for (p in synchronized(this) { posts.toList() }) {
            val key = keyOf(p) ?: continue
            if (canView(viewer, p) && filter(p)) out += p to key
        }
        return out.sortedWith(compareByDescending<Pair<P, Instant>> { it.second }.thenByDescending { it.first.id })
            .filter { after == null || it.second < after.at || (it.second == after.at && it.first.id < after.id) }
            .take(limit).map { row(viewer, it.first, it.second) }
    }

    override suspend fun getPost(id: UUID, viewer: UUID): PostRow? {
        val p = synchronized(this) { posts.firstOrNull { it.id == id } } ?: return null
        return if (canView(viewer, p)) row(viewer, p) else null
    }

    @Synchronized override suspend fun updatePostBody(id: UUID, body: String, now: Instant): Boolean {
        val p = posts.firstOrNull { it.id == id && !it.deleted } ?: return false
        p.body = body; p.edited = now; return true
    }

    @Synchronized override suspend fun deletePost(id: UUID, now: Instant): Boolean {
        val p = posts.firstOrNull { it.id == id && !it.deleted } ?: return false
        p.deleted = true; return true
    }

    /** Wyciszenie nie dotyczy treści anonimowych (jak w SQL `NOT_MUTED`). */
    private suspend fun muted(viewer: UUID, p: P) = !p.anonymous && profiles.isMuted(viewer, p.author)

    override suspend fun followingFeed(viewer: UUID, limit: Int, after: PageCursor?) = list(viewer, limit, after) { p ->
        !muted(viewer, p) && !p.anonymous && p.visibility != "private" && (p.author == viewer || profiles.followState(viewer, p.author) == "accepted")
    }

    override suspend fun discoverFeed(viewer: UUID, limit: Int, after: PageCursor?) = list(viewer, limit, after) { p ->
        !muted(viewer, p) && p.visibility == "public" && (p.anonymous || (p.author != viewer && profiles.followState(viewer, p.author) == null))
    }

    override suspend fun userPosts(viewer: UUID, authorId: UUID, limit: Int, after: PageCursor?) =
        list(viewer, limit, after) { it.author == authorId && !it.anonymous }

    override suspend fun searchPosts(viewer: UUID, query: String, limit: Int, after: PageCursor?) =
        list(viewer, limit, after) { !muted(viewer, it) && it.visibility != "private" && it.body.contains(query, ignoreCase = true) }

    override suspend fun savedPosts(viewer: UUID, limit: Int, after: PageCursor?) =
        list(viewer, limit, after, keyOf = { saves[viewer to it.id] }) { true }

    @Synchronized override suspend fun setReaction(postId: UUID, accountId: UUID, type: String, now: Instant) { reactions[postId to accountId] = type }
    @Synchronized override suspend fun removeReaction(postId: UUID, accountId: UUID) { reactions.remove(postId to accountId) }
    @Synchronized override suspend fun savePost(postId: UUID, accountId: UUID, now: Instant) { saves.putIfAbsent(accountId to postId, now) }
    @Synchronized override suspend fun unsavePost(postId: UUID, accountId: UUID) { saves.remove(accountId to postId) }

    @Synchronized override suspend fun createComment(postId: UUID, parentId: UUID?, authorId: UUID, body: String, now: Instant): UUID {
        val c = C(UUID.randomUUID(), postId, parentId, authorId, body, now); comments += c; return c.id
    }

    private suspend fun crow(c: C): CommentRow {
        val a = profiles.findById(c.author)!!
        val p = posts.first { it.id == c.post }
        return CommentRow(c.id, c.post, c.parent, c.author, a.nickname, a.winkwinkId, a.displayName, c.body, c.at, p.author, p.anonymous,
            comments.count { it.parent == c.id && !it.deleted }, a.avatarObjectKey)
    }

    override suspend fun getComment(id: UUID): CommentRow? {
        val c = synchronized(this) { comments.firstOrNull { it.id == id && !it.deleted } } ?: return null
        return if (posts.first { it.id == c.post }.deleted) null else crow(c)
    }

    override suspend fun listComments(postId: UUID, parentId: UUID?, viewer: UUID, limit: Int, after: PageCursor?): List<CommentRow> {
        val anonymousAuthor = synchronized(this) { posts.firstOrNull { it.id == postId && it.anonymous }?.author }
        val rows = synchronized(this) { comments.filter { it.post == postId && it.parent == parentId && !it.deleted }.toList() }
            // Komentarze autora anonimowego posta: tylko blokada „autor → widz” je ukrywa (patrz PostVisibility).
            .filter { if (it.author == anonymousAuthor) !profiles.hasBlocked(it.author, viewer) else !profiles.isBlockedEitherWay(viewer, it.author) }
            .filter { it.author == anonymousAuthor || !profiles.isMuted(viewer, it.author) }
            .sortedWith(compareBy<C> { it.at }.thenBy { it.id })
            .filter { after == null || it.at > after.at || (it.at == after.at && it.id > after.id) }
            .take(limit)
        return rows.map { crow(it) }
    }

    @Synchronized override suspend fun deleteComment(id: UUID, now: Instant): Boolean {
        val hit = comments.filter { (it.id == id || it.parent == id) && !it.deleted }
        hit.forEach { it.deleted = true }; return hit.isNotEmpty()
    }
}
