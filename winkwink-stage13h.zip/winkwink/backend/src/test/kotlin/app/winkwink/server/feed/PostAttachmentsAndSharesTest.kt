package app.winkwink.server.feed

import app.winkwink.server.api.ApiException
import app.winkwink.server.media.InMemoryMediaStorage
import app.winkwink.server.profile.InMemoryProfileStore
import app.winkwink.server.profile.ProfileService
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.test.runTest
import java.awt.image.BufferedImage
import java.io.ByteArrayOutputStream
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import javax.imageio.ImageIO
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** Etap B: załączniki i udostępnianie. Napisane, niewykonane (brak narzędzi w sesji). */
class PostAttachmentsAndSharesTest {
    private val graph = InMemoryProfileStore()
    private val clock = object : Clock() {
        var t: Instant = Instant.parse("2026-11-22T12:00:00Z")
        override fun getZone() = ZoneOffset.UTC
        override fun withZone(zone: java.time.ZoneId?) = this
        override fun instant(): Instant { t = t.plusSeconds(1); return t }
    }
    private val feedStore = InMemoryFeedStore(graph)
    private val extras = InMemoryPostExtrasStore()
    private val storage = InMemoryMediaStorage()
    private val profiles = ProfileService(graph, clock)
    private val feed = FeedService(feedStore, profiles, clock, extras = extras)
    private val attachments = AttachmentService(extras, feedStore, storage, clock)
    private val alice = graph.seed("alice")
    private val bob = graph.seed("bob")

    private fun png(): ByteArray = ByteArrayOutputStream().also {
        ImageIO.write(BufferedImage(4, 4, BufferedImage.TYPE_INT_RGB), "png", it)
    }.toByteArray()

    private fun mp4(): ByteArray = byteArrayOf(0, 0, 0, 24) + "ftypmp42".toByteArray() + ByteArray(32)
    private fun pdf(): ByteArray = "%PDF-1.4\n%%EOF".toByteArray()

    private suspend fun assertApi(status: HttpStatusCode, code: String, block: suspend () -> Unit) {
        val e = assertFailsWith<ApiException> { block() }
        assertEquals(status, e.status); assertEquals(code, e.code)
    }

    @Test fun `upload validates declared type against content`() = runTest {
        assertApi(HttpStatusCode.UnsupportedMediaType, "unsupported_media_type") { attachments.upload(alice.accountId, pdf(), "image/png", null) }
        assertApi(HttpStatusCode.UnsupportedMediaType, "unsupported_media_type") { attachments.upload(alice.accountId, png(), "text/html", null) }
        assertApi(HttpStatusCode.UnsupportedMediaType, "unsupported_media_type") { attachments.upload(alice.accountId, "<script>".toByteArray(), "application/pdf", null) }
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { attachments.upload(alice.accountId, ByteArray(0), "image/png", null) }
    }

    @Test fun `size limits are enforced per kind`() = runTest {
        val bigPdf = "%PDF-".toByteArray() + ByteArray(AttachmentService.DOCUMENT_MAX_BYTES)
        assertApi(HttpStatusCode.PayloadTooLarge, "payload_too_large") { attachments.upload(alice.accountId, bigPdf, "application/pdf", "a.pdf") }
    }

    @Test fun `image is re-encoded and stored under an opaque key with no file name`() = runTest {
        val row = attachments.upload(alice.accountId, png(), "image/png", "../../etc/passwd.png")
        assertEquals("image", row.kind)
        assertNull(row.fileName)
        assertTrue(row.objectKey.startsWith("post/"))
        assertNotNull(storage.files[row.objectKey])
    }

    @Test fun `document name is sanitized`() = runTest {
        val row = attachments.upload(alice.accountId, pdf(), "application/pdf", "..\\..\\evil\"name;.pdf")
        assertEquals("application/pdf", row.mime)
        val name = row.fileName!!
        assertTrue('/' !in name && '\\' !in name && '"' !in name && !name.startsWith("."))
    }

    @Test fun `pending uploads are capped`() = runTest {
        repeat(AttachmentService.MAX_PENDING) { attachments.upload(alice.accountId, pdf(), "application/pdf", "a.pdf") }
        assertApi(HttpStatusCode.TooManyRequests, "too_many_pending") { attachments.upload(alice.accountId, pdf(), "application/pdf", "a.pdf") }
    }

    @Test fun `pending attachment is visible only to its owner`() = runTest {
        val row = attachments.upload(alice.accountId, png(), "image/png", null)
        assertNotNull(attachments.download(alice.accountId, row.id))
        assertApi(HttpStatusCode.NotFound, "attachment_not_found") { attachments.download(bob.accountId, row.id) }
        assertApi(HttpStatusCode.NotFound, "attachment_not_found") { attachments.deletePending(bob.accountId, row.id) }
        attachments.deletePending(alice.accountId, row.id)
        assertNull(storage.files[row.objectKey])
    }

    @Test fun `post with attachments can have empty body and attachments follow post visibility`() = runTest {
        val img = attachments.upload(alice.accountId, png(), "image/png", null)
        val post = feed.create(alice.accountId, "", "followers", false, attachmentIds = listOf(img.id.toString()))
        assertEquals(1, post.attachments.size)
        assertEquals(img.id, post.attachments.first().id)
        // Bob nie obserwuje Alice → post, a więc i plik, są niedostępne.
        assertApi(HttpStatusCode.NotFound, "attachment_not_found") { attachments.download(bob.accountId, img.id) }
        profiles.follow(bob.accountId, "alice")
        assertNotNull(attachments.download(bob.accountId, img.id))
    }

    @Test fun `empty body without attachments is rejected`() = runTest {
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { feed.create(alice.accountId, "  ", "public", false) }
    }

    @Test fun `cannot attach someone elses or already used attachment`() = runTest {
        val img = attachments.upload(alice.accountId, png(), "image/png", null)
        assertApi(HttpStatusCode.NotFound, "attachment_not_found") { feed.create(bob.accountId, "x", "public", false, attachmentIds = listOf(img.id.toString())) }
        feed.create(alice.accountId, "x", "public", false, attachmentIds = listOf(img.id.toString()))
        assertApi(HttpStatusCode.NotFound, "attachment_not_found") { feed.create(alice.accountId, "y", "public", false, attachmentIds = listOf(img.id.toString())) }
    }

    @Test fun `attachment limits`() = runTest {
        val v1 = attachments.upload(alice.accountId, mp4(), "video/mp4", null).id.toString()
        val v2 = attachments.upload(alice.accountId, mp4(), "video/mp4", null).id.toString()
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { feed.create(alice.accountId, "x", "public", false, attachmentIds = listOf(v1, v2)) }
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { feed.create(alice.accountId, "x", "public", false, attachmentIds = listOf(v1, v1)) }
        val many = List(FeedService.MAX_ATTACHMENTS + 1) { attachments.upload(alice.accountId, png(), "image/png", null).id.toString() }
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { feed.create(alice.accountId, "x", "public", false, attachmentIds = many) }
    }

    @Test fun `anonymous posts accept images only and never expose the uploader`() = runTest {
        val video = attachments.upload(alice.accountId, mp4(), "video/mp4", null).id.toString()
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { feed.create(alice.accountId, "x", "public", true, attachmentIds = listOf(video)) }
        val img = attachments.upload(alice.accountId, png(), "image/png", null).id.toString()
        val post = feed.create(alice.accountId, "anon", "public", true, attachmentIds = listOf(img))
        val dto = post.toDto(bob.accountId)
        assertNull(dto.author)
        assertEquals(1, dto.attachments.size)
        val json = kotlinx.serialization.json.Json { encodeDefaults = true }.encodeToString(PostDto.serializer(), dto)
        assertTrue(alice.accountId.toString() !in json)
    }

    @Test fun `share creates a post that points to a public original`() = runTest {
        val original = feed.create(alice.accountId, "original", "public", false)
        val shared = feed.share(bob.accountId, original.id, "look", "public")
        assertTrue(shared.isShare)
        assertEquals(original.id, shared.sharedPost?.id)
        assertEquals(bob.accountId, shared.authorId)
        assertEquals(1, feed.get(alice.accountId, original.id).shares)
    }

    @Test fun `only public posts can be shared`() = runTest {
        val fol = feed.create(alice.accountId, "f", "followers", false)
        profiles.follow(bob.accountId, "alice")
        assertApi(HttpStatusCode.Forbidden, "not_shareable") { feed.share(bob.accountId, fol.id, "", "public") }
        val priv = feed.create(alice.accountId, "p", "private", false)
        assertApi(HttpStatusCode.NotFound, "post_not_found") { feed.share(bob.accountId, priv.id, "", "public") }
    }

    @Test fun `sharing a share points to the original and keeps anonymity of the original`() = runTest {
        val anon = feed.create(alice.accountId, "secret author", "public", true)
        val s1 = feed.share(bob.accountId, anon.id, "", "public")
        val carol = graph.seed("carol")
        val s2 = feed.share(carol.accountId, s1.id, "again", "public")
        assertEquals(anon.id, s2.sharedPost?.id)
        val dto = s2.toDto(carol.accountId)
        assertNull(dto.shared?.author)
        assertEquals(true, dto.shared?.anonymous)
    }

    @Test fun `share visibility and comment are validated`() = runTest {
        val p = feed.create(alice.accountId, "o", "public", false)
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { feed.share(bob.accountId, p.id, "", "private") }
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { feed.share(bob.accountId, p.id, "x".repeat(5001), "public") }
    }

    @Test fun `share of a deleted original is reported as unavailable`() = runTest {
        val p = feed.create(alice.accountId, "o", "public", false)
        val s = feed.share(bob.accountId, p.id, "c", "public")
        feed.delete(alice.accountId, p.id)
        val after = feed.get(bob.accountId, s.id)
        assertTrue(after.sharedUnavailable)
        assertNull(after.sharedPost)
    }

    @Test fun `abandoned uploads are purged`() = runTest {
        val row = attachments.upload(alice.accountId, png(), "image/png", null)
        clock.t = clock.t.plus(AttachmentService.PENDING_TTL).plusSeconds(60)
        assertEquals(1, attachments.purgeAbandoned())
        assertNull(storage.files[row.objectKey])
    }
}
