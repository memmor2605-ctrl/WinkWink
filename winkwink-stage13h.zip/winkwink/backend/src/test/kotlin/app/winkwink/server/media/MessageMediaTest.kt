package app.winkwink.server.media

import app.winkwink.server.api.ApiException
import io.ktor.http.HttpStatusCode
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import java.util.UUID
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class MessageMediaTest {
    // ---- deklarowany typ ----

    @Test fun `declared types allow only images voice and documents`() {
        assertEquals("image", MessageMedia.declaredKind("image/jpeg"))
        assertEquals("image", MessageMedia.declaredKind("IMAGE/PNG; charset=binary"))
        assertEquals("voice", MessageMedia.declaredKind("audio/mp4"))
        assertEquals("document", MessageMedia.declaredKind("application/pdf"))
        assertEquals("document", MessageMedia.declaredKind("application/octet-stream"))
        listOf("text/html", "application/javascript", "image/svg+xml", "application/x-msdownload", "application/x-sh", "image/gif", "video/mp4", "application/zip", "application/vnd.android.package-archive")
            .forEach { assertNull(MessageMedia.declaredKind(it), it) }
    }

    // ---- dokumenty ----

    @Test fun `real document formats are recognised by content`() {
        assertEquals(MessageMedia.PDF, MessageMedia.detectDocument(TestMedia.pdf()))
        assertEquals(MessageMedia.DOCX, MessageMedia.detectDocument(TestMedia.docx()))
        assertEquals(MessageMedia.XLSX, MessageMedia.detectDocument(TestMedia.xlsx()))
        assertEquals(MessageMedia.PPTX, MessageMedia.detectDocument(TestMedia.pptx()))
        assertEquals(MessageMedia.ODT, MessageMedia.detectDocument(TestMedia.odt()))
        assertEquals(MessageMedia.ODS, MessageMedia.detectDocument(TestMedia.odt("application/vnd.oasis.opendocument.spreadsheet")))
        assertEquals(MessageMedia.RTF, MessageMedia.detectDocument("{\\rtf1\\ansi hello}".toByteArray()))
        assertEquals(MessageMedia.TXT, MessageMedia.detectDocument("zwykły tekst ąęś\nline2".toByteArray()))
    }

    @Test fun `unsafe or unknown content is rejected whatever the name says`() {
        assertNull(MessageMedia.detectDocument(byteArrayOf(0x4D, 0x5A, 0x90.toByte(), 0x00, 0x03, 0x00))) // MZ (exe)
        assertNull(MessageMedia.detectDocument(byteArrayOf(0x7F, 'E'.code.toByte(), 'L'.code.toByte(), 'F'.code.toByte(), 2, 1, 1, 0))) // ELF
        assertNull(MessageMedia.detectDocument("<html><body>hi</body></html>".toByteArray()))
        assertNull(MessageMedia.detectDocument("  \n<!DOCTYPE html><title>x</title>".toByteArray()))
        assertNull(MessageMedia.detectDocument("<svg xmlns='http://www.w3.org/2000/svg'/>".toByteArray()))
        assertNull(MessageMedia.detectDocument("#!/bin/sh\nrm -rf /".toByteArray()))
        assertNull(MessageMedia.detectDocument("text <script>alert(1)</script>".toByteArray()))
        assertNull(MessageMedia.detectDocument(byteArrayOf(1, 2, 3, 0, 5)))
        assertNull(MessageMedia.detectDocument(ByteArray(0)))
        assertNull(MessageMedia.detectDocument(byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 0x11, 0xE0.toByte(), 0xA1.toByte(), 0xB1.toByte(), 0x1A, 0xE1.toByte()))) // OLE (.doc)
        assertNull(MessageMedia.detectDocument(TestMedia.zip(mapOf("a.txt" to "x")))) // zwykły ZIP
    }

    @Test fun `macros active content and embedded executables are rejected`() {
        assertNull(MessageMedia.detectDocument(TestMedia.docx(mapOf("word/vbaProject.bin" to "x"))))
        assertNull(MessageMedia.detectDocument(TestMedia.docx(mapOf("word/embeddings/payload.exe" to "MZ"))))
        assertNull(MessageMedia.detectDocument(TestMedia.docx(mapOf("../evil.txt" to "x"))))
        assertNull(MessageMedia.detectDocument(TestMedia.odt(extra = mapOf("Basic/Standard/Module1.xml" to "<m/>"))))
        assertNull(MessageMedia.detectDocument(TestMedia.odt(mimetype = "application/x-evil")))
        assertNull(MessageMedia.detectDocument(TestMedia.pdf("/OpenAction << /S /JavaScript /JS (app.alert(1)) >> ")))
        assertNull(MessageMedia.detectDocument(TestMedia.pdf("/AA << /O << /S /Launch /F (cmd.exe) >> >> ")))
        assertNull(MessageMedia.detectDocument("{\\rtf1{\\object\\objemb{\\*\\objdata 0105}}}".toByteArray()))
    }

    @Test fun `zip directory reading survives garbage`() {
        assertNull(ZipDirectory.entries(ByteArray(10)))
        assertNull(ZipDirectory.entries("PK\u0003\u0004 not really a zip".toByteArray()))
        val good = TestMedia.docx()
        assertNotNull(ZipDirectory.entries(good))
        // Ucięty koniec = brak katalogu centralnego.
        assertNull(ZipDirectory.entries(good.copyOf(good.size - 30)))
        // Uszkodzony offset katalogu.
        val bad = good.copyOf(); bad[bad.size - 6] = 0x7F; bad[bad.size - 5] = 0x7F
        assertNull(ZipDirectory.entries(bad))
    }

    @Test fun `plain text rules`() {
        assertTrue(MessageMedia.isSafePlainText("a,b,c\n1,2,3\n".toByteArray()))
        assertFalse(MessageMedia.isSafePlainText(ByteArray(MessageMedia.TEXT_MAX_BYTES + 1) { 'a'.code.toByte() }))
        assertFalse(MessageMedia.isSafePlainText(byteArrayOf(0xC3.toByte(), 0x28))) // niepoprawny UTF-8
        assertFalse(MessageMedia.isSafePlainText("a\u0000b".toByteArray()))
    }

    // ---- nazwy ----

    @Test fun `file name keeps stem and forces the real extension`() {
        assertEquals("raport.pdf", MessageMedia.documentFileName("raport.pdf", MessageMedia.PDF))
        assertEquals("raport.pdf", MessageMedia.documentFileName("raport.docx", MessageMedia.PDF))
        assertEquals("raport.pdf", MessageMedia.documentFileName("raport", MessageMedia.PDF))
        assertEquals("dane.csv", MessageMedia.documentFileName("dane.csv", MessageMedia.TXT))
        assertEquals("notatki.txt", MessageMedia.documentFileName("notatki.md", MessageMedia.TXT))
        assertEquals("document.pdf", MessageMedia.documentFileName(null, MessageMedia.PDF))
        assertEquals("passwd.pdf", MessageMedia.documentFileName("../../etc/passwd", MessageMedia.PDF))
        assertEquals("a.pdf", MessageMedia.documentFileName("C:\\Users\\x\\a.pdf", MessageMedia.PDF))
        assertTrue(MessageMedia.documentFileName("x".repeat(500) + ".pdf", MessageMedia.PDF)!!.length <= 100)
    }

    @Test fun `dangerous extensions in the name are refused`() {
        listOf("raport.exe.pdf", "setup.exe", "run.bat", "a.html", "a.svg", "x.js.txt", "macro.docm", "page.htm").forEach {
            assertNull(MessageMedia.documentFileName(it, MessageMedia.PDF), it)
        }
    }

    // ---- MP4 / głosówki ----

    @Test fun `audio only mp4 is recognised and duration is derived from the container`() {
        val info = assertNotNull(Mp4Inspector.inspect(TestMedia.mp4(durationMs = 2500)))
        assertTrue(Mp4Inspector.isAudioOnly(info))
        assertEquals(2500L, info.durationMs)
        assertEquals(3000L, Mp4Inspector.inspect(TestMedia.mp4(durationMs = 3000, timescale = 44100))!!.durationMs)
    }

    @Test fun `video mp4 and non mp4 are not audio only`() {
        assertFalse(Mp4Inspector.isAudioOnly(Mp4Inspector.inspect(TestMedia.mp4(handler = "vide"))!!))
        assertNull(Mp4Inspector.inspect(TestMedia.png()))
        assertNull(Mp4Inspector.inspect(ByteArray(40)))
        assertNull(Mp4Inspector.inspect(TestMedia.mp4().copyOf(30))) // ucięte pudełko moov
    }

    // ---- limiter ----

    @Test fun `upload limiter blocks after the per minute budget and recovers`() {
        var now = Instant.parse("2026-11-25T10:00:00Z")
        val clock = object : Clock() {
            override fun getZone() = ZoneOffset.UTC
            override fun withZone(zone: java.time.ZoneId?) = this
            override fun instant(): Instant = now
        }
        val limiter = UploadRateLimiter(perMinute = 3, perHour = 100, clock = clock)
        val a = UUID.randomUUID(); val b = UUID.randomUUID()
        repeat(3) { limiter.check(a) }
        val e = assertFailsWith<ApiException> { limiter.check(a) }
        assertEquals(HttpStatusCode.TooManyRequests, e.status)
        assertEquals("upload_rate_limited", e.code)
        assertTrue((e.retryAfterSeconds ?: 0) >= 1)
        limiter.check(b) // inne konto ma własny budżet
        now = now.plusSeconds(61)
        limiter.check(a)
    }

    @Test fun `upload limiter has an hourly budget too`() {
        var now = Instant.parse("2026-11-25T10:00:00Z")
        val clock = object : Clock() {
            override fun getZone() = ZoneOffset.UTC
            override fun withZone(zone: java.time.ZoneId?) = this
            override fun instant(): Instant = now
        }
        val limiter = UploadRateLimiter(perMinute = 100, perHour = 5, clock = clock)
        val a = UUID.randomUUID()
        repeat(5) { limiter.check(a); now = now.plusSeconds(120) }
        assertEquals(HttpStatusCode.TooManyRequests, assertFailsWith<ApiException> { limiter.check(a) }.status)
        now = now.plusSeconds(3600)
        limiter.check(a)
    }
}
