package app.winkwink.server.profile

import app.winkwink.server.api.ApiException
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.test.runTest
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

class ProfileServiceTest {
    private val store = InMemoryProfileStore()
    private val service = ProfileService(store, Clock.fixed(Instant.parse("2026-11-21T12:00:00Z"), ZoneOffset.UTC))
    private val alice = store.seed("alice")
    private val bob = store.seed("bob")
    private val priv = store.seed("private_pat", visibility = "private")

    private suspend fun assertApi(status: HttpStatusCode, code: String, block: suspend () -> Unit) {
        val e = assertFailsWith<ApiException> { block() }
        assertEquals(status, e.status); assertEquals(code, e.code)
    }

    @Test fun `public follow is accepted at once and counted`() = runTest {
        assertEquals("accepted", service.follow(alice.accountId, "bob"))
        assertEquals(1, service.view(alice.accountId, "@bob").followers)
        assertEquals("accepted", service.view(alice.accountId, "bob").relationship.following)
    }

    @Test fun `follow is idempotent`() = runTest {
        service.follow(alice.accountId, "bob"); service.follow(alice.accountId, "bob")
        assertEquals(1, service.view(bob.accountId, "bob").followers)
    }

    @Test fun `cannot follow or block self`() = runTest {
        assertApi(HttpStatusCode.BadRequest, "cannot_follow_self") { service.follow(alice.accountId, "alice") }
        assertApi(HttpStatusCode.BadRequest, "cannot_block_self") { service.block(alice.accountId, "alice") }
    }

    @Test fun `private profile requires approval and hides details until accepted`() = runTest {
        assertEquals("pending", service.follow(alice.accountId, "private_pat"))
        val limited = service.view(alice.accountId, "private_pat")
        assertFalse(limited.full); assertNull(limited.followers); assertNull(limited.toDto().bio)
        assertApiFollowersRestricted()
        service.respondToRequest(priv.accountId, "alice", approve = true)
        assertTrue(service.view(alice.accountId, "private_pat").full)
        assertEquals(1, service.followers(alice.accountId, "private_pat", null, null).items.size)
    }

    private suspend fun assertApiFollowersRestricted() =
        assertApi(HttpStatusCode.Forbidden, "profile_restricted") { service.followers(alice.accountId, "private_pat", null, null) }

    @Test fun `rejecting a request removes it and a non-pending request is 404`() = runTest {
        service.follow(alice.accountId, "private_pat")
        service.respondToRequest(priv.accountId, "alice", approve = false)
        assertEquals("none", service.view(alice.accountId, "private_pat").relationship.following)
        assertApi(HttpStatusCode.NotFound, "request_not_found") { service.respondToRequest(priv.accountId, "alice", approve = true) }
    }

    @Test fun `block hides profiles both ways removes follows and excludes from search`() = runTest {
        service.follow(alice.accountId, "bob"); service.follow(bob.accountId, "alice")
        service.block(alice.accountId, "bob")
        assertApi(HttpStatusCode.NotFound, "user_not_found") { service.view(bob.accountId, "alice") }
        assertApi(HttpStatusCode.NotFound, "user_not_found") { service.view(alice.accountId, "bob") }
        assertApi(HttpStatusCode.NotFound, "user_not_found") { service.follow(bob.accountId, "alice") }
        assertTrue(service.search(alice.accountId, "bo", null).isEmpty())
        assertTrue(service.search(bob.accountId, "al", null).isEmpty())
        assertEquals(listOf("bob"), service.blocked(alice.accountId, null, null).items.map { it.user.nickname })
        service.unblock(alice.accountId, "bob")
        assertEquals("accepted", service.follow(alice.accountId, "bob")) // stare obserwowanie nie wraca samo
        assertEquals(0, service.view(bob.accountId, "bob").following)
    }

    @Test fun `profile validation`() = runTest {
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { service.updateMine(alice.accountId, null, "x".repeat(281), null, null) }
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { service.updateMine(alice.accountId, null, null, listOf("javascript:alert(1)"), null) }
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { service.updateMine(alice.accountId, null, null, listOf("http://insecure.example"), null) }
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { service.updateMine(alice.accountId, null, null, List(6) { "https://e.example/$it" }, null) }
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { service.updateMine(alice.accountId, "   ", null, null, null) }
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { service.updateMine(alice.accountId, null, null, null, "everyone") }
    }

    @Test fun `profile update keeps winkwink id`() = runTest {
        val v = service.updateMine(alice.accountId, "Alice A.", "hi", listOf("https://alice.example/me"), "followers")
        assertEquals(alice.winkwinkId, v.user.winkwinkId)
        assertEquals("Alice A.", v.user.displayName); assertEquals("followers", v.user.visibility)
    }

    @Test fun `empty bio clears it and null keeps it`() = runTest {
        service.updateMine(alice.accountId, null, "hello", null, null)
        assertEquals("hello", service.updateMine(alice.accountId, null, null, null, null).user.bio)
        assertNull(service.updateMine(alice.accountId, null, "  ", null, null).user.bio)
    }

    @Test fun `search needs 2 chars and pagination returns cursor`() = runTest {
        assertApi(HttpStatusCode.BadRequest, "validation_failed") { service.search(alice.accountId, "a", null) }
        val users = (1..5).map { store.seed("fan$it") }
        users.forEach { service.follow(it.accountId, "bob") }
        val first = service.followers(alice.accountId, "bob", 2, null)
        assertEquals(2, first.items.size); assertTrue(first.nextCursor != null)
        val second = service.followers(alice.accountId, "bob", 2, first.nextCursor)
        assertTrue(second.items.none { s -> first.items.any { it.user.accountId == s.user.accountId } })
    }
}
