# Synchronizacja i trwała kolejka wysyłania (Stage 13G)

## Kolejka wysyłania (Android)
- Room (`WinkDatabase`: `outbox_messages`, `outbox_files`) + WorkManager (`OutboxWorker`, unikalna praca `winkwink-outbox`, warunek: sieć, backoff wykładniczy od 15 s). WorkManager jest inicjalizowany w `WinkWinkApp` (HiltWorkerFactory); domyślny initializer jest usunięty w manifeście.
- `ChatViewModel.send()` zapisuje wiadomość do Room (`OutboxRepository.enqueue`); lista „wysyłanych” w czacie pochodzi z `observe()`, nie z pamięci ViewModelu. Pliki (zdjęcia/dokumenty po przygotowaniu, nagranie głosowe) są kopiowane do `filesDir/outbox`.
- Przetwarzanie (`OutboxRepositoryImpl.process`, jedno naraz): per rozmowa rosnąco po `seq`; dla pliku bez `remoteId` upload strumieniowo z dysku (`Idempotency-Key` = id pliku), potem `POST …/messages` z `clientId` = id wiersza.
  - sukces → wiersz i pliki lokalne kasowane DOPIERO po odpowiedzi serwera; zdarzenie `sent` wstawia wiadomość do czatu;
  - błąd chwilowy (brak sieci, timeout, 5xx, 429, 401) → wiersz wraca do QUEUED, kolejka tej rozmowy czeka (zachowana kolejność); brak sieci nie zużywa prób, reszta: maks. 10 prób, potem FAILED;
  - błąd trwały (np. 403/404/413) → tylko ta wiadomość FAILED (użytkownik może „Ponów” lub usunąć), kolejne wychodzą dalej;
  - wygasłe wgrane pliki (`attachments_unavailable`) → ponowny upload z lokalnej kopii.
- Po ubiciu procesu wiersze SENDING wracają do QUEUED; start aplikacji planuje przejście kolejki. Pliki kolejki bez wiersza i starsze niż 24 h są sprzątane.
- Wylogowanie lub definitywnie odrzucony refresh token (`SessionCleaner`): zamknięcie WebSocket, anulowanie pracy, kasowanie kolejki i plików, cache obrazów i cache aplikacji.

## Synchronizacja po utracie połączenia
1. `ChatViewModel.load()` pobiera `serverTime` (przez `changes`) PRZED stroną najnowszych → `syncSince`.
2. Po każdym (ponownym) połączeniu WSS (także po zmianie Wi-Fi ↔ LTE, bo klient WSS łączy się od razu po powrocie sieci): `refreshLatest()` (statusy, nowe) + `syncChanges()` (zmiany od `syncSince − 10 s`, do 20 stron; za duża zaległość → pełne przeładowanie).
3. Scalanie po `id` (brak duplikatów); luka większa niż strona jest wykrywana w `applyLatest` (brak części wspólnej → lista zastąpiona).
4. Wiele urządzeń: zdarzenia WSS idą do wszystkich połączeń konta (także nadawcy), a `changes` odtwarza stan na każdym urządzeniu osobno.
Aplikacja zamknięta na dłużej: po otwarciu czatu zawsze ładowana jest świeża strona; lista rozmów odświeża się z REST.
