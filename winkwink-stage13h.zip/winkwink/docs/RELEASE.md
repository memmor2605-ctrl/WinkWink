# Przygotowanie wydania (zamknięta beta)

## Wymagania, których nie da się dostarczyć w repozytorium
- **Gradle Wrapper jest NIEKOMPLETNY**: w repozytorium nie ma `gradlew`, `gradlew.bat` ani `gradle/wrapper/gradle-wrapper.jar` (binarnego pliku nie wolno ani nie da się uczciwie wygenerować bez Gradle). Uzupełnienie: zainstaluj Gradle 8.10.2 (lub nowszy 8.x) i wykonaj `scripts/bootstrap-wrapper.sh` albo ręcznie `gradle wrapper --gradle-version 8.10.2` w `android/` i `backend/`; potem zacommituj wygenerowane pliki. Alternatywnie otwórz `android/` w Android Studio (sam użyje swojego Gradle).
- Backend: JDK 17, PostgreSQL 14+, Docker (opcjonalnie).

## Android — konfiguracja
| Ustawienie | Gdzie | Uwagi |
|---|---|---|
| Adres backendu (HTTPS) | `-Pwinkwink.apiBaseUrl=https://…` lub `WINKWINK_API_BASE_URL` | build `release` **przerywa się**, jeśli adres to domyślny zastępczy (`api.winkwink.example`); HTTP jest odrzucany |
| Wersja | `-Pwinkwink.versionCode=N -Pwinkwink.versionName=0.1.0-beta1` | domyślnie 1 / `0.1.0-beta1` |
| Podpisywanie | `WINKWINK_KEYSTORE_FILE`, `WINKWINK_KEYSTORE_PASSWORD`, `WINKWINK_KEY_ALIAS`, `WINKWINK_KEY_PASSWORD` (albo `winkwink.keystoreFile` itd. w `~/.gradle/gradle.properties`) | bez nich `assembleRelease` daje APK niepodpisany (nie zainstaluje się); klucz generujesz sam: `keytool -genkeypair -v -keystore winkwink.jks -alias winkwink -keyalg RSA -keysize 4096 -validity 10000`; `*.jks` jest w `.gitignore`; zachowaj kopię klucza |
| Firebase | `android/app/google-services.json` | patrz `docs/FIREBASE.md` |

Wydanie (`release`): R8/minifikacja i kompresja zasobów włączone (reguły w `proguard-rules.pro`), `allowBackup=false`, ruch nieszyfrowany zablokowany, ekran „Połączenie/diagnostyka” widoczny tylko w buildzie debug, brak logowania HTTP i tokenów. Uprawnienia: `INTERNET`, `ACCESS_NETWORK_STATE`, `RECORD_AUDIO` (tylko po stuknięciu nagrywania), `POST_NOTIFICATIONS`.

Komenda: `cd android && ./gradlew assembleRelease -Pwinkwink.apiBaseUrl=https://api.twojadomena.pl` (po uzupełnieniu wrappera). Instalacja testowa: `assembleDebug` (adres musi być HTTPS także w debug).

## Backend — zmienne środowiskowe
Wymagane: `WINKWINK_DB_URL`, `WINKWINK_DB_USER`, `WINKWINK_DB_PASSWORD`, `WINKWINK_JWT_SECRET` (min. 32 znaki losowe). Opcjonalne: `WINKWINK_ENV`, `WINKWINK_PORT`, `WINKWINK_TRUST_PROXY` (true za Caddy), `WINKWINK_RATE_LIMIT_PER_MINUTE`, `WINKWINK_LOG_LEVEL`, `WINKWINK_MEDIA_DIR`, `WINKWINK_FCM_CREDENTIALS_FILE`. Pełna lista i przykład: `.env.example`. Sekrety tylko w `.env` (poza repozytorium). HTTPS: Caddy (`deploy/Caddyfile`, `WINKWINK_PUBLIC_HOST`) — backend nie jest publikowany na hosta; serwer odrzuca żądania nie-HTTPS.

## Znane blokery wydania otwartego
- Reset hasła nie działa (brak dostawcy poczty — `503 email_delivery_unavailable`). W zamkniętej becie: użytkownik z zapomnianym hasłem wymaga ręcznej interwencji w bazie.
- Brak weryfikacji adresu e-mail.
