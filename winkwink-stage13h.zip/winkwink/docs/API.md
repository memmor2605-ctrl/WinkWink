# WinkWink API v1 — uwierzytelnianie (Etap 1)

Wszystkie ścieżki mają prefiks `/api/v1`. Tylko HTTPS (inaczej `403 https_required`). Ciała JSON, nieznane pola są odrzucane (`400 bad_request`).
Błąd: `{"error":{"code","message","requestId","details"?}}`. Nagłówek `X-Request-Id` w każdej odpowiedzi.
Endpointy chronione wymagają `Authorization: Bearer <accessToken>`; brak/nieważny token → `401 unauthorized`.

## Publiczne (limit żądań na IP: `WINKWINK_AUTH_RATE_LIMIT_PER_MINUTE`, domyślnie 20/min)

| Metoda i ścieżka | Ciało | Odpowiedź |
|---|---|---|
| `POST /auth/register` | `email, password, nickname, platform?, deviceName?` | `201 AuthResponse` · `409 email_taken` / `nickname_taken` · `422 validation_failed` |
| `POST /auth/login` | `email, password, platform?, deviceName?` | `200 AuthResponse` · `401 invalid_credentials` · `403 account_unavailable` · `429 too_many_attempts` (+`Retry-After`) |
| `POST /auth/refresh` | `refreshToken` | `200 Tokens` (rotacja) · `401 invalid_refresh_token` / `refresh_token_reused` |
| `POST /auth/password/forgot` | `email` | `202` zawsze dla poprawnego formatu (nie ujawnia istnienia konta) · `503 email_delivery_unavailable` |
| `POST /auth/password/reset` | `token, newPassword` | `200` · `400 invalid_or_expired_token` · `422` |

## Chronione

| Metoda i ścieżka | Opis |
|---|---|
| `POST /auth/logout` | Unieważnia bieżącą sesję (`204`). Access token przestaje działać natychmiast. |
| `GET /me` | `{email, profile{nickname, winkwinkId, bio, visibility}}` |
| `POST /me/password` | `{currentPassword, newPassword}`; unieważnia pozostałe sesje. `403 wrong_password` |
| `GET /me/sessions` | Aktywne sesje/urządzenia; bieżąca ma `current: true` |
| `DELETE /me/sessions/{id}` | Wylogowuje wskazane urządzenie (`204`); cudze/nieistniejące → `404` |
| `DELETE /me/sessions` | Wylogowuje wszystkie poza bieżącym: `{revoked: n}` |

## Model tokenów

- **Access**: JWT HS256, 15 min (`WINKWINK_ACCESS_TTL_SECONDS`), claim `sid` = id sesji. Przy każdym żądaniu sprawdzamy w bazie, że sesja nie jest unieważniona, nie wygasła, a konto jest `active`.
- **Refresh**: 256 bitów losowości, w bazie wyłącznie SHA-256. Każde użycie rotuje token (przesuwa okno do 30 dni). Ponowne użycie zrotowanego tokenu = unieważnienie całej sesji.
- **Hasła**: Argon2id (Bouncy Castle), m=19 MiB, t=2, p=1, sól 16 B.
- **Brute force**: 5 nieudanych prób na konto / 30 na IP w oknie 15 min → `429`. Liczniki trzymają wyłącznie hashe kluczy.


## Etap 2 — profile i graf społecznościowy (backend; niezweryfikowany buildem)
Wszystkie trasy wymagają `Authorization: Bearer`. `{id}` = WinkWink ID (`ww_…`) lub nick (z opcjonalnym `@`).
Użytkownik zablokowany (w którąkolwiek stronę) jest nieodróżnialny od nieistniejącego (`404 user_not_found`).

| Metoda | Ścieżka | Opis |
|---|---|---|
| PATCH | `/me/profile` | `displayName`, `clearDisplayName`, `bio` (≤280), `links` (≤5, tylko https), `visibility` (public/followers/private). WinkWink ID jest niezmienny (także w bazie). |
| GET | `/users/{id}` | Profil; dla `followers`/`private` bez zaakceptowanego obserwowania: `restricted=true`, bez bio/linków/liczników. |
| GET | `/users/search?q=&limit=` | Prefiks nicku / nazwy wyświetlanej albo dokładne WinkWink ID; q ≥ 2 znaki; bez zablokowanych. |
| POST/DELETE | `/users/{id}/follow` | Publiczny → `accepted`; inny → `pending`. Idempotentne. |
| GET | `/users/{id}/followers`, `/following` | Kursor: `?limit=&cursor=` → `nextCursor`. 403 `profile_restricted` bez uprawnień. |
| GET | `/me/follow-requests` | Prośby oczekujące. |
| POST | `/me/follow-requests/{id}/approve` | Akceptacja. |
| DELETE | `/me/follow-requests/{id}` | Odrzucenie. |
| POST/DELETE | `/users/{id}/block` | Blokada usuwa obserwowanie w obu kierunkach. |
| GET | `/me/blocks` | Lista zablokowanych. |

### Etap A — avatar, tło, wyciszanie, ustawienia (backend; niezweryfikowany buildem)

| Metoda | Ścieżka | Opis |
|---|---|---|
| PUT | `/me/avatar` | Surowe ciało = obraz, `Content-Type: image/jpeg` lub `image/png`, **wymagany `Content-Length`**. Maks. 2 MB; zwraca profil (`UserProfileDto`). |
| DELETE | `/me/avatar` | Usuwa avatar (plik też). Idempotentne; zwraca profil. |
| PUT / DELETE | `/me/background` | Jak wyżej; maks. 5 MB. |
| GET | `/users/{id}/avatar` | Bajty obrazu. Dostępny dla każdego zalogowanego, który może zobaczyć profil (nawet prywatny); blokada → `404 user_not_found`; brak → `404 media_not_found`. |
| GET | `/users/{id}/background` | Jak wyżej, ale tylko dla widzących pełny profil (właściciel, zaakceptowani obserwujący, profil publiczny); inaczej `404 media_not_found`. |
| POST/DELETE | `/users/{id}/mute` | Wyciszenie / cofnięcie. Idempotentne; `400 cannot_mute_self`. Nie usuwa obserwowania, nie blokuje, **nie powiadamia** wyciszanego i nic mu nie zmienia w widoczności. |
| GET | `/me/mutes?limit=&cursor=` | Lista wyciszonych (`{users, nextCursor}`), tylko własna. |
| PATCH | `/me/profile` | Nowe pole `hideFollowLists` (bool). Gdy `true`, `GET /users/{id}/followers|following` innych osób → `403 follow_lists_hidden`; liczniki i własna lista właściciela bez zmian. |
| GET | `/users/{id}/posts` | (istniejące) Posty profilu z kursorem; nigdy anonimowe; reguły widoczności jak w feedzie. |

Obrazy: dozwolone tylko JPEG i PNG, typ ustalany po sygnaturze bajtów (nagłówek klienta nie jest zaufany); wymiary sprawdzane przed dekodowaniem (maks. 10 000 px na bok i 25 Mpx); obraz jest dekodowany i kodowany od nowa (usuwa EXIF/GPS i dopisane dane) oraz skalowany (avatar ≤ 1024 px, tło ≤ 2048 px). Kody błędów: `415 unsupported_media_type`, `413 payload_too_large` / `image_too_large`, `400 invalid_image`, `411 length_required`. Pliki leżą w `MediaStorage` (domyślnie katalog `WINKWINK_MEDIA_DIR`), w bazie jest tylko klucz.

Nowe pola odpowiedzi: `UserProfileDto` — `avatarTag`, `backgroundTag` (znacznik wersji do cache'u; tło tylko w pełnym widoku), `muted` (tylko dla wywołującego), `followListsHidden`; `UserSummaryDto` — `avatarTag`; `AuthorDto` (posty, komentarze) — `hasAvatar`, `avatarTag`. Dla postów i komentarzy anonimowych `author` nadal jest `null`, więc avatar nie wycieka.

**Wyciszenie a anonimowość.** Wyciszenie ukrywa jawne posty/komentarze/powiadomienia wyciszonego w widokach zbiorczych (Following, Discover, wyszukiwanie, posty społeczności, komentarze, aktywność), ale **nie** filtruje treści anonimowych — inaczej wyciszenie podejrzanej osoby i zniknięcie anonimowego posta zdradzałoby autora (ta sama zasada co przy blokadzie). Profil wyciszonego i jego posty po jawnym wejściu na profil pozostają dostępne.


## Etap 3 — Social Feed (backend; niezweryfikowany buildem)
Wszystkie trasy wymagają Bearer. Listy: `?limit=` (1–50, domyślnie 20) i `?cursor=` → `nextCursor` (null = koniec).

| Metoda | Ścieżka | Opis |
|---|---|---|
| POST | `/posts` | `{body (1–5000), visibility: public/followers/private, anonymous}`; anonimowy tylko z `public`. |
| GET/PATCH/DELETE | `/posts/{id}` | Odczyt (404, gdy niewidoczny), edycja treści i usunięcie (tylko autor; inni widzący → 403). |
| GET | `/feed/following` | Własne i obserwowanych; bez anonimowych i prywatnych. |
| GET | `/feed/discover` | Publiczne posty spoza kręgu obserwowanych (oraz wszystkie anonimowe). |
| GET | `/users/{id}/posts` | Nieanonimowe posty autora widoczne dla Ciebie. |
| GET | `/posts/search?q=` | q ≥ 3 znaki; podciąg w treści (ILIKE, bez indeksu — do zastąpienia FTS/trigramem). |
| PUT/DELETE | `/posts/{id}/reaction` | `{type: like/love/laugh/wow/sad}`; jedna reakcja na użytkownika. |
| POST/DELETE | `/posts/{id}/save`, GET `/me/saved` | Zapisane posty (kolejność wg czasu zapisu). |
| GET/POST | `/posts/{id}/comments` | Komentarze rosnąco; POST `{body (≤2000), parentId?}`; tylko jeden poziom odpowiedzi. |
| GET | `/posts/{id}/comments/{commentId}/replies` | Odpowiedzi. |
| DELETE | `/comments/{id}` | Autor komentarza lub autor posta; usuwa też odpowiedzi. |

**Widoczność posta**: autor zawsze; blokada w którąkolwiek stronę ukrywa (wyjątek — post anonimowy: ukrywa go tylko blokada „autor zablokował widza”; blokada „widz zablokował autora” jest ignorowana, bo zniknięcie posta pozwalałoby zablokować podejrzaną osobę i poznać autora; to samo dotyczy komentarzy autora pod własnym anonimowym postem); `private` tylko autor; `followers` — zaakceptowani obserwujący; `public` — wszyscy, o ile profil autora jest publiczny, inaczej zaakceptowani obserwujący. Wariant `community`: tylko członkowie nieusuniętej społeczności posta (rola sprawdzana w bazie przy każdym żądaniu); utrata członkostwa lub usunięcie społeczności odbiera dostęp wszystkim poza autorem.

**Anonimowość**: odpowiedź nigdy nie zawiera ID autora ani konta; `author = null` także dla właściciela (`mine = true`). Post anonimowy nie trafia do Following ani na listę postów autora; w Discover jest zawsze dopuszczony (wykluczenie „obserwowanych” dotyczy tylko postów jawnych, by nieobecność nie zdradzała autora). Komentarze autora pod własnym anonimowym postem mają `authorHidden = true`. Backend zachowuje `author_id` na potrzeby moderacji.

Niedostępne: zdjęcia, galerie, filmy, załączniki (czeka na Object Storage), udostępnianie (repost) — nie zaimplementowane.

## Etap 4 (część 1) — Communities (backend; niezweryfikowany buildem)
Wszystkie trasy wymagają Bearer. Listy: `?limit=` (1–50) i `?cursor=` → `nextCursor` (brak pola = koniec).
**Typy**: `public` (wolne dołączanie), `private` (widoczna, dołączanie za zgodą moderatora+), `invite` (ukryta: dla osób bez członkostwa i zaproszenia odpowiada `404 community_not_found`, także w wyszukiwaniu).
**Role**: `owner` > `admin` > `moderator` > `member`. Uprawnienia sprawdza wyłącznie backend.

| Metoda | Ścieżka | Kto | Opis |
|---|---|---|---|
| POST | `/communities` | zalogowany | `{name 3–50, description ≤500, rules ≤2000, type}`; twórca = owner; powstaje kanał `general`. Nazwa unikalna (bez rozróżniania wielkości liter) → `409 community_name_taken`. |
| GET | `/communities/search?q=` | zalogowany | q 2–50 znaków; public i private po nazwie + `invite`, których jesteś członkiem. |
| GET | `/me/communities`, `/me/community-invites` | zalogowany | Moje członkostwa / otrzymane zaproszenia. |
| GET / PATCH / DELETE | `/communities/{id}` | widz / admin+ / owner | PATCH: pola pominięte = bez zmian; zmiana `type` tylko owner. DELETE = miękkie usunięcie, tylko owner. Odpowiedź: `myRole`, `myStatus` (member/requested/invited/none). |
| POST / DELETE | `/communities/{id}/membership` | zalogowany | Dołącz (`{state: member|requested}`) / opuść. Owner nie może opuścić (`409 owner_cannot_leave`). |
| DELETE | `/communities/{id}/join-request` | zalogowany | Cofnięcie własnej prośby. |
| GET | `/communities/{id}/members` | członek (public: każdy widzący) | Lista z rolami. |
| PUT | `/communities/{id}/members/{user}/role` | owner | `{role: admin|moderator|member}`; nie można nadać `owner` ani zmienić własnej roli. |
| DELETE | `/communities/{id}/members/{user}` | moderator+ | Tylko osoby o niższej randze. |
| POST | `/communities/{id}/invites` | moderator+ | `{user}` (WinkWink ID lub nick); idempotentne; zablokowani → `404 user_not_found`. |
| POST | `/communities/{id}/invitation/accept` · `/decline` | zaproszony | |
| GET | `/communities/{id}/requests` | moderator+ | Oczekujące prośby. |
| POST | `/communities/{id}/requests/{user}/approve` · `/reject` | moderator+ | |
| GET / POST / DELETE | `/communities/{id}/channels[/{channelId}]` | widz / admin+ / admin+ | Maks. 20 kanałów; nazwa 2–30 znaków, unikalna; nie można usunąć ostatniego (`409 last_channel`). |

Niezaimplementowane w tej części: publikowanie w społecznościach i widoczność „społeczność” postów, komentarze/reakcje w kanałach, zgłaszanie treści i moderacja (Etap 7), przekazanie własności, audyt działań, Android.

## Etap 4 (część 2) — posty w społecznościach (backend; niezweryfikowany buildem)
| Metoda | Ścieżka | Kto | Opis |
|---|---|---|---|
| POST | `/posts` | członek | Dla `visibility: "community"` wymagane `communityId` i `channelId` (kanał musi należeć do społeczności). Niebędący członkiem (także ukrytej/usuniętej społeczności) → `404 community_not_found`; zły kanał → `404 channel_not_found`. `communityId`/`channelId` przy innej widoczności → `400`. Anonimowość z `community` → `400`. |
| GET | `/communities/{id}/posts?channel=&limit=&cursor=` | członek | Posty społeczności (opcjonalnie jednego kanału), najnowsze pierwsze. Niebędący członkiem → `404 community_not_found`. |
| DELETE | `/posts/{id}` | autor lub moderator+ społeczności posta | Moderator+ może usuwać cudze posty wyłącznie w swojej społeczności; posty niespołecznościowe tylko autor (`403 forbidden`). |

Odpowiedź posta ma dodatkowo `communityId` i `channelId` (pominięte, gdy brak). Posty społeczności mogą pojawić się w Following i w wyszukiwaniu — tylko dla członków (ta sama reguła widoczności); nigdy w Discover.
Usunięcie kanału (`DELETE /communities/{id}/channels/{channelId}`) **twardo usuwa jego posty** wraz z komentarzami, reakcjami i zapisami (klucz obcy `ON DELETE CASCADE`).
Niezaimplementowane: moderowanie komentarzy przez moderatorów społeczności, przypinanie, zgłaszanie treści (Etap 7).

## Etap 6 (część 1) — powiadomienia (backend; niezweryfikowany buildem)
Wszystkie endpointy wymagają JWT. Powiadomienie **nie zawiera treści** — tylko typ, aktora i identyfikatory (`postId`, `commentId`, `communityId`).

| Metoda | Ścieżka | Opis |
|---|---|---|
| GET | `/notifications?type=&unread=true&limit=&cursor=` | Lista, najnowsze pierwsze; odpowiedź: `{notifications, nextCursor, unreadCount}`. Nieznany `type` → `400`. |
| | | Pole `actor` jest **pominięte**, a `actorAnonymous: true`, gdy aktorem jest autor anonimowego posta (odpowiedź autora anonimowego posta). Klient nie może wtedy poznać konta. |
| GET | `/notifications/unread-count` | `{unreadCount}` |
| POST | `/notifications/{id}/read` | `204`; cudze/nieistniejące/zły id → `404 notification_not_found`; idempotentne. |
| POST | `/notifications/read-all?type=` | `204`; opcjonalnie tylko jeden typ. |
| GET | `/notifications/settings` | `{types: {typ: włączony}}` |
| PUT | `/notifications/settings` | `{types: {typ: bool}}` — aktualizacja częściowa; nieznany typ → `400`. |

Typy: `new_follower` (profil publiczny), `follow_request` (profil z akceptacją), `reaction`, `comment` (do autora posta), `reply` (do autora komentarza; jeśli jest on też autorem posta, dostaje tylko `reply`), `community_invite`.
Reguły: brak powiadomień dla samego siebie, między zablokowanymi (także ukrywane po późniejszej blokadzie; **wyjątek**: powiadomienia z `actorAnonymous: true` ukrywa/blokuje wyłącznie blokada „aktor → odbiorca” — blokada „odbiorca → aktor” jest ignorowana, bo brak powiadomienia zdradzałby tożsamość anonimowego autora), dla wyłączonego typu, o usuniętych treściach i od nieaktywnych kont. Powtórzone reakcje / obserwowanie / zaproszenia tej samej osoby są deduplikowane (indeks unikalny). Autor posta anonimowego dostaje powiadomienia o reakcjach i komentarzach; nikt inny nie uzyskuje powiązania posta z kontem. Błąd zapisu powiadomienia nigdy nie psuje akcji, która je wywołała (logowany jest tylko typ i klasa wyjątku).
Niezaimplementowane: wzmianki, powiadomienia o wiadomościach, aktywność w społecznościach, komunikaty systemowe, FCM. Android: zaimplementowany (sesja 13).

## Etap 5 — Wiadomości (część 1: REST, backend)

> ⚠️ **To NIE jest end-to-end encryption.** Treść wiadomości jest w tej wersji czytelna dla serwera i przechowywana w PostgreSQL (ochrona: HTTPS/WSS w tranzycie, kontrola dostępu). Aplikacja nie może deklarować E2EE, dopóki nie zostanie wdrożony i zweryfikowany protokół (decyzja o bibliotece: `PROJECT_STATUS.md`). Czas rzeczywisty: patrz sekcja „WSS” poniżej (REST pozostaje źródłem prawdy; Android odpytuje REST co 60 s przy działającym WSS, co 8 s bez niego). Zdjęcia, dokumenty i wiadomości głosowe: sekcja „Etap F” poniżej.

Wszystkie trasy wymagają tokenu. Nie-członek dostaje `404 conversation_not_found` (nie odróżnia rozmowy nieistniejącej od cudzej).

| Metoda | Ścieżka | Opis |
|---|---|---|
| GET | `/conversations?archived=&q=&limit=&cursor=` | Lista rozmów wg ostatniej aktywności, `{conversations, nextCursor}`; `q` szuka po tytule grupy i nicku/nazwie rozmówcy. Zawiera `unreadCount`, `muted`, `archived`, `peer` (1:1), `lastMessage`. |
| POST | `/conversations/direct` | `{user}` (nick lub WinkWink ID) → `200`; jedna rozmowa na parę. `400` (siebie), `404 user_not_found`, `403 user_unavailable` (blokada w którąkolwiek stronę). |
| POST | `/conversations/group` | `{title (1–80), members[]}` → `201`; twórca = `owner`; max 50 osób; `403 user_unavailable`, jeśli ktoś jest zablokowany. |
| GET | `/conversations/{id}` | Podsumowanie rozmowy. |
| PATCH | `/conversations/{id}/settings` | `{muted?, archived?}` — ustawienia tylko dla wywołującego. |
| POST | `/conversations/{id}/read` | `204`; ustawia moment odczytu. |
| GET | `/conversations/{id}/messages?limit&cursor` | Najnowsze pierwsze; `{messages, nextCursor}`. Usunięta wiadomość: `deleted: true`, `body` pominięte. |
| POST | `/conversations/{id}/messages` | `{body (1–4000; może być pusta, gdy są załączniki), replyToId?, attachmentIds?[]}` → `201`. Odpowiedź musi wskazywać żywą wiadomość tej samej rozmowy. W 1:1 po blokadzie `403 user_unavailable`. |
| PATCH | `/messages/{id}` | `{body}` — tylko autor; ustawia `editedAt`. |
| DELETE | `/messages/{id}` | `204` — autor lub (w grupie) właściciel/administrator; treść jest czyszczona w bazie. |
| GET | `/conversations/{id}/members` | `{members}`. |
| POST | `/conversations/{id}/members` | `{user}` — tylko grupa; właściciel/administrator; idempotentne; `409 group_full`; `400 not_a_group`. |
| DELETE | `/conversations/{id}/members/{user}` | `204`; własne konto = opuszczenie grupy (`409 owner_cannot_leave` dla właściciela — brak przekazania własności); usuwać można osoby niższej rangi. |
| PUT | `/messages/{id}/reaction` | `{kind}` ∈ `like, love, laugh, wow, sad, thanks` → `200 MessageDto`; jedna reakcja na osobę (kolejna zmienia poprzednią); `400 validation_failed`, `404 message_not_found` (też dla obcej rozmowy i usuniętej wiadomości), `403 user_unavailable` w 1:1 po blokadzie. |
| DELETE | `/messages/{id}/reaction` | Usuwa własną reakcję → `200 MessageDto`. |
| PUT | `/conversations/{id}/members/{user}/role` | `{role: admin\|member}` — tylko właściciel, tylko grupa; nie dotyczy właściciela i własnego konta (`403 forbidden`); `200 {members}`. |
| GET/PUT | `/messages/settings` | `{readReceipts}` — wyłączenie oznacza, że ani nie wysyłasz, ani nie widzisz potwierdzeń odczytu. |

Status własnej wiadomości (`status`): `sent` | `delivered` | `read`. `delivered` = urządzenie każdego odbiorcy pobrało wiadomość przez REST (lista rozmów lub `GET …/messages`; po wdrożeniu WSS także on) — nie znaczy, że ktoś ją zobaczył. `read` = każdy odbiorca ją przeczytał (`POST …/read`). Oba stany ponad `sent` są widoczne tylko, gdy widz i wszyscy pozostali członkowie udostępniają potwierdzenia (`/messages/settings`); inaczej zawsze `sent`.

`MessageDto` (Etap D) ma dodatkowo `reactions: [{kind, count, mine}]` (bez informacji, kto zareagował; usunięcie wiadomości czyści reakcje), a `PersonDto` — `avatarTag` (wersja obrazu do `/users/{id}/avatar?v=`). Migracja `V14`: `message_reactions`, `conversation_members.last_delivered_at`. Moderatorzy nie mają dostępu do treści rozmów (brak takich tras).

**Wiadomości — kody błędów (Stage 12)**: `PATCH`/`DELETE /messages/{id}` zwraca `404 message_not_found` zarówno dla nieistniejącej wiadomości, jak i dla wiadomości z rozmowy, w której nie jesteś członkiem (wcześniej drugi przypadek dawał `conversation_not_found`, co ujawniało istnienie cudzych wiadomości).

## Etap F — multimedia w wiadomościach (zdjęcia, dokumenty, wiadomości głosowe)

> Stan: kod napisany, **niezweryfikowany buildem ani testami** (zasada tej sesji: bez Gradle/Dockera/PostgreSQL). Migracja: `V15__message_attachments.sql`.

Dwa kroki: (1) plik jest wysyłany do rozmowy i dostaje identyfikator (niedołączony, widoczny tylko dla właściciela), (2) wiadomość (`POST …/messages`) dołącza pliki po `attachmentIds`. Treści plików **nigdy** nie idą przez WSS ani PostgreSQL — w bazie są tylko metadane i klucz obiektu, bajty leżą w `MediaStorage` (`message/<uuid>`).

| Metoda | Ścieżka | Opis |
|---|---|---|
| POST | `/message-attachments?conversationId=&name=` | Surowe ciało = plik; `Content-Type` = typ deklarowany, `Content-Length` wymagany (`411`). Tylko członek rozmowy (`404 conversation_not_found`). → `201 MessageAttachmentDto`. |
| GET | `/message-attachments/{id}` | Pobranie pliku. Dostęp: aktualny członek rozmowy i nieusunięta wiadomość (niedołączony plik — tylko właściciel). Każdy odmowny powód to `404 attachment_not_found`. |
| DELETE | `/message-attachments/{id}` | `204` — wycofanie własnego, niedołączonego pliku (`404` dla cudzego lub już wysłanego). |

`MessageAttachmentDto`: `{id, kind: image|document|voice, mime, sizeBytes, fileName?, width?, height?, durationMs?}` — bez klucza obiektu i właściciela. `MessageDto.attachments` (kolejność = kolejność dołączenia); usunięta wiadomość nie ma załączników.

**Reguły wiadomości:** albo do 10 zdjęć, albo do 5 dokumentów, albo dokładnie jedna głosówka (bez tekstu); bez załączników treść jest wymagana, z zdjęciami/dokumentami podpis jest opcjonalny (edycja może go wyczyścić; głosówki nie są edytowalne). Pliki muszą być przesłane do tej samej rozmowy, przez tego samego nadawcę i niewykorzystane — inaczej `409 attachments_unavailable` (jeden kod dla cudzych, nieistniejących i użytych, by nie zdradzać istnienia). Dołączenie jest atomowe z wstawieniem wiadomości (jedna transakcja).

**Walidacja (zawartość, nie nagłówek):**
- Deklarowany typ musi być dozwolony: `image/jpeg|png`, `audio/mp4|m4a|x-m4a`, dokumenty (`pdf`, `docx`, `xlsx`, `pptx`, `odt/ods/odp`, `rtf`, `txt`, `csv`, `application/octet-stream`). HTML, SVG, JS, pliki wykonywalne itd. → `415 unsupported_media_type`.
- Zdjęcia: dekodowane i kodowane od nowa (bez EXIF/GPS), krawędź ≤ 2048 px, ≤ 8 MB.
- Dokumenty ≤ 10 MB, rozpoznawane po zawartości: PDF (odrzucane z `/JavaScript` i `/Launch`), OOXML/ODF po katalogu centralnym ZIP (bez dekompresji; odrzucane: makra `vbaProject.bin`, `Basic/`, `Scripts/`, pliki wykonywalne/skrypty w paczce, ścieżki `..`), RTF (bez `\objdata`), tekst UTF-8 (≤ 2 MB, bez znaków sterujących, bez HTML/SVG/skryptów). Starsze OLE (`.doc/.xls/.ppt`) nie są przyjmowane. Nazwa: bez ścieżek i znaków sterujących, rozszerzenie wymuszone z wykrytego typu; zakazane rozszerzenie w dowolnym segmencie (`raport.exe.pdf`) → `415`.
- Głosówki: kontener MP4 z wyłącznie ścieżkami `soun` (wideo → `415`), czas trwania liczony przez serwer z `mvhd` (0,3 s – 10 min: `400 recording_too_short`, `413 recording_too_long`), ≤ 8 MB.
- Limity: `413 payload_too_large`; `429 too_many_pending` (≥ 30 niedołączonych plików); `429 upload_rate_limited` (20/min i 200/h na konto, z `Retry-After`; stan w pamięci procesu).

**Pobieranie — nagłówki:** `X-Content-Type-Options: nosniff`, `Content-Security-Policy: default-src 'none'; sandbox`, `Cache-Control: private, max-age=3600`; dokumenty z `Content-Disposition: attachment; filename*=UTF-8''…`, zdjęcia i głosówki `inline`. Typ odpowiedzi to typ wykryty po zawartości.

**Sprzątanie:** usunięcie wiadomości oznacza jej załączniki (`deleted_at`) w tej samej transakcji, po czym serwis kasuje pliki i wiersze; co godzinę zadanie okresowe usuwa także niedołączone wysyłki starsze niż 24 h oraz wiersze oznaczone, których plik nie został skasowany (np. po awarii). Usunięcie konta/rozmowy kaskadowo usuwa wiersze, ale **nie pliki** (brak rekoncyliacji magazynu — znane ograniczenie).

**WSS:** bez nowych typów zdarzeń. Wiadomość z multimediami wywołuje zwykłe `message.new` (`message.updated` przy edycji podpisu, `message.deleted` po usunięciu); zdarzenia nie niosą metadanych ani treści — Android odświeża wiadomości przez REST, a bajty pobiera z `GET /message-attachments/{id}` (zdjęcia przez Coil z tokenem, głosówki do cache aplikacji, dokumenty zapisem w miejscu wskazanym przez użytkownika).

## Etap B — załączniki postów i udostępnianie (backend; niezweryfikowany buildem)

Pliki leżą w `MediaStorage` (nie w PostgreSQL). Dwa kroki: wysłanie pliku → dołączenie przy tworzeniu posta.

| Metoda | Ścieżka | Opis |
|---|---|---|
| POST | `/attachments?name=` | Surowe ciało = plik. `Content-Type`: `image/jpeg`, `image/png`, `video/mp4`, `application/pdf`. Wymagany `Content-Length`. 201 → `AttachmentDto`. |
| DELETE | `/attachments/{id}` | Usuwa własny, jeszcze niedołączony załącznik (204). |
| GET | `/attachments/{id}` | Plik. Dostęp = dostęp do posta (blokady, prywatność, członkostwo w społeczności); niedołączony — tylko właściciel. Inaczej 404 `attachment_not_found`. |
| POST | `/posts/{id}/share` | `{comment, visibility: public\|followers}` → 201 `PostDto` (nowy post-udostępnienie). |
| POST | `/posts` | Nowe pole `attachmentIds: [string]`; `body` może być puste, jeśli są załączniki. |

Limity: obraz 8 MB (po przetworzeniu max. krawędź 2048 px, ponowne kodowanie bez EXIF), film MP4 30 MB, PDF 10 MB; do 10 załączników na post, 1 film, 3 dokumenty; do 20 niedołączonych wysyłek na użytkownika (429 `too_many_pending`); porzucone wysyłki są sprzątane po 24 h. Typ jest rozpoznawany po sygnaturze bajtów i musi zgadzać się z `Content-Type` (415 `unsupported_media_type`; 413 `payload_too_large`). Klucze obiektów są losowe, nazwę zachowują tylko dokumenty (po sanityzacji). Odpowiedzi plików: `nosniff`, CSP `sandbox`, `Cache-Control: private`, PDF jako `attachment`.

`AttachmentDto`: `id, kind (image|video|document), mime, sizeBytes, fileName?, width?, height?` — bez właściciela i klucza obiektu.

`PostDto` — nowe pola: `attachments`, `shares` (liczba **publicznych** udostępnień), `isShare`, `shared` (oryginał z perspektywy widza), `sharedUnavailable`.

Anonimowość: posty anonimowe przyjmują wyłącznie obrazy (filmy i PDF nie są czyszczone z metadanych — 400). DTO załącznika nie zawiera autora. Udostępnienie anonimowego posta pozostawia oryginał anonimowym (`shared.author = null`); samo udostępnienie jest zawsze jawne.

Udostępnianie: tylko posty o widoczności `public` (inaczej 403 `not_shareable`); udostępnienie udostępnienia wskazuje oryginał; oryginał jest zawsze pobierany z uprawnieniami widza, więc usunięty/zablokowany/niewidoczny daje `sharedUnavailable=true`. Powiadomienia o udostępnieniu nie są wysyłane (nie zrealizowane).

## Etap C — zarządzanie społecznościami (backend; niezweryfikowany buildem)

| Metoda | Ścieżka | Kto | Opis |
|---|---|---|---|
| POST | `/communities/{id}/transfer-ownership` | owner | `{user}` → 204. Cel musi być członkiem (404 `not_member`), nie może być właścicielem. Atomowo: cel → `owner`, dotychczasowy właściciel → `admin`; wyciszenie celu jest zdejmowane. |
| PUT / DELETE | `/communities/{id}/members/{user}/mute` | moderator+ | Wycisza / cofa wyciszenie członka o **niższej** randze (właściciela nie da się wyciszyć; 403 w pozostałych przypadkach, 404 `not_member`). |
| GET | `/communities/{id}/invite-candidates?q=` | moderator+ | 2–40 znaków; wyszukiwanie jak `/users/search` (blokady pominięte), bez obecnych członków; `{candidates:[{winkwinkId,nickname,displayName,invited}]}`, max 10. |

Wyciszony członek zostaje w społeczności i może czytać, ale `POST /posts` w tej społeczności oraz komentarze pod jej postami zwracają 403 `muted_in_community`. Wyciszenie dotyczy tylko tej społeczności. `PersonDto.muted` jest wypełniane tylko dla moderatorów i wyżej (zwykli członkowie zawsze widzą `false`).

Powiadomienia (nowe typy, wymagają migracji V13): `community_invite_accepted` (do osoby, która zaprosiła, gdy zaproszenie zostało przyjęte; odrzucenie nie generuje powiadomienia) i `community_request_approved` (do osoby, której prośbę o dołączenie zatwierdzono; odrzucenie nie generuje powiadomienia). Oba używają przełącznika ustawień `community_invite`. Uprawnienia są sprawdzane wyłącznie po stronie backendu; Android jedynie ukrywa niedostępne przyciski.

### WSS — zdarzenia czasu rzeczywistego (Etap E)

`GET /api/v1/ws` (po reverse proxy: `wss://`). Uwierzytelnianie: nagłówek `Authorization: Bearer <access token>` w żądaniu otwierającym (token nigdy w adresie URL); bez ważnego tokenu → `401`. Połączenie trwa najwyżej 15 min i co 30 s serwer sprawdza, czy sesja jest aktywna — po wylogowaniu/unieważnieniu zamyka je (do ok. 30 s zwłoki). Maks. 5 połączeń na konto (najstarsze jest zamykane), ramka ≤ 4 KB, maks. 60 ramek na 10 s, ping serwera co 20 s.

**Serwer → klient** (JSON `{type, conversationId?, messageId?, actor?}`; zdarzenia NIE niosą treści — to wskazówki, stan pobiera się przez REST):
`hello` (po połączeniu), `message.new` (z `actor` = nadawca), `message.updated` (edycja, reakcja), `message.deleted`, `receipt` (zmiana „dostarczono”/„przeczytano”), `conversation.new`, `conversation.updated` (tylko własne urządzenia: wyciszenie/archiwum), `member.changed` (także dla usuwanego członka), `typing` (z `actor`), `pong`.
Zdarzenia dostają wszyscy członkowie rozmowy, także pozostałe urządzenia nadawcy. Zdarzenie `receipt` o dostarczeniu powstaje tylko, gdy odbiorca faktycznie pobrał nowe cudze wiadomości (brak pętli zdarzeń).

**Klient → serwer:** `{"type":"typing","conversationId":"…"}` (serwer przepuszcza najwyżej raz na 2 s na rozmowę) i `{"type":"ping"}`. Wysyłanie wiadomości i historia pozostają w REST.

**Prywatność wskaźnika pisania:** wysyła go tylko ten, kto sam ma włączone potwierdzenia (`/messages/settings`), i dostają go tylko osoby, które też je mają; w 1:1 nie dociera przez blokadę. Ramki od osób spoza rozmowy są po cichu ignorowane.

**Gwarancje:** dostarczenie wiadomości NIE zależy od WSS (REST + `delivered`/`read` jak wcześniej). Kolejka zdarzeń wolnego klienta ma 64 miejsca (najstarsze są odrzucane) — po ponownym połączeniu klient i tak dogania stan przez REST.

## Stage 13G — niezawodność, idempotencja, synchronizacja (backend; niezweryfikowany buildem)

### Idempotencja (`Idempotency-Key`)
Nagłówek `Idempotency-Key` (8–100 znaków `[A-Za-z0-9_.:-]`, zwykle UUID) działa na: `POST /posts`, `POST /posts/{id}/share`, `POST /posts/{id}/comments`, `POST /communities`, `POST /conversations/group`, `POST /attachments`, `POST /message-attachments`.
- Pierwsze żądanie wykonuje operację i zapisuje status + treść odpowiedzi (tabela `idempotency_keys`, 48 h, per konto).
- Ponowienie tym samym kluczem zwraca zapisaną odpowiedź (ten sam status) z nagłówkiem `Idempotent-Replayed: true`; operacja nie jest wykonywana drugi raz.
- Ten sam klucz do innej operacji → `422 idempotency_key_reused`. Ponowienie w trakcie pierwszego żądania → `409 request_in_progress` (+ `Retry-After: 1`). Zły format → `400 invalid_idempotency_key`.
- Błędy nie są zapamiętywane (rezerwacja zwalniana). Rezerwacja niedokończona >2 min (proces padł) może zostać przejęta.
- Brak nagłówka = zachowanie jak dotąd.
- Reakcje (`PUT/DELETE …/reaction`), zapis posta, obserwowanie itd. są idempotentne z natury (stan docelowy).

### Wysyłanie wiadomości — `clientId`
`POST /conversations/{id}/messages` przyjmuje opcjonalne `clientId` (UUID nadany przez klienta). Unikalność `(sender_id, client_id)` w bazie: ponowienie zwraca zapisaną wiadomość (status 201, ta sama treść) zamiast tworzyć duplikat — także przy równoległych ponowieniach. Sprawdzenie następuje przed walidacją załączników (pierwsza próba już je zużyła). `clientId` użyty w innej rozmowie → `409 client_id_reused`.

### Synchronizacja różnicowa
`GET /conversations/{id}/messages/changes?since=<ISO-8601>&limit=&cursor=` → `{ messages, nextCursor, serverTime }`.
- Zwraca wiadomości **zmienione** po `since` (nowe, edytowane, usunięte „nagrobki” z `deleted=true`, z nową reakcją), rosnąco po `(changed_at, id)`; `cursor` (z poprzedniej odpowiedzi) kontynuuje listę. Wymagane `since` albo `cursor`.
- `serverTime` (zegar serwera) jest punktem odniesienia następnej synchronizacji; klient odejmuje ~10 s zapasu i deduplikuje po `id`.
- Dostęp: tylko aktualny członek rozmowy (inaczej `404 conversation_not_found`). Status dostarczenia/odczytu nie zmienia `changed_at` — odświeża go zwykłe `GET …/messages` (strona najnowszych).
- WebSocket pozostaje wskazówką; REST (strona najnowszych + `changes`) odtwarza pełny stan.

### Pobieranie plików
`GET /attachments/{id}` i `GET /message-attachments/{id}` są strumieniowane (bufor 64 KB) i obsługują `Range: bytes=a-b` (pojedynczy zakres → `206`, `Accept-Ranges: bytes`, niespełnialny → `416 range_not_satisfiable`). Dostęp wciąż wg członkostwa w rozmowie / widoczności posta; równoległe usunięcie pliku → `404`.

### Limity żądań
Ciała `POST/PUT/PATCH`: JSON ≤ 256 KB, upload (`/attachments`, `/message-attachments`, `/me/avatar`, `/me/background`) ≤ 40 MB jako sufit (limity per typ pliku bez zmian). Żądania z `Transfer-Encoding` (bez `Content-Length`) → `411 length_required`; za duże → `413 payload_too_large`. CORS nie jest włączony (API dla aplikacji natywnej; przeglądarki są domyślnie blokowane).

### Usuwanie konta
`POST /me/delete` `{ "password": "…" }` → `204`. Wymaga hasła (`403 wrong_password`, limit prób jak przy zmianie hasła). Usuwa konto i kaskadą wszystko, co do niego należy (profil, sesje, posty, komentarze, reakcje, wiadomości, załączniki, powiadomienia), potem pliki z magazynu. Pliki, których nie udało się usunąć, zbiera rekoncyliacja magazynu.

### Sprzątanie plików
- Usunięta wiadomość: załączniki oznaczone `deleted_at`, plik kasowany, wiersz usuwany dopiero po skasowaniu pliku (nieudane próby ponawia zadanie godzinowe).
- Usunięty post: wiersze załączników i pliki usuwane zadaniem godzinowym (`purgeDeletedPosts`); pliki są niepobieralne od razu (dostęp = widoczność posta).
- Rekoncyliacja co 6 h (`MediaReconciler`): pliki starsze niż 24 h, na które nic w bazie nie wskazuje, są usuwane.
- `MediaStorage.delete` propaguje błędy IO (wcześniej je połykał i wiersz znikał mimo istniejącego pliku).

## Stage 13H — push, usuwanie konta, idempotencja

### Push (FCM)
Wszystkie trasy wymagają tokenu dostępu.
- `PUT /push/token` `{ "token": "<FCM>", "deviceName"?: "…" }` → `204`. Idempotentne; token (20–4096 znaków `[A-Za-z0-9_:.-]`) jest przypinany do bieżącej sesji i przepisywany, jeśli należał do innego konta. Maks. 10 tokenów na konto. `400 validation_failed` przy złym formacie.
- `DELETE /push/token` z nagłówkiem `X-Push-Token: <FCM>` → `204` (idempotentne; usuwa tylko token tego konta).
- `GET /push/settings` → `{ "messages": bool, "previews": bool, "configured": bool }` (`configured` = backend ma poświadczenia FCM). `PUT /push/settings` `{ "messages"?, "previews"? }` → to samo. Domyślnie `messages=true`, `previews=false`.
Ładunek FCM (data-only): `type` = `message` | `new_follower` | `follow_request` | `reaction` | `comment` | `reply` | `community_invite` | `community_invite_accepted` | `community_request_approved` | `account` | `dismiss`; plus identyfikatory (`conversationId`, `messageId`, `notificationId`, `postId`, `commentId`, `communityId`, `actorId`), `actor`/`sender`/`title` (nazwy) i `preview` tylko przy włączonym podglądzie. Zdarzenia `account`: `password_changed`, `new_login`.

### Usuwanie konta
`POST /me/delete` `{ "password" }` → `204`; `403 wrong_password`. Android: Profil → „Usuń konto” (ostrzeżenie, hasło, zaznaczenie zrozumienia, dialog potwierdzenia); po sukcesie sesja i dane lokalne są kasowane.

### Idempotencja — zmiany względem 13G
Odcisk żądania: ten sam `Idempotency-Key` z inną treścią (lub dla innego zasobu, np. innego posta przy komentarzu) → `422 idempotency_key_reused`, zamiast odtworzenia cudzej odpowiedzi. Rezerwacja niedokończona jest przejmowalna dopiero po 10 min, i tylko przez to samo żądanie (ten sam scope i odcisk); wynik zapisuje wyłącznie właściciel rezerwacji (znacznik `created_at` jako token), więc wolne żądanie nie nadpisze wyniku ponowienia, które je przejęło.
