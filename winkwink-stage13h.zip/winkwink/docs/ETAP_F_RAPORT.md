# Raport zmian — Etap F: multimedia w komunikatorze (WinkWink Stage 13E → 13F)

**Stan: kod napisany, NIEZBUDOWANY i NIEPRZETESTOWANY.** Nie uruchamiano Gradle, kompilacji, testów, Dockera ani PostgreSQL. Wykonano wyłącznie kontrole statyczne (bilans nawiasów we wszystkich plikach `.kt`, parytet i użycie kluczy `strings.xml` EN/PL, przegląd importów w zmienionych ekranach Androida).

## Ścieżka end-to-end (Android → API → Ktor → PostgreSQL + MediaStorage)
| Funkcja | Android | API | Backend | Magazyn |
|---|---|---|---|---|
| Zdjęcia (1–10, galeria, pełny ekran) | wybór → JPEG bez EXIF → upload przy wyborze → `send(attachmentIds)` | `POST /message-attachments`, `POST …/messages` | `MessageAttachmentService`, `MessageMedia`, `ImageProcessor` | `MediaStorage` `message/<uuid>` + `message_attachments` |
| Dokumenty (≤5, PDF/OOXML/ODF/RTF/TXT/CSV) | wybierak SAF, filtr rozszerzeń, zapis przez SAF | j.w. + `GET /message-attachments/{id}` | walidacja zawartości, bezpieczne nazwy, kontrola członkostwa | j.w. |
| Głosówki (≤10 min) | `MediaRecorder` AAC/M4A, podgląd, upload przy wysyłaniu, odtwarzacz z paskiem postępu | j.w. | parser MP4 (`soun`, czas z `mvhd`) | j.w. |
| Usuwanie | usunięcie wiadomości / wycofanie pliku | `DELETE /messages/{id}`, `DELETE /message-attachments/{id}` | znacznik `deleted_at` + kasowanie plików + sprzątanie co godzinę | pliki kasowane |
| WSS | bez zmian protokołu; po zdarzeniu odświeżenie przez REST | — | zwykłe `message.new/updated/deleted` | treść plików poza WS |

## Decyzje podjęte samodzielnie
- Dwa kroki (upload → dołączenie do wiadomości), jedna rodzina plików na wiadomość (zdjęcia ALBO dokumenty ALBO jedna głosówka), atomowe dołączenie w transakcji wstawiania wiadomości.
- Wiązanie pliku z rozmową przy uploadzie (nie da się go dołączyć gdzie indziej); jeden kod `409 attachments_unavailable` dla cudzych/nieistniejących/użytych.
- Typ pliku wyłącznie po zawartości; czas głosówki liczony przez serwer; zdjęcia przekodowywane (bez EXIF/GPS).
- Odrzucane: wykonywalne, HTML/SVG, skrypty, makra (`vbaProject.bin`, ODF `Basic/`), PDF z `/JavaScript`/`/Launch`, RTF z `\objdata`, starsze OLE, ZIP-y nierozpoznane jako OOXML/ODF, zakazane rozszerzenia w dowolnym segmencie nazwy.
- Brak nowych typów zdarzeń WSS (zmiana wiadomości = istniejące zdarzenia).
- Android: jeden współdzielony odtwarzacz (nowe odtwarzanie zatrzymuje poprzednie), nagrywanie kończy się w tle i trafia do podglądu, pliki pobierane do cache (głosówki) lub zapisywane przez systemowy wybierak (dokumenty).

## Pliki
Backend: `V15__message_attachments.sql`, `media/MessageMedia.kt`, `media/UploadRateLimiter.kt`, `message/{MessageStore,PostgresMessageStore,MessageService,MessageDtos,MessageRoutes,MessageAttachmentService,MessageAttachmentRoutes}.kt`, `Application.kt`.
Android: `domain/model/MessageModels`, `domain/media/{MessageMediaTypes,VoiceMedia}`, `domain/repository/MessageRepository`, `data/remote/MessageApi`, `data/repository/MessageRepositoryImpl`, `data/media/{AndroidMessageFilePreparer,AndroidVoiceRecorder,AndroidVoicePlayback}`, `di/RepositoryModule`, `ui/messages/{MessageViewModels,ChatScreens,MessageScreens,MessageMediaViews,ComposerMediaViews}`, `ui/components/RemoteImage`, `ui/auth/AuthCommon`, `res/values{,-pl}/strings.xml`, `AndroidManifest.xml` (`RECORD_AUDIO`).
Testy (niewykonane): backend `MessageMediaTest`, `MessageAttachmentsTest`, `MessageAttachmentRoutesTest`, test V15 w `PostgresIntegrationTest` (poprawiono też nieaktualne asercje wersji migracji); Android `MessageViewModelsTest`, `MessageRepositoryImplTest`, `MessageMediaTypesTest`.
Dokumentacja: `PROJECT_STATUS.md` (Sesja 24), `README.md`, `docs/API.md` („Etap F”).

## Znane ograniczenia (szczegóły w PROJECT_STATUS.md, Sesja 24)
Pliki w pamięci (bez streamingu/Range); brak wideo w czacie; niewysłane wiadomości z mediami tylko w pamięci ViewModelu; usunięcie konta/rozmowy nie kasuje plików; `MediaStorage.delete` połyka błędy IO; limiter w pamięci procesu; walidacja dokumentów heurystyczna, bez antywirusa; brak E2EE (pliki jawne na serwerze).

## Ryzyka kompilacji do sprawdzenia w pierwszej kolejności
Coil `SubcomposeAsyncImage` (slots + `imageLoader`), `LifecycleEventEffect`, `AudioFocusRequest`, `MediaRecorder(Context)`, smart-casty w `ChatScreens`, `Mp4Inspector` (lokalna rekurencja), `ZipDirectory` (`return` w `repeat`), dynamiczne SQL w `PostgresMessageStore`, migracja V15 na bazie z danymi, test z refleksją na `onCleared`.
