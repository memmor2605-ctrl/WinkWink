# Powiadomienia push (FCM) — konfiguracja

Kod jest kompletny; **konfiguracji Firebase nie ma w repozytorium i musisz ją wykonać sam**. Bez niej aplikacja i backend działają normalnie, tylko push jest wyłączony (`GET /push/settings` zwraca `configured:false`, a ekran ustawień wiadomości pokazuje informację).

## Co musisz zrobić
1. W [Firebase Console](https://console.firebase.google.com) utwórz projekt i dodaj aplikację **Android** z identyfikatorem pakietu `app.winkwink` (musi zgadzać się z `applicationId`).
2. Pobierz `google-services.json` i połóż go w `android/app/google-services.json`. Plik jest w `.gitignore`. Gdy istnieje, `app/build.gradle.kts` sam aplikuje plugin Google Services (bez pliku build przechodzi, a push jest wyłączony).
3. W Firebase: *Project settings → Service accounts → Generate new private key*. Zapisz JSON jako `secrets/firebase-service-account.json` obok `docker-compose.yml` (katalog `secrets/` jest w `.gitignore`; w compose jest montowany jako `/run/secrets/winkwink`, tylko do odczytu).
4. W `.env` ustaw `WINKWINK_FCM_CREDENTIALS_FILE=/run/secrets/winkwink/firebase-service-account.json` i zrestartuj backend. W logu startowym zniknie komunikat „Push notifications disabled”.
5. Włącz w projekcie Google Cloud „Firebase Cloud Messaging API (V1)” (domyślnie włączone w nowych projektach).

Nigdy nie umieszczaj klucza konta serwisowego w aplikacji ani w repozytorium. Aplikacja zawiera wyłącznie publiczną konfigurację `google-services.json`.

## Jak to działa
- Aplikacja po zalogowaniu pobiera token FCM i woła `PUT /push/token` (token jest przypięty do sesji; kilka urządzeń = kilka tokenów, maks. 10 na konto). Nowy token (`onNewToken`) jest rejestrowany od razu. Wylogowanie wywołuje `DELETE /push/token` (nagłówek `X-Push-Token`) i usuwa token lokalnie; usunięcie konta lub sesji usuwa tokeny kaskadą, a unieważnione sesje są dodatkowo pomijane przy wysyłce. Token zarejestrowany przez inne konto na tym samym telefonie jest przepisywany na nowe konto.
- Backend wysyła do FCM (HTTP v1, OAuth2 z konta serwisowego) wyłącznie wiadomości **data-only**; teksty powiadomień buduje aplikacja (PL/EN). Nieważne tokeny (`UNREGISTERED`/404/`INVALID_ARGUMENT`) są usuwane z bazy.
- Kanały Androida: Wiadomości, Aktywność, Społeczności, Bezpieczeństwo konta.
- Wiadomości: push **nie jest wysyłany**, gdy odbiorca ma otwarte WebSocket (aplikacja na pierwszym planie), gdy wyciszył rozmowę lub nadawcę, gdy jest blokada w którąkolwiek stronę albo gdy wyłączył „Powiadamiaj o nowych wiadomościach” (`PUT /push/settings`). Treść wiadomości trafia do powiadomienia tylko po włączeniu „Pokazuj treść” (domyślnie wyłączone); powiadomienia mają wersję publiczną bez nadawcy i treści na ekranie blokady.
- Powiadomienia społecznościowe (obserwujący, prośby, reakcje, komentarze, odpowiedzi, zaproszenia do społeczności): push idzie tylko dla powiadomienia faktycznie zapisanego w bazie, czyli po tych samych filtrach co lista (dedup, blokady, wyciszenia, ustawienia typów). Anonimowe zdarzenia nie ujawniają autora.
- Zdarzenia konta: zmiana hasła i nowe logowanie → push `account` na pozostałe urządzenia.
- Odczyt na jednym urządzeniu (rozmowa, powiadomienie, „oznacz wszystkie”) wysyła push `dismiss`, który zdejmuje powiadomienie na pozostałych urządzeniach.
- Stuknięcie: otwiera rozmowę, post, profil, społeczność lub prośby o obserwowanie i oznacza powiadomienie jako przeczytane (stan jest na serwerze).
- Android 13+: zgoda `POST_NOTIFICATIONS` jest proszona raz po wejściu do aplikacji.
