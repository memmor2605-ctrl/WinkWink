#!/usr/bin/env bash
# Generuje PEŁNY Gradle Wrapper (gradlew, gradlew.bat, gradle/wrapper/gradle-wrapper.jar) dla backendu i Androida.
# Wymaga zainstalowanego Gradle >= 8.10 oraz dostępu do sieci. Uruchom raz z katalogu głównego repozytorium,
# a następnie ZACOMMITUJ wygenerowane pliki (łącznie z gradle-wrapper.jar).
# Jar i skrypty są binarne/oficjalne — nie da się ich sensownie napisać ręcznie, dlatego nie ma ich w paczce Stage 12
# (środowisko, w którym powstała, nie miało sieci ani Gradle).
set -euo pipefail
GRADLE_VERSION="8.10.2"
root="$(cd "$(dirname "$0")/.." && pwd)"
command -v gradle >/dev/null || { echo "Brak polecenia 'gradle' (potrzebny >= 8.10)." >&2; exit 1; }
for module in backend android; do
  echo ">> $module"
  (cd "$root/$module" && gradle wrapper --gradle-version "$GRADLE_VERSION" --distribution-type bin)
done
echo "Gotowe. Sprawdź: (cd backend && ./gradlew --version) oraz (cd android && ./gradlew --version)"
