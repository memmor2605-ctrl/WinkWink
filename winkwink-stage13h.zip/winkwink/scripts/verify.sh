#!/usr/bin/env bash
# Stabilizacja Stage 12B: wykonuje kroki 3.1–3.7 i zapisuje PRAWDZIWE kody wyjścia do build-reports/verify.txt.
# Wymaga: JDK 17+ (toolchain 17 pobierze foojay), Android SDK (ANDROID_HOME), sieć, Docker (opcjonalnie, dla migracji).
# Nic tu nie udaje sukcesu: krok bez wymaganego narzędzia dostaje status SKIPPED, nieudany — FAILED.
set -uo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
out="$root/build-reports"; mkdir -p "$out"; report="$out/verify.txt"
: > "$report"
run() { # nazwa katalog polecenie...
  local name="$1" dir="$2"; shift 2
  echo ">> $name" ; (cd "$dir" && "$@") >"$out/$name.log" 2>&1
  local rc=$?; [ $rc -eq 0 ] && s=OK || s="FAILED($rc)"
  echo "$name: $s  (log: build-reports/$name.log)" | tee -a "$report"
}
skip() { echo "$1: SKIPPED — $2" | tee -a "$report"; }

[ -x "$root/backend/gradlew" ] && [ -f "$root/backend/gradle/wrapper/gradle-wrapper.jar" ] \
  || run wrapper "$root" bash scripts/bootstrap-wrapper.sh
run jdk-info "$root" bash -c 'java -version; echo JAVA_HOME=$JAVA_HOME'
run backend-compile "$root/backend" ./gradlew --no-daemon compileKotlin compileTestKotlin
run backend-test    "$root/backend" ./gradlew --no-daemon test
if [ -n "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]; then
  run android-compile "$root/android" ./gradlew --no-daemon :app:compileDebugKotlin
  run android-unit    "$root/android" ./gradlew --no-daemon :app:testDebugUnitTest
else
  skip android "brak ANDROID_HOME / ANDROID_SDK_ROOT"
fi
if command -v docker >/dev/null; then
  c=ww-verify-pg
  docker rm -f $c >/dev/null 2>&1
  docker run -d --name $c -e POSTGRES_PASSWORD=pw -e POSTGRES_DB=ww postgres:16 >/dev/null && sleep 8
  rc=0
  for f in $(ls "$root"/backend/src/main/resources/db/migration/V*.sql | sort -V); do
    docker exec -i $c psql -v ON_ERROR_STOP=1 -U postgres -d ww < "$f" >>"$out/migrations.log" 2>&1 || { echo "migracja nieudana: $(basename "$f")" >>"$report"; rc=1; break; }
  done
  [ $rc -eq 0 ] && echo "migrations V1-V10: OK" | tee -a "$report" || echo "migrations: FAILED (build-reports/migrations.log)" | tee -a "$report"
  docker rm -f $c >/dev/null 2>&1
else
  skip migrations "brak Dockera (alternatywa: uruchom backend z PostgreSQL — Flyway zrobi to przy starcie)"
fi
echo; cat "$report"
