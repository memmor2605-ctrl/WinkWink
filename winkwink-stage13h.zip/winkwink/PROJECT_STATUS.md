# PROJECT_STATUS — WinkWink

Ostatnia aktualizacja: sesja 26 (Stage 13H: zamknięcie bety, bez builda). Poprzednio sesja 25 (Stage 13G: niezawodność; bez builda i bez testów). Poprzednio: sesja 23 (Etap E: WSS i synchronizacja; bez builda i bez testów). Data: 2026-11-24.

## ⚠️ Najważniejsze zastrzeżenie
**Nic z kodu Etapu 1 nie zostało skompilowane ani uruchomione.** Środowisko tej sesji nie ma Gradle, Android SDK, PostgreSQL ani dostępu do sieci.
Wyniki testów: **brak (testy napisane, niewykonane)**. Wykonano tylko: kontrolę zbalansowania nawiasów w plikach `.kt`,
walidację XML zasobów oraz spójność kluczy stringów EN/PL (brak brakujących i niezdefiniowanych kluczy).
Stan na Stage 12 jest **nadal taki sam**: nic nie skompilowano (patrz sesja 15). Pierwsze `gradle test` w `backend/` i `./gradlew testDebugUnitTest` w `android/` może wymagać poprawek importów i wersji API (Ktor 3.0.1, Tink 1.15, Retrofit 2.11).

## Ukończone (kod napisany, niezweryfikowany buildem)
**Etap 1 — backend**
- Migracja `V3__auth_hardening.sql`: rotacja refresh tokenów, `login_attempts`, `password_reset_tokens`.
- Rejestracja (e-mail, hasło, nick; automatyczny profil z unikalnym `ww_xxxxxxxxxx`), logowanie, wylogowanie, odświeżanie z rotacją i wykrywaniem ponownego użycia.
- Argon2id (Bouncy Castle), JWT access tokeny, natychmiastowe unieważnianie sesji, blokada brute force (konto + IP), osobny rate limit tras `/auth`.
- Reset hasła (jednorazowy token, TTL 60 min, hash w bazie), zmiana hasła, lista/unieważnianie sesji i urządzeń.
- Walidacja e-mail/hasła/nicku/platformy, błędy JSON z `requestId`, logi bez haseł/tokenów.
- Testy (napisane): `PasswordHasherTest`, `ValidatorsTest`, `AuthServiceTest` (17 przypadków), `AuthRoutesTest` (8), `AppConfigTest` (+JWT), `HealthRoutesTest` (dostosowany).

**Etap 1 — Android**
- Ekrany: logowanie, rejestracja, reset hasła (kod), konto w zakładce Profil, zmiana hasła, urządzenia i sesje, wylogowanie z potwierdzeniem; PL + EN.
- Sesja szyfrowana Tink AES-256-GCM (klucz w Android Keystore), Bearer + automatyczne, serializowane odświeżanie po 401, wylogowanie lokalne po odrzuceniu refresh tokenu.
- Bramka: niezalogowany nie widzi powłoki z zakładkami.
- Testy (napisane): `AuthValidationTest`, `AuthRepositoryImplTest` (mapowanie błędów, wylogowanie offline, `SessionRefresher`).

## Sesja 3 — Etap 2 (backend), niezweryfikowany buildem
- Migracja `V4__profiles_social_graph.sql`: `display_name`, `links`, klucz tła; tabele `follows`, `blocks`; trigger blokujący zmianę `winkwink_id`.
- `profile/`: `ProfileStore` (+Postgres), `ProfileService`, DTO, trasy (profil, edycja, wyszukiwanie, obserwowanie z prośbami dla kont niepublicznych, listy kursorowe, blokowanie). Szczegóły: `docs/API.md`.
- Testy napisane, niewykonane: `ProfileServiceTest` (9 przypadków, `InMemoryProfileStore`).
- Android Etapu 2 (niezweryfikowany buildem): `SocialApi`/`SocialRepositoryImpl`, ekrany: wyszukiwanie osób (debounce), profil użytkownika (obserwuj / prośba / przestań, blokada z potwierdzeniem, widok ograniczony), edycja własnego profilu (nazwa, bio, linki, widoczność); PL + EN; wejścia z zakładki Profil. Testy napisane, niewykonane: `SocialRepositoryImplTest` (9).
- **Brak**: ekrany list obserwujących/obserwowanych, próśb o obserwowanie i zablokowanych (API istnieje), wyciszanie, avatar/tło (czeka na decyzję o Object Storage), testy tras HTTP profili, test `PostgresProfileStore` na prawdziwej bazie, ustawienia prywatności poza `visibility`, wyciszanie.
- Środowisko sesji: Java 21 jest, brak Gradle/Kotlin/PostgreSQL/sieci → nic nie skompilowano. Sprawdzono tylko zbalansowanie nawiasów.

## Sesja 4 — Etap 3 (backend feedu), niezweryfikowany buildem
- Migracja `V5__feed.sql` (posty, reakcje, zapisy, komentarze; CHECK: anonimowy ⇒ publiczny).
- `feed/`: `FeedStore` (+Postgres z jedną klauzulą widoczności), `FeedService`, DTO, trasy; reguła `PostVisibility` jako jedno źródło prawdy (SQL ją odwzorowuje). Szczegóły i zasady anonimowości: `docs/API.md`.
- Testy napisane, niewykonane: `FeedServiceTest` (13 przypadków, `InMemoryFeedStore`).
- **Brak**: UI Androida feedu; media/galerie/filmy/załączniki; udostępnianie; widoczność „społeczność” (Etap 4); wyszukiwanie postów bez indeksu FTS; limit tempa publikowania (tylko globalny rate limit); testy tras HTTP i `PostgresFeedStore` na prawdziwej bazie (ryzyko: kolejność placeholderów w SQL budowanym dynamicznie — pierwsze do sprawdzenia).

## Sesja 5 — przegląd własnego kodu i testy HTTP (niezweryfikowane buildem)
- Znaleziony i naprawiony błąd: `PATCH /me/profile` z pustym `bio` nie czyścił bio (wracała stara wartość). Teraz: pole pominięte = bez zmian, pusty ciąg = wyczyszczenie. Test: `ProfileServiceTest` + `SocialRoutesTest`.
- Dodano `SocialRoutesTest` (6 testów HTTP: 401 dla wszystkich tras, obserwowanie, edycja bio/linków, brak ujawniania autora anonimowego posta w JSON, routing `/posts/search` vs `/posts/{id}`, komentarze). Wymaga prawdziwego uruchomienia Ktor test host.
- Uwaga dla klientów: serializer pomija pola z wartością domyślną `null` (np. `nextCursor`) — brak pola = koniec listy.

## Sesja 6 — Etap 3 (Android feedu), niezweryfikowany buildem
Środowisko jak wcześniej: Java jest, brak Gradle/Kotlin/Android SDK/PostgreSQL/sieci → **nic nie skompilowano ani nie uruchomiono**. Sprawdzono tylko zbalansowanie nawiasów i spójność kluczy stringów EN/PL (brak brakujących i niezdefiniowanych).
- Warstwa danych: `FeedApi` (Retrofit, 14 endpointów z `docs/API.md`), `FeedDto.kt` (mapowanie do modeli domenowych; zły format daty → `ApiFailure("invalid_response")`), `FeedRepository`/`FeedRepositoryImpl`, `PostValidation` (limity 5000/2000, anonimowy ⇒ publiczny), wpięcie w Hilt (`NetworkModule`, `RepositoryModule`).
- UI (Compose, zakładka Feed zastąpiła atrapę): Following/Discover z kursorowym dociąganiem stron i odświeżaniem, karta posta (reakcje z menu 5 typów, zapis, licznik komentarzy), nowy post (widoczność, przełącznik anonimowości wymuszający „publiczny”), szczegóły posta (edycja i usuwanie własnego posta z potwierdzeniem, komentarze, odpowiedzi jednopoziomowe, usuwanie komentarza przez autora komentarza lub posta). Liczniki po dodaniu/usunięciu komentarza są pobierane z serwera, nie liczone lokalnie. Lista odświeża się po powrocie ze szczegółów, jeśli coś zmieniono.
- Anonimowość w UI: autor anonimowego posta pokazywany jako „Anonim”; komentarz autora pod własnym anonimowym postem jako „Anonim (autor posta)”; Android nigdy nie dostaje ID konta autora.
- Jawnie oznaczone jako niedostępne w UI: zdjęcia/galerie/filmy/załączniki, widoczność „dla społeczności”.
- Testy napisane, niewykonane: `FeedRepositoryImplTest` (12), `FeedViewModelsTest` (11; wymaga `Dispatchers.setMain`), `PostValidationTest` (4).
- Ekran „Zapisane” (wejście z zakładki Profil): `FeedApi.saved`, `SavedPostsViewModel`, `SavedPostsScreen`; odznaczenie usuwa post z listy dopiero po potwierdzeniu serwera. Testy napisane, niewykonane (+3).
- **Brak w Etapie 3 (Android)**: wyszukiwanie postów w UI, posty wybranego użytkownika na ekranie profilu, udostępnianie, media, pull-to-refresh (jest przycisk „Odśwież”), cache offline.
- Znane ryzyka do sprawdzenia przy pierwszym buildzie: `LaunchedEffect` w elemencie listy „more” (dociąganie), `getStateFlow` + `collectAsState` w `MainShell`, smart-casty `FailureBanner(list.failure)`.

## Sesja 7 — Etap 4 (backend społeczności, część 1), niezweryfikowany buildem
Środowisko jak wcześniej: brak Gradle/Kotlin/PostgreSQL/sieci → **nic nie skompilowano ani nie uruchomiono** (sprawdzono tylko zbalansowanie nawiasów).
- Migracja `V6__communities.sql`: `communities` (unikalna nazwa bez rozróżniania wielkości liter wśród nieusuniętych), `community_members` (role; indeks gwarantujący jednego właściciela), `community_join_requests`, `community_invites`, `community_channels`.
- `community/`: `CommunityStore` (+`PostgresCommunityStore`, naruszenie unikalności → 409), `CommunityService` (cała logika uprawnień po stronie backendu), DTO, trasy (kontrakt w `docs/API.md`), wpięcie w `Application.kt`.
- Zasady: typ `invite` jest niewidoczny (404) bez członkostwa/zaproszenia; usunięcie społeczności i zmiana typu tylko przez właściciela; admin edytuje nazwę/opis/zasady i kanały; moderator zaprasza, rozpatruje prośby i usuwa członków o niższej randze; właściciel nadaje role i nie może opuścić społeczności.
- Testy napisane, niewykonane: `CommunityServiceTest` (22 przypadki, `InMemoryCommunityStore` w `src/test`). Brak testów tras HTTP i `PostgresCommunityStore` na prawdziwej bazie (ryzyko: dynamiczne SQL z kursorami i kolejność placeholderów — sprawdzić pierwsze; wyszukiwanie to `LIKE '%q%'` bez indeksu trigramowego).
- **Brak w Etapie 4** (po sesji 8 zrobione: posty w kanałach, widoczność „społeczność”, komentarze/reakcje działają przez zwykłe trasy postów): moderacja komentarzy przez moderatorów, zgłaszanie treści i moderacja (Etap 7), przekazanie własności, powiadomienia o zaproszeniach (Etap 6), wyciszanie członków. (Android: częściowo — patrz sesja 9.)

## Sesja 8 — Etap 4 (posty w społecznościach), niezweryfikowany buildem
Środowisko jak wcześniej: tylko Java; brak Gradle/Kotlin/Android SDK/PostgreSQL/sieci → **nic nie skompilowano ani nie uruchomiono** (sprawdzono tylko zbalansowanie nawiasów; jedyny alarm to nawias wewnątrz literału tekstowego w `AuthRoutesTest`).
- Migracja `V7__community_posts.sql`: widoczność `community`, kolumny `community_id`/`channel_id`, klucz złożony (kanał musi należeć do społeczności), CHECK-i zakresu i anonimowości, indeks. Stare CHECK-i `posts` odwołujące się do `visibility` są usuwane dynamicznie (bloki `DO`) — **do sprawdzenia na prawdziwej bazie**, jak i cała migracja.
- Backend: `PostVisibility` obsługuje `community`; SQL `VISIBLE` ma szósty placeholder (stała `VISIBLE_VIEWER_ARGS`); `POST /posts` z `communityId`/`channelId`; `GET /communities/{id}/posts`; moderator+ może usuwać posty w swojej społeczności. Szczegóły: `docs/API.md`.
- Android: poprawiona etykieta widoczności (`community` nie jest już pokazywane jako „Publiczny”), EN + PL. **Brak** wyboru społeczności/kanału w ekranie nowego posta i jakichkolwiek ekranów społeczności.
- Testy napisane, niewykonane: `CommunityPostsTest` (14 przypadków: członkostwo, kanał z innej społeczności, walidacja, widoczność dla obcych, paginacja, filtr kanału, usuwanie przez moderatora i jego granice, utrata dostępu po wyjściu/usunięciu społeczności, blokady). `InMemoryFeedStore` przyjmuje opcjonalny `CommunityStore`.
- Znane ryzyka: usunięcie kanału twardo kasuje posty (udokumentowane; UI musi to potwierdzać); brak testu `PostgresFeedStore` na prawdziwej bazie (zapytanie `VISIBLE` jest teraz dłuższe); `communityRole` w `FeedStore` duplikuje część `CommunityStore.roleOf` (ten drugi nie uwzględnia usuniętych społeczności).

## Sesja 9 — Etap 4 (Android społeczności), niezweryfikowany buildem
Środowisko jak wcześniej: tylko Java → **nic nie skompilowano ani nie uruchomiono** (sprawdzono zbalansowanie nawiasów, spójność kluczy stringów EN/PL i poprawność XML).
- Dane: `CommunityApi` (11 endpointów z `docs/API.md`), `CommunityDto`, `CommunityRepository(Impl)`, `CommunityValidation`, Hilt (`NetworkModule`, `RepositoryModule`). `Post` ma opcjonalne `communityId`/`channelId`; `FeedRepository.createCommunityPost`.
- UI (zakładka Społeczności zastąpiła atrapę): lista „Moje społeczności” z dociąganiem stron, zaproszenia (przyjmij/odrzuć), wyszukiwanie z debounce, tworzenie (nazwa, opis, zasady, typ), szczegóły (opis, zasady, rola, dołącz / poproś o dołączenie / cofnij prośbę / opuść z potwierdzeniem, filtr kanałów, posty ze stronicowaniem, reakcje/zapis, okno pisania posta w wybranym kanale). Stan członkostwa i rola zawsze pochodzą z serwera (po akcji ekran ładuje się ponownie). Niebędący członkiem nie pobiera postów. Treść ekranu nowego posta w Feedzie wskazuje, że posty społeczności pisze się z poziomu społeczności.
- Testy napisane, niewykonane: `CommunityValidationTest` (2), `CommunityRepositoryImplTest` (10), `CommunityViewModelsTest` (15; wymaga `Dispatchers.setMain`). Debounce wyszukiwania nie jest testowany.
- **Brak w Androidzie społeczności**: lista członków i zarządzanie nimi (role, usuwanie), zapraszanie użytkowników, rozpatrywanie próśb (API istnieje), edycja/usuwanie społeczności, zarządzanie kanałami (dodawanie/usuwanie — usunięcie kanału kasuje jego posty), usuwanie cudzych postów przez moderatora w UI (backend pozwala), zgłaszanie treści (Etap 7). Właściciel/admin nie ma więc jeszcze w aplikacji żadnych narzędzi administracyjnych.
- Znane ryzyka do sprawdzenia przy pierwszym buildzie: `return@update` wewnątrz `MutableStateFlow.update` (`CommunityDetailViewModel.loadPosts`), `LaunchedEffect` w elemencie listy „more”, delegacja `object : CommunityApi by api` w teście, `Row` z `horizontalScroll` w elemencie `LazyColumn`.

## Sesja 10 — Etap 4 (zarządzanie społecznością w Androidzie), niezweryfikowany buildem
Środowisko jak wcześniej → **nic nie skompilowano ani nie uruchomiono** (sprawdzono nawiasy, klucze stringów EN/PL, XML). Ścieżki i pola żądań zweryfikowano ręcznie z `CommunityRoutes.kt`/`CommunityDtos.kt`.
- Nowy ekran „Zarządzanie” (przycisk „Zarządzaj” w szczegółach dla moderator+): zaproszenia (po nazwie użytkownika/WinkWink ID), prośby o dołączenie (przyjmij/odrzuć), lista członków ze stronicowaniem, zmiana ról (tylko właściciel), usuwanie członków niższej rangi, kanały (dodaj/usuń; admin+; usunięcie z ostrzeżeniem o twardym skasowaniu postów; ostatniego kanału nie można usunąć — reguła `last_channel` backendu), usunięcie społeczności (tylko właściciel, z potwierdzeniem).
- UI tylko odzwierciedla rolę; uprawnienia egzekwuje backend. Listy po każdej akcji ładują się z serwera.
- Testy napisane, niewykonane: +13 w `CommunityViewModelsTest` (10 zarządzania), +3 w `CommunityRepositoryImplTest`.
- **Nadal brak**: edycja nazwy/opisu/zasad/typu społeczności (backend `PATCH` istnieje), przekazanie własności, usuwanie cudzych postów przez moderatora przyciskiem na poście, wyszukiwanie użytkowników do zaproszenia (obecnie wpisuje się identyfikator ręcznie), zgłaszanie treści (Etap 7). Zaproszenie nieistniejącego użytkownika zwraca błąd z backendu — komunikat błędu jest ogólny.
- Do sprawdzenia przy pierwszym buildzie: `return@Column` w `ManageCommunityScreen`, importy w testach (`PersonDto` itd.).

## Sesja 11 — Etap 4 (edycja społeczności, moderacja postów), niezweryfikowany buildem
Środowisko jak wcześniej → **nic nie skompilowano ani nie uruchomiono** (sprawdzono nawiasy i klucze stringów EN/PL). Reguły zweryfikowano ręcznie z `CommunityService.update`: edycja wymaga admina, zmiana typu — właściciela.
- Edycja nazwy/opisu/zasad (admin+) i typu (tylko właściciel) na ekranie zarządzania; wysyłane są tylko zmienione pola; szkic nie jest nadpisywany przy przeładowaniu; błąd (np. `community_name_taken`) zachowuje szkic.
- Przycisk „Usuń post” przy cudzych postach dla moderator+ (z potwierdzeniem; post znika z listy po potwierdzeniu serwera).
- Testy napisane, niewykonane: +9 w `CommunityViewModelsTest`, +1 w `CommunityRepositoryImplTest`.
- **Etap 4 w Androidzie — nadal brak**: przekazanie własności (**backend też nie ma tego endpointu**), wyszukiwarka użytkowników do zaproszeń, komunikaty błędów specyficzne dla kodów backendu (obecnie ogólne), zgłaszanie treści i moderacja komentarzy (Etap 7), cache/offline. Wyznaczanie właściciela przy usunięciu konta zależy od Etapu 8.
- Etap 4 uznaję za funkcjonalnie kompletny **po stronie kodu**, ale niezweryfikowany: żadna część nie przeszła kompilacji ani testów.

## Sesja 12 — Etap 6 (powiadomienia, backend), niezweryfikowany buildem
Środowisko jak wcześniej → **nic nie skompilowano ani nie uruchomiono** (sprawdzono tylko nawiasy). Wiem też, że importy w trzech edytowanych serwisach nie są posortowane — jeśli projekt ma ktlint/detekt, build może to zgłosić.
- Migracja `V8__notifications.sql` (tabele `notifications`, `notification_settings`; CHECK-i spójności typ↔pola; indeks unikalny deduplikujący reakcje/obserwowanie/zaproszenia).
- Pakiet `notification`: `NotificationStore` (+Postgres), `NotificationService` (implementuje `Notifier`), trasy, DTO. Serwisy `ProfileService`, `FeedService`, `CommunityService` dostały opcjonalny `Notifier` (domyślnie `None`, więc dotychczasowe konstruktory i testy się nie zmieniają) i zgłaszają zdarzenia: obserwowanie / prośba, reakcja, komentarz, odpowiedź, zaproszenie do społeczności. Wiring w `Application.kt`.
- Testy napisane, niewykonane: `NotificationServiceTest` (15), `NotificationRoutesTest` (5), `InMemoryNotificationStore`.
- **Nie zrobione w Etapie 6**: Android (lista, licznik, ustawienia), wzmianki (wymagają parsowania @nick i reguł dla anonimowych treści), powiadomienia o wiadomościach (Etap 5), o aktywności w społecznościach (np. nowy post, prośba o dołączenie dla moderatorów), komunikaty systemowe, **FCM** (potrzebny projekt Firebase i klucz konta usługi — sekret poza repozytorium; to Twoja decyzja/konfiguracja), powiadomienie „prośba o obserwowanie zaakceptowana”.
- Znane ryzyka: `markRead` używa modyfikującego CTE (do sprawdzenia na prawdziwej bazie); zapytanie listy łączy 6 tabel — brak testu wydajności; powiadomienie o poście nie pokazuje się po jego soft-delete (JOIN), ale odpowiednie testy działają tylko na magazynie w pamięci, który nie modeluje usuwania.
- Otwarta decyzja: FCM — czy dane w payloadzie push mają być wyłącznie identyfikatorami (rekomendacja: tak, bez treści i nazw).

## Sesja 13 — Etap 6 (Android powiadomień) + poprawka prywatności, niezweryfikowane buildem
Środowisko: tylko Java 21 (brak Gradle/Kotlin/Android SDK/PostgreSQL/sieci) → **nic nie skompilowano ani nie uruchomiono**. Sprawdzono tylko zbalansowanie nawiasów we wszystkich 141 plikach `.kt`, poprawność XML i zgodność kluczy `activity_*` EN/PL (26/26).
- **Błąd prywatności (backend) — naprawiony w kodzie:** gdy autor *anonimowego* posta odpowiadał na komentarz, powiadomienie o odpowiedzi trafiało do komentującego z prawdziwym aktorem (nick i WinkWink ID autora) — ujawnienie powiązania anonimowego posta z kontem. Teraz: `NotificationEvent.actorAnonymous`, migracja `V9__notification_actor_anonymous.sql` (kolumna `actor_anonymous`), `NotificationDto` pomija `actor` i ustawia `actorAnonymous: true`; konto nadal zapisane w bazie (moderacja). Test regresyjny HTTP w `NotificationRoutesTest` (odpowiedź autora anonimowego posta nie zawiera jego nicku). Zmiana kontraktu opisana w `docs/API.md`. **Zmiana API:** `actor` jest teraz opcjonalne.
- **Android — Etap 6:** `NotificationApi` (+DTO, mapowanie; anonimowy aktor nigdy nie jest pokazywany), `NotificationRepository(Impl)`, Hilt. Zakładka **Aktywność** zastąpiła atrapę: lista kursorowa z dociąganiem, filtry (wszystkie / nieprzeczytane / 6 typów), oznaczanie jednego (po potwierdzeniu serwera) i wszystkich (z uwzględnieniem aktywnego filtra typu), przejście do profilu / posta / społeczności, ekran **ustawień powiadomień** (przełączniki per typ, stan z serwera), licznik nieprzeczytanych na ikonie zakładki (odświeżany przy zmianie ekranu). PL + EN.
- Ekran ustawień **wprost** informuje, że powiadomienia push nie są jeszcze dostępne.
- Testy napisane, niewykonane: `NotificationRepositoryImplTest` (8), `ActivityViewModelsTest` (13; wymaga `Dispatchers.setMain`), backend +1 (`NotificationRoutesTest`).
- **Nadal brak w Etapie 6:** FCM (czeka na projekt Firebase i klucz konta usługi — poza repozytorium), wzmianki, powiadomienia o wiadomościach (Etap 5) i aktywności w społecznościach, komunikaty systemowe, powiadomienie „prośba o obserwowanie zaakceptowana”, pull-to-refresh (jest przycisk „Odśwież”), testy UI Compose.
- Znane ryzyka do sprawdzenia przy pierwszym buildzie: `FilterChip` może wymagać `@OptIn(ExperimentalMaterial3Api::class)` zależnie od wersji BOM; `LaunchedEffect` w elemencie „more”; `BadgedBox`/`Badge` w `MainShell`; `hiltViewModel()` w `MainShell` (zakres: Activity); odświeżanie licznika przy **każdej** zmianie ekranu (do ograniczenia, gdy pojawi się cache lub WSS).
- Do sprawdzenia na prawdziwej bazie: migracja V9 (prosty `ADD COLUMN ... DEFAULT false`) oraz zapytanie listy z nową kolumną.

## Sesja 14 — Etap 5 (wiadomości, backend REST), niezweryfikowany buildem
Środowisko jak wcześniej → **nic nie skompilowano ani nie uruchomiono** (sprawdzono tylko zbalansowanie nawiasów w plikach backendu). **Wiadomości NIE są szyfrowane end-to-end** — treść czytelna dla serwera; ograniczenie opisane w `docs/API.md`.
- Migracja `V10__messages.sql`: `conversations` (jedna rozmowa 1:1 na parę dzięki `direct_key`), `conversation_members` (role, `left_at`, odczyt, wyciszenie, archiwum), `messages` (odpowiedzi, edycja, miękkie usuwanie z czyszczeniem treści), `message_settings` (potwierdzenia odczytu).
- Pakiet `message`: `MessageStore` (+Postgres, +`InMemoryMessageStore` w testach), `MessageService` (cała autoryzacja po stronie backendu), DTO, trasy; wpięte w `Application.kt`. Funkcje: rozmowy 1:1 i grupowe, tekst, odpowiedzi, edycja (autor), usuwanie (autor / właściciel grupy), status wysłano/przeczytano z kontrolą prywatności, licznik nieprzeczytanych, wyszukiwanie, archiwizacja, wyciszanie, zarządzanie członkami grup, blokady.
- Testy napisane, niewykonane: `MessageServiceTest` (14), `MessageRoutesTest` (5, HTTP).
- **Brak w Etapie 5:** cały Android wiadomości (zakładka nadal oznaczona jako niedostępna), WSS (synchronizacja, ponowne połączenie, wskaźnik pisania), status „dostarczono”, zdjęcia/dokumenty/głosowe (Object Storage), reakcje na wiadomości, przekazanie własności i role administratora w grupie (brak endpointu zmiany roli), powiadomienia o wiadomościach (CHECK typów w `notifications` do rozszerzenia), **E2EE**.
- Ryzyka do sprawdzenia na prawdziwej bazie: długie zapytanie `summaries` (LATERAL + podzapytania; kolejność placeholderów), `ON CONFLICT (direct_key)` dla rozmów 1:1, powrót do grupy po opuszczeniu (`addMember` zeruje odczyt). Rozmowa 1:1 po blokadzie pozostaje widoczna (historia), ale wysyłanie jest blokowane.

## Sesja 15 — Stage 12: stabilizacja i weryfikacja (przegląd statyczny; build NIEWYKONANY)

### Czego NIE udało się zrobić (środowisko)
Środowisko: JDK 21 + Python. **Brak** Gradle, Kotlin, Android SDK, PostgreSQL, Dockera i dostępu do sieci (sprawdzone: brak odpowiedzi z Maven Central
i services.gradle.org, brak `~/.gradle`, `~/.m2`, `pg_ctl`). Dlatego **NIE wykonano**: budowy backendu, uruchomienia testów backendu, budowy Androida,
testów jednostkowych Androida, migracji V1–V10 na PostgreSQL, wygenerowania `gradle-wrapper.jar`/`gradlew`. Żadnego z tych wyników nie deklaruję.
Wyniki: kompilacja backendu — **niewykonana**; kompilacja Androida — **niewykonana**; testy backendu — **niewykonane**; testy Androida — **niewykonane**.

### Co faktycznie zrobiono (statycznie)
- Kontrola składni: bilans nawiasów we wszystkich 154 plikach `.kt`/`.kts` (z literałami, raw stringami, komentarzami, szablonami `${}`) — 0 problemów; 8 plików XML poprawnych; stringi EN/PL: 286/286, brak kluczy użytych w kodzie a niezdefiniowanych. **To nie jest kompilacja** — nie wykrywa błędów typów, importów ani rozwiązywania symboli.
- Zgodność API Android ↔ backend (skrypt porównujący adnotacje Retrofit z trasami Ktor, z uwzględnieniem zagnieżdżeń): **63/63 endpointów Androida istnieje** w backendzie z tą samą metodą i ścieżką. Pola 16 DTO żądań Androida ⊆ pola żądań backendu (istotne, bo backend ma `ignoreUnknownKeys = false`); wymagane pola odpowiedzi zgadzają się; nadmiarowe pola odpowiedzi (`hasAvatar`, `visibility` w `UserSummaryDto`) Android toleruje (`ignoreUnknownKeys = true`). Heurystyka po nazwach pól — nie zastępuje testu kontraktowego.
- Zależności: każdy import `io.ktor.*` backendu ma pokrycie w `build.gradle.kts`; importy Androida nie wymagają bibliotek spoza `libs.versions.toml`; używane ikony (`Person`, `Notifications`, `Home`, `Face`, `Email`, `AutoMirrored.ArrowBack`) należą — według mojej wiedzy, bez możliwości sprawdzenia w artefakcie — do `material-icons-core`; testy Androida używają tylko JUnit4 i `kotlinx-coroutines-test` (zadeklarowane). Wersje bibliotek zgodne z kompatybilnością znaną na dzień pisania (Kotlin 2.0.21, KSP 2.0.21-1.0.28, AGP 8.7.3 na Gradle 8.10.2, Ktor 3.0.1, Hilt 2.52, Flyway 10.21 + `flyway-database-postgresql`) — **nie sprawdzono rozwiązywania zależności** (brak sieci).
- Przegląd SQL: `PostgresMessageStore`, `PostgresNotificationStore`, `PostgresCommunityStore`, `PostgresFeedStore` oraz migracji V5–V10 — ręczna analiza kolejności placeholderów (m.in. `summaries`: 2 + filtry + kursor + limit; `VISIBLE`: dokładnie 6 identyfikatorów widza = `VISIBLE_VIEWER_ARGS`; `search`: LIKE przed viewer), kolumn względem schematu, ograniczeń CHECK, `ON CONFLICT`, modyfikującego CTE w `markRead` (wykonywane niezależnie od odczytu — poprawne), `ESCAPE '\'`. Nie znalazłem błędu w kolejności placeholderów. **To nadal tylko czytanie kodu.**

### Znalezione i naprawione błędy
1. **Prywatność (poważny): blokada jako wyrocznia deanonimizacji** — dla treści anonimowych skutek blokady zdradzał autora: widz blokuje podejrzaną osobę i sprawdza, czy anonimowy post / komentarz autora pod własnym postem / powiadomienie o odpowiedzi znika (albo nie powstaje). Dotyczyło `PostVisibility`/SQL `VISIBLE`, SQL komentarzy, `NotificationService.notify` i `FROM_VISIBLE` powiadomień. Poprawka: dla treści anonimowych ignorowany jest kierunek „widz/odbiorca zablokował autora”; kierunek „autor zablokował widza” nadal ukrywa. Zachowanie treści jawnych bez zmian. Zmiany: `PostgresFeedStore` (2 fragmenty SQL, bez zmiany liczby placeholderów), `PostgresNotificationStore` (1 fragment), `NotificationService`, komentarz w `FeedStore.kt`, oba magazyny w pamięci używane w testach. Opisane w `docs/API.md`. Testy: `FeedServiceTest` +2, `NotificationServiceTest` +2, oraz test SQL w `PostgresIntegrationTest`. **Zmiana zachowania uzasadniona prywatnością; niezweryfikowana buildem.**
2. **Autoryzacja rozmów: wyrocznia istnienia wiadomości** — `PATCH/DELETE /messages/{id}` dawał `conversation_not_found` dla istniejącej cudzej wiadomości i `message_not_found` dla nieistniejącej. Teraz oba przypadki → `404 message_not_found`. Test: `MessageServiceTest` +1.
3. **Gradle**: `android/gradle/gradle-wrapper.properties` leżał w złym katalogu (Gradle szuka `gradle/wrapper/`) — przeniesiony; dodano `backend/gradle/wrapper/gradle-wrapper.properties` (8.10.2); dodano `scripts/bootstrap-wrapper.sh`; oba `settings.gradle.kts` dostały `foojay-resolver-convention 0.8.0` (oba moduły wymagają `jvmToolchain(17)`, a bez resolvera build zawiedzie na maszynie z samym JDK 21 — jak to środowisko). **Wrapper nadal niekompletny** (brak `gradlew`, `gradlew.bat`, `gradle-wrapper.jar` — plików binarnych/oficjalnych nie dało się wygenerować bez Gradle i sieci; nie pisałem ich z pamięci).
4. Dokumentacja: README zawierał nieaktualne zdania (stan zakładek, brak informacji o wrapperze) — poprawione; dodano instrukcję pierwszego uruchomienia.

### Nowe testy (napisane, niewykonane)
`PostgresIntegrationTest` (5 testów, **pomijane bez** `WINKWINK_TEST_DATABASE_URL`; raportowane jako *skipped*, nie *passed*): migracje V1–V10 na pustej bazie + ograniczenia V3/V4/V7; rotacja refresh tokenów w `PostgresAuthStore` (poprzedni hash rozpoznawany, nieaktualna rotacja odrzucona); prywatność anonimowych treści/powiadomień w prawdziwym SQL; zapytania `PostgresMessageStore` (jedna rozmowa 1:1 na parę, `summaries` z filtrem/archiwum/kursorem/unread, miękkie usuwanie, powrót do grupy); `markRead`/deduplikacja w `PostgresNotificationStore`. Testy backendu: 147 → 157 (+5 jednostkowych, +5 integracyjnych); Android bez zmian (124 `@Test`).
Nie usunięto ani nie osłabiono żadnego istniejącego testu.

### Znalezione, NIEnaprawione (decyzje / ryzyka)
- **Historia grupy po ponownym dodaniu**: `messages()` zwraca wszystkie wiadomości rozmowy bez względu na `joined_at`; osoba usunięta z grupy i dodana ponownie widzi wiadomości z okresu, gdy jej nie było (nowi członkowie widzą też historię sprzed dołączenia). Wymaga decyzji produktowej (widoczność od `joined_at`?), więc nie zmieniałem.
- **Rotacja refresh tokenów**: wykrywane jest tylko ponowne użycie *bezpośrednio poprzedniego* tokenu; token starszy o dwie rotacje daje zwykłe `401 invalid_refresh_token` bez unieważnienia sesji. Równoległe odświeżenie tym samym tokenem → drugie żądanie dostaje 401 (bez unieważnienia). Utrata odpowiedzi `/auth/refresh` nadal wylogowuje (już w „Znanych ograniczeniach”).
- `conversations.created_by ... ON DELETE CASCADE`: usunięcie konta twórcy usuwa rozmowę (także grupową) wraz z wiadomościami innych osób — do przeglądu przy Etapie 8 (usuwanie konta).
- Skutek uboczny poprawki 1: odbiorca, który zablokował (nieznanego mu) anonimowego autora, nadal dostaje jego anonimowe odpowiedzi — to świadoma cena braku wyroczni. Rozważyć wyciszanie wątku po stronie odbiorcy.
- Wszystkie ryzyka z sesji 2–14 (np. `LaunchedEffect` w elementach „more”, `FilterChip` i `@OptIn`, `return@update` w `MutableStateFlow.update`, `hiltViewModel()` w `MainShell`, nieposortowane importy) **pozostają niezweryfikowane** — to pierwsze miejsca do sprawdzenia, gdy kompilator coś zgłosi. Release: `isMinifyEnabled = true` bez przetestowanych reguł R8 dla Tink/Retrofit — przed wydaniem zbudować `assembleRelease` i sprawdzić.
- Brak testów Compose/instrumentowanych; testy HTTP tras Communities i Profile nadal tylko przez serwisy.

### Zmodyfikowane / dodane pliki (względem Stage 11)
Zmodyfikowane: `README.md`, `PROJECT_STATUS.md`, `docs/API.md`, `android/settings.gradle.kts`, `backend/settings.gradle.kts`, `backend/.../feed/FeedStore.kt`, `.../feed/PostgresFeedStore.kt`, `.../message/MessageService.kt`, `.../notification/NotificationService.kt`, `.../notification/PostgresNotificationStore.kt`; testy: `FeedServiceTest`, `InMemoryFeedStore`, `MessageServiceTest`, `NotificationServiceTest`, `InMemoryNotificationStore`.
Przeniesione: `android/gradle/gradle-wrapper.properties` → `android/gradle/wrapper/gradle-wrapper.properties`.
Dodane: `backend/gradle/wrapper/gradle-wrapper.properties`, `scripts/bootstrap-wrapper.sh`, `backend/src/test/kotlin/app/winkwink/server/database/PostgresIntegrationTest.kt`.

## Sesja 22 — Etap D (Android Messages + uzupełnienia backendu), kod napisany, NIEZBUDOWANY i NIEPRZETESTOWANY

Nie uruchamiano kompilacji ani testów (zgodnie z poleceniem). Sprawdzono tylko statycznie: nawiasy w nowych/zmienionych plikach `.kt`, parytet 444/444 kluczy EN/PL, brak użytych a niezdefiniowanych `R.string.*`, poprawność XML, brak zdublowanych nazw klas w pakietach.

### Ukończone w kodzie (niezweryfikowane)
- **Backend (uzupełnienia pod Android):** migracja `V14` (`message_reactions`, `conversation_members.last_delivered_at`); reakcje `PUT/DELETE /messages/{id}/reaction` (6 rodzajów, jedna na osobę, liczniki bez ujawniania autorów reakcji, czyszczone przy usunięciu wiadomości); status `delivered` (ustawiany przy pobraniu listy rozmów / wiadomości przez REST, widoczny tylko przy włączonych potwierdzeniach obu stron); `PUT /conversations/{id}/members/{user}/role` (właściciel nadaje/odbiera `admin`); `avatarTag` w osobach wiadomości. Szczegóły: `docs/API.md`.
- **Android Messages:** `MessageApi`/`MessageRepositoryImpl` (pełny kontrakt REST wiadomości), `MessageValidation`, Hilt. Zakładka Wiadomości zastąpiła atrapę: lista rozmów (wyszukiwanie z debounce, aktywne/zarchiwizowane, nieprzeczytane, podgląd, wyciszanie, archiwizowanie, stronicowanie), nowa rozmowa 1:1 (wyszukiwarka osób), nowa grupa (nazwa + wybór członków), wejście „Napisz wiadomość” z profilu użytkownika, ekran czatu (wysyłanie z lokalnym statusem „wysyłanie / nie wysłano” + ponów/odrzuć, odpowiedzi z podglądem cytatu, edycja własnych, usuwanie z potwierdzeniem — autor lub właściciel/admin grupy, 6 reakcji, statusy wysłano/dostarczono/przeczytano, kopiowanie tekstu, wyciszanie/archiwizacja z poziomu czatu, dociąganie starszych), zarządzanie członkami grupy (lista, dodawanie przez wyszukiwarkę, usuwanie, role admin, opuszczenie grupy z potwierdzeniem; właściciel nie może opuścić), ustawienia wiadomości (potwierdzenia dostarczenia/odczytu). Wszystkie stany zawsze z serwera po potwierdzeniu; UI tylko odzwierciedla uprawnienia, egzekwuje je backend.
- **Stan szyfrowania:** ekran czatu i ustawienia jawnie pokazują „Bez szyfrowania end-to-end” (`MessagingStatus.encryption = TRANSPORT_ONLY`); do zmiany dopiero po Etapie G.
- Testy napisane, **niewykonane**: backend `MessageServiceTest` (+5), `MessageRoutesTest` (+2); Android `MessageRepositoryImplTest` (6), `MessageViewModelsTest` (17).

### Częściowo / ograniczenia
- (Zaktualizowane w sesji 23) Odświeżanie na żywo przez WSS, REST jako zapas. „Dostarczono” oznacza pobranie przez REST, nie wyświetlenie.
- Brak załączników i wiadomości głosowych w czacie (Etap F), brak powiadomień o wiadomościach i FCM (Etap H). Wskaźnik pisania i licznik na zakładce dodano w sesji 23.
- Historia grupy po ponownym dodaniu — nadal bez decyzji produktowej (nowi członkowie widzą całą historię). Brak przekazania własności grupy i zmiany nazwy grupy. Reakcje pokazują tylko liczby (bez listy osób).
- Wiadomości od konta, które zablokowałeś/-aś, nadal są widoczne w historii (zgodnie z wcześniejszą decyzją backendu); wysyłanie jest blokowane.
- Edycja/usunięcie cudzej wiadomości w 1:1 niemożliwe (tylko autor).
- Avatar grupy to inicjał (grupy nie mają obrazów).

### Do sprawdzenia przy pierwszym buildzie
`LifecycleResumeEffect` (lifecycle-runtime-compose 2.8.7), `LocalClipboardManager` (może być oznaczony jako przestarzały), `Icons.AutoMirrored.Filled.Send` w `material-icons-core`, `FilterChip` bez `@OptIn`, `reverseLayout` w `LazyColumn` z elementem „more” (`LaunchedEffect`), `GroupMembersViewModel` (wywołanie `AuthRepository.me()`), `supportingText = if … else null`, SQL w `PostgresMessageStore` (nowe kolumny `avatar_object_key`/`last_delivered_at`, `greatest(coalesce(...))`, dynamiczne `IN (?,…)`), migracja `V14` na realnej bazie.

### Zmienione/nowe pliki
Backend — `V14__message_reactions_delivery.sql`, `message/{MessageStore,PostgresMessageStore,MessageService,MessageDtos,MessageRoutes}.kt`; testy `InMemoryMessageStore.kt`, `MessageServiceTest.kt`, `MessageRoutesTest.kt`. Android — `domain/model/MessageModels.kt`, `domain/repository/MessageRepository.kt`, `domain/validation/MessageValidation.kt`, `data/remote/MessageApi.kt`, `data/repository/MessageRepositoryImpl.kt`, `ui/messages/{MessageViewModels,MessageScreens,ChatScreens}.kt`, `di/{NetworkModule,RepositoryModule}.kt`, `ui/navigation/{MainTab,MainShell}.kt`, `ui/social/SocialScreens.kt` (przycisk „Napisz wiadomość”), `ui/auth/AuthCommon.kt` (nowe kody błędów), strings EN/PL (usunięto `placeholder_messages`); testy `data/MessageRepositoryImplTest.kt`, `ui/MessageViewModelsTest.kt`; `docs/API.md`, `README.md`.

### Otwarte decyzje
Widoczność historii grupy od `joined_at`; czy pokazywać listę osób przy reakcjach; czy wyłączone potwierdzenia mają też ukrywać wskaźnik pisania (Etap E).

### Następny zalecany krok
Zbuduj i uruchom testy (Etapy A–D), potem **Etap E**: WSS (uwierzytelnienie, zdarzenia, ponowne łączenie, synchronizacja po powrocie sieci, wskaźnik pisania, na żywo statusy), z REST jako zapasem.

## Sesja 23 — Etap E (WSS i synchronizacja), kod napisany, NIEZBUDOWANY i NIEPRZETESTOWANY

Nie uruchamiano kompilacji ani testów. Statycznie sprawdzono: nawiasy w nowych/zmienionych plikach `.kt`, parytet kluczy EN/PL, brak użytych a niezdefiniowanych `R.string.*`.

### Ukończone w kodzie (niezweryfikowane)
- **Backend:** `ktor-server-websockets`; `RealtimeHub` (rejestr połączeń, kolejka 64 z odrzucaniem najstarszych, limit 5 połączeń na konto), `GET /api/v1/ws` uwierzytelniany nagłówkiem Bearer (JWT + aktywna sesja), życie połączenia ≤ 15 min i kontrola sesji co 30 s, limity ramek, `hello`/`ping`. `MessageService` publikuje zdarzenia (`message.new/updated/deleted`, `receipt`, `conversation.new/updated`, `member.changed`, `typing`) przez interfejs `MessageEvents`; błąd publikacji nigdy nie psuje operacji. Zdarzenia nie niosą treści. `markDelivered` zwraca tylko rozmowy, w których stan faktycznie się zmienił — dzięki temu `receipt` nie nakręca pętli. Wskaźnik pisania: tylko przy włączonych potwierdzeniach po obu stronach, w 1:1 nie przez blokadę.
- **Android:** `RealtimeClient` + `OkHttpRealtimeClient` (OkHttp WebSocket na kliencie „authed”: Bearer, TLS, HTTPS-only, odświeżenie tokenu po 401, ping 25 s, backoff 1→30 s z jitterem, natychmiastowe ponowienie po powrocie sieci przez `ConnectivityManager`, zdarzenie `connected` po każdym połączeniu). WSS jest utrzymywany, gdy aplikacja jest na pierwszym planie (`LifecycleResumeEffect` w `MainShell`). Lista rozmów i czat odświeżają się na zdarzeniach (z zlewaniem serii), po powrocie połączenia dogonienie stanu przez REST i automatyczne ponowienie wiadomości, które nie wyszły przez brak sieci (tylko błędy `network`/`timeout`). Wskaźnik pisania (wysyłanie co ≥ 3 s, wygasanie po 6 s, czyszczony nową wiadomością tej osoby), baner „brak połączenia na żywo”, znaczek nieprzeczytanych wiadomości na zakładce (bez wyciszonych; przybliżony przy > 30 rozmowach). Odpytywanie REST zostało jako zapas: 60 s przy WSS, 8 s bez. Utrata dostępu do rozmowy (np. usunięcie z grupy) jest pokazywana po zdarzeniu.
- Testy napisane, **niewykonane**: backend `RealtimeHubTest` (6), `MessageEventsTest` (9), `RealtimeRoutesTest` (2, testy WS przez Ktor test host); Android `RealtimeClientTest` (5), `MessageViewModelsTest` rozszerzony do 26 testów.

### Częściowo / ograniczenia
- WSS działa tylko na pierwszym planie; w tle nie ma połączenia ani powiadomień (to Etap H: FCM). Do tego czasu wiadomość w tle zostanie odebrana po powrocie do aplikacji.
- Wylogowanie zamyka połączenie z opóźnieniem do ok. 30 s (kontrola sesji); `RealtimeHub.disconnectSession` jest gotowe, ale nie podpięte pod wylogowanie.
- Odrzucone zdarzenia (przepełniona kolejka) nie są sygnalizowane — klient odzyskuje stan przy następnym zdarzeniu, ponownym połączeniu lub odpytaniu REST.
- Brak heartbeat po stronie aplikacji poza pingiem OkHttp; brak testów na prawdziwej sieci i proxy (Caddy przekazuje WebSockety domyślnie — do potwierdzenia na wdrożeniu).
- Wiele instancji serwera: `RealtimeHub` jest w pamięci procesu — przy skalowaniu poziomym zdarzenia nie przejdą między instancjami (potrzebny broker, np. PostgreSQL LISTEN/NOTIFY lub Redis). Przy jednej instancji (obecny docker-compose) działa.
- Wskaźnik pisania ukrywany przy wyłączonych potwierdzeniach (decyzja zapisana wcześniej jako otwarta — przyjęto „tak”).

### Do sprawdzenia przy pierwszym buildzie
Importy `io.ktor.server.websocket.WebSockets` i opcje `pingPeriod`/`timeout`/`maxFrameSize` (kotlin.time.Duration w Ktor 3.0.1); `ktor-client-websockets` w testach i `webSocket {}` zagnieżdżony w teście; `Frame.Text`/`close` w `RealtimeRoutes`; w Androidzie `newWebSocket` z URL `https://`, `registerDefaultNetworkCallback`, `Json.encodeToString` (nieużywany import `kotlinx.serialization.encodeToString`), `LifecycleResumeEffect(intervalMs)`; SQL `UPDATE … RETURNING` z `EXISTS` i `'-infinity'::timestamptz`.

### Zmienione/nowe pliki
Backend — `build.gradle.kts`, `realtime/{RealtimeHub,RealtimeRoutes}.kt`, `Application.kt`, `message/{MessageStore,PostgresMessageStore,MessageService}.kt`; testy `realtime/{RealtimeHubTest,RealtimeRoutesTest}.kt`, `message/{InMemoryMessageStore,MessageEventsTest}.kt`. Android — `AndroidManifest.xml` (ACCESS_NETWORK_STATE), `domain/realtime/RealtimeClient.kt`, `data/realtime/OkHttpRealtimeClient.kt`, `di/RepositoryModule.kt`, `ui/messages/{MessageViewModels,MessageScreens,ChatScreens}.kt`, `ui/navigation/MainShell.kt`, strings EN/PL; testy `data/RealtimeClientTest.kt`, `ui/MessageViewModelsTest.kt`; `docs/API.md`, `README.md`.

### Otwarte decyzje
Broker zdarzeń przy skalowaniu na wiele instancji; czy wylogowanie ma natychmiast zamykać WSS (podpięcie `disconnectSession`); czy w tle utrzymywać połączenie (zużycie baterii) czy polegać na FCM.

### Następny zalecany krok
Zbuduj i uruchom testy (Etapy A–E). Potem **Etap F**: wspólna warstwa plików (upload/pobieranie przez backend, kontrola dostępu, limity, walidacja MIME/rozszerzeń, bezpieczne identyfikatory) dla avatarów, tła, postów, galerii, filmów, dokumentów i wiadomości głosowych — z wykorzystaniem istniejącego `MediaStorage`.

## W trakcie
- **Weryfikacja buildów i testów obu projektów — nadal niewykonana** (blokada środowiskowa; patrz sesja 15 i „Następny krok”).

## Nierozpoczęte
Etapy 7, 8 (moderacja, ustawienia/eksport/usuwanie konta — poza obecnym zakresem), WSS (Etap E), załączniki i głosówki w wiadomościach (Etap F), E2EE (Etap G), FCM (Etap H). Etapy 2, 3 i 4 są częściowo zrobione (patrz sesje 3–12).
Z Etapu 1 brakuje: testów integracyjnych repozytoriów na prawdziwym PostgreSQL (np. Testcontainers), testów UI Compose/instrumentowanych, wysyłki e-maili.

## Znane ograniczenia / ryzyka
- **Reset hasła nie działa end-to-end**: serwer używa `UnavailableEmailSender` i uczciwie odpowiada `503 email_delivery_unavailable`. Android pokazuje ten komunikat.
- `PostgresAuthStore` nie ma żadnego testu na prawdziwej bazie (testy serwisu/tras używają `InMemoryAuthStore` z `src/test`).
- Utrata odpowiedzi `/auth/refresh` (np. zerwana sieć po stronie klienta po rotacji) powoduje przy kolejnej próbie „ponowne użycie” i wylogowanie. Rozważyć krótkie okno tolerancji.
- Rejestracja zdradza zajętość e-maila (`409 email_taken`) — standardowy kompromis UX; do przeglądu.
- Brak limitu liczby sesji na konto oraz sprzątania wygasłych sesji / starych tokenów resetu.
- Android: brak pull-to-refresh i cache (Room) — kolejne etapy.
- `docker-compose.yml` i `.env.example` wymagają teraz `WINKWINK_JWT_SECRET` (≥32 znaki, bez wartości domyślnej).

## Wyniki testów
Backend: **nie uruchomiono** (157 testów napisanych, w tym 5 wymagających PostgreSQL). Android: **nie uruchomiono** (124 napisane). Migracje V1–V10 na PostgreSQL: **nie uruchomiono**.
(Brak narzędzi w środowisku sesji — dotyczy wszystkich sesji 2–15.) Jedyne wykonane kontrole: statyczne, opisane w sesji 15.

## Otwarte decyzje techniczne (wymagają Twojej zgody)
1. **Dostawca poczty** dla resetu hasła i weryfikacji: (a) własny SMTP (np. Angus Mail, EPL-2.0), (b) API dostawcy (Postmark/SES/Mailgun), (c) na razie tylko kod wydawany w panelu admina. Bez tego reset nie zadziała.
2. **Nowe zależności licencyjne** (sprawdź akceptację): Bouncy Castle `bcprov` (licencja MIT), `java-jwt` przez ktor-auth-jwt (MIT), Google Tink Android (Apache-2.0).
3. **E2EE (Etap 5)**: kandydaci do oceny licencji/aktualności/kompatybilności: libsignal (AGPL-3.0 — wymaga oceny wpływu na dystrybucję zamkniętą), implementacja MLS (np. OpenMLS, MIT) lub Olm/Vodozemac (Apache-2.0). Nie deklarujemy E2EE do czasu wdrożenia i weryfikacji.
4. **Object Storage**: S3-zgodny (AWS S3 / Cloudflare R2 / MinIO) — wybór dostawcy blokuje avatar, tło oraz zdjęcia/filmy/załączniki w feedzie.

## Następny zalecany krok
**Stage 12b — wykonać faktyczny build (nic nowego nie dodawać, dopóki nie będzie zielono):**
1. `./scripts/bootstrap-wrapper.sh`, zacommitować wrapper (z `gradle-wrapper.jar`).
2. `cd backend && gradle build` → naprawić błędy kompilacji (najpierw `main`, potem `test`), potem zielone testy jednostkowe.
3. Postgres w Dockerze + `WINKWINK_TEST_DATABASE_URL` → `gradle test --tests '*PostgresIntegrationTest'` — to pierwszy prawdziwy test migracji V1–V10 i SQL magazynów (najbardziej prawdopodobne miejsca błędów: V7 `DO $$`, `summaries`, `markRead` CTE).
4. `cd android && gradle testDebugUnitTest assembleDebug` → naprawić błędy (patrz lista ryzyk wyżej).
5. Dodać CI (GitHub Actions: backend + usługa PostgreSQL, Android), żeby wyniki były powtarzalne.
6. Zdecydować o historii grupy po ponownym dodaniu i o oknie tolerancji rotacji refresh tokenów.
Dopiero potem: Android komunikatora (lista rozmów, czat), WSS, E2EE (po decyzji o bibliotece), Etap 7 (moderacja), Etap 8.

## Sesja 16 — Stage 12B: zmiana zakresu i próba stabilizacji (**builda nie wykonano**)
Środowisko: Java 21; **brak** Gradle, Kotlina, Android SDK, PostgreSQL, Dockera i sieci (`services.gradle.org` nie rozwiązuje się). Żadnego z kroków stabilizacji nie dało się wykonać:
- Gradle Wrapper: **nie przygotowany** — `gradle-wrapper.jar` jest binarny i wymaga Gradle/sieci (patrz `scripts/bootstrap-wrapper.sh`).
- Kompilacja backendu, testy backendu, kompilacja Androida, testy jednostkowe, migracje V1–V10: **niewykonane**. Wyniki: brak.
- Dodano `scripts/verify.sh` — uruchamia te kroki na maszynie z narzędziami i zapisuje prawdziwe statusy do `build-reports/verify.txt` (OK / FAILED / SKIPPED).
Zmiana zakresu (przyjęta): e-mail, weryfikacja adresu, reset hasła e-mailem, moderacja globalna, panel admina, zgłoszenia, ostrzeżenia/bany, audyt, eksport, usuwanie kont — nie rozwijane, bez atrap. Kod istniejący nie został usunięty.
- Reset hasła zależy od e-maila i jest już uczciwie niedostępny: `UnavailableEmailSender` → HTTP 503 `email_delivery_unavailable`, Android pokazuje komunikat `fail_email_unavailable`; pozostałe moduły niezależne. Ekran „Zapomniałem hasła” nadal pozwala wpisać e-mail — do rozważenia ukrycie go (zmiany nie robiłem bez możliwości kompilacji).
- Do sprawdzenia przy realnym buildzie: `foojay` w `settings.gradle.kts` pobiera JDK 17 (lokalnie jest 21); zgodność Ktor 3.0.1 / Kotlin 2.0.21; wersje Androida w `libs.versions.toml`.
- Zmiany w kodzie źródłowym: brak. Dalszy rozwój (punkt 4) **nie rozpoczęty** — dokładanie kolejnych niezbudowanych modułów zwiększałoby tylko dług.
**Następny krok:** uruchomić `bash scripts/verify.sh` i wkleić `build-reports/verify.txt` + logi nieudanych kroków; wtedy naprawię rzeczywiste błędy.

## Sesja 17 — przegląd statyczny ryzyk z sesji 8 (nadal **bez builda**, środowisko bez narzędzi i sieci)
Sprawdzono ręcznie (nie uruchomieniem):
- `PostgresFeedStore.query`: liczba i kolejność placeholderów zgadza się z argumentami — 2 (SELECT: `my_reaction`, `saved`) + argumenty joinów + 6 (`VISIBLE_VIEWER_ARGS`: 2× blokady, autor, 2× `FOLLOWS_AUTHOR`, członkostwo społeczności) + where + kursor (2) + limit. Nie znaleziono rozbieżności.
- `V7__community_posts.sql`: kolumny `community_channels.id`/`community_id` istnieją w V6, klucz złożony `(channel_id, community_id)` ma pod sobą `UNIQUE (id, community_id)`; CHECK-i są dodawane po usunięciu starych. Składnia wygląda poprawnie, ale **nie wykonano jej na PostgreSQL**.
To nie jest weryfikacja — tylko zawężenie listy podejrzanych. Zmian w kodzie nie wprowadzono.

## Sesja 18 — Etap 2 (Android: listy relacji), rozwój bez builda — **niezweryfikowane buildem**
Na wyraźne polecenie „kontynuuj bez build”. Środowisko bez Gradle/Kotlina/SDK/PostgreSQL/sieci → **nic nie skompilowano ani nie uruchomiono**. Sprawdzono statycznie: zbalansowanie nawiasów we wszystkich plikach `.kt`, poprawność XML, zgodność kluczy EN/PL, brak użytych a niezdefiniowanych `R.string.*`.
- **Nowe (Android):** ekrany list użytkowników — obserwujący, obserwowani (z profilu, przyciski pod licznikami), prośby o obserwowanie (akceptuj/odrzuć) i zablokowani (odblokuj), oba z zakładki Profil. Kursorowe dociąganie („Pokaż więcej”), błąd z ponowieniem (np. `profile_restricted` z backendu). Wiersz znika po akcji dopiero po potwierdzeniu serwera.
- Pliki: `SocialApi` (+6 endpointów istniejących w backendzie, kontrakt bez zmian), `SocialRepository(Impl)` (+6 metod, `UserPage`), `UserListViewModel.kt`, `UserListScreen` (w `SocialScreens.kt`), trasa `Routes.USER_LIST`, `MainShell`, `ProfileScreen`, stringi `ulist_*`.
- Testy napisane, niewykonane: +4 w `SocialRepositoryImplTest` (fake `SocialApi` rozszerzony), nowy `UserListViewModelTest` (5 + 1 na nieznany rodzaj listy; wymaga `Dispatchers.setMain`).
- Backend: bez zmian.
- Do sprawdzenia przy pierwszym buildzie: pełność fake `SocialApi` / `FakeSocial` względem interfejsów; import `UserListDto` w `SocialRepositoryImpl`; `private companion object` w środku klasy (legalne, ale ktlint może zgłosić kolejność); nawigacja do `USER_LIST` z innej zakładki niż Profil (trasa jest w grafie Profilu).
- **Nadal brak w Etapie 2:** avatar i tło (Object Storage — decyzja otwarta), wyciszanie, ustawienia prywatności poza `visibility`, posty użytkownika na ekranie jego profilu, testy tras HTTP profili, test `PostgresProfileStore` na prawdziwej bazie.


## Sesja 19 — Etap A (profile i identity), kod napisany, NIEZBUDOWANY i NIEPRZETESTOWANY
Zgodnie z poleceniem nie uruchamiano Gradle, testów ani bazy. Wykonano tylko statyczną kontrolę nawiasów (fałszywe alarmy od `//` w literałach tekstowych; plik `ProfileService.kt` miał ten sam wynik przed zmianami). Klucze stringów EN/PL zgodne, brak niezdefiniowanych.

### Ukończone (kod napisany, niezweryfikowany)
- **Magazyn plików**: interfejs `MediaStorage` + `LocalFileMediaStorage` (katalog `WINKWINK_MEDIA_DIR`, walidacja kluczy, brak path traversal, zapis atomowy). Podmiana na S3-compatible = nowa implementacja interfejsu. Wolumen `media` w `docker-compose.yml`, katalog w `Dockerfile`.
- **Obrazy**: `ImageProcessor` — typ po sygnaturze bajtów (JPEG/PNG), limit wymiarów przed dekodowaniem, ponowne kodowanie (usuwa EXIF/GPS), skalowanie (avatar 1024, tło 2048). Limity 2 MB / 5 MB, wymagany `Content-Length`.
- **Backend**: `PUT/DELETE /me/avatar`, `/me/background`, `GET /users/{id}/avatar|background` (tło tylko dla widzących pełny profil; blokada → 404), wyciszanie (`POST/DELETE /users/{id}/mute`, `GET /me/mutes`), `hideFollowLists`, migracja `V11`. Wyciszenie filtruje Following, Discover, wyszukiwanie, posty społeczności, komentarze i powiadomienia; **nie filtruje treści anonimowych** (anty-deanonimizacja). `avatarTag` w profilach, listach i autorach postów/komentarzy (autor anonimowy nadal `null`).
- **Android**: wybór zdjęcia (systemowy PickVisualMedia), zmniejszanie/JPEG/usunięcie EXIF na urządzeniu, upload, zmiana, usuwanie z potwierdzeniem; avatar w profilu, listach, wyszukiwarce, kartach postów i komentarzach; tło profilu (proporcja 3:1, przycinane); wyciszanie/cofanie na profilu; ekran „Wyciszeni”; przełącznik ukrywania list; sekcja postów na profilu z paginacją („Załaduj więcej”); wejście „Mój profil i posty” w zakładce Profil. Nowa zależność: Coil 2.7.0 (Apache 2.0).
- Testy napisane, **niewykonane**: backend `MediaStorageTest`, `ImageProcessorTest`, `ProfileMediaAndMuteTest`, +4 w `FeedServiceTest`, +1 w `NotificationServiceTest`; Android `ProfileExtrasRepositoryImplTest` (8), `ProfileExtrasViewModelsTest` (7).

### Częściowo / nie zrobione
- Etap A: nie sprawdzono, czy `DefaultHeaders` (`Cache-Control: no-store`) nie nadpisuje nagłówka cache obrazów — jeśli tak, avatary pobierają się za każdym razem. Brak testu HTTP tras mediów i testu `PostgresProfileStore` (V11, `swapKey`, `user_mutes`) na prawdziwej bazie. Avatary nie są jeszcze pokazywane na listach społeczności ani w liście członków. Brak limitu tempa uploadów poza globalnym. Timeout wywołania (15 s) może przerwać wolny upload większego tła. Dodatkowe „ustawienia prywatności” ograniczone do `hideFollowLists`.
- **Etapy B–H nierozpoczęte** (feed: media/wyszukiwanie/udostępnianie/pull-to-refresh; communities: przekazanie własności itd.; Android Messages; WSS; załączniki; Activity+FCM; E2EE).

### Otwarte decyzje / ryzyka
- Avatar widoczny dla każdego zalogowanego, który widzi profil (także prywatny) — zmienić, jeśli ma być ukrywany.
- Przy pierwszym buildzie sprawdzić: importy `io.ktor.server.request.contentLength/contentType`, `receive<ByteArray>()`, `ImageLoader` w Hilt, `ExifInterface` (android.media), `PickVisualMediaRequest`.

### Następny zalecany krok
Zbudować backend i Androida, naprawić błędy kompilacji Etapu A, potem Etap B (media w postach na wspólnym `MediaStorage`).

## Sesja 20 — Etap B (Social Feed: media, udostępnianie, wyszukiwanie), kod napisany, NIEZBUDOWANY i NIEPRZETESTOWANY

Nie uruchamiano kompilacji ani testów (zgodnie z poleceniem). Etap A (profile) był gotowy z sesji 19 i nie był zmieniany.

**Zrobione w kodzie (niezweryfikowane):**
- Backend: migracja `V12` (tabele `post_attachments`, `post_shares`, zdjęcie limitu pustej treści), `PostExtrasStore` (+Postgres), `AttachmentService`/`AttachmentRoutes` (upload surowym ciałem, pobieranie z kontrolą dostępu przez post, usuwanie niedołączonych, sprzątanie porzuconych co godzinę), `MediaSniffer` (MP4/PDF po sygnaturze, sanityzacja nazw), `FeedService.create` z `attachmentIds`, `FeedService.share`, wzbogacanie postów (załączniki, licznik publicznych udostępnień, oryginał), `POST /posts/{id}/share`.
- Android: wyszukiwanie publikacji (`SearchPostsScreen`, debounce 400 ms, min. 3 znaki), przeciągnięcie listy do odświeżenia (Feed, Zapisane), udostępnianie (na profilu z komentarzem i widocznością lub tekst do innej aplikacji), wybór zdjęć/filmu/PDF w ekranie tworzenia posta z natychmiastowym uploadem, ponawianiem i usuwaniem, galeria (siatka + pełny ekran z przesuwaniem), film (pobranie do cache i odtwarzanie `VideoView`), dokument (zapis przez systemowy wybierak), wybór społeczności i kanału przy widoczności „Społeczność”, edycja posta z pustą treścią gdy są załączniki.
- Testy napisane, niewykonane: `PostAttachmentsAndSharesTest` (backend), rozszerzone `FeedRepositoryImplTest` i `FeedViewModelsTest` (Android).
- Teksty EN/PL: parytet kluczy sprawdzony skryptem statycznym; nawiasy w edytowanych plikach sprawdzone skryptem.

**Częściowo / nie zrobione w Etapie B:**
- Powiadomienia o udostępnieniu posta — brak.
- Wideo: brak streamingu i seeku po stronie serwera (cały plik do 30 MB w pamięci, odtwarzanie po pobraniu); brak miniatur i transkodowania; metadane filmu/PDF nie są czyszczone (dlatego anonimowe posty tylko ze zdjęciami).
- Usunięcie posta nie usuwa jeszcze plików z magazynu (post jest usuwany logicznie; wiersze załączników zostają).
- Edycja listy załączników istniejącego posta — brak (tylko tekst).
- Wyszukiwanie to `LIKE` po treści, bez rankingu i indeksu pełnotekstowego.
- Ekran postów w społeczności (Etap C) nadal publikuje tylko tekst; załączniki są dostępne z ekranu tworzenia posta w Feedzie.

**Do sprawdzenia przy pierwszym buildzie (ryzyka kompilacji):** `PullToRefreshBox` (Material3 1.3, `@ExperimentalMaterial3Api`), `PickMultipleVisualMedia(maxItems=10)`, `HorizontalPager`, smart-casty na polach stanu w nowych ekranach, `launch`/`delay` w `Application.kt`, wywołania `ImageIO` w `MediaSniffer.dimensions`, SQL w `PostgresPostExtrasStore` (dynamiczne `IN (?,…)`), migracja V12 na realnej bazie (usuwanie nazwanych CHECK-ów przez `pg_get_constraintdef`).

**Zmienione/nowe pliki:** backend — `V12__post_attachments_shares.sql`, `feed/PostExtrasStore.kt`, `feed/PostgresPostExtrasStore.kt`, `feed/AttachmentService.kt`, `feed/AttachmentRoutes.kt`, `media/MediaSniffer.kt`, `feed/FeedService.kt`, `feed/FeedStore.kt`, `feed/FeedDtos.kt`, `feed/FeedRoutes.kt`, `Application.kt`, testy `InMemoryPostExtrasStore.kt`, `PostAttachmentsAndSharesTest.kt`. Android — `FeedModels`, `FeedDto`, `FeedApi`, `FeedRepository(+Impl)`, `AttachmentPreparer`, `AndroidAttachmentPreparer`, `ImagePreparer` (ImageKind.POST), `RepositoryModule`, `FeedViewModels`, `FeedScreens`, `AttachmentViews`, `MainShell`, `MainTab`, `PostValidation`, `RemoteImage`, `CommunityViewModels`, strings EN/PL, testy i atrapy w `src/test`.

**Otwarte decyzje:** czy wideo ma dostać streaming (Range) i limit większy niż 30 MB (wymaga zmiany `MediaStorage` na strumienie); czy usuwanie postów ma twardo kasować pliki; czy udostępnienia mają generować powiadomienia.

**Następny zalecany krok:** zbuduj i uruchom testy (backend + Android), napraw ewentualne błędy kompilacji z listy ryzyk, a potem Etap C (Communities: przekazanie własności, wyszukiwanie użytkowników do zaproszeń, obsługa zaproszeń i powiadomień, wyciszanie).

## Sesja 21 — Etap C (Communities), kod napisany, NIEZBUDOWANY i NIEPRZETESTOWANY

Nie uruchamiano kompilacji ani testów.

**Zrobione w kodzie (niezweryfikowane):**
- Backend: migracja `V13` (`community_mutes`, nowe typy powiadomień i ich CHECK-i), `CommunityService.transferOwnership` (tylko właściciel, atomowo w magazynie, dawny właściciel → admin), `setMuted` (moderator+ wobec niższej rangi), `inviteCandidates` (wyszukiwanie osób do zaproszeń bez członków i zablokowanych), powiadomienia `community_invite_accepted` i `community_request_approved`, flaga `muted` w liście członków widoczna tylko dla moderatorów, egzekwowanie wyciszenia w `FeedService` (posty i komentarze w społeczności → 403 `muted_in_community`).
- Android: ekran zarządzania ma wyszukiwanie osób do zaproszenia (debounce 400 ms, oznaczenie „Zaproszono”, stany ładowania/pusty/błąd z ponowieniem), przyciski „Wycisz/Cofnij wyciszenie” i „Przekaż własność” (z potwierdzeniem) zależne od roli, oznaczenie wyciszonych; Aktywność obsługuje nowe typy powiadomień.
- Testy napisane, niewykonane: `CommunityManagementTest` (backend, 13 testów), rozszerzone `CommunityViewModelsTest` (Android).

**Uprawnienia (egzekwowane w backendzie):** owner — wszystko, w tym przekazanie własności, zmiana ról, typu i usunięcie; admin — edycja, kanały, moderacja; moderator — zaproszenia, prośby, usuwanie i wyciszanie niższych rang, usuwanie cudzych postów; member — czytanie i pisanie (o ile nie wyciszony).

**Ograniczenia / nie zrobione:**
- Filtr „Zaproszenia do społeczności” w Aktywności filtruje po dokładnym typie, więc nowych typów (zaakceptowane zaproszenie/prośba) tam nie pokaże; pojawiają się na liście „Wszystkie”.
- Wyciszenie nie ma terminu wygaśnięcia ani powodu; brak listy wyciszonych poza listą członków.
- Wyciszanie *aktywności społeczności* przez samego użytkownika (np. wyłączenie powiadomień z jednej społeczności) — nie zrealizowane.
- Ekran postów w społeczności nadal publikuje tylko tekst (załączniki — ekran tworzenia posta w Feedzie, patrz Etap B).
- Brak powiadomienia o zmianie roli lub przekazaniu własności.

**Do sprawdzenia przy buildzie:** migracja V13 na bazie z danymi (usuwanie CHECK-ów po `pg_get_constraintdef`), `InMemoryCommunityStore.transferOwnership` (podmiana wiersza `C`), nakładanie się przeciążeń `person`/`pers` w teście.

**Zmienione/nowe pliki:** backend — `V13__community_mutes_notification_types.sql`, `community/{CommunityStore,PostgresCommunityStore,CommunityService,CommunityRoutes,CommunityDtos}.kt`, `notification/{NotificationStore,NotificationService}.kt`, `feed/{FeedStore,PostgresFeedStore,FeedService}.kt`, testy `CommunityManagementTest.kt`, `InMemoryCommunityStore.kt`, `InMemoryFeedStore.kt`. Android — `CommunityModels`, `CommunityDto`, `CommunityApi`, `CommunityRepository(+Impl)`, `ManageCommunityViewModel`, `ManageCommunityScreen`, `ActivityScreens`, `NotificationModels`, strings EN/PL, testy.

**Następny zalecany krok:** zbuduj i uruchom testy (Etapy B i C), a potem Etap D (Android Messages: lista rozmów, czat, wiadomości, reakcje, statusy, archiwizacja, wyciszanie, członkowie grup) — backend REST już istnieje (Sesja 14).

## Sesja 24 — Etap F (multimedia w komunikatorze), kod napisany, NIEZBUDOWANY i NIEPRZETESTOWANY

Nie uruchamiano Gradle, kompilacji, testów, Dockera ani PostgreSQL (zgodnie z poleceniem). Rozwinięto istniejące `MessageService`/`MessageStore`/`MessageApi`/`MessageRepository`/`ChatViewModel`/`ChatScreens`; nic nie przepisywano, nie usunięto żadnej funkcji. Żadnych atrap ani danych przykładowych.

**Zrobione w kodzie (niezweryfikowane) — ścieżka Android → API → Ktor → PostgreSQL + MediaStorage:**
- Backend: migracja `V15__message_attachments.sql` (tabela `message_attachments`, zdjęcie limitu pustej treści wiadomości, `deleted_at` jako znacznik do sprzątania); `MessageStore`/`PostgresMessageStore` (atomowe dołączenie plików w transakcji wstawiania wiadomości, `attachmentsFor`, `tombstonePending`, `purgeCandidates`); `MessageService.send/edit/delete` z załącznikami i sprzątaniem plików; `MessageAttachmentService` + `MessageAttachmentRoutes` (upload surowym ciałem, pobieranie z kontrolą członkostwa, wycofanie, sprzątanie porzuconych co godzinę); `MessageMedia` (walidacja zawartości: PDF/OOXML/ODF po katalogu centralnym ZIP bez dekompresji/RTF/TXT/CSV, parser MP4 dla głosówek z czasem trwania liczonym po stronie serwera, bezpieczne nazwy); `UploadRateLimiter` (20/min i 200/h na konto); `MessageDto.attachments`, podgląd załączników ostatniej wiadomości na liście rozmów.
- Android: modele i DTO (`MessageAttachment`), `MessageApi`/`MessageRepository(+Impl)` (upload, usuwanie, pobieranie, `send` z `attachmentIds`), `AndroidMessageFilePreparer` (zdjęcia → JPEG bez EXIF, dokumenty z filtrem rozszerzeń), `AndroidVoiceRecorder` (MediaRecorder, AAC/M4A, 64 kb/s, limit 10 min), `AndroidVoicePlayback` (jeden odtwarzacz w aplikacji, fokus audio, cache głosówek), `ChatViewModel` (szkice załączników z natychmiastowym uploadem, ponawianie, usuwanie, nagrywanie/podgląd/wysyłanie, upload głosówki przy wysyłaniu, ponawianie po powrocie sieci, brak duplikatów po utracie odpowiedzi), `ChatScreens` + `MessageMediaViews` + `ComposerMediaViews` (galeria w bąbelku, pełny ekran z przesuwaniem, wiersz dokumentu z zapisem przez systemowy wybierak, odtwarzacz z paskiem postępu i czasem, pasek nagrywania, uprawnienie mikrofonu z obsługą trwałej odmowy), podgląd na liście rozmów, teksty EN/PL, uprawnienie `RECORD_AUDIO`.
- WSS: bez zmian protokołu. Wiadomość z multimediami używa istniejących `message.new/updated/deleted`; Android odświeża przez REST (istniejące mechanizmy synchronizacji i ponownego łączenia nietknięte).
- Testy napisane, niewykonane: backend — `MessageMediaTest`, `MessageAttachmentsTest`, `MessageAttachmentRoutesTest`, nowy test w `PostgresIntegrationTest` (V15); Android — rozszerzone `MessageViewModelsTest` i `MessageRepositoryImplTest`, nowy `MessageMediaTypesTest`.

**Częściowo / nie zrobione:**
- Przepustowość: pliki są w pamięci (zdjęcia ≤ 8 MB, dokumenty ≤ 10 MB, głosówki ≤ 8 MB), bez streamingu/Range; głosówki są pobierane w całości przed odtworzeniem. Brak miniatur serwerowych (zdjęcia są przeskalowane do 2048 px).
- Brak wideo w czacie; brak fali dźwiękowej; brak zmiany prędkości odtwarzania.
- Niewysłane wiadomości z mediami żyją tylko w pamięci `ChatViewModel` (jak teksty): po zabiciu procesu przepadają; nagranie czeka w cache i jest sprzątane po 24 h, a wgrane niedołączone pliki serwer usuwa po 24 h.
- Usunięcie konta/rozmowy kasuje wiersze kaskadowo, **ale nie pliki** w magazynie (brak zadania rekoncyliującego). `MediaStorage.delete` połyka błędy IO, więc nieudane skasowanie pliku po usunięciu wiadomości nie jest ponawiane (ponawiane są tylko wiersze oznaczone, których serwis nie zdążył obsłużyć).
- Limiter uploadów jest w pamięci procesu (przy wielu instancjach każda liczy osobno); brak limitu dziennego bajtów.
- Walidacja dokumentów jest heurystyczna: PDF z JavaScriptem wykrywany po nazwach w strumieniu (ukryte w skompresowanych strumieniach obiektów mogą ujść), brak antywirusa; makra/OLE odrzucane, starszych `.doc/.xls/.ppt` nie przyjmujemy. CSV może zawierać formuły — to ryzyko aplikacji, która go otworzy.
- Dostęp po historii: nowy członek grupy widzi i pobiera pliki starszych wiadomości (zgodnie z istniejącą decyzją o widoczności historii); po zablokowaniu użytkownika istniejące pliki w rozmowie bezpośredniej pozostają pobieralne dla członków (rozmowy zablokowanych są tylko do odczytu).
- Pliki są przechowywane jawnie (brak E2EE) — aplikacja nadal nie deklaruje szyfrowania end-to-end.
- Reakcje/odpowiedzi na wiadomość z mediami używają etykiety „Zdjęcie/Dokument/Wiadomość głosowa” w podglądzie; wyszukiwanie wiadomości po treści nie obejmuje nazw plików.

**Do sprawdzenia przy pierwszym buildzie (ryzyka kompilacji, kod pisany bez kompilatora):** `SubcomposeAsyncImage` z `imageLoader` i slotami `loading/error` (Coil 2.x), `LifecycleEventEffect`, `PickMultipleVisualMedia(10)`, własny `CreateTypedDocument`, `AudioFocusRequest` (API 26+), `MediaRecorder(Context)` przy SDK ≥ 31, `Slider` w bąbelku, smart-casty na polach stanu w `ChatScreens`, `Mp4Inspector` (lokalna funkcja rekurencyjna z przechwytywanymi zmiennymi), `ZipDirectory` (nielokalne `return` w `repeat`), `PostgresMessageStore` (dynamiczne `IN (?,…)`, `RETURNING` z listą kolumn), migracja V15 na bazie z danymi (usuwanie CHECK po `pg_get_constraintdef`), testy z refleksją na `onCleared`.

**Zmienione/nowe pliki:** backend — `V15__message_attachments.sql`, `media/{MessageMedia,UploadRateLimiter}.kt`, `message/{MessageStore,PostgresMessageStore,MessageService,MessageDtos,MessageRoutes,MessageAttachmentService,MessageAttachmentRoutes}.kt`, `Application.kt`, testy `media/{TestMedia,MessageMediaTest}.kt`, `message/{InMemoryMessageStore,MessageAttachmentsTest,MessageAttachmentRoutesTest}.kt`, `database/PostgresIntegrationTest.kt`. Android — `domain/model/MessageModels`, `domain/media/{MessageMediaTypes,VoiceMedia}`, `domain/repository/MessageRepository`, `data/remote/MessageApi`, `data/repository/MessageRepositoryImpl`, `data/media/{AndroidMessageFilePreparer,AndroidVoiceRecorder,AndroidVoicePlayback}`, `di/RepositoryModule`, `ui/messages/{MessageViewModels,ChatScreens,MessageScreens,MessageMediaViews,ComposerMediaViews}`, `ui/components/RemoteImage`, `ui/auth/AuthCommon` (nowe kody błędów), strings EN/PL, `AndroidManifest.xml`, testy `MessageViewModelsTest`, `MessageRepositoryImplTest`, `media/MessageMediaTypesTest`.

**Otwarte decyzje:** czy pliki mają dostać streaming (Range) i większe limity (wymaga zmiany `MediaStorage` na strumienie); czy wprowadzić zadanie rekoncyliujące magazyn z bazą (pliki po usunięciu kont/rozmów); czy nowi członkowie grupy mają widzieć pliki sprzed dołączenia; czy dodać skanowanie antywirusowe dokumentów.

**Następny zalecany krok:** zbuduj i uruchom testy (backend + Android), napraw błędy kompilacji z listy ryzyk, sprawdź migrację V15 na realnej bazie, a potem przetestuj ręcznie na urządzeniu: nagrywanie z odmową mikrofonu, utratę sieci w trakcie uploadu i ponowienie, zdarzenie WSS z drugiego konta.



## Sesja 25 — Stage 13G (niezawodność, trwałość danych, synchronizacja), kod napisany, NIEZBUDOWANY i NIEPRZETESTOWANY

Nie uruchamiano Gradle, testów, Dockera ani PostgreSQL. Nic nie zostało skompilowane.

**Znaleziony błąd kompilacji z Etapu F (naprawiony):** `MessageDto` (backend) nie miał pola `attachments`, którego używało `toDto()`.

**Zaimplementowane (kod):**
- Migracja `V16`: `idempotency_keys`; `messages.client_id` (unikalne per nadawca) i `changed_at`; indeksy kluczy obcych / sprzątania.
- Backend: idempotencja (`Idempotency-Key`) na tworzeniu postów, komentarzy, udostępnień, społeczności, grup, uploadów; `clientId` wiadomości; endpoint zmian `…/messages/changes`; streaming + `Range` plików; `MediaStorage.delete` propaguje błędy IO (+ `deleteQuietly` tam, gdzie rekord jest już zmieniony); sprzątanie plików usuniętych postów; `MediaReconciler` (osierocone pliki, co 6 h); limity rozmiaru żądań i odrzucanie chunked; `POST /me/delete` (usuwanie konta z plikami); kompensacja częściowych zapisów przy tworzeniu posta z załącznikami i udostępnianiu.
- Android: Room + WorkManager (trwała kolejka: tekst, zdjęcia, dokumenty, głosówki; kolejność, ponawianie, ręczne ponów/usuń, brak duplikatów przez `clientId`); `IdempotentRetryInterceptor` (klucz + ponowienia przy chwilowych awariach dla operacji tworzących); `TransferTimeoutInterceptor` (dłuższe limity dla plików); synchronizacja różnicowa w czacie + naprawa luki w `applyLatest`; strumieniowe pobieranie z anulowaniem (`downloadAttachmentToFile`, dotąd nieużywane przez UI); `SessionCleaner` (czyszczenie po wylogowaniu).
- Dokumentacja: `docs/API.md` (Stage 13G), `docs/SYNC_AND_OUTBOX.md`, README.

**Nie zrobione / ograniczenia:**
- Brak nowych testów backendu (idempotencja, changes, Range, reconciler, usuwanie konta) i testów `OutboxRepositoryImpl`; testy `ChatViewModel` zostały przepisane pod kolejkę (usunięto 11 testów starego pending w pamięci). Wszystko wymaga uruchomienia.
- UI usuwania konta nie istnieje (tylko backend). Ekrany pobierania (`MessageMediaViews`, `AttachmentViews`, głosówki) nadal używają `downloadAttachment` (bajty w RAM, z limitem 32 MB i anulowaniem); `downloadAttachmentToFile` jest gotowe, ale niepodpięte.
- Idempotencja po stronie Androida dla postów/komentarzy/społeczności obejmuje ponowienia wewnątrz jednego wywołania; ponowne stuknięcie „Opublikuj” po błędzie używa nowego klucza (możliwy duplikat, jeśli serwer wykonał operację mimo błędu po stronie klienta).
- Idempotencja nie obejmuje reakcji/zapisów (są idempotentne z natury).
- Wylogowanie kasuje niewysłane wiadomości (świadomy kompromis bezpieczeństwa).
- Statusy dostarczenia/odczytu starszych wiadomości poza pierwszą stroną odświeżają się tylko przy przeładowaniu. Lista rozmów i inne listy (feed, komentarze…) nie mają pamięci podręcznej offline; ich paginacja kursorowa jest po stronie serwera (przeglądnięta, bez zmian).
- Brak indeksu trigramowego dla wyszukiwania `LIKE '%q%'` (pg_trgm wymaga uprawnień).
- Limiter uploadów i hub WebSocket są w pamięci procesu (jedna instancja). Zdjęcia profilu nadal w pamięci (≤ 5 MB).

**Do sprawdzenia przy pierwszym buildzie:** `ByteWriteChannel.writeFully` (Ktor 3.0.1) w `StreamedResponse`; `inline reified` + `@PublishedApi` w `Idempotency`; `ON CONFLICT (sender_id, client_id) WHERE client_id IS NOT NULL` w `PostgresMessageStore`; Room (`@Relation`, abstract DAO z `@Transaction open`); `HiltWorker` + `Configuration.Provider`; `okio.source`; `Interceptor.Chain.withCallTimeout`; migracja V16 na bazie z danymi.


## Sesja 26 — Stage 13H (zamknięcie bety), kod napisany, NIEZBUDOWANY i NIEPRZETESTOWANY

Nie uruchamiano Gradle, testów, Dockera ani bazy. Nic nie zostało skompilowane; kod z 13G i 13H nigdy nie przeszedł przez kompilator.

**Dodane:**
- Push FCM end-to-end (kod): migracja `V17` (`push_tokens`, `message_settings.push_messages/push_previews`, `idempotency_keys.fingerprint`); backend `push/*` (HTTP v1 bez SDK, OAuth2 z konta serwisowego, tokeny per sesja/urządzenie, usuwanie nieważnych, ustawienia, zdarzenia konta, `dismiss` między urządzeniami); podpięcie do wiadomości (wyciszenie rozmowy/nadawcy, blokady, obecność WSS, ustawienia) i powiadomień społecznościowych (tylko dla zapisanych, zdeduplikowanych); Android: `FirebaseMessagingService`, kanały, wersja publiczna na ekranie blokady, deep linki + oznaczanie jako przeczytane, zgoda `POST_NOTIFICATIONS`, przełączniki w ustawieniach wiadomości. Wymaga Twojej konfiguracji Firebase (`docs/FIREBASE.md`).
- Usuwanie konta w aplikacji (ekran, potwierdzenia, `POST /me/delete`, czyszczenie sesji/kolejki/cache/WS/tokenu FCM).
- Strumieniowe pobieranie (`downloadAttachmentToFile`) podpięte do filmów, dokumentów i głosówek (plik `.part` → atomowa podmiana, anulowanie przy zamknięciu ekranu, cache głosówek i filmów).
- Konfiguracja release: wersja z właściwości Gradle, podpisywanie ze zmiennych środowiskowych, odmowa buildu release z adresem zastępczym, reguły R8, diagnostyka tylko w debug, usunięty nieużywany `ModulePlaceholderScreen`.

**Poprawione:** idempotencja — odcisk żądania, token własności rezerwacji (brak nadpisania przez wolne żądanie), przejęcie tylko przy tym samym scope/odcisku, TTL rezerwacji 10 min.

**Nie zrobione / znane braki:**
- **Gradle Wrapper niekompletny** (brak `gradlew`, `gradlew.bat`, `gradle-wrapper.jar`) — patrz `docs/RELEASE.md`.
- Brak pliku `google-services.json` i poświadczeń FCM (celowo); bez nich push jest wyłączony, a build przechodzi.
- Reset hasła i weryfikacja e-mail nadal niedostępne (brak dostawcy poczty).
- Brak postępu pobierania i przycisku „Anuluj” w UI (anulowanie następuje przy opuszczeniu ekranu).
- Brak testów backendu dla push/idempotencji/changes/Range/reconcilera oraz testów kolejki Androida.
- Brak ikon i wygaszania powiadomień grupowych (jedno powiadomienie na rozmowę/zdarzenie).
- Powiadomienie o wiadomości jest pomijane, gdy odbiorca ma otwarte WSS; jeśli połączenie jest „wiszące” (martwe, a serwer jeszcze go nie wykrył), push nie przyjdzie do czasu zamknięcia gniazda.

**Do sprawdzenia przy pierwszym buildzie:** wszystko z listy 13G oraz: `FirebaseMessaging` + warunkowy plugin Google Services; `PushNotificationPresenter` (NotificationCompat, `activeNotifications`); `@AndroidEntryPoint` na serwisie FCM; `AuthRepositoryImpl` z parametrem domyślnym przy Hilt; sygnatury `FakeAccountApi`; JDK `HttpClient` w `FcmPushSender`; SQL `?::uuid IS NULL` w `PostgresPushStore.tokens`.
