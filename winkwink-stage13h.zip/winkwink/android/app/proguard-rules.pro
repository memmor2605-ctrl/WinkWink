-keepattributes *Annotation*, InnerClasses, Signature
-dontwarn org.jetbrains.annotations.**

# kotlinx.serialization: klasy DTO (Retrofit konwertuje je refleksyjnie przez serializery generowane w czasie kompilacji)
-keepclassmembers class app.winkwink.** { *** Companion; }
-keepclasseswithmembers class app.winkwink.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class app.winkwink.**$$serializer { *; }
# Retrofit: metody interfejsów API (generyczne typy zwrotne czytane z sygnatur)
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations, AnnotationDefault
-keep,allowobfuscation,allowshrinking interface retrofit2.Call
-keep,allowobfuscation,allowshrinking class kotlin.coroutines.Continuation
-keep,allowobfuscation,allowshrinking class retrofit2.Response
-dontwarn javax.annotation.**
-dontwarn kotlin.Unit
# Stos wywołań w raportach awarii ma być czytelny po mapowaniu (mapping.txt)
-keepattributes SourceFile, LineNumberTable
