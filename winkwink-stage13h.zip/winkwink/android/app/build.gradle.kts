plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}

// Plik google-services.json (konfiguracja Firebase, NIE sekret, ale specyficzna dla Twojego projektu) nie jest w repozytorium.
// Bez niego aplikacja się buduje, a powiadomienia push są wyłączone; z nim plugin Google Services konfiguruje FCM.
if (file("google-services.json").exists()) apply(plugin = "com.google.gms.google-services")

const val PLACEHOLDER_API_URL = "https://api.winkwink.example"

// Adres backendu pochodzi z konfiguracji środowiskowej — nigdy z kodu.
val apiBaseUrl: String = (providers.gradleProperty("winkwink.apiBaseUrl").orNull
    ?: System.getenv("WINKWINK_API_BASE_URL")
    ?: PLACEHOLDER_API_URL).trim()

require(apiBaseUrl.startsWith("https://")) {
    "winkwink.apiBaseUrl / WINKWINK_API_BASE_URL must start with https:// (HTTP is not allowed)."
}
val normalizedApiBaseUrl = apiBaseUrl.trimEnd('/') + "/"

kotlin { jvmToolchain(17) }

android {
    namespace = "app.winkwink"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.winkwink"
        minSdk = 26
        targetSdk = 35
        // Numer wersji z -Pwinkwink.versionCode / -Pwinkwink.versionName (CI); domyślnie wartości poniżej.
        versionCode = (providers.gradleProperty("winkwink.versionCode").orNull ?: "1").toInt()
        versionName = providers.gradleProperty("winkwink.versionName").orNull ?: "0.1.0-beta1"
        buildConfigField("String", "API_BASE_URL", "\"$normalizedApiBaseUrl\"")
    }

    // Podpisywanie wydania: wyłącznie ze zmiennych środowiskowych / ~/.gradle/gradle.properties — nigdy z repozytorium.
    // Bez nich assembleRelease daje niepodpisany APK (nie da się go zainstalować; podpisz go przez apksigner).
    val keystorePath = System.getenv("WINKWINK_KEYSTORE_FILE") ?: providers.gradleProperty("winkwink.keystoreFile").orNull
    signingConfigs {
        if (keystorePath != null) create("release") {
            storeFile = file(keystorePath)
            storePassword = System.getenv("WINKWINK_KEYSTORE_PASSWORD") ?: providers.gradleProperty("winkwink.keystorePassword").orNull
            keyAlias = System.getenv("WINKWINK_KEY_ALIAS") ?: providers.gradleProperty("winkwink.keyAlias").orNull
            keyPassword = System.getenv("WINKWINK_KEY_PASSWORD") ?: providers.gradleProperty("winkwink.keyPassword").orNull
        }
    }

    buildTypes {
        release {
            signingConfigs.findByName("release")?.let { signingConfig = it }
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.material3)
    implementation(libs.compose.icons.core)
    debugImplementation(libs.compose.ui.tooling)

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.datastore.preferences)

    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.navigation.compose)

    implementation(libs.retrofit)
    implementation(libs.retrofit.kotlinx.serialization)
    implementation(libs.okhttp)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.kotlinx.coroutines.android)

    // Szyfrowanie sesji w spoczynku: Tink (AES-256-GCM) z kluczem w Android Keystore — bez własnej kryptografii.
    implementation(libs.tink.android)

    // Ładowanie avatarów i zdjęć (Apache 2.0); korzysta z klienta OkHttp z tokenem, więc obrazy prywatne pobiera ta sama sesja.
    implementation(libs.coil.compose)

    // Trwała kolejka wysyłania: Room (lokalna baza) + WorkManager (wznawianie po restarcie procesu/telefonu i po powrocie sieci).
    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)
    implementation(libs.work.runtime)
    implementation(libs.hilt.work)
    ksp(libs.hilt.work.compiler)

    // Powiadomienia push (FCM). Sekretów Firebase Admin tu nie ma: wysyła backend; aplikacja dostaje tylko własny token urządzenia.
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.messaging)

    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
}

// Wydanie z adresem zastępczym nie ma sensu (aplikacja nie połączyłaby się z żadnym serwerem) — przerywamy build.
gradle.taskGraph.whenReady {
    val releaseRequested = allTasks.any { it.project == project && (it.name.contains("Release", ignoreCase = true) && (it.name.startsWith("assemble") || it.name.startsWith("bundle") || it.name.startsWith("package"))) }
    if (releaseRequested && apiBaseUrl == PLACEHOLDER_API_URL) {
        throw GradleException("Release build requires a real backend: set WINKWINK_API_BASE_URL or -Pwinkwink.apiBaseUrl=https://...")
    }
}
