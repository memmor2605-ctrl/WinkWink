package app.winkwink

import app.winkwink.domain.validation.PostValidation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PostValidationTest {
    @Test fun blankPostIsInvalid() { assertFalse(PostValidation.postBodyValid("   \n")) }
    @Test fun postLimitIsInclusive() {
        assertTrue(PostValidation.postBodyValid("a".repeat(PostValidation.POST_MAX)))
        assertFalse(PostValidation.postBodyValid("a".repeat(PostValidation.POST_MAX + 1)))
    }
    @Test fun commentLimitIsInclusive() {
        assertTrue(PostValidation.commentBodyValid("a".repeat(PostValidation.COMMENT_MAX)))
        assertFalse(PostValidation.commentBodyValid("a".repeat(PostValidation.COMMENT_MAX + 1)))
    }
    @Test fun anonymousForcesPublic() {
        assertEquals("public", PostValidation.visibilityFor(true, "private"))
        assertEquals("followers", PostValidation.visibilityFor(false, "followers"))
    }
}
