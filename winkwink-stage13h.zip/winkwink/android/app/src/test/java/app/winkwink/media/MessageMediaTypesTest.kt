package app.winkwink.media

import app.winkwink.domain.media.MessageDocumentTypes
import app.winkwink.domain.media.PlaybackState
import app.winkwink.domain.media.PlaybackStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MessageMediaTypesTest {
    @Test fun extensionDecidesTheMimeForCommonDocuments() {
        assertEquals("application/pdf", MessageDocumentTypes.mimeFor("raport.PDF", "application/octet-stream"))
        assertEquals("application/vnd.openxmlformats-officedocument.wordprocessingml.document", MessageDocumentTypes.mimeFor("umowa.docx", null))
        assertEquals("text/csv", MessageDocumentTypes.mimeFor("dane.csv", "text/comma-separated-values"))
        assertEquals("text/plain", MessageDocumentTypes.mimeFor("notatki.txt", null))
        assertEquals("application/vnd.oasis.opendocument.text", MessageDocumentTypes.mimeFor("x.odt", null))
    }

    @Test fun reportedMimeIsUsedOnlyWhenNameGivesNothingAndItIsAllowed() {
        assertEquals("application/pdf", MessageDocumentTypes.mimeFor(null, "application/pdf"))
        assertEquals("application/pdf", MessageDocumentTypes.mimeFor("plik_bez_rozszerzenia", "application/pdf; charset=binary"))
        assertNull(MessageDocumentTypes.mimeFor(null, "application/octet-stream"))
        assertNull(MessageDocumentTypes.mimeFor("x.zip", "application/zip"))
    }

    @Test fun executablesScriptsHtmlAndMacroFilesAreRefused() {
        listOf("setup.exe", "run.bat", "a.js", "page.html", "img.svg", "macro.docm", "tool.apk", "x.sh", "raport.exe.pdf", "a.html.txt").forEach {
            assertTrue(it, MessageDocumentTypes.hasBlockedExtension(it))
            assertNull(it, MessageDocumentTypes.mimeFor(it, "application/pdf"))
        }
        assertFalse(MessageDocumentTypes.hasBlockedExtension("Raport kwartalny 2026.pdf"))
        assertFalse(MessageDocumentTypes.hasBlockedExtension(null))
    }

    @Test fun pickerListsOnlyAllowedTypes() {
        val types = MessageDocumentTypes.pickerMimeTypes.toSet()
        assertTrue("application/pdf" in types)
        assertFalse("text/html" in types); assertFalse("application/x-msdownload" in types); assertFalse("application/octet-stream" in types)
    }

    @Test fun playbackFractionIsPerKeyAndClamped() {
        val s = PlaybackState("a", PlaybackStatus.PLAYING, positionMs = 1500, durationMs = 3000)
        assertEquals(0.5f, s.fraction("a", 0), 0.001f)
        assertEquals(0f, s.fraction("b", 3000), 0f) // inna wiadomość nie pokazuje cudzego postępu
        assertEquals(1f, PlaybackState("a", PlaybackStatus.PLAYING, 9000, 3000).fraction("a", 0), 0f)
        assertEquals(0.25f, PlaybackState("a", PlaybackStatus.PLAYING, 500, 0).fraction("a", 2000), 0.001f) // czas z serwera, gdy odtwarzacz go jeszcze nie zna
        assertEquals(0f, PlaybackState().fraction("a", 0), 0f)
        assertTrue(s.isActive("a")); assertFalse(s.isActive("b"))
    }
}
