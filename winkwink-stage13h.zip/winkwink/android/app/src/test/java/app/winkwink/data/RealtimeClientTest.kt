package app.winkwink.data

import app.winkwink.data.realtime.parseRealtimeEvent
import app.winkwink.data.realtime.reconnectDelayMs
import app.winkwink.domain.realtime.RealtimeTypes
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RealtimeClientTest {
    private val json = Json { ignoreUnknownKeys = true }

    @Test fun parsesEventWithActorAndIgnoresUnknownFields() {
        val e = parseRealtimeEvent(json, """{"type":"typing","conversationId":"c1","actor":{"winkwinkId":"ww_a","nickname":"ala","displayName":"Ala","avatarTag":"t"},"extra":1}""")!!
        assertEquals(RealtimeTypes.TYPING, e.type); assertEquals("c1", e.conversationId); assertEquals("Ala", e.actor?.name)
    }

    @Test fun parsesBareEvent() {
        val e = parseRealtimeEvent(json, """{"type":"receipt","conversationId":"c2"}""")!!
        assertNull(e.actor); assertNull(e.messageId)
    }

    @Test fun garbageFramesAreIgnored() {
        assertNull(parseRealtimeEvent(json, "not json"))
        assertNull(parseRealtimeEvent(json, """{"conversationId":"c1"}"""))
        assertNull(parseRealtimeEvent(json, ""))
    }

    @Test fun backoffGrowsAndIsCapped() {
        val full = { 1.0 }
        assertEquals(listOf(1_000L, 2_000L, 4_000L, 8_000L, 16_000L, 30_000L, 30_000L), (0..6).map { reconnectDelayMs(it, full) })
    }

    @Test fun backoffJitterStaysBetweenHalfAndFull() {
        assertEquals(500L, reconnectDelayMs(0) { 0.0 })
        (0..40).forEach { a -> reconnectDelayMs(a).let { assertTrue(it in 500L..30_000L) } }
        assertEquals(1_000L, reconnectDelayMs(-5) { 1.0 })
    }
}
