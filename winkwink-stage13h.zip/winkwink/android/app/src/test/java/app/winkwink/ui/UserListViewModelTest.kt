package app.winkwink.ui

import androidx.lifecycle.SavedStateHandle
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.UserPage
import app.winkwink.domain.model.UserProfile
import app.winkwink.domain.model.UserSummary
import app.winkwink.domain.repository.SocialRepository
import app.winkwink.ui.social.UserListViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test

private fun u(id: String) = UserSummary(id, "nick_$id", null)

private class FakeSocial : SocialRepository {
    var pages: (String?) -> Result<UserPage> = { c ->
        if (c == null) Result.success(UserPage(listOf(u("a"), u("b")), "c2")) else Result.success(UserPage(listOf(u("b"), u("c")), null))
    }
    var actionResult: Result<Unit> = Result.success(Unit)
    val approved = mutableListOf<String>()
    val unblocked = mutableListOf<String>()
    var lastFollowersOf: String? = null

    override suspend fun followers(identifier: String, cursor: String?): Result<UserPage> { lastFollowersOf = identifier; return pages(cursor) }
    override suspend fun following(identifier: String, cursor: String?) = pages(cursor)
    override suspend fun followRequests(cursor: String?) = pages(cursor)
    override suspend fun blocked(cursor: String?) = pages(cursor)
    override suspend fun approveRequest(identifier: String): Result<Unit> { approved += identifier; return actionResult }
    override suspend fun rejectRequest(identifier: String): Result<Unit> = actionResult
    override suspend fun unblock(identifier: String): Result<Unit> { unblocked += identifier; return actionResult }

    override suspend fun profile(identifier: String): Result<UserProfile> = error("unused")
    override suspend fun search(query: String): Result<List<UserSummary>> = error("unused")
    override suspend fun follow(identifier: String): Result<String> = error("unused")
    override suspend fun unfollow(identifier: String): Result<Unit> = error("unused")
    override suspend fun block(identifier: String): Result<Unit> = error("unused")
    override suspend fun updateProfile(displayName: String, bio: String, links: List<String>, visibility: String): Result<UserProfile> = error("unused")
}

@OptIn(ExperimentalCoroutinesApi::class)
class UserListViewModelTest {
    private val repo = FakeSocial()

    @Before fun setUp() { Dispatchers.setMain(UnconfinedTestDispatcher()) }
    @After fun tearDown() { Dispatchers.resetMain() }

    private fun vm(kind: String, id: String = "ww_me") = UserListViewModel(repo, SavedStateHandle(mapOf("kind" to kind, "id" to id)))

    @Test fun loadsFirstPageForTargetProfile() {
        val m = vm("followers", "ww_target")
        assertEquals(listOf("a", "b"), m.state.value.users.map { it.winkwinkId })
        assertEquals("c2", m.state.value.nextCursor)
        assertEquals("ww_target", repo.lastFollowersOf)
    }

    @Test fun loadMoreAppendsWithoutDuplicatesAndEndsList() {
        val m = vm("following")
        m.loadMore()
        assertEquals(listOf("a", "b", "c"), m.state.value.users.map { it.winkwinkId })
        assertNull(m.state.value.nextCursor)
    }

    @Test fun approveRemovesRowOnlyAfterServerSuccess() {
        val m = vm("requests")
        repo.actionResult = Result.failure(ApiFailure("server_error", "x"))
        m.approve(u("a"))
        assertEquals(2, m.state.value.users.size)
        assertNotNull(m.state.value.failure); assertNull(m.state.value.busyId)
        repo.actionResult = Result.success(Unit)
        m.approve(u("a"))
        assertEquals(listOf("b"), m.state.value.users.map { it.winkwinkId })
        assertEquals(listOf("a", "a"), repo.approved)
    }

    @Test fun unblockRemovesRow() {
        val m = vm("blocked")
        m.unblock(u("b"))
        assertEquals(listOf("a"), m.state.value.users.map { it.winkwinkId })
    }

    @Test fun restrictedListShowsFailureAndRetryReloads() {
        repo.pages = { Result.failure(ApiFailure("profile_restricted", "x")) }
        val m = vm("followers")
        assertEquals("profile_restricted", m.state.value.failure?.code)
        repo.pages = { Result.success(UserPage(listOf(u("z")), null)) }
        m.refresh()
        assertNull(m.state.value.failure)
        assertEquals(listOf("z"), m.state.value.users.map { it.winkwinkId })
    }

    @Test(expected = IllegalArgumentException::class) fun unknownKindIsRejected() { vm("bogus") }
}
