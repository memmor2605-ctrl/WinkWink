package app.winkwink.ui

import androidx.lifecycle.SavedStateHandle
import app.winkwink.domain.media.AttachmentPrepareException
import app.winkwink.domain.media.MessageFilePreparer
import app.winkwink.domain.media.PlaybackState
import app.winkwink.domain.media.PlaybackStatus
import app.winkwink.domain.media.RecordedVoice
import app.winkwink.domain.media.VoicePlayback
import app.winkwink.domain.media.VoiceRecordException
import app.winkwink.domain.media.VoiceRecorder
import app.winkwink.domain.model.MessageAttachment
import app.winkwink.domain.model.PreparedFile
import app.winkwink.ui.feed.UploadStatus
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.ChatMember
import app.winkwink.domain.model.ChatMessage
import app.winkwink.domain.model.ChatMessagePage
import app.winkwink.domain.model.ChatPerson
import app.winkwink.domain.model.ChatReaction
import app.winkwink.domain.model.Conversation
import app.winkwink.domain.model.ConversationPage
import app.winkwink.domain.realtime.RealtimeClient
import app.winkwink.domain.realtime.RealtimeEvent
import app.winkwink.domain.realtime.RealtimeState
import app.winkwink.domain.realtime.RealtimeTypes
import app.winkwink.domain.repository.MessageRepository
import app.winkwink.ui.messages.MessagingBackgroundViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import app.winkwink.ui.messages.ChatViewModel
import app.winkwink.ui.messages.ConversationListViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.time.Instant

private val me = ChatPerson("ww_me", "me", null)
private val other = ChatPerson("ww_bob", "bobby", "Bobby")
private fun at(sec: Int) = Instant.parse("2026-11-24T10:00:00Z").plusSeconds(sec.toLong())

private fun message(id: String, sec: Int, mine: Boolean = false, body: String? = "text $id", reactions: List<ChatReaction> = emptyList()) =
    ChatMessage(id, "c1", if (mine) me else other, body, null, at(sec), null, false, mine, if (mine) "sent" else null, reactions)

private fun conversation(id: String = "c1", unread: Int = 0, muted: Boolean = false, archived: Boolean = false) =
    Conversation(id, "direct", null, other, 2, muted, archived, unread, "member", null, at(0))

private class FakeMessages : MessageRepository {
    var convs: Result<ConversationPage> = Result.success(ConversationPage(listOf(conversation("c1"), conversation("c2")), null))
    var conv: Result<Conversation> = Result.success(conversation(unread = 2))
    var pages: (String?) -> Result<ChatMessagePage> = { Result.success(ChatMessagePage(listOf(message("m2", 20), message("m1", 10, mine = true)), null)) }
    var sendResult: () -> Result<ChatMessage> = { Result.success(message("new", 30, mine = true)) }
    var editResult: Result<ChatMessage> = Result.success(message("m1", 10, mine = true, body = "edited"))
    var deleteResult: Result<Unit> = Result.success(Unit)
    var flagsResult: (String, Boolean?, Boolean?) -> Result<Conversation> = { id, muted, archived -> Result.success(conversation(id, muted = muted ?: false, archived = archived ?: false)) }
    val sent = mutableListOf<Triple<String, String, String?>>()
    val sentAttachmentIds = mutableListOf<List<String>>()
    val uploaded = mutableListOf<PreparedFile>()
    val deletedAttachments = mutableListOf<String>()
    var uploadResult: (PreparedFile) -> Result<MessageAttachment> = { f -> Result.success(attachment("att${uploaded.size}", f.kind)) }
    val reacted = mutableListOf<String>()
    val unreacted = mutableListOf<String>()
    var markedRead = 0

    override suspend fun conversations(archived: Boolean, query: String?, cursor: String?) = convs
    override suspend fun conversation(id: String) = conv
    override suspend fun messages(id: String, cursor: String?) = pages(cursor)
    override suspend fun markRead(id: String): Result<Unit> { markedRead++; return Result.success(Unit) }
    override suspend fun send(id: String, body: String, replyToId: String?, attachmentIds: List<String>): Result<ChatMessage> {
        sent += Triple(id, body, replyToId); sentAttachmentIds += attachmentIds; return sendResult()
    }
    override suspend fun uploadAttachment(conversationId: String, file: PreparedFile): Result<MessageAttachment> { uploaded += file; return uploadResult(file) }
    override suspend fun deleteAttachment(id: String): Result<Unit> { deletedAttachments += id; return Result.success(Unit) }
    override suspend fun downloadAttachment(id: String): Result<ByteArray> = Result.success(ByteArray(0))
    override suspend fun edit(messageId: String, body: String) = editResult
    override suspend fun delete(messageId: String) = deleteResult
    override suspend fun react(messageId: String, kind: String): Result<ChatMessage> { reacted += kind; return Result.success(message(messageId, 20, reactions = listOf(ChatReaction(kind, 1, true)))) }
    override suspend fun unreact(messageId: String): Result<ChatMessage> { unreacted += messageId; return Result.success(message(messageId, 20)) }
    override suspend fun setFlags(id: String, muted: Boolean?, archived: Boolean?) = flagsResult(id, muted, archived)

    override suspend fun startDirect(user: String): Result<Conversation> = error("unused")
    override suspend fun createGroup(title: String, members: List<String>): Result<Conversation> = error("unused")
    override suspend fun members(id: String): Result<List<ChatMember>> = error("unused")
    override suspend fun addMember(id: String, user: String): Result<List<ChatMember>> = error("unused")
    override suspend fun removeMember(id: String, user: String): Result<Unit> = error("unused")
    override suspend fun setMemberRole(id: String, user: String, role: String): Result<List<ChatMember>> = error("unused")
    override suspend fun readReceipts(): Result<Boolean> = error("unused")
    override suspend fun setReadReceipts(enabled: Boolean): Result<Boolean> = error("unused")
}

private fun attachment(id: String, kind: String = "image", durationMs: Long? = null) =
    MessageAttachment(id, kind, if (kind == "voice") "audio/mp4" else "image/jpeg", 1000, if (kind == "document") "$id.pdf" else null, null, null, durationMs)

private class FakeFiles : MessageFilePreparer {
    val failures = mutableMapOf<String, String>()
    private fun prepare(uri: String, kind: String, mime: String): Result<PreparedFile> =
        failures[uri]?.let { Result.failure(AttachmentPrepareException(it)) } ?: Result.success(PreparedFile(byteArrayOf(1, 2, 3), mime, if (kind == "document") "$uri.pdf" else null, kind))
    override suspend fun prepareImage(uri: String) = prepare(uri, "image", "image/jpeg")
    override suspend fun prepareDocument(uri: String) = prepare(uri, "document", "application/pdf")
}

private class FakeRecorder : VoiceRecorder {
    var recording = false
    var startResult: Result<Unit> = Result.success(Unit)
    var stopResult: Result<RecordedVoice> = Result.success(RecordedVoice(java.io.File.createTempFile("voice", ".m4a").also { it.writeBytes(byteArrayOf(9, 9, 9)); it.deleteOnExit() }.absolutePath, 4000, 3))
    val discarded = mutableListOf<String>()
    var cancelled = 0
    override val isRecording get() = recording
    override fun start(): Result<Unit> { if (startResult.isSuccess) recording = true; return startResult }
    override fun stop(): Result<RecordedVoice> { recording = false; return stopResult }
    override fun cancel() { recording = false; cancelled++ }
    override fun discard(path: String) { discarded += path }
    var readResult: ByteArray? = byteArrayOf(9, 9, 9)
    override suspend fun read(path: String): ByteArray? = readResult
}

private class FakeOutbox : app.winkwink.domain.outbox.OutboxRepository {
    val items = MutableStateFlow<List<app.winkwink.domain.outbox.OutboxMessage>>(emptyList())
    val drafts = mutableListOf<app.winkwink.domain.outbox.OutboxDraft>()
    val retried = mutableListOf<String>()
    val discarded = mutableListOf<String>()
    override val sent = kotlinx.coroutines.flow.MutableSharedFlow<ChatMessage>(extraBufferCapacity = 8)
    override fun observe(conversationId: String): kotlinx.coroutines.flow.Flow<List<app.winkwink.domain.outbox.OutboxMessage>> = items
    override suspend fun enqueue(draft: app.winkwink.domain.outbox.OutboxDraft): String { drafts += draft; return "o${drafts.size}" }
    override suspend fun retry(id: String) { retried += id }
    override suspend fun discard(id: String) { discarded += id }
    override suspend fun clearAll() { items.value = emptyList() }
    override suspend fun process() = app.winkwink.domain.outbox.OutboxRun.DONE
}

private class FakeOutboxFiles : app.winkwink.domain.outbox.OutboxFiles {
    val saved = mutableListOf<String>()
    val deleted = mutableListOf<String>()
    override suspend fun save(bytes: ByteArray, extension: String): String = "/outbox/f${saved.size}.$extension".also { saved += it }
    override suspend fun adopt(sourcePath: String): String? = sourcePath
    override fun delete(path: String) { deleted += path }
    override fun clear() {}
}

private class FakePlayback : VoicePlayback {
    override val state = MutableStateFlow(PlaybackState())
    val calls = mutableListOf<String>()
    override fun toggleRemote(attachmentId: String, durationHintMs: Long) { calls += "remote:$attachmentId"; state.value = PlaybackState(attachmentId, PlaybackStatus.PLAYING, 0, durationHintMs) }
    override fun toggleLocal(key: String, path: String, durationHintMs: Long) { calls += "local:$key"; state.value = PlaybackState(key, PlaybackStatus.PLAYING, 0, durationHintMs) }
    override fun seekTo(key: String, fraction: Float) { calls += "seek:$key:$fraction" }
    override fun stop() { calls += "stop"; state.value = PlaybackState() }
}

private class FakeRealtime : RealtimeClient {
    override val state = MutableStateFlow(RealtimeState.ONLINE)
    val flow = MutableSharedFlow<RealtimeEvent>(extraBufferCapacity = 16)
    override val events: SharedFlow<RealtimeEvent> = flow
    val typingSent = mutableListOf<String>()
    var started = 0
    var stopped = 0
    var canSend = true
    override fun start() { started++ }
    override fun stop() { stopped++ }
    override fun sendTyping(conversationId: String): Boolean { if (canSend) typingSent += conversationId; return canSend }
}

@OptIn(ExperimentalCoroutinesApi::class)
class MessageViewModelsTest {
    private val repo = FakeMessages()
    private val realtime = FakeRealtime()
    private val files = FakeFiles()
    private val recorder = FakeRecorder()
    private val playback = FakePlayback()
    private val outbox = FakeOutbox()
    private val outboxFiles = FakeOutboxFiles()

    @Before fun setUp() { Dispatchers.setMain(UnconfinedTestDispatcher()) }
    @After fun tearDown() { Dispatchers.resetMain() }

    private fun chat() = ChatViewModel(repo, realtime, files, recorder, playback, outbox, outboxFiles, SavedStateHandle(mapOf("id" to "c1")))

    // ---- lista ----

    @Test fun listLoadsFirstPage() {
        val vm = ConversationListViewModel(repo, realtime)
        assertEquals(listOf("c1", "c2"), vm.state.value.items.map { it.id })
        assertTrue(vm.state.value.loaded)
    }

    @Test fun listFailureIsShownAndRetryRecovers() {
        repo.convs = Result.failure(ApiFailure("network", "x"))
        val vm = ConversationListViewModel(repo, realtime)
        assertEquals("network", vm.state.value.failure?.code)
        repo.convs = Result.success(ConversationPage(listOf(conversation("c1")), null))
        vm.refresh()
        assertNull(vm.state.value.failure); assertEquals(1, vm.state.value.items.size)
    }

    @Test fun archiveRemovesRowOnlyAfterServerSuccess() {
        val vm = ConversationListViewModel(repo, realtime)
        repo.flagsResult = { _, _, _ -> Result.failure(ApiFailure("server_error", "x")) }
        vm.toggleArchive(conversation("c1"))
        assertEquals(2, vm.state.value.items.size); assertNotNull(vm.state.value.actionFailure)
        repo.flagsResult = { id, m, a -> Result.success(conversation(id, muted = m ?: false, archived = a ?: false)) }
        vm.toggleArchive(conversation("c1"))
        assertEquals(listOf("c2"), vm.state.value.items.map { it.id })
    }

    @Test fun muteUpdatesRowFromServer() {
        val vm = ConversationListViewModel(repo, realtime)
        vm.toggleMute(conversation("c1"))
        assertTrue(vm.state.value.items.first { it.id == "c1" }.muted)
    }

    // ---- czat ----

    @Test fun chatLoadsAndMarksReadWhenUnread() {
        val vm = chat()
        assertEquals(listOf("m2", "m1"), vm.state.value.messages.map { it.id })
        assertEquals(1, repo.markedRead)
        assertEquals(0, vm.state.value.conversation?.unreadCount)
    }

    @Test fun chatLoadFailureKeepsRetry() {
        repo.conv = Result.failure(ApiFailure("conversation_not_found", "x"))
        val vm = chat()
        assertEquals("conversation_not_found", vm.state.value.failure?.code)
        repo.conv = Result.success(conversation())
        vm.load()
        assertNull(vm.state.value.failure); assertTrue(vm.state.value.loaded)
    }

    @Test fun blankOrTooLongDraftIsNotSent() {
        val vm = chat()
        vm.onDraft("   "); vm.send()
        vm.onDraft("x".repeat(4001)); vm.send()
        assertTrue(repo.sent.isEmpty())
    }

    @Test fun replyIsSentWithParentIdAndClearedAfter() {
        val vm = chat()
        vm.startReply(vm.state.value.messages.first())
        vm.onDraft("odp"); vm.send()
        assertEquals("m2", repo.sent.single().third)
        assertNull(vm.state.value.replyTo)
    }

    @Test fun editReplacesMessageAndFailureKeepsDraft() {
        val vm = chat()
        val mine = vm.state.value.messages.first { it.mine }
        vm.startEdit(mine)
        assertEquals("text m1", vm.state.value.draft)
        repo.editResult = Result.failure(ApiFailure("server_error", "x"))
        vm.onDraft("edited"); vm.send()
        assertEquals("edited", vm.state.value.draft); assertNotNull(vm.state.value.editing); assertNotNull(vm.state.value.actionFailure)
        repo.editResult = Result.success(message("m1", 10, mine = true, body = "edited"))
        vm.send()
        assertEquals("edited", vm.state.value.messages.first { it.id == "m1" }.body)
        assertNull(vm.state.value.editing); assertEquals("", vm.state.value.draft)
    }

    @Test fun cannotEditForeignMessage() {
        val vm = chat()
        vm.startEdit(vm.state.value.messages.first { !it.mine })
        assertNull(vm.state.value.editing)
    }

    @Test fun deleteMarksMessageDeletedOnlyAfterSuccess() {
        val vm = chat()
        val m = vm.state.value.messages.first { it.mine }
        repo.deleteResult = Result.failure(ApiFailure("forbidden", "x"))
        vm.delete(m)
        assertFalse(vm.state.value.messages.first { it.id == "m1" }.deleted)
        repo.deleteResult = Result.success(Unit)
        vm.delete(m)
        val after = vm.state.value.messages.first { it.id == "m1" }
        assertTrue(after.deleted); assertNull(after.body)
    }

    @Test fun reactingTwiceWithSameKindUndoes() {
        val vm = chat()
        val m = vm.state.value.messages.first { !it.mine }
        vm.react(m, "love")
        assertEquals("love", vm.state.value.messages.first { it.id == m.id }.myReaction)
        vm.react(vm.state.value.messages.first { it.id == m.id }, "love")
        assertEquals(listOf("m2"), repo.unreacted)
        assertNull(vm.state.value.messages.first { it.id == m.id }.myReaction)
    }

    @Test fun refreshLatestMergesNewAndUpdatedMessagesAndMarksRead() {
        val vm = chat()
        val readBefore = repo.markedRead
        repo.pages = { Result.success(ChatMessagePage(listOf(message("m3", 40), message("m2", 20), message("m1", 10, mine = true).copy(status = "read")), null)) }
        vm.refreshLatest()
        assertEquals(listOf("m3", "m2", "m1"), vm.state.value.messages.map { it.id })
        assertEquals("read", vm.state.value.messages.first { it.id == "m1" }.status)
        assertEquals(readBefore + 1, repo.markedRead)
    }

    @Test fun muteAndArchiveInChatUseServerState() {
        val vm = chat()
        vm.toggleMute()
        assertTrue(vm.state.value.conversation!!.muted)
    }

    // ---- czas rzeczywisty ----

    @Test fun eventForThisConversationRefreshesChatAndOtherConversationsAreIgnored() {
        val vm = chat()
        repo.pages = { Result.success(ChatMessagePage(listOf(message("m3", 40), message("m2", 20), message("m1", 10, mine = true)), null)) }
        realtime.flow.tryEmit(RealtimeEvent(RealtimeTypes.MESSAGE_NEW, "other"))
        assertEquals(listOf("m2", "m1"), vm.state.value.messages.map { it.id })
        realtime.flow.tryEmit(RealtimeEvent(RealtimeTypes.MESSAGE_NEW, "c1", "m3"))
        assertEquals(listOf("m3", "m2", "m1"), vm.state.value.messages.map { it.id })
    }

    @Test fun typingShowsNameAndNewMessageFromThatPersonClearsIt() {
        val vm = chat()
        realtime.flow.tryEmit(RealtimeEvent(RealtimeTypes.TYPING, "c1", actor = other))
        assertEquals(listOf("Bobby"), vm.state.value.typing)
        realtime.flow.tryEmit(RealtimeEvent(RealtimeTypes.TYPING, "elsewhere", actor = ChatPerson("ww_x", "x", null)))
        assertEquals(listOf("Bobby"), vm.state.value.typing)
        realtime.flow.tryEmit(RealtimeEvent(RealtimeTypes.MESSAGE_NEW, "c1", "m9", other))
        assertTrue(vm.state.value.typing.isEmpty())
    }

    @Test fun draftSendsTypingOnceAndNotForBlankOrEdit() {
        val vm = chat()
        vm.onDraft("   ")
        assertTrue(realtime.typingSent.isEmpty())
        vm.onDraft("h"); vm.onDraft("he"); vm.onDraft("hej")
        assertEquals(listOf("c1"), realtime.typingSent) // ograniczenie częstotliwości
        val vm2 = chat()
        vm2.startEdit(vm2.state.value.messages.first { it.mine })
        vm2.onDraft("poprawka")
        assertEquals(1, realtime.typingSent.size)
    }

    @Test fun failedTypingSendDoesNotThrottleNextAttempt() {
        val vm = chat()
        realtime.canSend = false
        vm.onDraft("a")
        realtime.canSend = true
        vm.onDraft("ab")
        assertEquals(listOf("c1"), realtime.typingSent)
    }

    @Test fun losingAccessToConversationIsShownAfterRealtimeRefresh() {
        val vm = chat()
        repo.pages = { Result.failure(ApiFailure("conversation_not_found", "x")) }
        realtime.flow.tryEmit(RealtimeEvent(RealtimeTypes.MEMBER_CHANGED, "c1"))
        assertEquals("conversation_not_found", vm.state.value.failure?.code)
    }

    @Test fun networkFailureDuringRealtimeRefreshStaysSilent() {
        val vm = chat()
        repo.pages = { Result.failure(ApiFailure("network", "x")) }
        realtime.flow.tryEmit(RealtimeEvent(RealtimeTypes.RECEIPT, "c1"))
        assertNull(vm.state.value.failure); assertEquals(2, vm.state.value.messages.size)
    }

    @Test fun listRefreshesOnEventsButNotOnTyping() {
        val vm = ConversationListViewModel(repo, realtime)
        repo.convs = Result.success(ConversationPage(listOf(conversation("c9")), null))
        realtime.flow.tryEmit(RealtimeEvent(RealtimeTypes.TYPING, "c1", actor = other))
        assertEquals(listOf("c1", "c2"), vm.state.value.items.map { it.id })
        realtime.flow.tryEmit(RealtimeEvent(RealtimeTypes.CONVERSATION_NEW, "c9"))
        assertEquals(listOf("c9"), vm.state.value.items.map { it.id })
    }

    @Test fun badgeCountsUnreadOfUnmutedConversationsAndControlsConnection() {
        repo.convs = Result.success(ConversationPage(listOf(conversation("c1", unread = 2), conversation("c2", unread = 5, muted = true), conversation("c3", unread = 1)), null))
        val vm = MessagingBackgroundViewModel(repo, realtime)
        vm.start()
        assertEquals(1, realtime.started); assertEquals(3, vm.unread.value)
        repo.convs = Result.success(ConversationPage(listOf(conversation("c1", unread = 0)), null))
        realtime.flow.tryEmit(RealtimeEvent(RealtimeTypes.RECEIPT, "c1"))
        assertEquals(0, vm.unread.value)
        vm.stop()
        assertEquals(1, realtime.stopped)
    }

    // ---- Etap F: zdjęcia i dokumenty ----

    @Test fun captionIsSentWithAttachments() {
        val vm = chat()
        vm.addDocuments(listOf("doc")); vm.onDraft("  umowa  "); vm.send()
        assertEquals("umowa", repo.sent.single().second)
        assertEquals("document", repo.uploaded.single().kind)
    }

    @Test fun cannotSendWhileUploadingOrAfterFailureUntilRetried() {
        val vm = chat()
        repo.uploadResult = { Result.failure(ApiFailure("network", "x")) }
        vm.addImages(listOf("u1"))
        val a = vm.state.value.draftAttachments.single()
        assertEquals(UploadStatus.Failed, a.status); assertEquals("network", a.errorCode)
        assertTrue(vm.state.value.hasFailedUpload); assertFalse(vm.state.value.canSend)
        vm.send(); assertTrue(repo.sent.isEmpty())
        repo.uploadResult = { f -> Result.success(attachment("ok", f.kind)) }
        vm.retryAttachment(a.localId)
        assertEquals(UploadStatus.Done, vm.state.value.draftAttachments.single().status)
        assertEquals("ok", vm.state.value.draftAttachments.single().remoteId)
        assertTrue(vm.state.value.canSend)
    }

    @Test fun offlineUploadsAreRetriedAfterReconnect() {
        val vm = chat()
        repo.uploadResult = { Result.failure(ApiFailure("timeout", "x")) }
        vm.addImages(listOf("u1"))
        repo.uploadResult = { f -> Result.success(attachment("ok", f.kind)) }
        realtime.flow.tryEmit(RealtimeEvent(RealtimeTypes.CONNECTED))
        assertEquals(UploadStatus.Done, vm.state.value.draftAttachments.single().status)
    }

    @Test fun removingAnUploadedFileWithdrawsItFromTheServer() {
        val vm = chat()
        vm.addImages(listOf("u1"))
        vm.removeAttachment(vm.state.value.draftAttachments.single().localId)
        assertTrue(vm.state.value.draftAttachments.isEmpty())
        assertEquals(listOf("att1"), repo.deletedAttachments)
    }

    @Test fun attachmentLimitsAndMixingAreEnforcedOnDevice() {
        val vm = chat()
        vm.addImages((1..11).map { "u$it" })
        assertEquals(10, vm.state.value.draftAttachments.size); assertEquals("too_many", vm.state.value.notice)
        vm.addDocuments(listOf("d1"))
        assertEquals("mixed_kinds", vm.state.value.notice); assertEquals(10, repo.uploaded.size)
        val docs = chat()
        docs.addDocuments((1..6).map { "d$it" })
        assertEquals(5, docs.state.value.draftAttachments.size); assertEquals("too_many_documents", docs.state.value.notice)
    }

    @Test fun unsupportedAndUnreadableFilesNeverReachTheServer() {
        val vm = chat()
        files.failures["bad"] = AttachmentPrepareException.UNSUPPORTED
        vm.addDocuments(listOf("bad"))
        assertEquals("unsupported_type", vm.state.value.notice)
        files.failures["big"] = AttachmentPrepareException.TOO_LARGE
        vm.addDocuments(listOf("big"))
        assertEquals("file_too_large", vm.state.value.notice)
        assertTrue(repo.uploaded.isEmpty()); assertTrue(vm.state.value.draftAttachments.isEmpty())
        vm.dismissNotice(); assertNull(vm.state.value.notice)
    }

    @Test fun deletingMessageClearsItsAttachmentsLocally() {
        val vm = chat()
        val withPhoto = message("m9", 40, mine = true).copy(attachments = listOf(attachment("a9")))
        repo.pages = { Result.success(ChatMessagePage(listOf(withPhoto), null)) }
        vm.load()
        vm.delete(vm.state.value.messages.single())
        val m = vm.state.value.messages.single()
        assertTrue(m.deleted); assertTrue(m.attachments.isEmpty())
    }

    @Test fun voiceMessagesCannotBeEdited() {
        val vm = chat()
        val voice = message("v1", 40, mine = true).copy(attachments = listOf(attachment("a1", "voice", 3000)))
        vm.startEdit(voice)
        assertNull(vm.state.value.editing)
    }

    // ---- Etap F: wiadomości głosowe ----

    @Test fun cancelAndDiscardDeleteTheRecording() {
        val vm = chat()
        vm.startRecording(); vm.cancelRecording()
        assertFalse(vm.state.value.recording); assertEquals(1, recorder.cancelled); assertNull(vm.state.value.voiceDraft)
        vm.startRecording(); vm.stopRecording()
        val path = vm.state.value.voiceDraft!!.path
        vm.discardVoice()
        assertNull(vm.state.value.voiceDraft); assertEquals(listOf(path), recorder.discarded)
        assertTrue(repo.uploaded.isEmpty())
    }

    @Test fun recordingFailuresBecomeNotices() {
        val vm = chat()
        recorder.startResult = Result.failure(VoiceRecordException(VoiceRecordException.START_FAILED))
        vm.startRecording()
        assertEquals("record_start_failed", vm.state.value.notice); assertFalse(vm.state.value.recording)
        recorder.startResult = Result.success(Unit)
        recorder.stopResult = Result.failure(VoiceRecordException(VoiceRecordException.TOO_SHORT))
        vm.startRecording(); vm.stopRecording()
        assertEquals("record_too_short", vm.state.value.notice); assertNull(vm.state.value.voiceDraft)
    }

    @Test fun backgroundingWhileRecordingMovesToPreview() {
        val vm = chat()
        vm.startRecording()
        vm.onBackgrounded()
        assertFalse(vm.state.value.recording); assertNotNull(vm.state.value.voiceDraft)
    }

    @Test fun filesAndVoiceDoNotMix() {
        val vm = chat()
        vm.addImages(listOf("u1"))
        vm.startRecording()
        assertEquals("voice_busy", vm.state.value.notice); assertFalse(vm.state.value.recording)
        val v = chat()
        v.startRecording(); v.stopRecording()
        v.addImages(listOf("u1"))
        assertEquals("voice_busy", v.state.value.notice); assertTrue(repo.uploaded.size == 1)
    }

    @Test fun startingPlaybackOfAnotherMessageUsesTheSingleSharedPlayer() {
        val vm = chat()
        vm.toggleVoice(attachment("a1", "voice", 3000))
        vm.toggleVoice(attachment("a2", "voice", 5000))
        assertEquals(listOf("remote:a1", "remote:a2"), playback.calls)
        assertEquals("a2", vm.playback.value.key) // jeden aktywny klucz = poprzednie odtwarzanie przestaje być aktywne
        vm.startRecording()
        assertEquals("stop", playback.calls.last()) // nagrywanie zatrzymuje odtwarzanie
    }

    @Test fun previewPlaybackUsesItsOwnKey() {
        val vm = chat()
        vm.startRecording(); vm.stopRecording()
        vm.togglePreview(); vm.seekPreview(0.5f)
        assertEquals(listOf("local:voice-preview", "seek:voice-preview:0.5"), playback.calls)
    }

    @Test fun leavingTheChatStopsRecordingAndPlayback() {
        val vm = chat()
        vm.startRecording()
        val onCleared = vm.javaClass.getDeclaredMethod("onCleared").apply { isAccessible = true }
        onCleared.invoke(vm)
        assertEquals(1, recorder.cancelled); assertEquals("stop", playback.calls.last())
    }

    @Test fun sendWritesToTheDurableOutboxInsteadOfMemory() {
        val vm = chat()
        vm.onDraft("hello")
        vm.send()
        assertEquals(1, outbox.drafts.size)
        assertEquals("hello", outbox.drafts.single().body)
        assertEquals("c1", outbox.drafts.single().conversationId)
        assertEquals("", vm.state.value.draft)
    }

    @Test fun pendingListComesFromTheOutbox() {
        val vm = chat()
        outbox.items.value = listOf(
            app.winkwink.domain.outbox.OutboxMessage("o1", "c1", "x", null, emptyList(), app.winkwink.domain.outbox.OutboxStatus.FAILED, ApiFailure("forbidden", "x")),
        )
        assertEquals(1, vm.state.value.pending.size)
        assertTrue(vm.state.value.pending.single().failed)
        vm.retry("o1"); vm.discard("o1")
        assertEquals(listOf("o1"), outbox.retried); assertEquals(listOf("o1"), outbox.discarded)
    }

    @Test fun confirmedOutboxMessageAppearsOnTopOnce() = runTest {
        val vm = chat()
        outbox.sent.emit(message("sent1", 99, mine = true))
        outbox.sent.emit(message("sent1", 99, mine = true))
        assertEquals(1, vm.state.value.messages.count { it.id == "sent1" })
        assertEquals("sent1", vm.state.value.messages.first().id)
    }

    @Test fun voiceRecordingIsMovedToOutboxStorageAndQueued() {
        val vm = chat()
        vm.startRecording(); vm.stopRecording(); vm.send()
        val draft = outbox.drafts.single()
        assertEquals("voice", draft.files.single().kind)
        assertEquals("audio/mp4", draft.files.single().mime)
    }
}
