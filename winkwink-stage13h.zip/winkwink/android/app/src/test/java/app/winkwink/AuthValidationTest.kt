package app.winkwink

import app.winkwink.domain.validation.AuthValidation
import app.winkwink.domain.validation.FieldError
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AuthValidationTest {
    @Test fun emailAcceptsValidAndRejectsInvalid() {
        assertNull(AuthValidation.email(" ala@example.com "))
        listOf("", "ala", "a@b", "a..b@c.pl", "a b@c.pl").forEach { assertEquals(FieldError.EMAIL_INVALID, AuthValidation.email(it)) }
    }

    @Test fun passwordRules() {
        assertNull(AuthValidation.newPassword("long-enough-1", "a@b.co"))
        assertEquals(FieldError.PASSWORD_TOO_SHORT, AuthValidation.newPassword("short"))
        assertEquals(FieldError.PASSWORD_TOO_LONG, AuthValidation.newPassword("x".repeat(129)))
        assertEquals(FieldError.PASSWORD_SAME_AS_EMAIL, AuthValidation.newPassword("ala@example.com", "ALA@example.com"))
    }

    @Test fun nicknameMatchesBackendRule() {
        assertNull(AuthValidation.nickname("ala_01.x"))
        assertEquals(FieldError.NICKNAME_INVALID, AuthValidation.nickname("a"))
        assertEquals(FieldError.NICKNAME_INVALID, AuthValidation.nickname("ala kot"))
    }
}
