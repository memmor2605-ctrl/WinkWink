package app.winkwink.ui

import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.Attachment
import app.winkwink.domain.model.Channel
import app.winkwink.domain.model.CommunityPage
import app.winkwink.domain.model.PreparedFile
import app.winkwink.ui.feed.SearchPostsViewModel
import app.winkwink.ui.feed.UploadStatus
import app.winkwink.domain.model.Comment
import app.winkwink.domain.model.CommentPage
import app.winkwink.domain.model.FeedKind
import app.winkwink.domain.model.Post
import app.winkwink.domain.model.PostPage
import app.winkwink.domain.repository.FeedRepository
import app.winkwink.ui.feed.ComposePostViewModel
import app.winkwink.ui.feed.FeedViewModel
import app.winkwink.ui.feed.SavedPostsViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.time.Instant

private fun samplePost(id: String, reaction: String? = null) = Post(
    id, null, false, false, "body $id", "public", Instant.parse("2026-11-21T10:00:00Z"), false, 0, 0, reaction, false,
)

private class FakeFeedRepository : FeedRepository {
    var pages: MutableMap<String?, Result<PostPage>> = mutableMapOf(null to Result.success(PostPage(listOf(samplePost("a"), samplePost("b")), "n1")))
    val feedCalls = mutableListOf<Pair<FeedKind, String?>>()
    var createResult: Result<Post> = Result.success(samplePost("new"))
    var lastCreate: Triple<String, String, Boolean>? = null

    override suspend fun feed(kind: FeedKind, cursor: String?): Result<PostPage> { feedCalls += kind to cursor; return pages[cursor] ?: Result.success(PostPage(emptyList(), null)) }
    var savedPage: Result<PostPage> = Result.success(PostPage(listOf(samplePost("s1"), samplePost("s2")), null))
    override suspend fun saved(cursor: String?) = savedPage
    override suspend fun post(id: String) = Result.success(samplePost(id))
    var lastCreateIds: List<String> = emptyList()
    override suspend fun createPost(body: String, visibility: String, anonymous: Boolean, attachmentIds: List<String>): Result<Post> { lastCreate = Triple(body, visibility, anonymous); lastCreateIds = attachmentIds; return createResult }
    var lastCommunityPost: Triple<String, String, String>? = null
    var lastCommunityIds: List<String> = emptyList()
    override suspend fun createCommunityPost(body: String, communityId: String, channelId: String, attachmentIds: List<String>): Result<Post> { lastCommunityPost = Triple(body, communityId, channelId); lastCommunityIds = attachmentIds; return createResult }
    override suspend fun updatePost(id: String, body: String) = Result.success(samplePost(id))
    override suspend fun deletePost(id: String) = Result.success(Unit)
    override suspend fun react(id: String, type: String) = Result.success(samplePost(id, type))
    override suspend fun unreact(id: String) = Result.success(samplePost(id))
    override suspend fun setSaved(id: String, saved: Boolean) = Result.success(Unit)
    override suspend fun comments(postId: String, parentId: String?, cursor: String?) = Result.success(CommentPage(emptyList<Comment>(), null))
    override suspend fun addComment(postId: String, parentId: String?, body: String): Result<Comment> = Result.failure(ApiFailure("x", "x"))
    override suspend fun deleteComment(id: String) = Result.success(Unit)

    val searchCalls = mutableListOf<Pair<String, String?>>()
    var searchResult: Result<PostPage> = Result.success(PostPage(listOf(samplePost("r1")), null))
    val shareCalls = mutableListOf<Triple<String, String, String>>()
    var shareResult: Result<Post> = Result.success(samplePost("shared"))
    var uploadResult: Result<Attachment> = Result.success(Attachment("remote1", "image", "image/jpeg", 10, null, null, null))
    var uploadCount = 0
    val deletedAttachments = mutableListOf<String>()
    override suspend fun search(query: String, cursor: String?): Result<PostPage> { searchCalls += query to cursor; return searchResult }
    override suspend fun share(id: String, comment: String, visibility: String): Result<Post> { shareCalls += Triple(id, comment, visibility); return shareResult }
    override suspend fun uploadAttachment(file: PreparedFile): Result<Attachment> {
        uploadCount++
        return uploadResult.map { it.copy(id = "remote$uploadCount", kind = file.kind) }
    }
    override suspend fun deleteAttachment(id: String): Result<Unit> { deletedAttachments += id; return Result.success(Unit) }
    override suspend fun downloadAttachment(id: String): Result<ByteArray> = Result.success(ByteArray(0))
}

@OptIn(ExperimentalCoroutinesApi::class)
class FeedViewModelsTest {
    private val repo = FakeFeedRepository()
    private val communities = StubCommunityRepository()
    private fun compose() = ComposePostViewModel(repo, communities, FakeAttachmentPreparer())

    @Before fun setUp() { Dispatchers.setMain(UnconfinedTestDispatcher()) }
    @After fun tearDown() { Dispatchers.resetMain() }

    @Test fun loadsFollowingOnInit() {
        val vm = FeedViewModel(repo)
        val l = vm.state.value.following
        assertEquals(listOf("a", "b"), l.posts.map { it.id })
        assertTrue(l.loaded); assertFalse(l.loading); assertEquals("n1", l.nextCursor)
    }

    @Test fun discoverLoadsLazilyOnFirstSelection() {
        val vm = FeedViewModel(repo)
        assertEquals(1, repo.feedCalls.size)
        vm.selectTab(FeedKind.Discover)
        assertEquals(2, repo.feedCalls.size)
        vm.selectTab(FeedKind.Following); vm.selectTab(FeedKind.Discover)
        assertEquals(2, repo.feedCalls.size) // brak ponownego pobierania załadowanych list
    }

    @Test fun loadMoreAppendsAndSkipsDuplicates() {
        repo.pages["n1"] = Result.success(PostPage(listOf(samplePost("b"), samplePost("c")), null))
        val vm = FeedViewModel(repo)
        vm.loadMore(FeedKind.Following)
        val l = vm.state.value.following
        assertEquals(listOf("a", "b", "c"), l.posts.map { it.id })
        assertNull(l.nextCursor)
    }

    @Test fun loadMoreFailureKeepsPostsAndCursor() {
        repo.pages["n1"] = Result.failure(ApiFailure("network", "x"))
        val vm = FeedViewModel(repo)
        vm.loadMore(FeedKind.Following)
        val l = vm.state.value.following
        assertEquals(2, l.posts.size); assertEquals("n1", l.nextCursor); assertNotNull(l.failure); assertFalse(l.loadingMore)
    }

    @Test fun initialFailureIsExposedAndNotLoaded() {
        repo.pages[null] = Result.failure(ApiFailure("timeout", "x"))
        val vm = FeedViewModel(repo)
        val l = vm.state.value.following
        assertTrue(l.posts.isEmpty()); assertEquals("timeout", l.failure?.code); assertFalse(l.loaded)
    }

    @Test fun reactionReplacesPostInList() {
        val vm = FeedViewModel(repo)
        vm.react(vm.state.value.following.posts[0], "love")
        assertEquals("love", vm.state.value.following.posts[0].myReaction)
    }

    @Test fun savingTogglesLocalFlagAfterServerConfirms() {
        val vm = FeedViewModel(repo)
        vm.toggleSave(vm.state.value.following.posts[1])
        assertTrue(vm.state.value.following.posts[1].saved)
    }

    @Test fun anonymousSwitchForcesPublicAndLocksVisibility() {
        val vm = compose()
        vm.onVisibility("followers")
        vm.onAnonymous(true)
        assertEquals("public", vm.state.value.visibility)
        vm.onVisibility("private")
        assertEquals("public", vm.state.value.visibility)
    }

    @Test fun publishSendsAndMarksCreated() {
        val vm = compose()
        vm.onBody("Cześć")
        vm.publish()
        assertEquals(Triple("Cześć", "public", false), repo.lastCreate)
        assertTrue(vm.state.value.created)
    }

    @Test fun savedListLoadsAndUnsaveRemovesOnlyAfterServerOk() {
        val vm = SavedPostsViewModel(repo)
        assertEquals(listOf("s1", "s2"), vm.state.value.posts.map { it.id })
        vm.unsave(vm.state.value.posts[0])
        assertEquals(listOf("s2"), vm.state.value.posts.map { it.id })
    }

    @Test fun savedFailureIsExposed() {
        repo.savedPage = Result.failure(ApiFailure("network", "x"))
        val vm = SavedPostsViewModel(repo)
        assertEquals("network", vm.state.value.failure?.code); assertFalse(vm.state.value.loading)
    }

    @Test fun blankBodyIsNotPublished() {
        val vm = compose()
        vm.onBody("   ")
        vm.publish()
        assertNull(repo.lastCreate)
    }

    @Test fun publishFailureIsShownAndNotCreated() {
        repo.createResult = Result.failure(ApiFailure("rate_limited", "x", httpStatus = 429))
        val vm = compose()
        vm.onBody("x"); vm.publish()
        assertFalse(vm.state.value.created); assertEquals("rate_limited", vm.state.value.failure?.code); assertFalse(vm.state.value.posting)
    }

    @Test fun uploadedAttachmentIsSentWithPostAndBodyMayBeEmpty() {
        val vm = compose()
        vm.addAttachments(listOf("content://img/1"))
        assertEquals(UploadStatus.Done, vm.state.value.attachments.single().status)
        assertTrue(vm.state.value.canPost) // pusta treść + załącznik
        vm.publish()
        assertEquals(listOf("remote1"), repo.lastCreateIds)
        assertTrue(vm.state.value.created)
    }

    @Test fun failedUploadBlocksPublishUntilRemoved() {
        repo.uploadResult = Result.failure(ApiFailure("network", "x"))
        val vm = compose()
        vm.onBody("x")
        vm.addAttachments(listOf("content://img/1"))
        assertTrue(vm.state.value.hasFailedUpload); assertFalse(vm.state.value.canPost)
        vm.removeAttachment(vm.state.value.attachments.single().localId)
        assertTrue(vm.state.value.canPost)
    }

    @Test fun removingUploadedAttachmentDeletesItOnServer() {
        val vm = compose()
        vm.addAttachments(listOf("content://img/1"))
        vm.removeAttachment(vm.state.value.attachments.single().localId)
        assertEquals(listOf("remote1"), repo.deletedAttachments)
    }

    @Test fun anonymousRejectsVideoAndVideoBlocksAnonymous() {
        val vm = compose()
        vm.onAnonymous(true)
        vm.addAttachments(listOf("video:1"))
        assertEquals("anonymous_images_only", vm.state.value.attachmentNotice)
        assertTrue(vm.state.value.attachments.isEmpty())
        vm.onAnonymous(false)
        vm.addAttachments(listOf("video:1"))
        vm.onAnonymous(true)
        assertFalse(vm.state.value.anonymous)
        assertEquals("anonymous_images_only", vm.state.value.attachmentNotice)
    }

    @Test fun attachmentLimitsAreEnforced() {
        val vm = compose()
        vm.addAttachments(listOf("video:1", "video:2"))
        assertEquals("too_many_videos", vm.state.value.attachmentNotice)
        vm.addAttachments(listOf("doc:1", "doc:2", "doc:3", "doc:4"))
        assertEquals("too_many_documents", vm.state.value.attachmentNotice)
        vm.addAttachments(listOf("bad:1"))
        assertEquals("unsupported_type", vm.state.value.attachmentNotice)
    }

    @Test fun communityVisibilityPublishesToChosenChannel() {
        communities.mine = Result.success(CommunityPage(listOf(testCommunity("c1")), null))
        communities.channels = mapOf("c1" to listOf(Channel("ch1", "general"), Channel("ch2", "off-topic")))
        val vm = compose()
        vm.onVisibility("community")
        assertEquals("c1", vm.state.value.communityId) // jedna społeczność → wybrana automatycznie
        assertEquals("ch1", vm.state.value.channelId)
        vm.onChannel("ch2")
        vm.onBody("w społeczności")
        vm.publish()
        assertEquals(Triple("w społeczności", "c1", "ch2"), repo.lastCommunityPost)
        assertNull(repo.lastCreate)
    }

    @Test fun communityModeNeedsChannelAndDisablesAnonymous() {
        communities.mine = Result.success(CommunityPage(listOf(testCommunity("c1"), testCommunity("c2")), null))
        val vm = compose()
        vm.onBody("x")
        vm.onVisibility("community")
        assertFalse(vm.state.value.canPost) // nie wybrano społeczności
        vm.onAnonymous(true)
        assertFalse(vm.state.value.anonymous); assertEquals("community", vm.state.value.visibility)
    }

    @Test fun communityLoadFailureIsExposedAndRetryable() {
        communities.mine = Result.failure(ApiFailure("network", "x"))
        val vm = compose()
        vm.onVisibility("community")
        assertEquals("network", vm.state.value.communitiesFailure?.code)
        communities.mine = Result.success(CommunityPage(emptyList(), null))
        vm.loadCommunities()
        assertTrue(vm.state.value.communitiesLoaded); assertNull(vm.state.value.communitiesFailure)
    }

    @Test fun searchSubmitCallsRepositoryAndShortQueryDoesNot() {
        val vm = SearchPostsViewModel(repo)
        vm.onQuery("ab"); vm.submit()
        assertTrue(repo.searchCalls.isEmpty())
        vm.onQuery(" hello "); vm.submit()
        assertEquals(listOf("hello" to null), repo.searchCalls)
        assertEquals("r1", vm.state.value.posts.single().id); assertTrue(vm.state.value.searched)
    }

    @Test fun searchFailureIsExposed() {
        repo.searchResult = Result.failure(ApiFailure("network", "x"))
        val vm = SearchPostsViewModel(repo)
        vm.onQuery("hello"); vm.submit()
        assertEquals("network", vm.state.value.failure?.code); assertFalse(vm.state.value.loading)
    }

    @Test fun shareRefreshesFollowingAndFailureIsShown() {
        val vm = FeedViewModel(repo)
        vm.share(vm.state.value.following.posts[0], "hej", "public")
        assertEquals(Triple("a", "hej", "public"), repo.shareCalls.single())
        assertTrue(vm.state.value.shareNotice)
        repo.shareResult = Result.failure(ApiFailure("not_shareable", "x", httpStatus = 403))
        vm.dismissShareNotice()
        vm.share(vm.state.value.following.posts[0], "", "public")
        assertFalse(vm.state.value.shareNotice); assertEquals("not_shareable", vm.state.value.actionFailure?.code)
    }
}
