package app.winkwink.data

import app.winkwink.data.remote.AddMemberRequestDto
import app.winkwink.data.remote.ChatMemberListDto
import app.winkwink.data.remote.ChatMessageDto
import app.winkwink.data.remote.ChatMessageListDto
import app.winkwink.data.remote.ChatPersonDto
import app.winkwink.data.remote.ChatReactionDto
import app.winkwink.data.remote.ConversationDto
import app.winkwink.data.remote.ConversationListDto
import app.winkwink.data.remote.ConversationSettingsRequestDto
import app.winkwink.data.remote.CreateGroupRequestDto
import app.winkwink.data.remote.EditMessageRequestDto
import app.winkwink.data.remote.MemberRoleRequestDto
import app.winkwink.data.remote.MessageApi
import app.winkwink.data.remote.MessageAttachmentDto
import app.winkwink.data.remote.MessageSettingsDto
import app.winkwink.data.remote.SendMessageRequestDto
import app.winkwink.data.remote.SetReactionRequestDto
import app.winkwink.data.remote.StartDirectRequestDto
import app.winkwink.data.repository.MessageRepositoryImpl
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.PreparedFile
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody
import okhttp3.ResponseBody
import okhttp3.ResponseBody.Companion.toResponseBody
import java.io.IOException
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import retrofit2.Response

private val bob = ChatPersonDto("ww_bob", "bobby", "Bobby", "tag1")

private fun msg(id: String = "m1", mine: Boolean = false, deleted: Boolean = false, status: String? = "read", createdAt: String = "2026-11-24T10:00:00Z") =
    ChatMessageDto(id, "c1", bob, if (deleted) "leaked" else "hej", null, createdAt, null, deleted, mine, status, listOf(ChatReactionDto("love", 2, true)))

private fun conv(last: ChatMessageDto? = msg()) =
    ConversationDto("c1", "direct", null, bob, 2, muted = true, unreadCount = 3, myRole = "member", lastMessage = last, activityAt = "2026-11-24T10:00:00Z")

private class FakeMessageApi : MessageApi {
    var list: () -> Response<ConversationListDto> = { Response.success(ConversationListDto(listOf(conv()), "next")) }
    var messages: () -> Response<ChatMessageListDto> = { Response.success(ChatMessageListDto(listOf(msg()), null)) }
    var lastConversations: List<Any?>? = null
    var lastSettings: ConversationSettingsRequestDto? = null
    var lastSend: SendMessageRequestDto? = null
    var lastReaction: SetReactionRequestDto? = null
    var lastRole: Triple<String, String, MemberRoleRequestDto>? = null
    var lastReceipts: MessageSettingsDto? = null

    override suspend fun conversations(archived: Boolean, q: String?, limit: Int, cursor: String?): Response<ConversationListDto> {
        lastConversations = listOf(archived, q, limit, cursor); return list()
    }
    override suspend fun startDirect(body: StartDirectRequestDto) = Response.success(conv())
    override suspend fun createGroup(body: CreateGroupRequestDto) = Response.success(conv())
    override suspend fun conversation(id: String) = Response.success(conv())
    override suspend fun settings(id: String, body: ConversationSettingsRequestDto): Response<ConversationDto> { lastSettings = body; return Response.success(conv()) }
    override suspend fun markRead(id: String): Response<Unit> = Response.success(Unit)
    override suspend fun messages(id: String, limit: Int, cursor: String?) = messages()
    override suspend fun send(id: String, body: SendMessageRequestDto): Response<ChatMessageDto> { lastSend = body; return Response.success(msg(mine = true, status = "sent")) }
    override suspend fun edit(id: String, body: EditMessageRequestDto) = Response.success(msg())
    override suspend fun delete(id: String): Response<Unit> = Response.success(Unit)
    override suspend fun react(id: String, body: SetReactionRequestDto): Response<ChatMessageDto> { lastReaction = body; return Response.success(msg()) }
    override suspend fun unreact(id: String) = Response.success(msg())
    override suspend fun members(id: String) = Response.success(ChatMemberListDto(emptyList()))
    override suspend fun addMember(id: String, body: AddMemberRequestDto) = Response.success(ChatMemberListDto(emptyList()))
    override suspend fun removeMember(id: String, user: String): Response<Unit> = Response.success(Unit)
    override suspend fun setMemberRole(id: String, user: String, body: MemberRoleRequestDto): Response<ChatMemberListDto> {
        lastRole = Triple(id, user, body)
        return Response.success(ChatMemberListDto(listOf(app.winkwink.data.remote.ChatMemberDto(bob, "admin", "2026-11-24T10:00:00Z"))))
    }
    var lastUpload: Triple<String, String?, RequestBody>? = null
    var upload: () -> Response<MessageAttachmentDto> = { Response.success(MessageAttachmentDto("att1", "voice", "audio/mp4", 99, null, null, null, 4200)) }
    var download: () -> Response<ResponseBody> = { Response.success("hello".toResponseBody("audio/mp4".toMediaType())) }
    var downloadThrows: IOException? = null
    val deletedAttachments = mutableListOf<String>()
    override suspend fun changes(id: String, since: String?, limit: Int, cursor: String?): Response<app.winkwink.data.remote.ChatChangesDto> =
        Response.success(app.winkwink.data.remote.ChatChangesDto(emptyList(), null, "2026-11-26T10:00:00Z"))
    override suspend fun uploadAttachment(conversationId: String, name: String?, body: RequestBody, idempotencyKey: String?): Response<MessageAttachmentDto> {
        lastUpload = Triple(conversationId, name, body); return upload()
    }
    override suspend fun deleteAttachment(id: String): Response<Unit> { deletedAttachments += id; return Response.success(Unit) }
    override suspend fun downloadAttachment(id: String): Response<ResponseBody> { downloadThrows?.let { throw it }; return download() }
    override suspend fun readReceipts() = Response.success(MessageSettingsDto(true))
    override suspend fun setReadReceipts(body: MessageSettingsDto): Response<MessageSettingsDto> { lastReceipts = body; return Response.success(body) }
}

class MessageRepositoryImplTest {
    private val api = FakeMessageApi()
    private val repo = MessageRepositoryImpl(api, Json { ignoreUnknownKeys = true })

    @Test fun conversationsMapPeerLastMessageAndCursor() = runTest {
        val page = repo.conversations(false, "  ", null).getOrThrow()
        val c = page.items.single()
        assertEquals("Bobby", c.displayName); assertEquals("tag1", c.peer?.avatarTag)
        assertEquals(3, c.unreadCount); assertTrue(c.muted)
        assertEquals("next", page.nextCursor)
        // puste zapytanie nie jest wysyłane
        assertEquals(listOf(false, null, 30, null), api.lastConversations)
    }

    @Test fun statusIsKeptOnlyForOwnMessagesAndReactionsMapped() = runTest {
        api.messages = { Response.success(ChatMessageListDto(listOf(msg("a", mine = true, status = "delivered"), msg("b", mine = false, status = "read")), null)) }
        val items = repo.messages("c1", null).getOrThrow().items
        assertEquals("delivered", items[0].status); assertNull(items[1].status)
        assertEquals("love", items[0].myReaction)
    }

    @Test fun deletedMessageNeverCarriesBody() = runTest {
        api.messages = { Response.success(ChatMessageListDto(listOf(msg(deleted = true)), null)) }
        val m = repo.messages("c1", null).getOrThrow().items.single()
        assertTrue(m.deleted); assertNull(m.body)
    }

    @Test fun badDateBecomesInvalidResponse() = runTest {
        api.messages = { Response.success(ChatMessageListDto(listOf(msg(createdAt = "yesterday")), null)) }
        assertEquals("invalid_response", (repo.messages("c1", null).exceptionOrNull() as ApiFailure).code)
    }

    @Test fun serverErrorIsMappedToApiFailure() = runTest {
        api.list = { app.winkwink.errorResponse(404, """{"error":{"code":"conversation_not_found","message":"x"}}""") }
        assertEquals("conversation_not_found", (repo.conversations(true, null, null).exceptionOrNull() as ApiFailure).code)
    }

    @Test fun requestsCarryExpectedBodies() = runTest {
        repo.setFlags("c1", muted = null, archived = true)
        assertEquals(ConversationSettingsRequestDto(null, true), api.lastSettings)
        repo.send("c1", "hej", "m0"); assertEquals(SendMessageRequestDto("hej", "m0"), api.lastSend)
        repo.react("m1", "wow"); assertEquals(SetReactionRequestDto("wow"), api.lastReaction)
        val members = repo.setMemberRole("c1", "ww_bob", "admin").getOrThrow()
        assertEquals("admin", members.single().role); assertEquals("admin", api.lastRole?.third?.role)
        repo.setReadReceipts(false); assertEquals(MessageSettingsDto(false), api.lastReceipts)
    }

    // ---- Etap F ----

    @Test fun sendCarriesAttachmentIds() = runTest {
        repo.send("c1", "", null, listOf("a1", "a2"))
        assertEquals(SendMessageRequestDto("", null, listOf("a1", "a2")), api.lastSend)
    }

    @Test fun messageAttachmentsAreMappedAndDroppedForDeletedMessages() = runTest {
        val att = listOf(MessageAttachmentDto("a1", "document", "application/pdf", 1234, "raport.pdf"), MessageAttachmentDto("a2", "voice", "audio/mp4", 99, null, null, null, 4200))
        api.messages = { Response.success(ChatMessageListDto(listOf(
            msg("m1").copy(attachments = att),
            msg("m2", deleted = true).copy(attachments = att),
        ), null)) }
        val items = repo.messages("c1", null).getOrThrow().items
        assertEquals("raport.pdf", items[0].documents.single().fileName)
        assertEquals(4200L, items[0].voice?.durationMs)
        assertTrue(items[1].attachments.isEmpty()) // usunięta wiadomość nie oddaje załączników
    }

    @Test fun uploadSendsRawBodyWithMimeAndNameAndMapsResult() = runTest {
        val file = PreparedFile(byteArrayOf(1, 2, 3, 4), "audio/mp4", "voice.m4a", "voice")
        val a = repo.uploadAttachment("c1", file).getOrThrow()
        assertEquals("att1", a.id); assertTrue(a.isVoice); assertEquals(4200L, a.durationMs)
        val (conv, name, body) = api.lastUpload!!
        assertEquals("c1", conv); assertEquals("voice.m4a", name)
        assertEquals("audio/mp4", body.contentType().toString()); assertEquals(4L, body.contentLength())
    }

    @Test fun uploadErrorsKeepServerCodes() = runTest {
        api.upload = { app.winkwink.errorResponse(415, """{"error":{"code":"unsupported_media_type","message":"x"}}""") }
        val f = PreparedFile(byteArrayOf(1), "application/pdf", "a.pdf", "document")
        assertEquals("unsupported_media_type", (repo.uploadAttachment("c1", f).exceptionOrNull() as ApiFailure).code)
        api.upload = { app.winkwink.errorResponse(429, """{"error":{"code":"upload_rate_limited","message":"x"}}""") }
        assertEquals("upload_rate_limited", (repo.uploadAttachment("c1", f).exceptionOrNull() as ApiFailure).code)
    }

    @Test fun downloadReturnsBytesAndMapsFailures() = runTest {
        assertEquals("hello", String(repo.downloadAttachment("a1").getOrThrow()))
        api.download = { Response.error(404, "".toResponseBody(null)) }
        assertEquals("attachment_not_found", (repo.downloadAttachment("a1").exceptionOrNull() as ApiFailure).code)
        api.downloadThrows = IOException("offline")
        assertEquals("network", (repo.downloadAttachment("a1").exceptionOrNull() as ApiFailure).code)
    }

    @Test fun deleteAttachmentCallsApi() = runTest {
        repo.deleteAttachment("a9")
        assertEquals(listOf("a9"), api.deletedAttachments)
    }
}
