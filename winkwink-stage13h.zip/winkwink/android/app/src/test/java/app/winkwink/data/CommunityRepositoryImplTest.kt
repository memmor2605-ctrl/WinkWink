package app.winkwink.data

import app.winkwink.data.remote.ChannelDto
import app.winkwink.data.remote.ChannelListDto
import app.winkwink.data.remote.CommunityApi
import app.winkwink.data.remote.CommunityDto
import app.winkwink.data.remote.CommunityListDto
import app.winkwink.data.remote.CreateChannelRequestDto
import app.winkwink.data.remote.CreateCommunityRequestDto
import app.winkwink.data.remote.InviteCandidateDto
import app.winkwink.data.remote.InviteCandidateListDto
import app.winkwink.data.remote.InviteRequestDto
import app.winkwink.data.remote.TransferOwnershipRequestDto
import app.winkwink.data.remote.PersonDto
import app.winkwink.data.remote.PersonListDto
import app.winkwink.data.remote.RoleRequestDto
import app.winkwink.data.remote.UpdateCommunityRequestDto
import app.winkwink.data.remote.JoinResponseDto
import app.winkwink.data.remote.PostDto
import app.winkwink.data.remote.PostListDto
import app.winkwink.data.repository.CommunityRepositoryImpl
import app.winkwink.domain.model.ApiFailure
import app.winkwink.errorResponse
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import retrofit2.Response

private fun communityDto(id: String = "c1", status: String = "member", role: String? = "member", createdAt: String = "2026-11-21T10:00:00Z") =
    CommunityDto(id, "Rowery", "Opis", "Zasady", "public", 3, role, status, createdAt)

private class FakeCommunityApi : CommunityApi {
    val calls = mutableListOf<String>()
    var lastCreate: CreateCommunityRequestDto? = null
    var lastUpdate: UpdateCommunityRequestDto? = null
    var lastPosts: Triple<String, String?, String?>? = null
    var lastQuery: String? = null
    var create: () -> Response<CommunityDto> = { Response.success(201, communityDto()) }
    var join: () -> Response<JoinResponseDto> = { Response.success(JoinResponseDto("member")) }
    var mine: () -> Response<CommunityListDto> = { Response.success(CommunityListDto(listOf(communityDto()), "next")) }

    override suspend fun mine(limit: Int, cursor: String?) = mine.invoke()
    override suspend fun invites(limit: Int, cursor: String?): Response<CommunityListDto> = Response.success(CommunityListDto(listOf(communityDto("inv", "invited", null))))
    override suspend fun search(q: String, limit: Int, cursor: String?): Response<CommunityListDto> { lastQuery = q; return Response.success(CommunityListDto(emptyList())) }
    override suspend fun create(body: CreateCommunityRequestDto): Response<CommunityDto> { lastCreate = body; return create.invoke() }
    override suspend fun update(id: String, body: UpdateCommunityRequestDto): Response<CommunityDto> { lastUpdate = body; return Response.success(communityDto(id)) }
    override suspend fun get(id: String): Response<CommunityDto> = Response.success(communityDto(id))
    override suspend fun join(id: String): Response<JoinResponseDto> { calls += "join:$id"; return join.invoke() }
    override suspend fun leave(id: String): Response<Unit> { calls += "leave:$id"; return Response.success(Unit) }
    override suspend fun cancelRequest(id: String): Response<Unit> { calls += "cancel:$id"; return Response.success(Unit) }
    override suspend fun acceptInvite(id: String): Response<Unit> { calls += "accept:$id"; return Response.success(Unit) }
    override suspend fun declineInvite(id: String): Response<Unit> { calls += "decline:$id"; return Response.success(Unit) }
    override suspend fun channels(id: String): Response<ChannelListDto> = Response.success(ChannelListDto(listOf(ChannelDto("ch1", "general"))))
    var members: () -> Response<PersonListDto> = { Response.success(PersonListDto(listOf(PersonDto("u1", "maria", "Maria", "moderator", "2026-11-21T10:00:00Z")), "mc")) }
    override suspend fun members(id: String, limit: Int, cursor: String?): Response<PersonListDto> = members()
    override suspend fun setRole(id: String, user: String, body: RoleRequestDto): Response<Unit> { calls += "role:$user:${body.role}"; return Response.success(Unit) }
    override suspend fun removeMember(id: String, user: String): Response<Unit> { calls += "remove:$user"; return Response.success(Unit) }
    override suspend fun transferOwnership(id: String, body: TransferOwnershipRequestDto): Response<Unit> { calls += "transfer:${body.user}"; return Response.success(Unit) }
    override suspend fun mute(id: String, user: String): Response<Unit> { calls += "mute:$user"; return Response.success(Unit) }
    override suspend fun unmute(id: String, user: String): Response<Unit> { calls += "unmute:$user"; return Response.success(Unit) }
    var lastCandidateQuery: String? = null
    override suspend fun inviteCandidates(id: String, q: String): Response<InviteCandidateListDto> {
        lastCandidateQuery = q
        return Response.success(InviteCandidateListDto(listOf(InviteCandidateDto("olek", "olek", null, true))))
    }
    override suspend fun invite(id: String, body: InviteRequestDto): Response<Unit> { calls += "invite:${body.user}"; return Response.success(Unit) }
    override suspend fun requests(id: String, limit: Int, cursor: String?): Response<PersonListDto> = Response.success(PersonListDto(emptyList()))
    override suspend fun approveRequest(id: String, user: String): Response<Unit> { calls += "approve:$user"; return Response.success(Unit) }
    override suspend fun rejectRequest(id: String, user: String): Response<Unit> { calls += "reject:$user"; return Response.success(Unit) }
    override suspend fun createChannel(id: String, body: CreateChannelRequestDto): Response<ChannelDto> { calls += "channel:${body.name}"; return Response.success(201, ChannelDto("ch9", body.name)) }
    override suspend fun deleteChannel(id: String, channelId: String): Response<Unit> { calls += "delchannel:$channelId"; return Response.success(Unit) }
    override suspend fun delete(id: String): Response<Unit> { calls += "delete:$id"; return Response.success(Unit) }
    override suspend fun posts(id: String, channel: String?, limit: Int, cursor: String?): Response<PostListDto> {
        lastPosts = Triple(id, channel, cursor)
        return Response.success(
            PostListDto(
                listOf(PostDto("p1", null, false, false, "hej", "community", "2026-11-21T10:00:00Z", null, 0, 0, null, false, communityId = id, channelId = "ch1")),
                "pc",
            ),
        )
    }
}

class CommunityRepositoryImplTest {
    private val api = FakeCommunityApi()
    private val repo = CommunityRepositoryImpl(api, Json { ignoreUnknownKeys = true })

    @Test fun mineMapsCommunitiesAndCursor() = runTest {
        val page = repo.mine(null).getOrThrow()
        assertEquals("Rowery", page.communities.single().name)
        assertTrue(page.communities.single().isMember)
        assertEquals("next", page.nextCursor)
    }

    @Test fun createTrimsFieldsAndSendsType() = runTest {
        repo.create("  Rowery  ", " Opis ", " Zasady ", "private").getOrThrow()
        assertEquals(CreateCommunityRequestDto("Rowery", "Opis", "Zasady", "private"), api.lastCreate)
    }

    @Test fun createNameTakenSurfacesBackendCode() = runTest {
        api.create = { errorResponse(409, """{"error":{"code":"community_name_taken","message":"Name taken","requestId":"r"}}""") }
        val e = repo.create("Rowery", "", "", "public").exceptionOrNull() as ApiFailure
        assertEquals("community_name_taken", e.code); assertEquals(409, e.httpStatus)
    }

    @Test fun joinReturnsServerState() = runTest {
        api.join = { Response.success(JoinResponseDto("requested")) }
        assertEquals("requested", repo.join("c1").getOrThrow())
    }

    @Test fun respondToInviteUsesAcceptOrDecline() = runTest {
        repo.respondToInvite("c1", true).getOrThrow(); repo.respondToInvite("c2", false).getOrThrow()
        assertEquals(listOf("accept:c1", "decline:c2"), api.calls)
    }

    @Test fun leaveAndCancelCallTheirEndpoints() = runTest {
        repo.leave("c1").getOrThrow(); repo.cancelRequest("c1").getOrThrow()
        assertEquals(listOf("leave:c1", "cancel:c1"), api.calls)
    }

    @Test fun postsPassChannelAndCursorAndKeepCommunityIds() = runTest {
        val page = repo.posts("c1", "ch1", "cur").getOrThrow()
        assertEquals(Triple("c1", "ch1", "cur"), api.lastPosts)
        assertEquals("ch1", page.posts.single().channelId); assertEquals("c1", page.posts.single().communityId)
        assertEquals("pc", page.nextCursor)
    }

    @Test fun nonMemberGets404AsFailure() = runTest {
        // Backend odpowiada 404 community_not_found także dla ukrytych społeczności.
        val failing = object : CommunityApi by api {
            override suspend fun posts(id: String, channel: String?, limit: Int, cursor: String?): Response<PostListDto> =
                errorResponse(404, """{"error":{"code":"community_not_found","message":"x","requestId":"r"}}""")
        }
        val e = CommunityRepositoryImpl(failing, Json { ignoreUnknownKeys = true }).posts("c1", null, null).exceptionOrNull() as ApiFailure
        assertEquals("community_not_found", e.code)
    }

    @Test fun adminCallsMapToEndpoints() = runTest {
        repo.setRole("c1", "u1", "admin").getOrThrow(); repo.removeMember("c1", "u2").getOrThrow()
        repo.invite("c1", "  maria ").getOrThrow()
        repo.decideRequest("c1", "u3", true).getOrThrow(); repo.decideRequest("c1", "u4", false).getOrThrow()
        assertEquals(listOf("role:u1:admin", "remove:u2", "invite:maria", "approve:u3", "reject:u4"), api.calls)
    }

    @Test fun channelAndCommunityAdmin() = runTest {
        assertEquals("ogólny", repo.createChannel("c1", "  ogólny ").getOrThrow().name)
        repo.deleteChannel("c1", "ch1").getOrThrow(); repo.delete("c1").getOrThrow()
        assertEquals(listOf("channel:ogólny", "delchannel:ch1", "delete:c1"), api.calls)
    }

    @Test fun membersMapRoleAndCursor() = runTest {
        val page = repo.members("c1", null).getOrThrow()
        assertEquals("moderator", page.people.single().role); assertEquals("mc", page.nextCursor)
    }

    @Test fun updateSendsOnlyGivenFieldsTrimmed() = runTest {
        repo.update("c1", "  Nowa nazwa ", null, null, null).getOrThrow()
        assertEquals(UpdateCommunityRequestDto(name = "Nowa nazwa"), api.lastUpdate)
    }

    @Test fun searchTrimsQuery() = runTest {
        repo.search("  row ", null).getOrThrow()
        assertEquals("row", api.lastQuery)
    }

    @Test fun badDateBecomesInvalidResponse() = runTest {
        api.mine = { Response.success(CommunityListDto(listOf(communityDto(createdAt = "nie-data")))) }
        val e = repo.mine(null).exceptionOrNull() as ApiFailure
        assertEquals("invalid_response", e.code)
        assertFalse(repo.mine(null).isSuccess); assertNull(repo.mine(null).getOrNull())
    }

    @Test fun transferMuteAndCandidatesGoToTheRightEndpoints() = runTest {
        repo.transferOwnership("c1", "maria").getOrThrow()
        repo.setMuted("c1", "maria", true).getOrThrow()
        repo.setMuted("c1", "maria", false).getOrThrow()
        assertEquals(listOf("transfer:maria", "mute:maria", "unmute:maria"), api.calls.takeLast(3))
        val found = repo.inviteCandidates("c1", " @ol ").getOrThrow()
        assertEquals("ol", api.lastCandidateQuery)
        assertEquals("olek", found.single().winkwinkId); assertTrue(found.single().invited)
    }

    @Test fun personMutedFlagIsMapped() = runTest {
        api.members = { Response.success(PersonListDto(listOf(PersonDto("a", "a", null, "member", "2026-11-21T10:00:00Z", true)), null)) }
        assertTrue(repo.members("c1", null).getOrThrow().people.single().muted)
    }
}
