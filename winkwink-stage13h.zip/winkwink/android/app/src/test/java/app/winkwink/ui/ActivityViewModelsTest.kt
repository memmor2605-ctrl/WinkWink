package app.winkwink.ui

import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.AppNotification
import app.winkwink.domain.model.NotificationActor
import app.winkwink.domain.model.NotificationPage
import app.winkwink.domain.repository.NotificationRepository
import app.winkwink.ui.activity.ActivityViewModel
import app.winkwink.ui.activity.NotificationSettingsViewModel
import app.winkwink.ui.activity.UnreadBadgeViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.time.Instant

private val T1 = Instant.parse("2026-11-22T10:00:00Z")
private fun notif(id: String, type: String = "reaction", read: Boolean = false) =
    AppNotification(id, type, NotificationActor("ww_x", "bobby", null, false), "p1", null, null, T1, read)

private class FakeNotifications : NotificationRepository {
    val listCalls = mutableListOf<Triple<String?, Boolean, String?>>()
    var pages: (String?, Boolean, String?) -> Result<NotificationPage> = { _, _, cursor ->
        if (cursor == null) Result.success(NotificationPage(listOf(notif("a"), notif("b", read = true)), "c2", 1))
        else Result.success(NotificationPage(listOf(notif("b", read = true), notif("c")), null, 2))
    }
    var markReadResult: Result<Unit> = Result.success(Unit)
    val markReadIds = mutableListOf<String>()
    val markAllTypes = mutableListOf<String?>()
    var markAllResult: Result<Unit> = Result.success(Unit)
    var unread: Result<Int> = Result.success(5)
    var settingsResult: Result<Map<String, Boolean>> = Result.success(mapOf("reaction" to true, "comment" to true))
    var updateResult: ((Map<String, Boolean>) -> Result<Map<String, Boolean>>) = { c -> Result.success(mapOf("reaction" to true, "comment" to true) + c) }

    override suspend fun list(type: String?, unreadOnly: Boolean, cursor: String?): Result<NotificationPage> {
        listCalls += Triple(type, unreadOnly, cursor); return pages(type, unreadOnly, cursor)
    }
    override suspend fun unreadCount() = unread
    override suspend fun markRead(id: String): Result<Unit> { markReadIds += id; return markReadResult }
    override suspend fun markAllRead(type: String?): Result<Unit> { markAllTypes += type; return markAllResult }
    override suspend fun settings() = settingsResult
    override suspend fun updateSettings(changes: Map<String, Boolean>) = updateResult(changes)
}

@OptIn(ExperimentalCoroutinesApi::class)
class ActivityViewModelsTest {
    private val repo = FakeNotifications()

    @Before fun setUp() { Dispatchers.setMain(UnconfinedTestDispatcher()) }
    @After fun tearDown() { Dispatchers.resetMain() }

    @Test fun initLoadsFirstPageAndUnreadCount() {
        val vm = ActivityViewModel(repo)
        val s = vm.state.value
        assertEquals(listOf("a", "b"), s.items.map { it.id })
        assertEquals("c2", s.cursor)
        assertEquals(1, s.unreadCount)
        assertTrue(s.loaded); assertFalse(s.loading)
    }

    @Test fun loadMoreAppendsWithoutDuplicates() {
        val vm = ActivityViewModel(repo)
        vm.loadMore()
        assertEquals(listOf("a", "b", "c"), vm.state.value.items.map { it.id })
        assertNull(vm.state.value.cursor)
        vm.loadMore()
        assertEquals(2, repo.listCalls.size)
    }

    @Test fun failureKeepsListAndExposesError() {
        val vm = ActivityViewModel(repo)
        repo.pages = { _, _, _ -> Result.failure(ApiFailure("network", "x")) }
        vm.refresh()
        assertEquals("network", vm.state.value.failure?.code)
        assertEquals(2, vm.state.value.items.size)
        assertFalse(vm.state.value.loading)
    }

    @Test fun filterByTypeReloadsFromTheServer() {
        val vm = ActivityViewModel(repo)
        vm.setType("comment")
        assertEquals(Triple<String?, Boolean, String?>("comment", false, null), repo.listCalls.last())
        vm.setUnreadOnly()
        assertEquals(Triple<String?, Boolean, String?>(null, true, null), repo.listCalls.last())
        vm.setType(null)
        assertEquals(Triple<String?, Boolean, String?>(null, false, null), repo.listCalls.last())
    }

    @Test fun markReadUpdatesItemAndCounterOnlyAfterServerConfirms() {
        val vm = ActivityViewModel(repo)
        vm.markRead(vm.state.value.items.first())
        assertTrue(vm.state.value.items.first { it.id == "a" }.read)
        assertEquals(0, vm.state.value.unreadCount)
    }

    @Test fun markReadFailureLeavesNotificationUnread() {
        val vm = ActivityViewModel(repo)
        repo.markReadResult = Result.failure(ApiFailure("notification_not_found", "x", httpStatus = 404))
        vm.markRead(vm.state.value.items.first())
        assertFalse(vm.state.value.items.first { it.id == "a" }.read)
        assertEquals(1, vm.state.value.unreadCount)
        assertEquals("notification_not_found", vm.state.value.actionFailure?.code)
    }

    @Test fun markReadSkipsAlreadyReadItems() {
        val vm = ActivityViewModel(repo)
        vm.markRead(vm.state.value.items.first { it.read })
        assertTrue(repo.markReadIds.isEmpty())
    }

    @Test fun markAllReadRespectsActiveTypeFilterAndRefreshes() {
        val vm = ActivityViewModel(repo)
        vm.setType("reply")
        val before = repo.listCalls.size
        vm.markAllRead()
        assertEquals(listOf<String?>("reply"), repo.markAllTypes)
        assertEquals(before + 1, repo.listCalls.size)
    }

    @Test fun markAllReadFailureDoesNotRefresh() {
        val vm = ActivityViewModel(repo)
        repo.markAllResult = Result.failure(ApiFailure("timeout", "x"))
        val before = repo.listCalls.size
        vm.markAllRead()
        assertEquals(before, repo.listCalls.size)
        assertNotNull(vm.state.value.actionFailure)
    }

    @Test fun badgeShowsServerCountAndIgnoresErrors() {
        val vm = UnreadBadgeViewModel(repo)
        vm.refresh()
        assertEquals(5, vm.count.value)
        repo.unread = Result.failure(ApiFailure("network", "x"))
        vm.refresh()
        assertEquals(5, vm.count.value)
    }

    @Test fun settingsLoadAndToggleUseServerState() {
        val vm = NotificationSettingsViewModel(repo)
        assertEquals(true, vm.state.value.types["reaction"])
        vm.toggle("reaction", false)
        assertEquals(false, vm.state.value.types["reaction"])
        assertTrue(vm.state.value.saving.isEmpty())
    }

    @Test fun settingsToggleFailureKeepsPreviousValue() {
        val vm = NotificationSettingsViewModel(repo)
        repo.updateResult = { Result.failure(ApiFailure("network", "x")) }
        vm.toggle("reaction", false)
        assertEquals(true, vm.state.value.types["reaction"])
        assertEquals("network", vm.state.value.failure?.code)
        assertTrue(vm.state.value.saving.isEmpty())
    }

    @Test fun settingsLoadFailureIsReportedAndRetryable() {
        repo.settingsResult = Result.failure(ApiFailure("network", "x"))
        val vm = NotificationSettingsViewModel(repo)
        assertEquals("network", vm.state.value.failure?.code)
        repo.settingsResult = Result.success(mapOf("reaction" to false))
        vm.load()
        assertEquals(false, vm.state.value.types["reaction"])
        assertNull(vm.state.value.failure)
    }
}
