package app.winkwink

import app.winkwink.data.remote.AccountApi
import app.winkwink.data.remote.AuthResponseDto
import app.winkwink.data.remote.ChangePasswordRequestDto
import app.winkwink.data.remote.ForgotPasswordRequestDto
import app.winkwink.data.remote.LoginRequestDto
import app.winkwink.data.remote.MeDto
import app.winkwink.data.remote.PublicAuthApi
import app.winkwink.data.remote.RefreshRequestDto
import app.winkwink.data.remote.RegisterRequestDto
import app.winkwink.data.remote.ResetPasswordRequestDto
import app.winkwink.data.remote.RevokedDto
import app.winkwink.data.remote.SessionsResponseDto
import app.winkwink.data.remote.TokensDto
import app.winkwink.domain.model.StoredSession
import app.winkwink.domain.repository.SessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.ResponseBody.Companion.toResponseBody
import retrofit2.Response
import java.io.IOException

class FakeSessionStore(initial: StoredSession? = null) : SessionStore {
    private val state = MutableStateFlow(initial)
    override val session: StateFlow<StoredSession?> = state
    var clears = 0
    override suspend fun save(session: StoredSession) { state.value = session }
    override suspend fun clear() { clears++; state.value = null }
}

fun <T> errorResponse(code: Int, body: String, retryAfter: String? = null): Response<T> {
    val raw = okhttp3.Response.Builder()
        .code(code).message("err").protocol(Protocol.HTTP_1_1)
        .request(Request.Builder().url("https://api.test/").build())
        .apply { retryAfter?.let { header("Retry-After", it) } }
        .build()
    return Response.error(body.toResponseBody("application/json".toMediaType()), raw)
}

fun tokens(access: String = "a1", refresh: String = "r1") = TokensDto("s1", access, "2026-11-21T12:15:00Z", refresh, "2026-12-21T12:00:00Z")

fun authResponse() = AuthResponseDto(tokens(), MeDto("ala@example.com", app.winkwink.data.remote.ProfileDto("ala", "ww_abcdefghij", null, "public")))

class FakePublicApi : PublicAuthApi {
    var register: () -> Response<AuthResponseDto> = { Response.success(authResponse()) }
    var login: () -> Response<AuthResponseDto> = { Response.success(authResponse()) }
    var refresh: () -> Response<TokensDto> = { Response.success(tokens("a2", "r2")) }
    var refreshCalls = 0
    override suspend fun register(body: RegisterRequestDto) = register()
    override suspend fun login(body: LoginRequestDto) = login()
    override suspend fun refresh(body: RefreshRequestDto): Response<TokensDto> { refreshCalls++; return refresh() }
    override suspend fun forgot(body: ForgotPasswordRequestDto): Response<Unit> = Response.success(Unit)
    override suspend fun reset(body: ResetPasswordRequestDto): Response<Unit> = Response.success(Unit)
}

class FakeAccountApi : AccountApi {
    var logout: () -> Response<Unit> = { Response.success(Unit) }
    var logoutCalls = 0
    override suspend fun logout(): Response<Unit> { logoutCalls++; return logout() }
    override suspend fun deleteAccount(body: app.winkwink.data.remote.DeleteAccountRequestDto): Response<Unit> = Response.success(Unit)
    override suspend fun me(): Response<MeDto> = throw IOException("offline")
    override suspend fun changePassword(body: ChangePasswordRequestDto): Response<Unit> = Response.success(Unit)
    override suspend fun sessions(): Response<SessionsResponseDto> = Response.success(SessionsResponseDto(emptyList()))
    override suspend fun revokeSession(id: String): Response<Unit> = Response.success(Unit)
    override suspend fun revokeOthers(): Response<RevokedDto> = Response.success(RevokedDto(0))
}
