package app.winkwink.ui

import androidx.lifecycle.SavedStateHandle
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.PreparedFile
import app.winkwink.domain.model.Attachment
import app.winkwink.domain.model.Channel
import app.winkwink.domain.model.InviteCandidate
import app.winkwink.domain.model.Comment
import app.winkwink.domain.model.CommentPage
import app.winkwink.domain.model.Community
import app.winkwink.domain.model.CommunityPage
import app.winkwink.domain.model.FeedKind
import app.winkwink.domain.model.Person
import app.winkwink.domain.model.PersonPage
import app.winkwink.domain.model.Post
import app.winkwink.domain.model.PostPage
import app.winkwink.domain.repository.CommunityRepository
import app.winkwink.domain.repository.FeedRepository
import app.winkwink.ui.community.CommunitiesViewModel
import app.winkwink.ui.community.CommunityDetailViewModel
import app.winkwink.ui.community.CreateCommunityViewModel
import app.winkwink.ui.community.ManageCommunityViewModel
import app.winkwink.ui.community.ManageUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.time.Instant

private val T0 = Instant.parse("2026-11-21T10:00:00Z")
private fun community(id: String = "c1", status: String = "member", role: String? = "member") =
    Community(id, "Rowery", "", "", "public", 2, role, status, T0)
private fun post(id: String) = Post(id, null, false, false, "b$id", "community", T0, false, 0, 0, null, false, "c1", "ch1")

private class FakeCommunities : CommunityRepository {
    var current: Community = community()
    var joinResult: Result<String> = Result.success("member")
    var leaveResult: Result<Unit> = Result.success(Unit)
    var createResult: Result<Community> = Result.success(community("new"))
    var mineResult: Result<CommunityPage> = Result.success(CommunityPage(listOf(community()), null))
    var invitesResult: Result<CommunityPage> = Result.success(CommunityPage(emptyList(), null))
    var postsByChannel: MutableMap<String?, Result<PostPage>> = mutableMapOf(null to Result.success(PostPage(listOf(post("p1")), null)))
    val postCalls = mutableListOf<Pair<String?, String?>>()
    val invitesAnswered = mutableListOf<Pair<String, Boolean>>()
    var createArgs: List<String>? = null

    override suspend fun mine(cursor: String?) = mineResult
    override suspend fun invites(cursor: String?) = invitesResult
    override suspend fun search(query: String, cursor: String?) = Result.success(CommunityPage(emptyList(), null))
    override suspend fun create(name: String, description: String, rules: String, type: String): Result<Community> { createArgs = listOf(name, description, rules, type); return createResult }
    var updateArgs: List<String?>? = null
    var updateResult: Result<Community>? = null
    override suspend fun update(id: String, name: String?, description: String?, rules: String?, type: String?): Result<Community> {
        updateArgs = listOf(name, description, rules, type)
        return updateResult ?: Result.success(current.copy(name = name ?: current.name, description = description ?: current.description, rules = rules ?: current.rules, type = type ?: current.type))
    }
    override suspend fun get(id: String) = Result.success(current)
    override suspend fun join(id: String): Result<String> {
        joinResult.onSuccess { current = current.copy(myStatus = if (it == "member") "member" else "requested", myRole = if (it == "member") "member" else null) }
        return joinResult
    }
    override suspend fun leave(id: String) = leaveResult
    override suspend fun cancelRequest(id: String) = Result.success(Unit)
    override suspend fun respondToInvite(id: String, accept: Boolean): Result<Unit> { invitesAnswered += id to accept; return Result.success(Unit) }
    override suspend fun channels(id: String) = Result.success(listOf(Channel("ch1", "general"), Channel("ch2", "offtopic")))
    val admin = mutableListOf<String>()
    var members: List<Person> = emptyList()
    var requests: List<Person> = emptyList()
    var adminResult: Result<Unit> = Result.success(Unit)
    override suspend fun members(id: String, cursor: String?) = Result.success(PersonPage(members, null))
    override suspend fun setRole(id: String, userId: String, role: String): Result<Unit> { admin += "role:$userId:$role"; return adminResult }
    override suspend fun removeMember(id: String, userId: String): Result<Unit> { admin += "remove:$userId"; return adminResult }
    override suspend fun invite(id: String, userId: String): Result<Unit> { admin += "invite:$userId"; return adminResult }
    var candidates: Result<List<InviteCandidate>> = Result.success(emptyList())
    val candidateQueries = mutableListOf<String>()
    override suspend fun inviteCandidates(id: String, query: String): Result<List<InviteCandidate>> { candidateQueries += query; return candidates }
    override suspend fun transferOwnership(id: String, userId: String): Result<Unit> { admin += "transfer:$userId"; return adminResult }
    override suspend fun setMuted(id: String, userId: String, muted: Boolean): Result<Unit> { admin += "${if (muted) "mute" else "unmute"}:$userId"; return adminResult }
    override suspend fun requests(id: String, cursor: String?) = Result.success(PersonPage(requests, null))
    override suspend fun decideRequest(id: String, userId: String, approve: Boolean): Result<Unit> { admin += "${if (approve) "approve" else "reject"}:$userId"; return adminResult }
    override suspend fun createChannel(id: String, name: String): Result<Channel> { admin += "channel:$name"; return adminResult.map { Channel("new", name) } }
    override suspend fun deleteChannel(id: String, channelId: String): Result<Unit> { admin += "delchannel:$channelId"; return adminResult }
    override suspend fun delete(id: String): Result<Unit> { admin += "delete"; return adminResult }
    override suspend fun posts(id: String, channelId: String?, cursor: String?): Result<PostPage> {
        postCalls += channelId to cursor
        return postsByChannel[channelId] ?: Result.success(PostPage(emptyList(), null))
    }
}

private class StubFeed : FeedRepository {
    var lastCommunityPost: Triple<String, String, String>? = null
    var communityPostResult: Result<Post> = Result.success(post("new"))
    override suspend fun createCommunityPost(body: String, communityId: String, channelId: String, attachmentIds: List<String>): Result<Post> {
        lastCommunityPost = Triple(body, communityId, channelId); return communityPostResult
    }
    override suspend fun feed(kind: FeedKind, cursor: String?) = Result.success(PostPage(emptyList(), null))
    override suspend fun saved(cursor: String?) = Result.success(PostPage(emptyList(), null))
    override suspend fun post(id: String) = Result.success(post(id))
    override suspend fun createPost(body: String, visibility: String, anonymous: Boolean, attachmentIds: List<String>) = Result.success(post("x"))
    override suspend fun updatePost(id: String, body: String) = Result.success(post(id))
    val deletedPosts = mutableListOf<String>()
    var deleteResult: Result<Unit> = Result.success(Unit)
    override suspend fun deletePost(id: String): Result<Unit> { deletedPosts += id; return deleteResult }
    override suspend fun react(id: String, type: String) = Result.success(post(id).copy(myReaction = type))
    override suspend fun unreact(id: String) = Result.success(post(id))
    override suspend fun setSaved(id: String, saved: Boolean) = Result.success(Unit)
    override suspend fun comments(postId: String, parentId: String?, cursor: String?) = Result.success(CommentPage(emptyList<Comment>(), null))
    override suspend fun addComment(postId: String, parentId: String?, body: String): Result<Comment> = Result.failure(ApiFailure("x", "x"))
    override suspend fun search(query: String, cursor: String?): Result<PostPage> = error("unused")
    override suspend fun share(id: String, comment: String, visibility: String): Result<Post> = error("unused")
    override suspend fun uploadAttachment(file: PreparedFile): Result<Attachment> = error("unused")
    override suspend fun deleteAttachment(id: String): Result<Unit> = error("unused")
    override suspend fun downloadAttachment(id: String): Result<ByteArray> = error("unused")
    override suspend fun deleteComment(id: String) = Result.success(Unit)
}

@OptIn(ExperimentalCoroutinesApi::class)
class CommunityViewModelsTest {
    private val repo = FakeCommunities()
    private val feed = StubFeed()

    @Before fun setUp() { Dispatchers.setMain(UnconfinedTestDispatcher()) }
    @After fun tearDown() { Dispatchers.resetMain() }

    private fun detail() = CommunityDetailViewModel(repo, feed, SavedStateHandle(mapOf("id" to "c1")))

    @Test fun memberLoadsChannelsAndPosts() {
        val s = detail().state.value
        assertEquals(listOf("ch1", "ch2"), s.channels.map { it.id })
        assertEquals(listOf("p1"), s.posts.map { it.id })
        assertTrue(s.postsLoaded)
    }

    @Test fun nonMemberDoesNotRequestPosts() {
        repo.current = community(status = "none", role = null)
        val s = detail().state.value
        assertTrue(repo.postCalls.isEmpty())
        assertTrue(s.posts.isEmpty())
    }

    @Test fun joiningReloadsStateAndPostsFromServer() {
        repo.current = community(status = "none", role = null)
        val vm = detail()
        vm.join()
        assertTrue(vm.state.value.community!!.isMember)
        assertEquals(1, repo.postCalls.size)
    }

    @Test fun privateCommunityJoinShowsRequestedWithoutPosts() {
        repo.current = community(status = "none", role = null)
        repo.joinResult = Result.success("requested")
        val vm = detail()
        vm.join()
        assertEquals("requested", vm.state.value.community!!.myStatus)
        assertTrue(repo.postCalls.isEmpty())
    }

    @Test fun joinFailureKeepsStateAndReportsError() {
        repo.current = community(status = "none", role = null)
        repo.joinResult = Result.failure(ApiFailure("community_not_found", "x", httpStatus = 404))
        val vm = detail()
        vm.join()
        assertEquals("community_not_found", vm.state.value.actionFailure?.code)
        assertFalse(vm.state.value.community!!.isMember)
        assertFalse(vm.state.value.busy)
    }

    @Test fun selectingChannelReloadsPostsForThatChannel() {
        repo.postsByChannel["ch2"] = Result.success(PostPage(listOf(post("o1")), null))
        val vm = detail()
        vm.selectChannel("ch2")
        assertEquals(listOf("o1"), vm.state.value.posts.map { it.id })
        assertEquals("ch2", repo.postCalls.last().first)
    }

    @Test fun loadMoreAppendsWithoutDuplicates() {
        repo.postsByChannel[null] = Result.success(PostPage(listOf(post("p1")), "n1"))
        val vm = detail()
        repo.postsByChannel[null] = Result.success(PostPage(listOf(post("p1"), post("p2")), null))
        vm.loadPosts()
        assertEquals(listOf("p1", "p2"), vm.state.value.posts.map { it.id })
        assertNull(vm.state.value.postsCursor)
    }

    @Test fun publishUsesSelectedChannelAndRefreshesList() {
        val vm = detail()
        vm.selectChannel("ch2")
        vm.startCompose(); vm.onDraft("  nowy post  ")
        vm.publish()
        assertEquals(Triple("  nowy post  ", "c1", "ch2"), feed.lastCommunityPost)
        assertFalse(vm.state.value.composing); assertEquals("", vm.state.value.draft)
    }

    @Test fun publishDefaultsToFirstChannelAndRejectsBlankDraft() {
        val vm = detail()
        vm.onDraft("   "); vm.publish()
        assertNull(feed.lastCommunityPost)
        vm.onDraft("ok"); vm.publish()
        assertEquals("ch1", feed.lastCommunityPost?.third)
    }

    @Test fun publishFailureKeepsDraftAndComposer() {
        feed.communityPostResult = Result.failure(ApiFailure("community_not_found", "x", httpStatus = 404))
        val vm = detail()
        vm.startCompose(); vm.onDraft("tekst"); vm.publish()
        assertTrue(vm.state.value.composing); assertEquals("tekst", vm.state.value.draft)
        assertNotNull(vm.state.value.actionFailure)
    }

    @Test fun confirmedLeaveSetsLeftOnlyOnSuccess() {
        val vm = detail()
        repo.leaveResult = Result.failure(ApiFailure("owner_cannot_leave", "x", httpStatus = 409))
        vm.confirmLeave()
        assertFalse(vm.state.value.left); assertEquals("owner_cannot_leave", vm.state.value.actionFailure?.code)
        repo.leaveResult = Result.success(Unit)
        vm.confirmLeave()
        assertTrue(vm.state.value.left)
    }

    @Test fun createValidatesBeforeCallingBackend() {
        val vm = CreateCommunityViewModel(repo)
        vm.onName("ab"); vm.submit()
        assertNull(repo.createArgs)
        vm.onName("Rowery"); vm.onType("private"); vm.submit()
        assertEquals(listOf("Rowery", "", "", "private"), repo.createArgs)
        assertEquals("new", vm.state.value.createdId)
    }

    @Test fun createFailureIsShownAndNotNavigated() {
        repo.createResult = Result.failure(ApiFailure("community_name_taken", "x", httpStatus = 409))
        val vm = CreateCommunityViewModel(repo)
        vm.onName("Rowery"); vm.submit()
        assertNull(vm.state.value.createdId)
        assertEquals("community_name_taken", vm.state.value.failure?.code)
    }

    @Test fun listLoadsMineAndInvitesAndAnswersInvites() {
        repo.invitesResult = Result.success(CommunityPage(listOf(community("inv", "invited", null)), null))
        val vm = CommunitiesViewModel(repo)
        assertEquals(listOf("c1"), vm.state.value.mine.map { it.id })
        assertEquals(listOf("inv"), vm.state.value.invites.map { it.id })
        vm.respond(vm.state.value.invites.single(), true)
        assertEquals(listOf("inv" to true), repo.invitesAnswered)
    }

    @Test fun listFailureIsReportedAndNotMarkedLoaded() {
        repo.mineResult = Result.failure(ApiFailure("network", "x"))
        val vm = CommunitiesViewModel(repo)
        assertFalse(vm.state.value.loaded); assertEquals("network", vm.state.value.failure?.code)
    }

    // ---------- Zarządzanie ----------

    private fun person(id: String, role: String? = "member") = Person(id, "nick$id", null, role, T0)
    private fun manage(myRole: String? = "owner"): ManageCommunityViewModel {
        repo.current = community(role = myRole)
        repo.members = listOf(person("owner1", "owner"), person("mod1", "moderator"), person("m1"))
        return ManageCommunityViewModel(repo, SavedStateHandle(mapOf("id" to "c1")))
    }

    @Test fun plainMemberCannotOpenManagement() {
        val vm = manage("member")
        assertEquals(403, vm.state.value.failure?.httpStatus)
        assertTrue(vm.state.value.members.isEmpty())
    }

    @Test fun moderatorLoadsMembersAndRequestsButCannotManageChannels() {
        repo.requests = listOf(person("r1", null))
        val vm = manage("moderator")
        assertEquals(3, vm.state.value.members.size); assertEquals(1, vm.state.value.requests.size)
        assertTrue(vm.state.value.canModerate); assertFalse(vm.state.value.canManageChannels); assertFalse(vm.state.value.isOwner)
    }

    @Test fun removeOnlyLowerRanks() {
        val vm = manage("moderator")
        vm.remove(person("mod1", "moderator")); vm.remove(person("owner1", "owner"))
        assertTrue(repo.admin.isEmpty())
        vm.remove(person("m1"))
        assertEquals(listOf("remove:m1"), repo.admin)
    }

    @Test fun decidingRequestsReloads() {
        repo.requests = listOf(person("r1", null))
        val vm = manage("admin")
        repo.requests = emptyList()
        vm.decide(person("r1", null), true)
        assertEquals(listOf("approve:r1"), repo.admin)
        assertTrue(vm.state.value.requests.isEmpty())
    }

    @Test fun inviteTrimsAtSignAndClearsDraftOnSuccess() {
        val vm = manage("moderator")
        vm.onInviteDraft("  @maria "); vm.invite()
        assertEquals(listOf("invite:maria"), repo.admin)
        assertEquals("", vm.state.value.inviteDraft); assertEquals(ManageUiState.Notice.InviteSent, vm.state.value.notice)
    }

    @Test fun inviteFailureKeepsDraftAndShowsError() {
        val vm = manage("moderator")
        repo.adminResult = Result.failure(ApiFailure("user_not_found", "x", httpStatus = 404))
        vm.onInviteDraft("nikt"); vm.invite()
        assertEquals("nikt", vm.state.value.inviteDraft); assertEquals("user_not_found", vm.state.value.failure?.code)
        assertNull(vm.state.value.notice)
    }

    @Test fun addChannelIgnoresBlankAndClearsDraft() {
        val vm = manage("admin")
        vm.onChannelDraft("   "); vm.addChannel()
        assertTrue(repo.admin.isEmpty())
        vm.onChannelDraft(" ogólny "); vm.addChannel()
        assertEquals(listOf("channel:ogólny"), repo.admin); assertEquals("", vm.state.value.channelDraft)
    }

    @Test fun onlyOwnerCanDeleteCommunity() {
        manage("admin").deleteCommunity()
        assertTrue(repo.admin.isEmpty())
        val vm = manage("owner")
        vm.deleteCommunity()
        assertEquals(listOf("delete"), repo.admin); assertTrue(vm.state.value.deleted)
    }

    @Test fun failedDeleteDoesNotLeaveScreen() {
        val vm = manage("owner")
        repo.adminResult = Result.failure(ApiFailure("network", "x"))
        vm.deleteCommunity()
        assertFalse(vm.state.value.deleted); assertEquals("network", vm.state.value.failure?.code)
    }

    @Test fun roleChangeGoesToBackend() {
        val vm = manage("owner")
        vm.setRole(person("m1"), "moderator")
        assertEquals(listOf("role:m1:moderator"), repo.admin)
    }

    // ---------- Edycja i moderacja postów ----------

    @Test fun adminEditSendsOnlyChangedFieldsAndNeverType() {
        val vm = manage("admin")
        vm.onEditName("  Nowa nazwa "); vm.onEditType("private")
        vm.saveEdit()
        assertEquals(listOf("Nowa nazwa", null, null, null), repo.updateArgs)
        assertTrue(vm.state.value.saved); assertEquals("Nowa nazwa", vm.state.value.editName)
    }

    @Test fun ownerMayChangeType() {
        val vm = manage("owner")
        vm.onEditType("invite"); vm.saveEdit()
        assertEquals(listOf(null, null, null, "invite"), repo.updateArgs)
    }

    @Test fun invalidOrUnchangedEditIsNotSent() {
        val vm = manage("owner")
        vm.saveEdit()
        assertNull(repo.updateArgs)
        vm.onEditName("ab"); vm.saveEdit()
        assertNull(repo.updateArgs)
    }

    @Test fun moderatorCannotEdit() {
        val vm = manage("moderator")
        vm.onEditName("Inna nazwa"); vm.saveEdit()
        assertNull(repo.updateArgs)
    }

    @Test fun editFailureKeepsDraft() {
        val vm = manage("admin")
        repo.updateResult = Result.failure(ApiFailure("community_name_taken", "x", httpStatus = 409))
        vm.onEditName("Zajęta"); vm.saveEdit()
        assertEquals("Zajęta", vm.state.value.editName); assertFalse(vm.state.value.saved)
        assertEquals("community_name_taken", vm.state.value.failure?.code)
    }

    @Test fun moderatorRemovesOthersPostFromList() {
        repo.current = community(role = "moderator")
        val vm = detail()
        vm.moderatorDelete(vm.state.value.posts.single())
        assertEquals(listOf("p1"), feed.deletedPosts); assertTrue(vm.state.value.posts.isEmpty())
    }

    @Test fun plainMemberAndOwnPostsAreNeverModeratorDeleted() {
        val vm = detail()
        vm.moderatorDelete(vm.state.value.posts.single())
        assertTrue(feed.deletedPosts.isEmpty())
        repo.current = community(role = "moderator")
        val mod = detail()
        mod.moderatorDelete(mod.state.value.posts.single().copy(mine = true))
        assertTrue(feed.deletedPosts.isEmpty())
    }

    @Test fun failedModeratorDeleteKeepsPostAndReportsError() {
        repo.current = community(role = "admin")
        feed.deleteResult = Result.failure(ApiFailure("forbidden", "x", httpStatus = 403))
        val vm = detail()
        vm.moderatorDelete(vm.state.value.posts.single())
        assertEquals(1, vm.state.value.posts.size); assertEquals("forbidden", vm.state.value.actionFailure?.code)
    }

    private fun pers(nick: String, role: String, muted: Boolean = false) = Person(nick, nick, null, role, T0, muted)

    @Test fun ownerTransfersOwnershipAndReloads() {
        val vm = manage("owner")
        repo.members = listOf(pers("maria", "member"))
        vm.transferOwnership(pers("maria", "member"))
        assertEquals(listOf("transfer:maria"), repo.admin)
    }

    @Test fun nonOwnerAndSelfRoleTransferNeverReachBackend() {
        val vm = manage("admin")
        vm.transferOwnership(pers("maria", "member"))
        assertTrue(repo.admin.isEmpty())
        val owner = manage("owner")
        owner.transferOwnership(pers("me", "owner"))
        assertTrue(repo.admin.isEmpty())
    }

    @Test fun transferFailureIsShown() {
        repo.adminResult = Result.failure(ApiFailure("forbidden", "x", httpStatus = 403))
        val vm = manage("owner")
        vm.transferOwnership(pers("maria", "member"))
        assertEquals("forbidden", vm.state.value.failure?.code)
    }

    @Test fun moderatorMutesOnlyLowerRanks() {
        val vm = manage("moderator")
        vm.setMuted(pers("maria", "member"), true)
        vm.setMuted(pers("adam", "admin"), true)
        vm.setMuted(pers("moda", "moderator"), true)
        assertEquals(listOf("mute:maria"), repo.admin)
        vm.setMuted(pers("maria", "member", muted = true), false)
        assertEquals(listOf("mute:maria", "unmute:maria"), repo.admin)
    }

    @Test fun candidateSearchUsesTrimmedQueryAndMarksInvited() {
        repo.candidates = Result.success(listOf(InviteCandidate("olek", "olek", null, false), InviteCandidate("ola", "ola", null, true)))
        val vm = manage("moderator")
        vm.onInviteDraft(" @ol ")
        vm.searchNow()
        assertEquals(listOf("ol"), repo.candidateQueries)
        assertEquals(2, vm.state.value.candidates.size); assertTrue(vm.state.value.candidatesSearched)
        vm.inviteCandidate(vm.state.value.candidates[1]) // już zaproszona — bez wywołania
        assertTrue(repo.admin.none { it.startsWith("invite:") })
        vm.inviteCandidate(vm.state.value.candidates[0])
        assertEquals(listOf("invite:olek"), repo.admin.filter { it.startsWith("invite:") })
        assertTrue(vm.state.value.candidates.all { it.invited })
    }

    @Test fun shortCandidateQueryDoesNotSearchAndFailureIsShown() {
        val vm = manage("moderator")
        vm.onInviteDraft("o"); vm.searchNow()
        assertTrue(repo.candidateQueries.isEmpty())
        repo.candidates = Result.failure(ApiFailure("network", "x"))
        vm.onInviteDraft("olek"); vm.searchNow()
        assertEquals("network", vm.state.value.candidatesFailure?.code)
        assertFalse(vm.state.value.candidatesLoading)
    }
}
