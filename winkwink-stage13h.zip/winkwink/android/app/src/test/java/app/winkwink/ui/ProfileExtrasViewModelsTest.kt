package app.winkwink.ui

import androidx.lifecycle.SavedStateHandle
import app.winkwink.domain.media.ImageKind
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.PreparedFile
import app.winkwink.domain.model.Attachment
import app.winkwink.domain.model.Comment
import app.winkwink.domain.model.CommentPage
import app.winkwink.domain.model.FeedKind
import app.winkwink.domain.model.Post
import app.winkwink.domain.model.PostPage
import app.winkwink.domain.model.UserPage
import app.winkwink.domain.model.UserProfile
import app.winkwink.domain.model.UserSummary
import app.winkwink.domain.repository.FeedRepository
import app.winkwink.domain.repository.ProfileExtrasRepository
import app.winkwink.ui.social.MutedUsersViewModel
import app.winkwink.ui.social.ProfilePostsViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.time.Instant

private fun post(id: String, reaction: String? = null, saved: Boolean = false) =
    Post(id, null, false, false, "body $id", "public", Instant.parse("2026-11-21T10:00:00Z"), false, 0, 0, reaction, saved)

private fun user(id: String) = UserSummary(id, "n_$id", null)

private class FakeExtras : ProfileExtrasRepository {
    var mutedPages: (String?) -> Result<UserPage> = { c -> if (c == null) Result.success(UserPage(listOf(user("a"), user("b")), "c2")) else Result.success(UserPage(listOf(user("b"), user("c")), null)) }
    var unmuteResult: Result<Unit> = Result.success(Unit)
    val unmuted = mutableListOf<String>()
    var postPages: (String?) -> Result<PostPage> = { c -> if (c == null) Result.success(PostPage(listOf(post("p1"), post("p2")), "n1")) else Result.success(PostPage(listOf(post("p2"), post("p3")), null)) }
    var lastPostsFor: String? = null

    override suspend fun muted(cursor: String?) = mutedPages(cursor)
    override suspend fun unmute(identifier: String): Result<Unit> { unmuted += identifier; return unmuteResult }
    override suspend fun userPosts(identifier: String, cursor: String?): Result<PostPage> { lastPostsFor = identifier; return postPages(cursor) }
    override suspend fun setImage(kind: ImageKind, uri: String): Result<UserProfile> = error("unused")
    override suspend fun removeImage(kind: ImageKind): Result<UserProfile> = error("unused")
    override suspend fun mute(identifier: String): Result<Unit> = error("unused")
    override suspend fun setHideFollowLists(hide: Boolean): Result<UserProfile> = error("unused")
}

private class FakeFeed : FeedRepository {
    var reactResult: Result<Post> = Result.success(post("p1", "like"))
    var saveResult: Result<Unit> = Result.success(Unit)
    override suspend fun react(id: String, type: String) = reactResult
    override suspend fun unreact(id: String) = Result.success(post(id))
    override suspend fun setSaved(id: String, saved: Boolean) = saveResult
    override suspend fun feed(kind: FeedKind, cursor: String?): Result<PostPage> = error("unused")
    override suspend fun saved(cursor: String?): Result<PostPage> = error("unused")
    override suspend fun post(id: String): Result<Post> = error("unused")
    override suspend fun createPost(body: String, visibility: String, anonymous: Boolean, attachmentIds: List<String>): Result<Post> = error("unused")
    override suspend fun createCommunityPost(body: String, communityId: String, channelId: String, attachmentIds: List<String>): Result<Post> = error("unused")
    override suspend fun updatePost(id: String, body: String): Result<Post> = error("unused")
    override suspend fun deletePost(id: String): Result<Unit> = error("unused")
    override suspend fun comments(postId: String, parentId: String?, cursor: String?): Result<CommentPage> = error("unused")
    override suspend fun addComment(postId: String, parentId: String?, body: String): Result<Comment> = error("unused")
    override suspend fun deleteComment(id: String): Result<Unit> = error("unused")
    override suspend fun search(query: String, cursor: String?): Result<PostPage> = error("unused")
    override suspend fun share(id: String, comment: String, visibility: String): Result<Post> = error("unused")
    override suspend fun uploadAttachment(file: PreparedFile): Result<Attachment> = error("unused")
    override suspend fun deleteAttachment(id: String): Result<Unit> = error("unused")
    override suspend fun downloadAttachment(id: String): Result<ByteArray> = error("unused")
}

@OptIn(ExperimentalCoroutinesApi::class)
class ProfileExtrasViewModelsTest {
    private val extras = FakeExtras()
    private val feed = FakeFeed()

    @Before fun setUp() { Dispatchers.setMain(UnconfinedTestDispatcher()) }
    @After fun tearDown() { Dispatchers.resetMain() }

    private fun posts() = ProfilePostsViewModel(extras, feed, SavedStateHandle(mapOf("id" to "ww_target")))

    @Test fun mutedListLoadsAndPages() {
        val vm = MutedUsersViewModel(extras)
        assertEquals(listOf("a", "b"), vm.state.value.users.map { it.winkwinkId })
        vm.loadMore()
        assertEquals(listOf("a", "b", "c"), vm.state.value.users.map { it.winkwinkId })
        assertNull(vm.state.value.nextCursor)
    }

    @Test fun unmuteRemovesUserOnlyAfterServerConfirms() {
        val vm = MutedUsersViewModel(extras)
        extras.unmuteResult = Result.failure(ApiFailure("network", "x"))
        vm.unmute(user("a"))
        assertEquals(2, vm.state.value.users.size); assertNotNull(vm.state.value.failure); assertNull(vm.state.value.busyId)
        extras.unmuteResult = Result.success(Unit)
        vm.unmute(user("a"))
        assertEquals(listOf("b"), vm.state.value.users.map { it.winkwinkId })
        assertEquals(listOf("a", "a"), extras.unmuted)
    }

    @Test fun postsLoadForTheProfileInNavigationArgument() {
        val vm = posts()
        assertEquals("ww_target", extras.lastPostsFor)
        assertEquals(listOf("p1", "p2"), vm.state.value.posts.map { it.id })
        assertTrue(vm.state.value.loaded)
    }

    @Test fun postsPaginateWithoutDuplicates() {
        val vm = posts()
        vm.loadMore()
        assertEquals(listOf("p1", "p2", "p3"), vm.state.value.posts.map { it.id })
        assertNull(vm.state.value.nextCursor)
        vm.loadMore() // brak kursora: nic się nie dzieje
        assertEquals(3, vm.state.value.posts.size)
    }

    @Test fun emptyProfileIsLoadedNotLoading() {
        extras.postPages = { Result.success(PostPage(emptyList(), null)) }
        val s = posts().state.value
        assertTrue(s.loaded); assertFalse(s.loading); assertTrue(s.posts.isEmpty())
    }

    @Test fun failureKeepsLoadedState() {
        val vm = posts()
        extras.postPages = { Result.failure(ApiFailure("network", "x")) }
        vm.refresh()
        assertEquals(2, vm.state.value.posts.size); assertNotNull(vm.state.value.failure)
    }

    @Test fun reactionAndSaveComeFromServerState() {
        val vm = posts()
        vm.react(vm.state.value.posts.first(), "like")
        assertEquals("like", vm.state.value.posts.first { it.id == "p1" }.myReaction)
        feed.saveResult = Result.failure(ApiFailure("network", "x"))
        vm.toggleSave(vm.state.value.posts.first { it.id == "p2" })
        assertFalse(vm.state.value.posts.first { it.id == "p2" }.saved); assertNotNull(vm.state.value.failure)
        feed.saveResult = Result.success(Unit)
        vm.toggleSave(vm.state.value.posts.first { it.id == "p2" })
        assertTrue(vm.state.value.posts.first { it.id == "p2" }.saved)
    }
}
