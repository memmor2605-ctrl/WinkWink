package app.winkwink

import app.winkwink.domain.validation.CommunityValidation
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CommunityValidationTest {
    @Test fun nameBounds() {
        assertFalse(CommunityValidation.nameValid("ab"))
        assertFalse(CommunityValidation.nameValid("  ab  "))
        assertTrue(CommunityValidation.nameValid("abc"))
        assertTrue(CommunityValidation.nameValid("x".repeat(50)))
        assertFalse(CommunityValidation.nameValid("x".repeat(51)))
    }

    @Test fun optionalFieldsBounds() {
        assertTrue(CommunityValidation.descriptionValid(""))
        assertTrue(CommunityValidation.descriptionValid("x".repeat(500)))
        assertFalse(CommunityValidation.descriptionValid("x".repeat(501)))
        assertTrue(CommunityValidation.rulesValid("x".repeat(2000)))
        assertFalse(CommunityValidation.rulesValid("x".repeat(2001)))
    }
}
