package app.winkwink.data

import app.winkwink.data.remote.FollowDto
import app.winkwink.data.remote.SocialApi
import app.winkwink.data.remote.UpdateProfileRequestDto
import app.winkwink.data.remote.UserListDto
import app.winkwink.data.remote.UserProfileDto
import app.winkwink.data.remote.UserSummaryDto
import app.winkwink.data.repository.SocialRepositoryImpl
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.validation.ProfileValidation
import app.winkwink.errorResponse
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import retrofit2.Response
import java.io.IOException

private class FakeSocialApi : SocialApi {
    var profile: suspend (String) -> Response<UserProfileDto> = { Response.success(dto(it)) }
    var search: suspend (String, Int) -> Response<UserListDto> = { _, _ -> Response.success(UserListDto(emptyList())) }
    var follow: suspend (String) -> Response<FollowDto> = { Response.success(FollowDto("accepted")) }
    var update: suspend (UpdateProfileRequestDto) -> Response<UserProfileDto> = { Response.success(dto("ww_me")) }
    var lastUpdate: UpdateProfileRequestDto? = null
    var lastQuery: String? = null

    override suspend fun profile(id: String) = profile.invoke(id)
    override suspend fun search(q: String, limit: Int): Response<UserListDto> { lastQuery = q; return search.invoke(q, limit) }
    override suspend fun follow(id: String) = follow.invoke(id)
    override suspend fun unfollow(id: String): Response<Unit> = Response.success(Unit)
    override suspend fun block(id: String): Response<Unit> = Response.success(Unit)
    override suspend fun unblock(id: String): Response<Unit> = Response.success(Unit)
    var lists: (String) -> Response<UserListDto> = { Response.success(UserListDto(emptyList())) }
    var lastCursor: String? = null
    var approved: String? = null
    override suspend fun followers(id: String, limit: Int, cursor: String?): Response<UserListDto> { lastCursor = cursor; return lists("followers:$id") }
    override suspend fun following(id: String, limit: Int, cursor: String?): Response<UserListDto> { lastCursor = cursor; return lists("following:$id") }
    override suspend fun followRequests(limit: Int, cursor: String?): Response<UserListDto> { lastCursor = cursor; return lists("requests") }
    override suspend fun approveRequest(id: String): Response<Unit> { approved = id; return Response.success(Unit) }
    override suspend fun rejectRequest(id: String): Response<Unit> = Response.success(Unit)
    override suspend fun blocks(limit: Int, cursor: String?): Response<UserListDto> { lastCursor = cursor; return lists("blocked") }
    override suspend fun updateProfile(body: UpdateProfileRequestDto): Response<UserProfileDto> { lastUpdate = body; return update.invoke(body) }

    companion object {
        fun dto(id: String) = UserProfileDto(winkwinkId = id, nickname = "ola", visibility = "public", links = listOf("https://e.example"), followers = 3, following = 1)
    }
}

class SocialRepositoryImplTest {
    private val api = FakeSocialApi()
    private val repo = SocialRepositoryImpl(api, Json { ignoreUnknownKeys = true })

    @Test fun profileMapsDto() = runTest {
        val p = repo.profile("ww_abcdefghij").getOrThrow()
        assertEquals("ww_abcdefghij", p.winkwinkId)
        assertEquals(listOf("https://e.example"), p.links)
        assertEquals(3, p.followers)
        assertEquals("none", p.followState)
    }

    @Test fun followersPageMapsUsersAndCursor() = runTest {
        api.lists = { Response.success(UserListDto(listOf(UserSummaryDto("ww_a", "ala")), nextCursor = "c2")) }
        val page = repo.followers("ww_me", "c1").getOrThrow()
        assertEquals("c1", api.lastCursor)
        assertEquals(listOf("ww_a"), page.users.map { it.winkwinkId })
        assertEquals("c2", page.nextCursor)
    }

    @Test fun missingNextCursorMeansEndOfList() = runTest {
        assertNull(repo.blocked(null).getOrThrow().nextCursor)
    }

    @Test fun restrictedListIsMappedToApiFailure() = runTest {
        api.lists = { errorResponse(403, """{"error":{"code":"profile_restricted","message":"x"}}""") }
        val e = repo.following("ww_x", null).exceptionOrNull()
        assertTrue(e is ApiFailure); assertEquals("profile_restricted", (e as ApiFailure).code)
    }

    @Test fun approveCallsApiWithIdentifier() = runTest {
        assertTrue(repo.approveRequest("ww_req").isSuccess)
        assertEquals("ww_req", api.approved)
    }

    @Test fun restrictedProfileHasNullCountersAndEmptyLinks() = runTest {
        api.profile = { Response.success(UserProfileDto(winkwinkId = it, nickname = "pat", visibility = "private", restricted = true)) }
        val p = repo.profile("pat").getOrThrow()
        assertTrue(p.restricted); assertNull(p.followers); assertTrue(p.links.isEmpty())
    }

    @Test fun notFoundExposesBackendCode() = runTest {
        api.profile = { errorResponse(404, """{"error":{"code":"user_not_found","message":"x"}}""") }
        val f = repo.profile("nobody").exceptionOrNull() as ApiFailure
        assertEquals("user_not_found", f.code); assertEquals(404, f.httpStatus)
    }

    @Test fun networkErrorBecomesFailure() = runTest {
        api.follow = { throw IOException("offline") }
        assertEquals("network", (repo.follow("x").exceptionOrNull() as ApiFailure).code)
    }

    @Test fun followReturnsServerState() = runTest {
        api.follow = { Response.success(FollowDto("pending")) }
        assertEquals("pending", repo.follow("pat").getOrThrow())
    }

    @Test fun searchTrimsQueryAndMapsResults() = runTest {
        api.search = { _, _ -> Response.success(UserListDto(listOf(UserSummaryDto("ww_a", "ala")))) }
        val r = repo.search("  al ").getOrThrow()
        assertEquals("al", api.lastQuery); assertEquals("ala", r.single().nickname)
    }

    @Test fun blankDisplayNameClearsIt() = runTest {
        repo.updateProfile("  ", " bio ", listOf("https://e.example"), "followers").getOrThrow()
        val sent = api.lastUpdate!!
        assertNull(sent.displayName); assertTrue(sent.clearDisplayName); assertEquals("bio", sent.bio); assertEquals("followers", sent.visibility)
    }

    @Test fun nonBlankDisplayNameIsSent() = runTest {
        repo.updateProfile(" Ala K. ", "", emptyList(), "public").getOrThrow()
        assertEquals("Ala K.", api.lastUpdate!!.displayName); assertFalse(api.lastUpdate!!.clearDisplayName)
    }

    @Test fun profileValidationHelpers() {
        assertEquals(listOf("https://a.example", "https://b.example"), ProfileValidation.splitLinks(" https://a.example \n\n https://b.example\n"))
        assertTrue(ProfileValidation.bioTooLong("x".repeat(281))); assertFalse(ProfileValidation.bioTooLong("x".repeat(280)))
        assertTrue(ProfileValidation.tooManyLinks(List(6) { "https://e.example/$it" }))
        assertTrue(ProfileValidation.displayNameTooLong("x".repeat(51)))
    }
}
