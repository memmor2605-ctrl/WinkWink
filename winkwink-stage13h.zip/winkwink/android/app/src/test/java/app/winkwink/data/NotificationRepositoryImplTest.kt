package app.winkwink.data

import app.winkwink.data.remote.NotificationActorDto
import app.winkwink.data.remote.NotificationApi
import app.winkwink.data.remote.NotificationDto
import app.winkwink.data.remote.NotificationListDto
import app.winkwink.data.remote.NotificationSettingsDto
import app.winkwink.data.remote.UnreadCountDto
import app.winkwink.data.repository.NotificationRepositoryImpl
import app.winkwink.domain.model.ApiFailure
import app.winkwink.errorResponse
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import retrofit2.Response

private fun dto(id: String = "n1", type: String = "reaction", anonymous: Boolean = false, createdAt: String = "2026-11-22T10:00:00Z") = NotificationDto(
    id = id, type = type,
    actor = NotificationActorDto("ww_abcdefghij", "bobby", "Bobby", false),
    actorAnonymous = anonymous, postId = "p1", createdAt = createdAt, read = false,
)

private class FakeNotificationApi : NotificationApi {
    var lastList: List<Any?>? = null
    var list: () -> Response<NotificationListDto> = { Response.success(NotificationListDto(listOf(dto()), "next", 3)) }
    var markRead: () -> Response<Unit> = { Response.success(Unit) }
    var lastMarkAllType: String? = "unset"
    var lastSettingsBody: NotificationSettingsDto? = null

    override suspend fun list(type: String?, unread: Boolean?, limit: Int, cursor: String?): Response<NotificationListDto> {
        lastList = listOf(type, unread, limit, cursor); return list.invoke()
    }
    override suspend fun unreadCount(): Response<UnreadCountDto> = Response.success(UnreadCountDto(7))
    override suspend fun markRead(id: String): Response<Unit> = markRead.invoke()
    override suspend fun markAllRead(type: String?): Response<Unit> { lastMarkAllType = type; return Response.success(Unit) }
    override suspend fun settings(): Response<NotificationSettingsDto> = Response.success(NotificationSettingsDto(mapOf("reaction" to true, "comment" to false)))
    override suspend fun updateSettings(body: NotificationSettingsDto): Response<NotificationSettingsDto> {
        lastSettingsBody = body; return Response.success(NotificationSettingsDto(mapOf("reaction" to false, "comment" to false)))
    }
}

class NotificationRepositoryImplTest {
    private val api = FakeNotificationApi()
    private val repo = NotificationRepositoryImpl(api, Json { ignoreUnknownKeys = true })

    @Test fun listMapsItemsCursorAndUnreadCount() = runTest {
        val page = repo.list(null, false, null).getOrThrow()
        assertEquals("n1", page.items.single().id)
        assertEquals("Bobby", page.items.single().actor?.name)
        assertEquals("next", page.nextCursor)
        assertEquals(3, page.unreadCount)
    }

    @Test fun listSendsFiltersAndOmitsUnreadWhenOff() = runTest {
        repo.list("comment", false, "c1")
        assertEquals(listOf("comment", null, 20, "c1"), api.lastList)
        repo.list(null, true, null)
        assertEquals(listOf(null, true, 20, null), api.lastList)
    }

    @Test fun anonymousActorIsNeverExposedEvenIfServerSendsOne() = runTest {
        api.list = { Response.success(NotificationListDto(listOf(dto(anonymous = true)), null, 1)) }
        assertNull(repo.list(null, false, null).getOrThrow().items.single().actor)
    }

    @Test fun missingActorMapsToNull() = runTest {
        api.list = { Response.success(NotificationListDto(listOf(dto().copy(actor = null, actorAnonymous = true)), null, 1)) }
        assertNull(repo.list(null, false, null).getOrThrow().items.single().actor)
    }

    @Test fun badDateBecomesInvalidResponseNotCrash() = runTest {
        api.list = { Response.success(NotificationListDto(listOf(dto(createdAt = "yesterday")), null, 0)) }
        val e = repo.list(null, false, null).exceptionOrNull() as ApiFailure
        assertEquals("invalid_response", e.code)
    }

    @Test fun markReadMapsNotFound() = runTest {
        api.markRead = { errorResponse(404, """{"error":{"code":"notification_not_found","message":"x","requestId":"r"}}""") }
        val e = repo.markRead("zzz").exceptionOrNull() as ApiFailure
        assertEquals("notification_not_found", e.code)
        assertEquals(404, e.httpStatus)
    }

    @Test fun markAllReadPassesTypeAndUnreadCountIsReturned() = runTest {
        assertTrue(repo.markAllRead("reply").isSuccess)
        assertEquals("reply", api.lastMarkAllType)
        repo.markAllRead(null)
        assertNull(api.lastMarkAllType)
        assertEquals(7, repo.unreadCount().getOrThrow())
    }

    @Test fun settingsRoundTripUsesServerMap() = runTest {
        assertEquals(mapOf("reaction" to true, "comment" to false), repo.settings().getOrThrow())
        val after = repo.updateSettings(mapOf("reaction" to false)).getOrThrow()
        assertEquals(mapOf("reaction" to false), api.lastSettingsBody?.types)
        assertEquals(false, after["reaction"])
    }
}
