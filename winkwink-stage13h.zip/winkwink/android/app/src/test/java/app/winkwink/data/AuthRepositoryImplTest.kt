package app.winkwink.data

import app.winkwink.FakeAccountApi
import app.winkwink.FakePublicApi
import app.winkwink.FakeSessionStore
import app.winkwink.data.remote.apiCall
import app.winkwink.data.remote.SessionRefresher
import app.winkwink.data.repository.AuthRepositoryImpl
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.StoredSession
import app.winkwink.errorResponse
import app.winkwink.tokens
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException
import java.net.SocketTimeoutException
import javax.net.ssl.SSLHandshakeException

class AuthRepositoryImplTest {
    private val json = Json { ignoreUnknownKeys = true }
    private val publicApi = FakePublicApi()
    private val accountApi = FakeAccountApi()
    private val store = FakeSessionStore()
    private val repo = AuthRepositoryImpl(publicApi, accountApi, store, json) { "Pixel Test" }

    private fun failure(r: Result<*>) = r.exceptionOrNull() as ApiFailure

    @Test fun loginStoresSessionAndReturnsAccount() = runTest {
        val r = repo.login("ala@example.com", "correct-horse-battery")
        assertEquals("ww_abcdefghij", r.getOrThrow().profile.winkwinkId)
        assertEquals("a1", store.session.value?.accessToken)
        assertEquals("r1", store.session.value?.refreshToken)
    }

    @Test fun wrongCredentialsDoNotStoreSessionAndExposeCode() = runTest {
        publicApi.login = { errorResponse(401, """{"error":{"code":"invalid_credentials","message":"Incorrect"}}""") }
        val f = failure(repo.login("ala@example.com", "bad"))
        assertEquals("invalid_credentials", f.code)
        assertEquals(401, f.httpStatus)
        assertNull(store.session.value)
    }

    @Test fun lockoutExposesRetryAfter() = runTest {
        publicApi.login = { errorResponse(429, """{"error":{"code":"too_many_attempts","message":"x"}}""", retryAfter = "900") }
        assertEquals(900L, failure(repo.login("a@b.co", "x")).retryAfterSeconds)
    }

    @Test fun validationDetailsArePreserved() = runTest {
        publicApi.register = { errorResponse(422, """{"error":{"code":"validation_failed","message":"m","details":["email: invalid format"]}}""") }
        assertEquals(listOf("email: invalid format"), failure(repo.register("x", "y", "z")).details)
    }

    @Test fun logoutAlwaysClearsLocalSessionEvenWhenOffline() = runTest {
        store.save(StoredSession("s1", "a1", "r1"))
        accountApi.logout = { throw IOException("offline") }
        repo.logout()
        assertNull(store.session.value)
        assertEquals(1, accountApi.logoutCalls)
    }

    @Test fun logoutWithoutSessionDoesNotCallServer() = runTest {
        repo.logout()
        assertEquals(0, accountApi.logoutCalls)
    }

    @Test fun networkErrorsMapToLocalCodes() = runTest {
        suspend fun code(t: Throwable) = failure(apiCall<Unit>(json) { throw t }).code
        assertEquals("timeout", code(SocketTimeoutException()))
        assertEquals("tls", code(SSLHandshakeException("bad cert")))
        assertEquals("network", code(IOException("down")))
        assertEquals("insecure", code(app.winkwink.data.remote.CleartextBlockedException("h")))
    }

    @Test fun nonJsonErrorBodyFallsBackToHttpCode() = runTest {
        publicApi.login = { errorResponse(502, "<html>bad gateway</html>") }
        val f = failure(repo.login("a@b.co", "x"))
        assertEquals("http_502", f.code)
        assertEquals(502, f.httpStatus)
    }

    // --- SessionRefresher ---

    @Test fun refresherRotatesAndSavesNewTokens() = runTest {
        store.save(StoredSession("s1", "a1", "r1"))
        val fresh = SessionRefresher(publicApi, store).refreshIfStale("a1")
        assertEquals("a2", fresh?.accessToken)
        assertEquals("r2", store.session.value?.refreshToken)
    }

    @Test fun refresherSkipsWhenAnotherCallerAlreadyRefreshed() = runTest {
        store.save(StoredSession("s1", "a2", "r2"))
        val result = SessionRefresher(publicApi, store).refreshIfStale("a1") // a1 jest już nieaktualny
        assertEquals("a2", result?.accessToken)
        assertEquals(0, publicApi.refreshCalls)
    }

    @Test fun refresherSignsOutOnDefiniteRejection() = runTest {
        store.save(StoredSession("s1", "a1", "r1"))
        publicApi.refresh = { errorResponse(401, """{"error":{"code":"refresh_token_reused","message":"x"}}""") }
        assertNull(SessionRefresher(publicApi, store).refreshIfStale("a1"))
        assertNull(store.session.value)
    }

    @Test fun refresherKeepsSessionOnTransientFailures() = runTest {
        store.save(StoredSession("s1", "a1", "r1"))
        publicApi.refresh = { errorResponse(503, "{}") }
        assertNull(SessionRefresher(publicApi, store).refreshIfStale("a1"))
        assertNotNull(store.session.value)
        publicApi.refresh = { throw IOException("offline") }
        assertNull(SessionRefresher(publicApi, store).refreshIfStale("a1"))
        assertTrue(store.clears == 0)
    }
}
