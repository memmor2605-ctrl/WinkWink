package app.winkwink.data

import app.winkwink.data.remote.HideFollowListsRequestDto
import app.winkwink.data.remote.PostDto
import app.winkwink.data.remote.PostListDto
import app.winkwink.data.remote.ProfileExtrasApi
import app.winkwink.data.remote.UserListDto
import app.winkwink.data.remote.UserProfileDto
import app.winkwink.data.remote.UserSummaryDto
import app.winkwink.data.repository.ProfileExtrasRepositoryImpl
import app.winkwink.domain.media.ImageKind
import app.winkwink.domain.media.ImagePrepareException
import app.winkwink.domain.media.ImagePreparer
import app.winkwink.domain.model.ApiFailure
import app.winkwink.errorResponse
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import okhttp3.RequestBody
import okio.Buffer
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import retrofit2.Response

private class FakeExtrasApi : ProfileExtrasApi {
    var avatarBody: ByteArray? = null
    var avatarContentType: String? = null
    var putResult: (() -> Response<UserProfileDto>)? = null
    var calls = mutableListOf<String>()
    var postsResult: Response<PostListDto> = Response.success(PostListDto(emptyList(), null))
    var lastHide: Boolean? = null

    private fun profile(tag: String?) = UserProfileDto(winkwinkId = "ww_me", nickname = "me", visibility = "public", isSelf = true, avatarTag = tag)

    override suspend fun putAvatar(body: RequestBody): Response<UserProfileDto> {
        calls += "putAvatar"
        avatarContentType = body.contentType().toString()
        avatarBody = Buffer().also { body.writeTo(it) }.readByteArray()
        return putResult?.invoke() ?: Response.success(profile("tag123456789"))
    }
    override suspend fun deleteAvatar(): Response<UserProfileDto> { calls += "deleteAvatar"; return Response.success(profile(null)) }
    override suspend fun putBackground(body: RequestBody): Response<UserProfileDto> { calls += "putBackground"; return Response.success(profile(null).copy(backgroundTag = "bg")) }
    override suspend fun deleteBackground(): Response<UserProfileDto> { calls += "deleteBackground"; return Response.success(profile(null)) }
    override suspend fun mute(id: String): Response<Unit> { calls += "mute:$id"; return Response.success(Unit) }
    override suspend fun unmute(id: String): Response<Unit> { calls += "unmute:$id"; return Response.success(Unit) }
    override suspend fun mutes(limit: Int, cursor: String?): Response<UserListDto> =
        Response.success(UserListDto(listOf(UserSummaryDto("ww_a", "a", null, "tagA")), "next"))
    override suspend fun setHideFollowLists(body: HideFollowListsRequestDto): Response<UserProfileDto> {
        lastHide = body.hideFollowLists; return Response.success(profile(null).copy(followListsHidden = body.hideFollowLists))
    }
    override suspend fun userPosts(id: String, limit: Int, cursor: String?): Response<PostListDto> { calls += "posts:$id:$cursor"; return postsResult }
}

private class FakePreparer(var result: Result<ByteArray> = Result.success(byteArrayOf(1, 2, 3))) : ImagePreparer {
    var lastKind: ImageKind? = null
    override suspend fun prepare(uri: String, kind: ImageKind): Result<ByteArray> { lastKind = kind; return result }
}

class ProfileExtrasRepositoryImplTest {
    private val api = FakeExtrasApi()
    private val prep = FakePreparer()
    private val repo = ProfileExtrasRepositoryImpl(api, prep, Json { ignoreUnknownKeys = true })

    @Test fun avatarUploadSendsPreparedJpegAndReturnsNewTag() = runTest {
        val p = repo.setImage(ImageKind.AVATAR, "content://pick/1").getOrThrow()
        assertEquals("tag123456789", p.avatarTag)
        assertEquals("image/jpeg", api.avatarContentType)
        assertArrayEquals(byteArrayOf(1, 2, 3), api.avatarBody)
        assertEquals(ImageKind.AVATAR, prep.lastKind)
    }

    @Test fun unreadableImageNeverReachesTheNetwork() = runTest {
        prep.result = Result.failure(ImagePrepareException("Not an image"))
        val e = repo.setImage(ImageKind.AVATAR, "content://pick/2").exceptionOrNull() as ApiFailure
        assertEquals("image_unreadable", e.code)
        assertTrue(api.calls.isEmpty())
    }

    @Test fun serverRejectionIsMappedToApiFailure() = runTest {
        api.putResult = { errorResponse(413, """{"error":{"code":"payload_too_large","message":"big"}}""") }
        val e = repo.setImage(ImageKind.AVATAR, "content://pick/3").exceptionOrNull() as ApiFailure
        assertEquals("payload_too_large", e.code); assertEquals(413, e.httpStatus)
    }

    @Test fun backgroundAndRemovalUseTheirOwnEndpoints() = runTest {
        assertEquals("bg", repo.setImage(ImageKind.BACKGROUND, "content://pick/4").getOrThrow().backgroundTag)
        assertNull(repo.removeImage(ImageKind.AVATAR).getOrThrow().avatarTag)
        repo.removeImage(ImageKind.BACKGROUND)
        assertEquals(listOf("putBackground", "deleteAvatar", "deleteBackground"), api.calls)
    }

    @Test fun muteUnmuteAndList() = runTest {
        repo.mute("ww_a"); repo.unmute("ww_a")
        assertEquals(listOf("mute:ww_a", "unmute:ww_a"), api.calls)
        val page = repo.muted(null).getOrThrow()
        assertEquals("tagA", page.users.single().avatarTag); assertEquals("next", page.nextCursor)
    }

    @Test fun hideFollowListsComesBackFromServer() = runTest {
        assertTrue(repo.setHideFollowLists(true).getOrThrow().followListsHidden)
        assertEquals(true, api.lastHide)
        assertFalse(repo.setHideFollowLists(false).getOrThrow().followListsHidden)
    }

    @Test fun userPostsPassesCursorAndMapsAuthorAvatar() = runTest {
        api.postsResult = Response.success(
            PostListDto(
                listOf(PostDto("p1", app.winkwink.data.remote.AuthorDto("ww_a", "a", null, true, "tagA"), false, false, "hi", "public", "2026-11-21T10:00:00Z", null, 0, 0, null, false)),
                "c2",
            ),
        )
        val page = repo.userPosts("ww_a", "c1").getOrThrow()
        assertEquals("posts:ww_a:c1", api.calls.single())
        assertEquals("tagA", page.posts.single().author?.avatarTag); assertEquals("c2", page.nextCursor)
    }

    @Test fun badDateInPostsIsInvalidResponse() = runTest {
        api.postsResult = Response.success(PostListDto(listOf(PostDto("p1", null, true, false, "x", "public", "not-a-date", null, 0, 0, null, false)), null))
        assertEquals("invalid_response", (repo.userPosts("ww_a", null).exceptionOrNull() as ApiFailure).code)
    }
}
