package app.winkwink.data

import app.winkwink.data.remote.CommentDto
import app.winkwink.data.remote.CommentListDto
import app.winkwink.data.remote.CreateCommentRequestDto
import app.winkwink.data.remote.CreatePostRequestDto
import app.winkwink.data.remote.AttachmentDto
import app.winkwink.data.remote.AuthorDto
import app.winkwink.data.remote.SharePostRequestDto
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody
import okhttp3.ResponseBody
import okhttp3.ResponseBody.Companion.toResponseBody
import app.winkwink.domain.model.PreparedFile
import app.winkwink.data.remote.FeedApi
import app.winkwink.data.remote.PostDto
import app.winkwink.data.remote.PostListDto
import app.winkwink.data.remote.ReactionRequestDto
import app.winkwink.data.remote.UpdatePostRequestDto
import app.winkwink.data.repository.FeedRepositoryImpl
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.FeedKind
import app.winkwink.errorResponse
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import retrofit2.Response

private fun postDto(id: String = "p1", anonymous: Boolean = false, createdAt: String = "2026-11-21T10:00:00Z") = PostDto(
    id = id,
    author = if (anonymous) null else AuthorDto("ww_abcdefghij", "ola", "Ola"),
    anonymous = anonymous, mine = false, body = "Hej", visibility = "public",
    createdAt = createdAt, editedAt = null, reactions = 2, comments = 1, myReaction = null, saved = false,
)

private class FakeFeedApi : FeedApi {
    var following: () -> Response<PostListDto> = { Response.success(PostListDto(listOf(postDto()), "c2")) }
    var discover: () -> Response<PostListDto> = { Response.success(PostListDto(emptyList())) }
    var createPost: (CreatePostRequestDto) -> Response<PostDto> = { Response.success(postDto()) }
    var lastCreate: CreatePostRequestDto? = null
    var lastCursor: String? = "unset"
    var calls = mutableListOf<String>()

    override suspend fun following(limit: Int, cursor: String?): Response<PostListDto> { lastCursor = cursor; calls += "following"; return following.invoke() }
    override suspend fun discover(limit: Int, cursor: String?): Response<PostListDto> { calls += "discover"; return discover.invoke() }
    override suspend fun saved(limit: Int, cursor: String?): Response<PostListDto> { calls += "saved:$cursor"; return Response.success(PostListDto(listOf(postDto("s")), null)) }
    override suspend fun post(id: String): Response<PostDto> = Response.success(postDto(id))
    override suspend fun createPost(body: CreatePostRequestDto): Response<PostDto> { lastCreate = body; return createPost.invoke(body) }
    override suspend fun updatePost(id: String, body: UpdatePostRequestDto): Response<PostDto> = Response.success(postDto(id))
    override suspend fun deletePost(id: String): Response<Unit> = Response.success(Unit)
    override suspend fun react(id: String, body: ReactionRequestDto): Response<PostDto> = Response.success(postDto(id).copy(myReaction = body.type))
    override suspend fun unreact(id: String): Response<PostDto> = Response.success(postDto(id))
    override suspend fun save(id: String): Response<Unit> { calls += "save"; return Response.success(Unit) }
    override suspend fun unsave(id: String): Response<Unit> { calls += "unsave"; return Response.success(Unit) }
    override suspend fun comments(id: String, limit: Int, cursor: String?): Response<CommentListDto> { calls += "comments"; return Response.success(CommentListDto(emptyList())) }
    override suspend fun replies(id: String, commentId: String, limit: Int, cursor: String?): Response<CommentListDto> { calls += "replies:$commentId"; return Response.success(CommentListDto(emptyList())) }
    override suspend fun addComment(id: String, body: CreateCommentRequestDto): Response<CommentDto> =
        Response.success(CommentDto("c1", id, body.parentId, null, true, true, body.body, "2026-11-21T10:05:00Z"))
    override suspend fun deleteComment(id: String): Response<Unit> = Response.success(Unit)

    var lastSearch: Triple<String, Int, String?>? = null
    var lastShare: Pair<String, SharePostRequestDto>? = null
    var lastUploadName: String? = "unset"
    var lastUploadType: String? = null
    var postWithAttachments: PostDto? = null
    var downloadBytes: ByteArray = "abc".toByteArray()
    override suspend fun search(query: String, limit: Int, cursor: String?): Response<PostListDto> {
        lastSearch = Triple(query, limit, cursor); return Response.success(PostListDto(listOf(postDto("r1")), "n"))
    }
    override suspend fun share(id: String, body: SharePostRequestDto): Response<PostDto> {
        lastShare = id to body
        return Response.success(postDto("sh").copy(isShare = true, shared = postDto(id, anonymous = true)))
    }
    override suspend fun uploadAttachment(body: RequestBody, name: String?): Response<AttachmentDto> {
        lastUploadName = name; lastUploadType = body.contentType()?.toString()
        return Response.success(AttachmentDto("a1", "image", "image/jpeg", 10, null, 4, 3))
    }
    override suspend fun deleteAttachment(id: String): Response<Unit> = Response.success(Unit)
    override suspend fun downloadAttachment(id: String): Response<ResponseBody> = Response.success(downloadBytes.toResponseBody("application/pdf".toMediaType()))
}

class FeedRepositoryImplTest {
    private val api = FakeFeedApi()
    private val repo = FeedRepositoryImpl(api, Json { ignoreUnknownKeys = true })

    @Test fun followingFeedMapsPostsAndCursor() = runTest {
        val page = repo.feed(FeedKind.Following, null).getOrThrow()
        assertEquals(1, page.posts.size)
        assertEquals("Ola", page.posts[0].author?.displayName)
        assertEquals("c2", page.nextCursor)
        assertNull(api.lastCursor)
    }

    @Test fun cursorIsPassedThrough() = runTest {
        repo.feed(FeedKind.Following, "abc").getOrThrow()
        assertEquals("abc", api.lastCursor)
    }

    @Test fun savedUsesSavedEndpointWithCursor() = runTest {
        val page = repo.saved("k1").getOrThrow()
        assertEquals("s", page.posts.single().id); assertEquals(listOf("saved:k1"), api.calls)
    }

    @Test fun discoverUsesDiscoverEndpoint() = runTest {
        repo.feed(FeedKind.Discover, null).getOrThrow()
        assertEquals(listOf("discover"), api.calls)
    }

    @Test fun anonymousPostHasNoAuthor() = runTest {
        api.following = { Response.success(PostListDto(listOf(postDto(anonymous = true)))) }
        val p = repo.feed(FeedKind.Following, null).getOrThrow().posts.single()
        assertTrue(p.anonymous); assertNull(p.author)
    }

    @Test fun anonymousCreateIsAlwaysPublicAndTrimmed() = runTest {
        repo.createPost("  tajne  ", "private", anonymous = true).getOrThrow()
        val sent = api.lastCreate!!
        assertEquals("public", sent.visibility); assertTrue(sent.anonymous); assertEquals("tajne", sent.body)
    }

    @Test fun nonAnonymousCreateKeepsVisibility() = runTest {
        repo.createPost("hej", "followers", anonymous = false).getOrThrow()
        assertEquals("followers", api.lastCreate!!.visibility)
    }

    @Test fun backendErrorBecomesApiFailure() = runTest {
        api.following = { errorResponse(403, """{"error":{"code":"forbidden","message":"x"}}""") }
        val f = repo.feed(FeedKind.Following, null).exceptionOrNull() as ApiFailure
        assertEquals("forbidden", f.code); assertEquals(403, f.httpStatus)
    }

    @Test fun malformedDateBecomesInvalidResponse() = runTest {
        api.following = { Response.success(PostListDto(listOf(postDto(createdAt = "yesterday")))) }
        val f = repo.feed(FeedKind.Following, null).exceptionOrNull() as ApiFailure
        assertEquals("invalid_response", f.code)
    }

    @Test fun repliesUseReplyEndpointOnlyWithParent() = runTest {
        repo.comments("p1", null, null).getOrThrow()
        repo.comments("p1", "c9", null).getOrThrow()
        assertEquals(listOf("comments", "replies:c9"), api.calls)
    }

    @Test fun anonymousAuthorCommentIsHidden() = runTest {
        val c = repo.addComment("p1", null, " hej ").getOrThrow()
        assertTrue(c.authorHidden); assertNull(c.author); assertEquals("hej", c.body)
    }

    @Test fun setSavedCallsMatchingEndpoint() = runTest {
        repo.setSaved("p1", true).getOrThrow()
        repo.setSaved("p1", false).getOrThrow()
        assertEquals(listOf("save", "unsave"), api.calls)
    }

    @Test fun reactReturnsUpdatedPost() = runTest {
        assertEquals("love", repo.react("p1", "love").getOrThrow().myReaction)
        assertFalse(repo.unreact("p1").getOrThrow().myReaction != null)
    }

    @Test fun searchTrimsQueryAndPassesCursor() = runTest {
        val page = repo.search("  hello  ", "c9").getOrThrow()
        assertEquals(Triple("hello", 20, "c9"), api.lastSearch)
        assertEquals("r1", page.posts.single().id); assertEquals("n", page.nextCursor)
    }

    @Test fun shareSendsCommentAndKeepsAnonymousOriginalHidden() = runTest {
        val shared = repo.share("orig", "  nice  ", "public").getOrThrow()
        assertEquals("orig" to SharePostRequestDto("nice", "public"), api.lastShare)
        assertTrue(shared.isShare)
        assertNull(shared.shared?.author)
        assertTrue(shared.shared?.anonymous == true)
    }

    @Test fun createPostSendsAttachmentIds() = runTest {
        repo.createPost("hi", "public", false, listOf("a1", "a2")).getOrThrow()
        assertEquals(listOf("a1", "a2"), api.lastCreate?.attachmentIds)
        repo.createCommunityPost("hi", "c1", "ch1", listOf("a3")).getOrThrow()
        assertEquals(listOf("a3"), api.lastCreate?.attachmentIds)
        assertEquals("community", api.lastCreate?.visibility)
    }

    @Test fun uploadSendsContentTypeAndNameAndMapsAttachment() = runTest {
        val a = repo.uploadAttachment(PreparedFile(byteArrayOf(1, 2, 3), "application/pdf", "plan.pdf", "document")).getOrThrow()
        assertEquals("plan.pdf", api.lastUploadName)
        assertEquals("application/pdf", api.lastUploadType)
        assertEquals("a1", a.id); assertTrue(a.isImage)
    }

    @Test fun downloadReturnsBytes() = runTest {
        assertEquals("abc", String(repo.downloadAttachment("a1").getOrThrow()))
    }
}
