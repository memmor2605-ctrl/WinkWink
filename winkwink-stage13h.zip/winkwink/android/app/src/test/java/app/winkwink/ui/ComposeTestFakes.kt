package app.winkwink.ui

import app.winkwink.domain.media.AttachmentPrepareException
import app.winkwink.domain.media.AttachmentPreparer
import app.winkwink.domain.model.Channel
import app.winkwink.domain.model.Community
import app.winkwink.domain.model.InviteCandidate
import app.winkwink.domain.model.CommunityPage
import app.winkwink.domain.model.PersonPage
import app.winkwink.domain.model.PostPage
import app.winkwink.domain.model.PreparedFile
import app.winkwink.domain.repository.CommunityRepository
import java.time.Instant

fun testCommunity(id: String, name: String = "Club $id") =
    Community(id, name, "", "", "public", 1, "member", "member", Instant.parse("2026-11-21T10:00:00Z"))

/** Tylko `mine` i `channels` działają; reszta zgłasza błąd, jeśli test jej niechcący użyje. */
class StubCommunityRepository : CommunityRepository {
    var mine: Result<CommunityPage> = Result.success(CommunityPage(emptyList(), null))
    var channels: Map<String, List<Channel>> = emptyMap()
    override suspend fun mine(cursor: String?) = mine
    override suspend fun channels(id: String): Result<List<Channel>> = Result.success(channels[id].orEmpty())
    override suspend fun invites(cursor: String?): Result<CommunityPage> = error("unused")
    override suspend fun search(query: String, cursor: String?): Result<CommunityPage> = error("unused")
    override suspend fun create(name: String, description: String, rules: String, type: String): Result<Community> = error("unused")
    override suspend fun get(id: String): Result<Community> = error("unused")
    override suspend fun update(id: String, name: String?, description: String?, rules: String?, type: String?): Result<Community> = error("unused")
    override suspend fun join(id: String): Result<String> = error("unused")
    override suspend fun leave(id: String): Result<Unit> = error("unused")
    override suspend fun cancelRequest(id: String): Result<Unit> = error("unused")
    override suspend fun respondToInvite(id: String, accept: Boolean): Result<Unit> = error("unused")
    override suspend fun members(id: String, cursor: String?): Result<PersonPage> = error("unused")
    override suspend fun setRole(id: String, userId: String, role: String): Result<Unit> = error("unused")
    override suspend fun removeMember(id: String, userId: String): Result<Unit> = error("unused")
    override suspend fun invite(id: String, userId: String): Result<Unit> = error("unused")
    override suspend fun inviteCandidates(id: String, query: String): Result<List<InviteCandidate>> = error("unused")
    override suspend fun transferOwnership(id: String, userId: String): Result<Unit> = error("unused")
    override suspend fun setMuted(id: String, userId: String, muted: Boolean): Result<Unit> = error("unused")
    override suspend fun requests(id: String, cursor: String?): Result<PersonPage> = error("unused")
    override suspend fun decideRequest(id: String, userId: String, approve: Boolean): Result<Unit> = error("unused")
    override suspend fun createChannel(id: String, name: String): Result<Channel> = error("unused")
    override suspend fun deleteChannel(id: String, channelId: String): Result<Unit> = error("unused")
    override suspend fun delete(id: String): Result<Unit> = error("unused")
    override suspend fun posts(id: String, channelId: String?, cursor: String?): Result<PostPage> = error("unused")
}

/** Uri zaczynające się od "video:" / "doc:" / "bad:" dają odpowiedni rodzaj pliku lub błąd; reszta to obraz. */
class FakeAttachmentPreparer : AttachmentPreparer {
    override suspend fun prepare(uri: String): Result<PreparedFile> = when {
        uri.startsWith("video:") -> Result.success(PreparedFile(byteArrayOf(1), "video/mp4", null, "video"))
        uri.startsWith("doc:") -> Result.success(PreparedFile(byteArrayOf(1), "application/pdf", "a.pdf", "document"))
        uri.startsWith("bad:") -> Result.failure(AttachmentPrepareException(AttachmentPrepareException.UNSUPPORTED))
        else -> Result.success(PreparedFile(byteArrayOf(1), "image/jpeg", null, "image"))
    }
}
