package app.winkwink.data.remote

import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException

class CleartextBlockedException(host: String) : IOException("Cleartext traffic to $host is not permitted")

/** Ostatnia linia obrony: żadne żądanie (HTTP ani WS) nie opuści aplikacji bez TLS. wss:// jest w OkHttp traktowane jako https. */
class HttpsOnlyInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        if (!request.url.isHttps) throw CleartextBlockedException(request.url.host)
        return chain.proceed(request)
    }
}
