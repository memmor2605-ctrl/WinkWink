package app.winkwink.data.media

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import app.winkwink.domain.media.AttachmentPrepareException
import app.winkwink.domain.media.ImageKind
import app.winkwink.domain.media.ImagePreparer
import app.winkwink.domain.media.MessageDocumentTypes
import app.winkwink.domain.media.MessageFilePreparer
import app.winkwink.domain.model.MessageMediaLimits
import app.winkwink.domain.model.PreparedFile
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AndroidMessageFilePreparer @Inject constructor(
    @ApplicationContext private val context: Context,
    private val images: ImagePreparer,
) : MessageFilePreparer {

    override suspend fun prepareImage(uri: String): Result<PreparedFile> = withContext(Dispatchers.IO) {
        images.prepare(uri, ImageKind.POST).fold(
            // Dowolny obraz obsługiwany przez system jest dekodowany i zapisywany jako JPEG bez EXIF/GPS.
            onSuccess = { Result.success(PreparedFile(it, "image/jpeg", null, "image")) },
            onFailure = { Result.failure(AttachmentPrepareException(AttachmentPrepareException.UNREADABLE)) },
        )
    }

    override suspend fun prepareDocument(uri: String): Result<PreparedFile> = withContext(Dispatchers.IO) {
        try {
            val parsed = Uri.parse(uri)
            val name = displayName(parsed)
            val mime = MessageDocumentTypes.mimeFor(name, context.contentResolver.getType(parsed))
                ?: return@withContext Result.failure(AttachmentPrepareException(AttachmentPrepareException.UNSUPPORTED))
            val bytes = read(parsed, MessageMediaLimits.DOCUMENT_MAX_BYTES)
                ?: return@withContext Result.failure(AttachmentPrepareException(AttachmentPrepareException.TOO_LARGE))
            if (bytes.isEmpty()) return@withContext Result.failure(AttachmentPrepareException(AttachmentPrepareException.UNREADABLE))
            Result.success(PreparedFile(bytes, mime, name, "document"))
        } catch (e: AttachmentPrepareException) {
            Result.failure(e)
        } catch (e: OutOfMemoryError) {
            Result.failure(AttachmentPrepareException(AttachmentPrepareException.TOO_LARGE))
        } catch (e: Exception) {
            Result.failure(AttachmentPrepareException(AttachmentPrepareException.UNREADABLE))
        }
    }

    private fun displayName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()

    /** Czyta plik z limitem; null = przekroczono limit (czytanie przerywane, żeby nie ładować wielkiego pliku do pamięci). */
    private fun read(uri: Uri, max: Int): ByteArray? {
        val input = context.contentResolver.openInputStream(uri) ?: throw AttachmentPrepareException(AttachmentPrepareException.UNREADABLE)
        input.use { stream ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(64 * 1024)
            var total = 0
            while (true) {
                val n = stream.read(buffer)
                if (n < 0) break
                total += n
                if (total > max) return null
                out.write(buffer, 0, n)
            }
            return out.toByteArray()
        }
    }
}
