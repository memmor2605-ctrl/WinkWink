package app.winkwink.ui.feed

import android.content.Intent
import android.text.format.DateUtils
import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import coil.compose.AsyncImage
import coil.imageLoader
import app.winkwink.ui.components.LocalWinkImageLoader
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.size
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.winkwink.R
import app.winkwink.domain.model.Comment
import app.winkwink.domain.model.FeedKind
import app.winkwink.domain.model.Post
import app.winkwink.domain.model.PostAuthor
import app.winkwink.domain.model.ReactionTypes
import app.winkwink.domain.validation.PostValidation
import app.winkwink.ui.auth.FailureBanner
import app.winkwink.ui.components.WwCard
import app.winkwink.ui.components.WwPrimaryButton
import app.winkwink.ui.components.WwScreenHeader
import app.winkwink.ui.theme.WwSpacing
import app.winkwink.ui.components.UserAvatar
import androidx.compose.ui.unit.dp
import java.time.Instant

@StringRes private fun reactionRes(type: String) = when (type) {
    "love" -> R.string.reaction_love
    "laugh" -> R.string.reaction_laugh
    "wow" -> R.string.reaction_wow
    "sad" -> R.string.reaction_sad
    else -> R.string.reaction_like
}

@StringRes private fun visibilityRes(v: String) = when (v) {
    "followers" -> R.string.post_vis_followers
    "private" -> R.string.post_vis_private
    "community" -> R.string.post_vis_community
    else -> R.string.post_vis_public
}

@Composable
private fun relativeTime(t: Instant): String = remember(t) {
    DateUtils.getRelativeTimeSpanString(t.toEpochMilli(), System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()
}

@Composable
private fun authorName(author: PostAuthor?): String =
    author?.let { it.displayName ?: it.nickname } ?: stringResource(R.string.post_anonymous_author)

/**
 * Karta posta. [onOpen] == null → widok szczegółów (bez przycisku komentarzy i bez klikania karty).
 * [onShare] != null → przycisk „Udostępnij” dla postów publicznych (udostępnienie na profilu: komentarz + widoczność).
 */
@Composable
fun PostCard(
    post: Post,
    onOpen: (() -> Unit)?,
    onReact: (String) -> Unit,
    onUnreact: () -> Unit,
    onToggleSave: () -> Unit,
    onOpenAuthor: (String) -> Unit,
    modifier: Modifier = Modifier,
    /** Tylko dla moderatorów społeczności przy cudzych postach; nadal sprawdzane przez backend. */
    onModeratorDelete: (() -> Unit)? = null,
    onShare: ((comment: String, visibility: String) -> Unit)? = null,
    /** Otwarcie oryginału udostępnionego posta. */
    onOpenOriginal: ((String) -> Unit)? = null,
) {
    var showShare by remember { mutableStateOf(false) }
    WwCard(if (onOpen != null) modifier.clickable(onClick = onOpen) else modifier) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            // Autor anonimowy: author == null → neutralny znak, żadnego zapytania o obraz.
            UserAvatar(post.author?.winkwinkId, post.author?.avatarTag, authorName(post.author), 40.dp)
            Column(Modifier.weight(1f)) {
                val author = post.author
                Text(
                    authorName(author),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = if (author != null) Modifier.clickable { onOpenAuthor(author.winkwinkId) } else Modifier,
                )
                val meta = buildString {
                    author?.let { append("@${it.nickname} · ") }
                    append(relativeTime(post.createdAt))
                }
                Text(
                    if (post.edited) "$meta · ${stringResource(R.string.post_edited)}" else meta,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(stringResource(visibilityRes(post.visibility)), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (post.body.isNotBlank()) Text(post.body, style = MaterialTheme.typography.bodyLarge)
        if (post.isShare) {
            val original = post.shared
            if (original != null) EmbeddedPost(original, onOpenAuthor, onOpenOriginal)
            else Text(stringResource(R.string.post_share_unavailable), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (post.attachments.isNotEmpty()) PostAttachments(post.attachments)
        Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs), verticalAlignment = Alignment.CenterVertically) {
            ReactionButton(post, onReact, onUnreact)
            if (onOpen != null) {
                TextButton(onClick = onOpen) { Text(stringResource(R.string.post_comments, post.comments)) }
            }
            TextButton(onClick = onToggleSave) { Text(stringResource(if (post.saved) R.string.post_saved else R.string.post_save)) }
            if (onShare != null && post.visibility == "public") {
                TextButton(onClick = { showShare = true }) {
                    Text(if (post.shares > 0) stringResource(R.string.post_share_count, post.shares) else stringResource(R.string.post_share))
                }
            }
            onModeratorDelete?.let { TextButton(onClick = it) { Text(stringResource(R.string.community_mod_delete)) } }
        }
    }
    if (showShare && onShare != null) {
        SharePostDialog(post, onDismiss = { showShare = false }, onShare = { c, v -> showShare = false; onShare(c, v) })
    }
}

/** Oryginał udostępnionego posta w ramce; autor anonimowego oryginału pozostaje „Anonim”. */
@Composable
private fun EmbeddedPost(original: Post, onOpenAuthor: (String) -> Unit, onOpenOriginal: ((String) -> Unit)?) {
    Column(
        Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
            .let { if (onOpenOriginal != null) it.clickable { onOpenOriginal(original.id) } else it }
            .padding(WwSpacing.sm),
        verticalArrangement = Arrangement.spacedBy(WwSpacing.xs),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            UserAvatar(original.author?.winkwinkId, original.author?.avatarTag, authorName(original.author), 24.dp)
            val author = original.author
            Text(
                authorName(author), style = MaterialTheme.typography.titleSmall,
                modifier = if (author != null) Modifier.clickable { onOpenAuthor(author.winkwinkId) } else Modifier,
            )
        }
        if (original.body.isNotBlank()) Text(original.body, style = MaterialTheme.typography.bodyMedium, maxLines = 8)
        if (original.attachments.isNotEmpty()) PostAttachments(original.attachments)
    }
}

/** Udostępnianie: na własnym profilu (z komentarzem i widocznością) albo jako zwykły tekst do innej aplikacji. Tylko dla postów publicznych. */
@Composable
private fun SharePostDialog(post: Post, onDismiss: () -> Unit, onShare: (String, String) -> Unit) {
    var comment by rememberSaveable { mutableStateOf("") }
    var visibility by rememberSaveable { mutableStateOf("public") }
    val context = LocalContext.current
    val chooserTitle = stringResource(R.string.post_share_external)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.post_share_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                OutlinedTextField(
                    value = comment, onValueChange = { comment = it }, minLines = 2, modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.post_share_comment)) },
                    isError = comment.trim().length > PostValidation.POST_MAX,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                    listOf("public", "followers").forEach { v ->
                        FilterChip(selected = visibility == v, onClick = { visibility = v }, label = { Text(stringResource(visibilityRes(v))) })
                    }
                }
                if (post.body.isNotBlank()) {
                    OutlinedButton(
                        onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, post.body) }
                            context.startActivity(Intent.createChooser(send, chooserTitle))
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(stringResource(R.string.post_share_external)) }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = comment.trim().length <= PostValidation.POST_MAX, onClick = { onShare(comment, visibility) }) { Text(stringResource(R.string.post_share_confirm)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } },
    )
}

@Composable
private fun ReactionButton(post: Post, onReact: (String) -> Unit, onUnreact: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    val mine = post.myReaction
    val label = stringResource(if (mine != null) reactionRes(mine) else R.string.post_reaction_none)
    Box {
        TextButton(onClick = { open = true }) { Text("$label · ${post.reactions}") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            ReactionTypes.all.forEach { type ->
                DropdownMenuItem(
                    text = { Text((if (mine == type) "✓ " else "") + stringResource(reactionRes(type))) },
                    onClick = { open = false; if (mine == type) onUnreact() else onReact(type) },
                )
            }
            if (mine != null) {
                DropdownMenuItem(text = { Text(stringResource(R.string.post_reaction_remove)) }, onClick = { open = false; onUnreact() })
            }
        }
    }
}

// ---------- Zakładka Feed ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedHomeScreen(
    onOpenPost: (String) -> Unit,
    onCompose: () -> Unit,
    onSearch: () -> Unit,
    onOpenUser: (String) -> Unit,
    /** true, gdy ekran szczegółów zmienił dane widoczne na liście. */
    stale: Boolean,
    onStaleHandled: () -> Unit,
    viewModel: FeedViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(stale) { if (stale) { viewModel.refreshCurrent(); onStaleHandled() } }
    val kind = s.tab
    val list = s.list(kind)

    Column(Modifier.fillMaxSize().padding(horizontal = WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            WwScreenHeader(title = stringResource(R.string.feed_title), modifier = Modifier.weight(1f))
            TextButton(onClick = onSearch) { Text(stringResource(R.string.feed_search)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            FilterChip(selected = kind == FeedKind.Following, onClick = { viewModel.selectTab(FeedKind.Following) }, label = { Text(stringResource(R.string.feed_tab_following)) })
            FilterChip(selected = kind == FeedKind.Discover, onClick = { viewModel.selectTab(FeedKind.Discover) }, label = { Text(stringResource(R.string.feed_tab_discover)) })
        }
        WwPrimaryButton(text = stringResource(R.string.feed_new_post), onClick = onCompose)
        s.actionFailure?.let {
            FailureBanner(it)
            TextButton(onClick = viewModel::dismissActionFailure) { Text(stringResource(R.string.action_dismiss)) }
        }
        if (s.shareNotice) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.post_share_done), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                TextButton(onClick = viewModel::dismissShareNotice) { Text(stringResource(R.string.action_dismiss)) }
            }
        }

        // Przeciągnięcie listy w dół odświeża bieżącą zakładkę; przy pierwszym ładowaniu (pusta lista) pokazujemy zwykły wskaźnik.
        PullToRefreshBox(isRefreshing = list.loading && list.posts.isNotEmpty(), onRefresh = viewModel::refreshCurrent, modifier = Modifier.weight(1f)) {
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm), contentPadding = PaddingValues(bottom = WwSpacing.md)) {
            if (list.loading && list.posts.isEmpty()) item { CircularProgressIndicator() }
            if (list.failure != null && list.posts.isEmpty()) item {
                Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                    FailureBanner(list.failure)
                    TextButton(onClick = { viewModel.refresh(kind) }) { Text(stringResource(R.string.action_retry)) }
                }
            }
            if (list.loaded && list.posts.isEmpty() && list.failure == null) item {
                WwCard {
                    Text(stringResource(if (kind == FeedKind.Following) R.string.feed_empty_following_title else R.string.feed_empty_discover_title), style = MaterialTheme.typography.titleMedium)
                    Text(
                        stringResource(if (kind == FeedKind.Following) R.string.feed_empty_following_body else R.string.feed_empty_discover_body),
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            items(list.posts, key = { it.id }) { post ->
                PostCard(
                    post = post,
                    onOpen = { onOpenPost(post.id) },
                    onReact = { viewModel.react(post, it) },
                    onUnreact = { viewModel.unreact(post) },
                    onToggleSave = { viewModel.toggleSave(post) },
                    onOpenAuthor = onOpenUser,
                    onShare = { comment, visibility -> viewModel.share(post, comment, visibility) },
                    onOpenOriginal = onOpenPost,
                )
            }
            if (list.loadingMore) item { CircularProgressIndicator() }
            // Element pojawia się w kompozycji dopiero przy końcu listy — wtedy dociągamy następną stronę.
            if (list.nextCursor != null && !list.loadingMore) item(key = "more") {
                LaunchedEffect(list.nextCursor) { viewModel.loadMore(kind) }
            }
            if (list.failure != null && list.posts.isNotEmpty()) item {
                Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                    FailureBanner(list.failure)
                    TextButton(onClick = { viewModel.loadMore(kind) }) { Text(stringResource(R.string.action_retry)) }
                }
            }
        }
        }
    }
}

// ---------- Nowy post ----------

@Composable
fun ComposePostScreen(onBack: () -> Unit, onPosted: () -> Unit, viewModel: ComposePostViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(s.created) { if (s.created) onPosted() }
    val mediaLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(FeedMaxPick)) { uris ->
        if (uris.isNotEmpty()) viewModel.addAttachments(uris.map { it.toString() })
    }
    val documentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) viewModel.addAttachments(uris.map { it.toString() })
    }
    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(WwSpacing.md),
        verticalArrangement = Arrangement.spacedBy(WwSpacing.md),
    ) {
        WwScreenHeader(title = stringResource(R.string.compose_title), onBack = onBack)
        OutlinedTextField(
            value = s.body, onValueChange = viewModel::onBody, minLines = 5, modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.compose_hint)) }, isError = s.tooLong,
            supportingText = { Text(if (s.tooLong) stringResource(R.string.err_post_long) else "${s.body.trim().length}/${PostValidation.POST_MAX}") },
        )

        Text(stringResource(R.string.compose_attachments), style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            OutlinedButton(onClick = { mediaLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }) {
                Text(stringResource(R.string.compose_add_media))
            }
            OutlinedButton(onClick = { documentLauncher.launch(arrayOf("application/pdf")) }, enabled = !s.anonymous) {
                Text(stringResource(R.string.compose_add_document))
            }
        }
        if (s.anonymous) Text(stringResource(R.string.compose_attachments_anonymous), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (s.preparing > 0) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            Text(stringResource(R.string.compose_preparing), style = MaterialTheme.typography.bodySmall)
        }
        s.attachmentNotice?.let { code ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(attachmentNoticeRes(code)), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                TextButton(onClick = viewModel::dismissAttachmentNotice) { Text(stringResource(R.string.action_dismiss)) }
            }
        }
        s.attachments.forEach { a ->
            DraftAttachmentRow(a, onRemove = { viewModel.removeAttachment(a.localId) }, onRetry = { viewModel.retryAttachment(a.localId) })
        }

        Text(stringResource(R.string.compose_visibility), style = MaterialTheme.typography.titleMedium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            listOf("public", "followers", "private", "community").forEach { v ->
                FilterChip(selected = s.visibility == v, enabled = !s.anonymous || v == "public", onClick = { viewModel.onVisibility(v) }, label = { Text(stringResource(visibilityRes(v))) })
            }
        }
        if (s.communityMode) CommunityTargetPicker(s, viewModel)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.compose_anonymous), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.compose_anonymous_help), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = s.anonymous, onCheckedChange = viewModel::onAnonymous, enabled = !s.communityMode)
        }
        s.failure?.let { FailureBanner(it) }
        WwPrimaryButton(text = stringResource(R.string.compose_publish), onClick = viewModel::publish, enabled = s.canPost, loading = s.posting)
        if (s.uploading) Text(stringResource(R.string.compose_wait_uploads), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (s.hasFailedUpload) Text(stringResource(R.string.compose_failed_uploads), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
    }
}

private const val FeedMaxPick = 10

@StringRes private fun attachmentNoticeRes(code: String) = when (code) {
    "too_many" -> R.string.attach_err_too_many
    "too_many_videos" -> R.string.attach_err_too_many_videos
    "too_many_documents" -> R.string.attach_err_too_many_documents
    "anonymous_images_only" -> R.string.attach_err_anonymous
    "unsupported_type" -> R.string.attach_err_unsupported
    "file_too_large" -> R.string.attach_err_too_large
    else -> R.string.attach_err_unreadable
}

@Composable
private fun DraftAttachmentRow(a: DraftAttachment, onRemove: () -> Unit, onRetry: () -> Unit) {
    val context = LocalContext.current
    WwCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            if (a.kind == "image") {
                AsyncImage(
                    model = a.uri, contentDescription = null, imageLoader = LocalWinkImageLoader.current ?: context.imageLoader,
                    contentScale = ContentScale.Crop, modifier = Modifier.size(56.dp).clip(MaterialTheme.shapes.small),
                )
            }
            Column(Modifier.weight(1f)) {
                Text(
                    a.name ?: stringResource(when (a.kind) { "video" -> R.string.attachment_video; "document" -> R.string.attachment_document; else -> R.string.attachment_image }),
                    style = MaterialTheme.typography.titleSmall, maxLines = 1,
                )
                Text(
                    stringResource(when (a.status) { UploadStatus.Uploading -> R.string.compose_uploading; UploadStatus.Done -> R.string.compose_uploaded; UploadStatus.Failed -> R.string.compose_upload_failed }),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (a.status == UploadStatus.Failed) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (a.status == UploadStatus.Uploading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            if (a.status == UploadStatus.Failed) TextButton(onClick = onRetry) { Text(stringResource(R.string.action_retry)) }
            TextButton(onClick = onRemove) { Text(stringResource(R.string.compose_remove_attachment)) }
        }
    }
}

/** Wybór społeczności (tylko takich, do których należy użytkownik) i kanału; backend i tak sprawdza członkostwo oraz przynależność kanału. */
@Composable
private fun CommunityTargetPicker(s: ComposeUiState, viewModel: ComposePostViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
        Text(stringResource(R.string.compose_community), style = MaterialTheme.typography.titleSmall)
        when {
            s.communitiesLoading -> CircularProgressIndicator(Modifier.size(24.dp))
            s.communitiesFailure != null -> {
                FailureBanner(s.communitiesFailure)
                TextButton(onClick = viewModel::loadCommunities) { Text(stringResource(R.string.action_retry)) }
            }
            s.communitiesLoaded && s.communities.isEmpty() ->
                Text(stringResource(R.string.compose_no_communities), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            else -> {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                    s.communities.forEach { c ->
                        FilterChip(selected = s.communityId == c.id, onClick = { viewModel.onCommunity(c.id) }, label = { Text(c.name, maxLines = 1) })
                    }
                }
                if (s.communityId != null) {
                    Text(stringResource(R.string.compose_channel), style = MaterialTheme.typography.titleSmall)
                    if (s.channelsLoading) CircularProgressIndicator(Modifier.size(24.dp))
                    else Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                        s.channels.forEach { ch ->
                            FilterChip(selected = s.channelId == ch.id, onClick = { viewModel.onChannel(ch.id) }, label = { Text(ch.name, maxLines = 1) })
                        }
                    }
                } else {
                    Text(stringResource(R.string.compose_pick_community), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

// ---------- Szczegóły posta i komentarze ----------

@Composable
fun PostDetailScreen(
    onBack: () -> Unit,
    onOpenUser: (String) -> Unit,
    onChanged: () -> Unit,
    onOpenPost: ((String) -> Unit)? = null,
    viewModel: PostDetailViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    var editing by rememberSaveable { mutableStateOf(false) }
    var commentToDelete by remember { mutableStateOf<Comment?>(null) }
    LaunchedEffect(s.changed) { if (s.changed) onChanged() }
    LaunchedEffect(s.deleted) { if (s.deleted) onBack() }

    Column(Modifier.fillMaxSize().imePadding()) {
        WwScreenHeader(title = stringResource(R.string.post_title), onBack = onBack, modifier = Modifier.padding(WwSpacing.md))
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            if (s.loading && s.post == null) item { CircularProgressIndicator() }
            s.failure?.let { f ->
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                        FailureBanner(f)
                        TextButton(onClick = viewModel::load) { Text(stringResource(R.string.action_retry)) }
                    }
                }
            }
            s.post?.let { p ->
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                        if (s.shareNotice) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(stringResource(R.string.post_share_done), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                TextButton(onClick = viewModel::dismissShareNotice) { Text(stringResource(R.string.action_dismiss)) }
                            }
                        }
                        PostCard(
                            p, onOpen = null, onReact = viewModel::react, onUnreact = viewModel::unreact, onToggleSave = viewModel::toggleSave, onOpenAuthor = onOpenUser,
                            onShare = { comment, visibility -> viewModel.share(comment, visibility) }, onOpenOriginal = onOpenPost,
                        )
                        if (p.mine) {
                            Row {
                                TextButton(onClick = { editing = true }) { Text(stringResource(R.string.post_edit)) }
                                TextButton(onClick = { confirmDelete = true }) { Text(stringResource(R.string.post_delete)) }
                            }
                        }
                    }
                }
                item { Text(stringResource(R.string.comments_title), style = MaterialTheme.typography.titleMedium) }
                if (s.comments.isEmpty() && !s.commentsLoading) item {
                    Text(stringResource(R.string.comments_empty), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                items(s.comments, key = { it.id }) { c ->
                    val replies = s.replies[c.id]
                    Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                        CommentRow(c, onReply = { viewModel.startReply(c) }, onDelete = if (c.mine || p.mine) ({ commentToDelete = c }) else null, onOpenUser = onOpenUser)
                        if (c.replyCount > 0) {
                            TextButton(onClick = { viewModel.toggleReplies(c) }) {
                                Text(if (replies?.expanded == true) stringResource(R.string.comment_hide_replies) else stringResource(R.string.comment_show_replies, c.replyCount))
                            }
                        }
                        if (replies?.expanded == true) {
                            Column(Modifier.padding(start = WwSpacing.lg), verticalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                                replies.items.forEach { r ->
                                    CommentRow(r, onReply = null, onDelete = if (r.mine || p.mine) ({ commentToDelete = r }) else null, onOpenUser = onOpenUser)
                                }
                                if (replies.loading) CircularProgressIndicator()
                                if (replies.nextCursor != null && !replies.loading) {
                                    TextButton(onClick = { viewModel.loadReplies(c.id) }) { Text(stringResource(R.string.comments_load_more)) }
                                }
                            }
                        }
                    }
                }
                if (s.commentsLoading) item { CircularProgressIndicator() }
                if (s.commentsCursor != null && !s.commentsLoading) item {
                    TextButton(onClick = { viewModel.loadComments() }) { Text(stringResource(R.string.comments_load_more)) }
                }
            }
        }
        s.actionFailure?.let {
            Column(Modifier.padding(horizontal = WwSpacing.md)) {
                FailureBanner(it)
                TextButton(onClick = viewModel::dismissActionFailure) { Text(stringResource(R.string.action_dismiss)) }
            }
        }
        if (s.post != null) {
            Column(Modifier.padding(WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                s.replyingTo?.let { target ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.comment_replying_to, authorName(target.author)), Modifier.weight(1f), style = MaterialTheme.typography.labelMedium)
                        TextButton(onClick = viewModel::cancelReply) { Text(stringResource(R.string.action_cancel)) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = s.draft, onValueChange = viewModel::onDraft, modifier = Modifier.weight(1f), maxLines = 4,
                        label = { Text(stringResource(R.string.comment_hint)) },
                        isError = s.draft.trim().length > PostValidation.COMMENT_MAX,
                    )
                    Button(onClick = viewModel::sendComment, enabled = s.draftValid && !s.sending) { Text(stringResource(R.string.comment_send)) }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.post_delete_title)) },
            text = { Text(stringResource(R.string.post_delete_body)) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; viewModel.deletePost() }) { Text(stringResource(R.string.post_delete)) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
    commentToDelete?.let { c ->
        AlertDialog(
            onDismissRequest = { commentToDelete = null },
            title = { Text(stringResource(R.string.comment_delete_title)) },
            text = { Text(stringResource(R.string.comment_delete_body)) },
            confirmButton = { TextButton(onClick = { commentToDelete = null; viewModel.deleteComment(c) }) { Text(stringResource(R.string.post_delete)) } },
            dismissButton = { TextButton(onClick = { commentToDelete = null }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
    if (editing) {
        var text by rememberSaveable { mutableStateOf(s.post?.body.orEmpty()) }
        AlertDialog(
            onDismissRequest = { editing = false },
            title = { Text(stringResource(R.string.post_edit_title)) },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, minLines = 3, modifier = Modifier.fillMaxWidth()) },
            confirmButton = {
                TextButton(enabled = PostValidation.editBodyValid(text, s.post?.let { it.attachments.isNotEmpty() || it.isShare } == true), onClick = { editing = false; viewModel.editPost(text) }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { editing = false }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
}

@Composable
private fun CommentRow(c: Comment, onReply: (() -> Unit)?, onDelete: (() -> Unit)?, onOpenUser: (String) -> Unit) {
    WwCard {
        val author = c.author
        val visibleAuthor = if (c.authorHidden) null else author
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            UserAvatar(visibleAuthor?.winkwinkId, visibleAuthor?.avatarTag, authorName(visibleAuthor), 28.dp)
            Column {
                Text(
                    if (visibleAuthor == null) stringResource(R.string.comment_author_hidden) else authorName(visibleAuthor),
                    style = MaterialTheme.typography.titleSmall,
                    modifier = if (visibleAuthor != null) Modifier.clickable { onOpenUser(visibleAuthor.winkwinkId) } else Modifier,
                )
                Text(relativeTime(c.createdAt), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(c.body, style = MaterialTheme.typography.bodyMedium)
        if (onReply != null || onDelete != null) {
            Row {
                onReply?.let { TextButton(onClick = it) { Text(stringResource(R.string.comment_reply)) } }
                onDelete?.let { TextButton(onClick = it) { Text(stringResource(R.string.post_delete)) } }
            }
        }
    }
}

// ---------- Zapisane ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedPostsScreen(onBack: () -> Unit, onOpenPost: (String) -> Unit, onOpenUser: (String) -> Unit, viewModel: SavedPostsViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(horizontal = WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
        WwScreenHeader(title = stringResource(R.string.saved_title), onBack = onBack)
        s.failure?.let { f ->
            FailureBanner(f)
            TextButton(onClick = viewModel::refresh) { Text(stringResource(R.string.action_retry)) }
        }
        PullToRefreshBox(isRefreshing = s.loading && s.posts.isNotEmpty(), onRefresh = viewModel::refresh, modifier = Modifier.weight(1f)) {
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm), contentPadding = PaddingValues(bottom = WwSpacing.md)) {
            if (s.loading && s.posts.isEmpty()) item { CircularProgressIndicator() }
            if (!s.loading && s.failure == null && s.posts.isEmpty()) item {
                WwCard {
                    Text(stringResource(R.string.saved_empty_title), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.saved_empty_body), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            items(s.posts, key = { it.id }) { post ->
                PostCard(
                    post = post,
                    onOpen = { onOpenPost(post.id) },
                    onReact = { viewModel.react(post, it) },
                    onUnreact = { viewModel.unreact(post) },
                    onToggleSave = { viewModel.unsave(post) },
                    onOpenAuthor = onOpenUser,
                )
            }
            if (s.loadingMore) item { CircularProgressIndicator() }
            if (s.nextCursor != null && !s.loadingMore) item(key = "more") {
                LaunchedEffect(s.nextCursor) { viewModel.loadMore() }
            }
        }
        }
    }
}

// ---------- Wyszukiwanie publikacji ----------

@Composable
fun SearchPostsScreen(
    onBack: () -> Unit,
    onOpenPost: (String) -> Unit,
    onOpenUser: (String) -> Unit,
    viewModel: SearchPostsViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    val failure = s.failure // lokalna kopia: smart-cast na polu właściwości delegowanej nie jest możliwy
    Column(Modifier.fillMaxSize().padding(horizontal = WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
        WwScreenHeader(title = stringResource(R.string.search_posts_title), onBack = onBack)
        OutlinedTextField(
            value = s.query, onValueChange = viewModel::onQuery, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.search_posts_hint)) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { viewModel.submit() }),
            isError = s.tooLong,
            supportingText = { if (s.tooLong) Text(stringResource(R.string.search_posts_too_long)) },
        )
        if (s.shareNotice) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.post_share_done), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                TextButton(onClick = viewModel::dismissShareNotice) { Text(stringResource(R.string.action_dismiss)) }
            }
        }
        s.actionFailure?.let {
            FailureBanner(it)
            TextButton(onClick = viewModel::dismissActionFailure) { Text(stringResource(R.string.action_dismiss)) }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm), contentPadding = PaddingValues(bottom = WwSpacing.md)) {
            if (s.query.isBlank() || (s.tooShort && !s.searched)) item {
                Text(stringResource(R.string.search_posts_idle), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (s.loading) item { CircularProgressIndicator() }
            if (failure != null && s.posts.isEmpty()) item {
                Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                    FailureBanner(failure)
                    TextButton(onClick = viewModel::retry) { Text(stringResource(R.string.action_retry)) }
                }
            }
            if (s.searched && !s.loading && s.posts.isEmpty() && failure == null) item {
                WwCard {
                    Text(stringResource(R.string.search_posts_empty_title), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.search_posts_empty_body), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            items(s.posts, key = { it.id }) { post ->
                PostCard(
                    post = post,
                    onOpen = { onOpenPost(post.id) },
                    onReact = { viewModel.react(post, it) },
                    onUnreact = { viewModel.unreact(post) },
                    onToggleSave = { viewModel.toggleSave(post) },
                    onOpenAuthor = onOpenUser,
                    onShare = { comment, visibility -> viewModel.share(post, comment, visibility) },
                    onOpenOriginal = onOpenPost,
                )
            }
            if (s.loadingMore) item { CircularProgressIndicator() }
            if (s.nextCursor != null && !s.loadingMore) item(key = "more") {
                LaunchedEffect(s.nextCursor) { viewModel.loadMore() }
            }
            if (failure != null && s.posts.isNotEmpty()) item {
                Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                    FailureBanner(failure)
                    TextButton(onClick = viewModel::loadMore) { Text(stringResource(R.string.action_retry)) }
                }
            }
        }
    }
}
