package app.winkwink.data.remote

import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Operacje tworzące (posty, komentarze, udostępnienia, społeczności, grupy, pliki) dostają nagłówek `Idempotency-Key`
 * (jeśli wywołujący nie ustawił własnego) i są ponawiane przy chwilowej awarii sieci lub 502/503/504 TYM SAMYM kluczem —
 * serwer wykona operację raz i przy ponowieniu zwróci zapisaną odpowiedź. Dzięki temu utrata odpowiedzi nie tworzy duplikatu.
 * Wiadomości używają własnego `clientId` (trwała kolejka), bez tego mechanizmu.
 */
class IdempotentRetryInterceptor(private val sleep: (Long) -> Unit = { Thread.sleep(it) }) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        if (original.method != "POST" || !isCreating(original.url.encodedPath)) return chain.proceed(original)
        val request = if (original.header(HEADER) != null) original
        else original.newBuilder().header(HEADER, UUID.randomUUID().toString()).build()
        var attempt = 0
        while (true) {
            try {
                val response = chain.proceed(request)
                if (response.code !in RETRYABLE || attempt >= MAX_RETRIES) return response
                response.close()
            } catch (e: IOException) {
                // Anulowanie (np. zamknięcie ekranu) i brak dalszego czasu nie są ponawiane.
                if (chain.call().isCanceled() || attempt >= MAX_RETRIES) throw e
            }
            attempt++
            sleep(BACKOFF_MS * attempt)
        }
    }

    companion object {
        const val HEADER = "Idempotency-Key"
        private const val MAX_RETRIES = 2
        private const val BACKOFF_MS = 400L
        private val RETRYABLE = setOf(502, 503, 504)
        private val CREATING = Regex(".*/(posts|communities|conversations/group|attachments|message-attachments|posts/[^/]+/(share|comments))$")
        fun isCreating(path: String) = CREATING.matches(path)
    }
}

/** Wysyłanie i pobieranie plików trwa dłużej niż zwykłe zapytanie JSON (limity zapisu/odczytu są większe; limitu całego wywołania nie ma). */
class TransferTimeoutInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val r = chain.request()
        val upload = r.method in setOf("POST", "PUT") && UPLOAD.matches(r.url.encodedPath)
        val download = r.method == "GET" && DOWNLOAD.matches(r.url.encodedPath)
        return when {
            upload -> chain.withWriteTimeout(120, TimeUnit.SECONDS).withReadTimeout(60, TimeUnit.SECONDS).proceed(r)
            download -> chain.withReadTimeout(60, TimeUnit.SECONDS).proceed(r)
            else -> chain.proceed(r)
        }
    }

    private companion object {
        val UPLOAD = Regex(".*/(attachments|message-attachments|me/avatar|me/background)$")
        val DOWNLOAD = Regex(".*/(attachments|message-attachments)/[^/]+$")
    }
}
