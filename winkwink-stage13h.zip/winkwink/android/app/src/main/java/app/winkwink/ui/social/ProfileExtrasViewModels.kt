package app.winkwink.ui.social

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.Post
import app.winkwink.domain.model.UserSummary
import app.winkwink.domain.repository.FeedRepository
import app.winkwink.domain.repository.ProfileExtrasRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

// ---------- Lista wyciszonych ----------

data class MutedUiState(
    val loading: Boolean = true,
    val users: List<UserSummary> = emptyList(),
    val nextCursor: String? = null,
    val loadingMore: Boolean = false,
    val busyId: String? = null,
    val failure: ApiFailure? = null,
)

@HiltViewModel
class MutedUsersViewModel @Inject constructor(private val repository: ProfileExtrasRepository) : ViewModel() {
    private val _state = MutableStateFlow(MutedUiState())
    val state: StateFlow<MutedUiState> = _state.asStateFlow()

    init { refresh() }

    fun refresh() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val r = repository.muted(null)
            _state.update {
                val page = r.getOrNull()
                it.copy(loading = false, users = page?.users ?: it.users, nextCursor = page?.nextCursor ?: if (page == null) it.nextCursor else null, failure = r.exceptionOrNull() as? ApiFailure)
            }
        }
    }

    fun loadMore() {
        val s = _state.value
        val cursor = s.nextCursor ?: return
        if (s.loadingMore || s.loading) return
        _state.update { it.copy(loadingMore = true, failure = null) }
        viewModelScope.launch {
            val r = repository.muted(cursor)
            _state.update {
                val page = r.getOrNull()
                if (page == null) it.copy(loadingMore = false, failure = r.exceptionOrNull() as? ApiFailure)
                else it.copy(
                    loadingMore = false,
                    users = (it.users + page.users).distinctBy { u -> u.winkwinkId },
                    nextCursor = page.nextCursor,
                )
            }
        }
    }

    /** Użytkownik znika z listy dopiero po potwierdzeniu serwera. */
    fun unmute(user: UserSummary) {
        if (_state.value.busyId != null) return
        _state.update { it.copy(busyId = user.winkwinkId, failure = null) }
        viewModelScope.launch {
            val r = repository.unmute(user.winkwinkId)
            _state.update {
                if (r.isSuccess) it.copy(busyId = null, users = it.users.filterNot { u -> u.winkwinkId == user.winkwinkId })
                else it.copy(busyId = null, failure = r.exceptionOrNull() as? ApiFailure)
            }
        }
    }
}

// ---------- Posty na profilu ----------

data class ProfilePostsUiState(
    val loading: Boolean = true,
    val posts: List<Post> = emptyList(),
    val nextCursor: String? = null,
    val loadingMore: Boolean = false,
    val failure: ApiFailure? = null,
    /** Pierwsze pobranie zakończone (rozróżnia „brak postów” od „jeszcze ładuję”). */
    val loaded: Boolean = false,
)

@HiltViewModel
class ProfilePostsViewModel @Inject constructor(
    private val extras: ProfileExtrasRepository,
    private val feed: FeedRepository,
    savedState: SavedStateHandle,
) : ViewModel() {
    private val identifier: String = checkNotNull(savedState["id"])
    private val _state = MutableStateFlow(ProfilePostsUiState())
    val state: StateFlow<ProfilePostsUiState> = _state.asStateFlow()

    init { refresh() }

    fun refresh() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val r = extras.userPosts(identifier, null)
            _state.update {
                val page = r.getOrNull()
                if (page == null) it.copy(loading = false, failure = r.exceptionOrNull() as? ApiFailure)
                else it.copy(loading = false, loaded = true, posts = page.posts, nextCursor = page.nextCursor)
            }
        }
    }

    fun loadMore() {
        val s = _state.value
        val cursor = s.nextCursor ?: return
        if (s.loadingMore || s.loading) return
        _state.update { it.copy(loadingMore = true, failure = null) }
        viewModelScope.launch {
            val r = extras.userPosts(identifier, cursor)
            _state.update {
                val page = r.getOrNull()
                if (page == null) it.copy(loadingMore = false, failure = r.exceptionOrNull() as? ApiFailure)
                else it.copy(loadingMore = false, posts = (it.posts + page.posts).distinctBy { p -> p.id }, nextCursor = page.nextCursor)
            }
        }
    }

    // Liczniki i stan reakcji zawsze pochodzą z odpowiedzi serwera.
    fun react(post: Post, type: String) = replaceFrom(post.id) { feed.react(post.id, type) }
    fun unreact(post: Post) = replaceFrom(post.id) { feed.unreact(post.id) }

    fun toggleSave(post: Post) {
        viewModelScope.launch {
            val r = feed.setSaved(post.id, !post.saved)
            if (r.isSuccess) replace(post.copy(saved = !post.saved)) else _state.update { it.copy(failure = r.exceptionOrNull() as? ApiFailure) }
        }
    }

    private fun replaceFrom(id: String, call: suspend () -> Result<Post>) {
        viewModelScope.launch {
            val r = call()
            val fresh = r.getOrNull()
            if (fresh != null) replace(fresh) else _state.update { it.copy(failure = r.exceptionOrNull() as? ApiFailure) }
        }
    }

    private fun replace(post: Post) = _state.update { s -> s.copy(posts = s.posts.map { if (it.id == post.id) post else it }) }
}
