package app.winkwink.data.remote

import app.winkwink.domain.repository.SessionStore
import kotlinx.coroutines.runBlocking
import okhttp3.Authenticator
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import okhttp3.Route

class AuthHeaderInterceptor(private val store: SessionStore) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val token = store.session.value?.accessToken ?: return chain.proceed(chain.request())
        return chain.proceed(chain.request().newBuilder().header("Authorization", "Bearer $token").build())
    }
}

/** Po 401 próbuje jednokrotnie odświeżyć sesję i powtórzyć żądanie. */
class TokenAuthenticator(private val refresher: dagger.Lazy<SessionRefresher>) : Authenticator {
    override fun authenticate(route: Route?, response: Response): Request? {
        if (generateSequence(response) { it.priorResponse }.count() > 2) return null
        val sent = response.request.header("Authorization")?.removePrefix("Bearer ")
        val fresh = runBlocking { refresher.get().refreshIfStale(sent) } ?: return null
        return response.request.newBuilder().header("Authorization", "Bearer ${fresh.accessToken}").build()
    }
}
