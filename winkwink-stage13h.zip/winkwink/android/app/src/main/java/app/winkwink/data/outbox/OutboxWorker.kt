package app.winkwink.data.outbox

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.BackoffPolicy
import androidx.work.CoroutineWorker
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import app.winkwink.domain.outbox.OutboxRepository
import app.winkwink.domain.outbox.OutboxRun
import app.winkwink.domain.outbox.OutboxScheduler
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Provider
import javax.inject.Singleton

/** Przejście kolejki wysyłania w tle: WorkManager uruchamia je po powrocie sieci, po restarcie telefonu i procesu. */
@HiltWorker
class OutboxWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val outbox: Provider<OutboxRepository>,
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = when (outbox.get().process()) {
        OutboxRun.DONE -> Result.success()
        OutboxRun.RETRY_LATER -> Result.retry() // wykładniczy backoff ustawiony w WorkManagerOutboxScheduler
    }
}

@Singleton
class WorkManagerOutboxScheduler @Inject constructor(@ApplicationContext private val context: Context) : OutboxScheduler {
    override fun schedule() {
        val request = OneTimeWorkRequestBuilder<OutboxWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
            .build()
        // KEEP: trwające przejście i tak weźmie nowe wiersze; REPLACE przerwałoby wysyłkę w połowie.
        WorkManager.getInstance(context).enqueueUniqueWork(UNIQUE, ExistingWorkPolicy.APPEND_OR_REPLACE, request)
    }

    override fun cancel() { WorkManager.getInstance(context).cancelUniqueWork(UNIQUE) }

    private companion object { const val UNIQUE = "winkwink-outbox" }
}
