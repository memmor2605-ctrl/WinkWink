package app.winkwink.domain.repository

import app.winkwink.domain.model.SessionInfo
import app.winkwink.domain.model.UserAccount

/** Wszystkie metody zwracają Result; porażka zawiera [app.winkwink.domain.model.ApiFailure]. */
interface AuthRepository {
    suspend fun register(email: String, password: String, nickname: String): Result<UserAccount>
    suspend fun login(email: String, password: String): Result<UserAccount>
    /** Zawsze czyści lokalną sesję, nawet gdy serwer jest niedostępny. */
    suspend fun logout()
    suspend fun me(): Result<UserAccount>
    /** Trwale usuwa konto (wymaga hasła). Po sukcesie sesja lokalna jest wyczyszczona. */
    suspend fun deleteAccount(password: String): Result<Unit> =
        Result.failure(app.winkwink.domain.model.ApiFailure("unsupported", "Not supported"))
    suspend fun requestPasswordReset(email: String): Result<Unit>
    suspend fun resetPassword(token: String, newPassword: String): Result<Unit>
    suspend fun changePassword(currentPassword: String, newPassword: String): Result<Unit>
    suspend fun sessions(): Result<List<SessionInfo>>
    suspend fun revokeSession(id: String): Result<Unit>
    suspend fun revokeOtherSessions(): Result<Int>
}
