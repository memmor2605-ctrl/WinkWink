package app.winkwink.domain.media

import kotlinx.coroutines.flow.StateFlow

/** Nagranie zapisane lokalnie, jeszcze niewysłane. */
data class RecordedVoice(val path: String, val durationMs: Long, val sizeBytes: Long)

/** Powód niepowodzenia nagrywania (mapowany na tekst w UI). */
class VoiceRecordException(val code: String) : Exception(code) {
    companion object {
        const val START_FAILED = "record_start_failed"
        const val STOP_FAILED = "record_failed"
        const val TOO_SHORT = "record_too_short"
        const val BUSY = "record_busy"
    }
}

/**
 * Nagrywanie głosu do pliku M4A (AAC w kontenerze MPEG-4) — format obsługiwany przez każde urządzenie z Androidem i przyjmowany przez backend.
 * Jedno nagranie naraz. Uprawnienie mikrofonu musi być przyznane PRZED [start] (sprawdza je i prosi o nie UI).
 */
interface VoiceRecorder {
    val isRecording: Boolean
    fun start(): Result<Unit>
    /** Kończy nagrywanie i zwraca plik; za krótkie nagranie jest odrzucane i kasowane ([VoiceRecordException.TOO_SHORT]). */
    fun stop(): Result<RecordedVoice>
    /** Przerywa nagrywanie i kasuje plik. Bezpieczne, gdy nic nie nagrywa. */
    fun cancel()
    /** Kasuje plik nagrania (np. po wysłaniu albo odrzuceniu podglądu). */
    fun discard(path: String)
    /** Wczytuje nagranie do wysłania (poza głównym wątkiem); null, gdy pliku już nie ma. */
    suspend fun read(path: String): ByteArray?
}

enum class PlaybackStatus { IDLE, LOADING, PLAYING, PAUSED, ERROR }

/**
 * Stan odtwarzania. Jest JEDEN aktywny odtwarzacz w aplikacji: [key] wskazuje, która wiadomość (id załącznika) albo podgląd
 * nagrania gra lub czeka. Rozpoczęcie innego odtwarzania zatrzymuje poprzednie.
 */
data class PlaybackState(
    val key: String? = null,
    val status: PlaybackStatus = PlaybackStatus.IDLE,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
) {
    fun isActive(k: String) = key == k
    fun fraction(k: String, fallbackDurationMs: Long): Float {
        if (key != k) return 0f
        val d = if (durationMs > 0) durationMs else fallbackDurationMs
        return if (d <= 0) 0f else (positionMs.toFloat() / d).coerceIn(0f, 1f)
    }
}

interface VoicePlayback {
    val state: StateFlow<PlaybackState>
    /** Odtwarza/pauzuje głosówkę z serwera (pobiera plik do pamięci podręcznej przy pierwszym użyciu). */
    fun toggleRemote(attachmentId: String, durationHintMs: Long)
    /** Odtwarza/pauzuje lokalny plik (podgląd przed wysłaniem). */
    fun toggleLocal(key: String, path: String, durationHintMs: Long)
    /** Przewija aktywne odtwarzanie do [fraction] (0..1). */
    fun seekTo(key: String, fraction: Float)
    fun stop()
}
