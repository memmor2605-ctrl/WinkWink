package app.winkwink.domain.validation

/** Lustrzane odbicie limitów backendu (backend i tak sprawdza je samodzielnie). */
object CommunityValidation {
    const val NAME_MIN = 3
    const val NAME_MAX = 50
    const val DESCRIPTION_MAX = 500
    const val RULES_MAX = 2000

    fun nameValid(name: String) = name.trim().length in NAME_MIN..NAME_MAX
    fun descriptionValid(v: String) = v.trim().length <= DESCRIPTION_MAX
    fun rulesValid(v: String) = v.trim().length <= RULES_MAX
}
