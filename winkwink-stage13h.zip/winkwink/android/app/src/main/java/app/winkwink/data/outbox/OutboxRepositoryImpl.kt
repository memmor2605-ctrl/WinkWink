package app.winkwink.data.outbox

import app.winkwink.data.local.OutboxDao
import app.winkwink.data.local.OutboxFileEntity
import app.winkwink.data.local.OutboxMessageEntity
import app.winkwink.data.local.OutboxMessageWithFiles
import app.winkwink.data.remote.MessageApi
import app.winkwink.data.remote.SendMessageRequestDto
import app.winkwink.data.remote.apiCall
import app.winkwink.data.remote.toDomain
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.ChatMessage
import app.winkwink.domain.outbox.OutboxDraft
import app.winkwink.domain.outbox.OutboxFile
import app.winkwink.domain.outbox.OutboxMessage
import app.winkwink.domain.outbox.OutboxRepository
import app.winkwink.domain.outbox.OutboxRun
import app.winkwink.domain.outbox.OutboxScheduler
import app.winkwink.domain.outbox.OutboxStatus
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody
import okio.BufferedSink
import okio.source
import java.io.File
import java.util.UUID
import javax.inject.Inject
import javax.inject.Provider
import javax.inject.Singleton

/** Plik jako ciało żądania: strumieniowo z dysku, z jawnym Content-Length (serwer wymaga go z góry). */
internal class FileRequestBody(private val file: File, private val mime: String) : RequestBody() {
    override fun contentType() = mime.toMediaType()
    override fun contentLength() = file.length()
    override fun writeTo(sink: BufferedSink) { file.source().use { sink.writeAll(it) } }
}

private sealed interface Step {
    data object Sent : Step
    data class Retry(val failure: ApiFailure, val counts: Boolean) : Step
    data class Fail(val failure: ApiFailure) : Step
}

/**
 * Trwała kolejka wysyłania (Room). Gwarancje:
 *  - kolejność: wiadomości jednej rozmowy wychodzą po kolei; błąd chwilowy zatrzymuje kolejkę tej rozmowy (kolejność nie zamienia się),
 *    błąd trwały (np. 403) oznacza TĘ wiadomość jako nieudaną i kolejne idą dalej;
 *  - brak duplikatów: `clientId` = id wiersza, serwer zwraca istniejącą wiadomość przy ponowieniu; upload ma stały `Idempotency-Key`;
 *  - lokalne pliki są kasowane dopiero po potwierdzeniu wiadomości przez serwer;
 *  - jedno przejście naraz ([mutex]); wiersze zostawione w SENDING przez ubity proces wracają do QUEUED.
 */
@Singleton
class OutboxRepositoryImpl @Inject constructor(
    private val dao: OutboxDao,
    private val api: MessageApi,
    private val json: Json,
    private val files: OutboxFileStore,
    private val scheduler: Provider<OutboxScheduler>,
) : OutboxRepository {
    private val mutex = Mutex()
    private val _sent = MutableSharedFlow<ChatMessage>(extraBufferCapacity = 32, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    override val sent: SharedFlow<ChatMessage> = _sent.asSharedFlow()

    override fun observe(conversationId: String): Flow<List<OutboxMessage>> =
        dao.observe(conversationId).map { list -> list.map { it.toDomain() } }

    override suspend fun enqueue(draft: OutboxDraft): String {
        val id = UUID.randomUUID().toString()
        val entity = OutboxMessageEntity(id, draft.conversationId, 0, draft.body, draft.replyToId, "QUEUED", 0, null, 0, System.currentTimeMillis())
        val fileRows = draft.files.mapIndexed { i, f -> OutboxFileEntity(UUID.randomUUID().toString(), id, i, f.kind, f.path, f.mime, f.name, f.sizeBytes, f.remoteId) }
        dao.enqueue(entity, fileRows)
        scheduler.get().schedule()
        return id
    }

    override suspend fun retry(id: String) { dao.requeue(id); scheduler.get().schedule() }

    override suspend fun discard(id: String) = withContext(NonCancellable) {
        val rows = dao.files(id)
        // Plik wgrany na serwer, ale niedołączony do wiadomości: wycofujemy (best effort — serwer sprząta porzucone po 24 h).
        rows.mapNotNull { it.remoteId }.forEach { runCatching { apiCall(json) { api.deleteAttachment(it) } } }
        dao.delete(id)
        rows.forEach { files.delete(it.path) }
    }

    override suspend fun clearAll() = withContext(NonCancellable) {
        mutex.withLock { dao.deleteAll(); files.clear() }
    }

    override suspend fun process(): OutboxRun = mutex.withLock {
        dao.resetSending()
        files.sweep(dao.allPaths().toSet(), SWEEP_AGE_MS)
        var retryLater = false
        for (conversation in dao.conversationsWithQueued()) {
            if (!processConversation(conversation)) retryLater = true
        }
        if (retryLater || dao.queuedCount() > 0) OutboxRun.RETRY_LATER else OutboxRun.DONE
    }

    /** @return false, gdy trzeba spróbować później (błąd chwilowy). */
    private suspend fun processConversation(conversationId: String): Boolean {
        for (item in dao.queued(conversationId)) {
            dao.markSending(item.message.id)
            when (val step = sendOne(item)) {
                Step.Sent -> Unit
                is Step.Retry -> {
                    val attempts = item.message.attempts + if (step.counts) 1 else 0
                    if (attempts >= MAX_ATTEMPTS) dao.markFailed(item.message.id, step.failure.code, step.failure.httpStatus)
                    else dao.markRetry(item.message.id, attempts, step.failure.code, step.failure.httpStatus)
                    return false // kolejność: następne wiadomości tej rozmowy czekają
                }
                is Step.Fail -> dao.markFailed(item.message.id, step.failure.code, step.failure.httpStatus)
            }
        }
        return true
    }

    private suspend fun sendOne(item: OutboxMessageWithFiles): Step {
        val m = item.message
        val rows = dao.files(m.id)
        val hadRemote = rows.isNotEmpty() && rows.all { it.remoteId != null }
        var freshUpload = false
        val remoteIds = ArrayList<String>()
        for (f in rows) {
            var remote = f.remoteId
            if (remote == null) {
                val file = File(f.path)
                if (!file.isFile) return Step.Fail(ApiFailure("file_unreadable", "Local file is missing"))
                val up = apiCall(json) { api.uploadAttachment(m.conversationId, if (f.kind == "document") f.name else null, FileRequestBody(file, f.mime), f.id) }
                val dto = up.getOrNull() ?: return classify(up.exceptionOrNull())
                remote = dto.id
                dao.setRemoteId(f.id, remote)
                freshUpload = true
            }
            remoteIds += remote
        }
        val result = apiCall(json) { api.send(m.conversationId, SendMessageRequestDto(m.body, m.replyToId, remoteIds, clientId = m.id)) }
        val dto = result.getOrNull()
        if (dto == null) {
            val failure = result.exceptionOrNull() as? ApiFailure
            if (failure?.code == "attachments_unavailable" && hadRemote && !freshUpload) {
                // Wgrane wcześniej pliki wygasły (serwer sprząta niedołączone po 24 h) — wgramy je ponownie z lokalnej kopii.
                dao.clearRemoteIds(m.id)
                return Step.Retry(failure, counts = true)
            }
            return classify(failure)
        }
        val message = try { dto.toDomain() } catch (e: java.time.DateTimeException) { return Step.Retry(ApiFailure("invalid_response", "Unexpected response"), true) }
        // Dopiero po potwierdzeniu serwera wiersz i lokalne pliki znikają.
        dao.delete(m.id)
        rows.forEach { files.delete(it.path) }
        _sent.tryEmit(message)
        return Step.Sent
    }

    private fun classify(e: Throwable?): Step {
        val f = e as? ApiFailure ?: ApiFailure("unknown", "Unknown error")
        return when {
            f.code == "network" || f.code == "tls" -> Step.Retry(f, counts = false) // brak internetu nie zużywa prób
            f.code == "timeout" || f.httpStatus >= 500 || f.httpStatus == 408 || f.httpStatus == 429 || f.code == "request_in_progress" -> Step.Retry(f, counts = true)
            f.httpStatus == 401 -> Step.Retry(f, counts = false) // sesja zostanie odświeżona albo kolejka zostanie wyczyszczona przy wylogowaniu
            else -> Step.Fail(f)
        }
    }

    private fun OutboxMessageWithFiles.toDomain() = OutboxMessage(
        id = message.id, conversationId = message.conversationId, body = message.body, replyToId = message.replyToId,
        files = files.sortedBy { it.position }.map { OutboxFile(it.id, it.kind, it.path, it.mime, it.name, it.sizeBytes, it.remoteId) },
        status = runCatching { OutboxStatus.valueOf(message.status) }.getOrDefault(OutboxStatus.QUEUED),
        failure = message.failureCode?.takeIf { message.status == "FAILED" || message.attempts > 0 }?.let { ApiFailure(it, it, httpStatus = message.failureHttp) },
    )

    private companion object {
        const val MAX_ATTEMPTS = 10
        const val SWEEP_AGE_MS = 24L * 60 * 60 * 1000
    }
}
