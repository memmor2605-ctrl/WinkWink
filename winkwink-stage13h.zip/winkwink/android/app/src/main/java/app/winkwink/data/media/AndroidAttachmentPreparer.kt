package app.winkwink.data.media

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import app.winkwink.domain.media.AttachmentLimits
import app.winkwink.domain.media.AttachmentPrepareException
import app.winkwink.domain.media.AttachmentPreparer
import app.winkwink.domain.media.ImageKind
import app.winkwink.domain.media.ImagePreparer
import app.winkwink.domain.model.PreparedFile
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AndroidAttachmentPreparer @Inject constructor(
    @ApplicationContext private val context: Context,
    private val images: ImagePreparer,
) : AttachmentPreparer {

    override suspend fun prepare(uri: String): Result<PreparedFile> = withContext(Dispatchers.IO) {
        try {
            val parsed = Uri.parse(uri)
            val resolver = context.contentResolver
            val mime = resolver.getType(parsed)?.lowercase() ?: return@withContext fail(AttachmentPrepareException.UNSUPPORTED)
            val name = displayName(parsed)
            when {
                mime == "image/jpeg" || mime == "image/png" || mime == "image/webp" || mime == "image/heic" || mime == "image/heif" -> {
                    // Dowolny obraz obsługiwany przez system jest dekodowany i zapisywany jako JPEG (bez EXIF).
                    images.prepare(uri, ImageKind.POST).fold(
                        onSuccess = { Result.success(PreparedFile(it, "image/jpeg", null, "image")) },
                        onFailure = { fail(AttachmentPrepareException.UNREADABLE) },
                    )
                }
                mime == "video/mp4" -> read(parsed, AttachmentLimits.VIDEO_MAX_BYTES)?.let {
                    Result.success(PreparedFile(it, "video/mp4", null, "video"))
                } ?: fail(AttachmentPrepareException.TOO_LARGE)
                mime == "application/pdf" -> read(parsed, AttachmentLimits.DOCUMENT_MAX_BYTES)?.let {
                    Result.success(PreparedFile(it, "application/pdf", name ?: "document.pdf", "document"))
                } ?: fail(AttachmentPrepareException.TOO_LARGE)
                else -> fail(AttachmentPrepareException.UNSUPPORTED)
            }
        } catch (e: AttachmentPrepareException) {
            Result.failure(e)
        } catch (e: OutOfMemoryError) {
            fail(AttachmentPrepareException.TOO_LARGE)
        } catch (e: Exception) {
            fail(AttachmentPrepareException.UNREADABLE)
        }
    }

    private fun fail(code: String): Result<PreparedFile> = Result.failure(AttachmentPrepareException(code))

    private fun displayName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()

    /** Czyta plik z limitem; null = przekroczono limit (czytanie przerywane, żeby nie ładować wielkiego pliku do pamięci). */
    private fun read(uri: Uri, max: Int): ByteArray? {
        val input = context.contentResolver.openInputStream(uri) ?: throw AttachmentPrepareException(AttachmentPrepareException.UNREADABLE)
        input.use { stream ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(64 * 1024)
            var total = 0
            while (true) {
                val n = stream.read(buffer)
                if (n < 0) break
                total += n
                if (total > max) return null
                out.write(buffer, 0, n)
            }
            return out.toByteArray()
        }
    }
}
