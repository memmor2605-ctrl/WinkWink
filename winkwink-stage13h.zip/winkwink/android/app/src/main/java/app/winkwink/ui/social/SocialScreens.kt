package app.winkwink.ui.social

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.material3.Switch
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import app.winkwink.domain.media.ImageKind
import app.winkwink.domain.model.UserSummary
import app.winkwink.ui.components.ProfileBackground
import app.winkwink.ui.components.UserAvatar
import app.winkwink.ui.feed.PostCard
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.winkwink.R
import app.winkwink.ui.auth.FailureBanner
import app.winkwink.ui.components.WwCard
import app.winkwink.ui.components.WwPrimaryButton
import app.winkwink.ui.components.WwScreenHeader
import app.winkwink.ui.theme.WwSpacing

@Composable
fun UserSearchScreen(onBack: () -> Unit, onOpenUser: (String) -> Unit, viewModel: UserSearchViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().imePadding().padding(WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.md)) {
        WwScreenHeader(title = stringResource(R.string.search_users_title), onBack = onBack)
        OutlinedTextField(
            value = s.query,
            onValueChange = viewModel::onQuery,
            label = { Text(stringResource(R.string.search_users_hint)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        s.failure?.let { FailureBanner(it) }
        when {
            s.loading -> CircularProgressIndicator()
            s.searched && s.results.isEmpty() -> WwCard {
                Text(stringResource(R.string.search_users_empty_title), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.search_users_empty_body), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                items(s.results, key = { it.winkwinkId }) { u ->
                    WwCard(Modifier.clickable { onOpenUser(u.winkwinkId) }) { UserHeaderRow(u) }
                }
            }
        }
    }
}

/** Awatar + nazwa + @nick; wspólny wiersz list użytkowników. */
@Composable
internal fun UserHeaderRow(u: UserSummary) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
        UserAvatar(u.winkwinkId, u.avatarTag, u.displayName ?: u.nickname, 44.dp)
        Column {
            Text(u.displayName ?: u.nickname, style = MaterialTheme.typography.titleMedium)
            Text("@${u.nickname}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun UserProfileScreen(
    onBack: () -> Unit,
    onEditProfile: () -> Unit,
    onOpenFollowers: (String) -> Unit,
    onOpenFollowing: (String) -> Unit,
    onOpenPost: (String) -> Unit,
    onOpenUser: (String) -> Unit,
    /** Otwiera rozmowę 1:1 z tym użytkownikiem (argument: WinkWink ID). */
    onMessage: (String) -> Unit,
    viewModel: UserProfileViewModel = hiltViewModel(),
    postsViewModel: ProfilePostsViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    var confirmBlock by rememberSaveable { mutableStateOf(false) }
    val uriHandler = LocalUriHandler.current

    // Po udanej blokadzie profil przestaje być dostępny — wracamy (efekt uboczny poza kompozycją).
    LaunchedEffect(s.blocked) { if (s.blocked) onBack() }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(WwSpacing.md),
        verticalArrangement = Arrangement.spacedBy(WwSpacing.md),
    ) {
        WwScreenHeader(title = stringResource(R.string.user_profile_title), onBack = onBack)
        if (s.loading && s.profile == null) CircularProgressIndicator()
        s.failure?.let {
            FailureBanner(it)
            TextButton(onClick = viewModel::load) { Text(stringResource(R.string.action_retry)) }
        }
        s.profile?.let { p ->
            // Tło tylko w pełnym widoku (serwer i tak nie zwróci znacznika dla widoku ograniczonego).
            if (p.backgroundTag != null) ProfileBackground(p.winkwinkId, p.backgroundTag)
            WwCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.md)) {
                    UserAvatar(p.winkwinkId, p.avatarTag, p.displayName ?: p.nickname, 64.dp)
                    Column {
                        Text(p.displayName ?: p.nickname, style = MaterialTheme.typography.headlineSmall)
                        Text("@${p.nickname} · ${p.winkwinkId}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (!p.restricted) {
                    Text(
                        stringResource(R.string.user_profile_counts, p.followers ?: 0, p.following ?: 0),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    if (!p.followListsHidden || p.isSelf) {
                        Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                            TextButton(onClick = { onOpenFollowers(p.winkwinkId) }) { Text(stringResource(R.string.ulist_followers)) }
                            TextButton(onClick = { onOpenFollowing(p.winkwinkId) }) { Text(stringResource(R.string.ulist_following)) }
                        }
                    } else {
                        Text(stringResource(R.string.user_profile_lists_hidden), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    p.bio?.takeIf { it.isNotBlank() }?.let { Text(it, style = MaterialTheme.typography.bodyLarge) }
                    p.links.forEach { link -> TextButton(onClick = { uriHandler.openUri(link) }) { Text(link) } }
                } else {
                    Text(stringResource(R.string.user_profile_restricted), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (p.followedByThem && !p.isSelf) {
                    Text(stringResource(R.string.user_profile_follows_you), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
            }
            if (p.isSelf) {
                WwPrimaryButton(text = stringResource(R.string.edit_profile_title), onClick = onEditProfile)
            } else {
                val label = when (p.followState) {
                    "accepted" -> R.string.follow_state_following
                    "pending" -> R.string.follow_state_requested
                    else -> R.string.follow_action
                }
                if (p.followState == "none") {
                    WwPrimaryButton(text = stringResource(label), onClick = viewModel::toggleFollow, loading = s.actionInProgress)
                } else {
                    OutlinedButton(onClick = viewModel::toggleFollow, enabled = !s.actionInProgress, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(label))
                    }
                }
                OutlinedButton(onClick = { onMessage(p.winkwinkId) }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.msg_profile_action))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                    TextButton(onClick = viewModel::toggleMute, enabled = !s.actionInProgress) {
                        Text(stringResource(if (p.muted) R.string.unmute_action else R.string.mute_action))
                    }
                    TextButton(onClick = { confirmBlock = true }, enabled = !s.actionInProgress) { Text(stringResource(R.string.block_action)) }
                }
                if (p.muted) {
                    Text(stringResource(R.string.user_profile_muted_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (!p.restricted) {
                val ps by postsViewModel.state.collectAsStateWithLifecycle()
                Text(stringResource(R.string.profile_posts_title), style = MaterialTheme.typography.titleMedium)
                ps.failure?.let {
                    FailureBanner(it)
                    TextButton(onClick = postsViewModel::refresh) { Text(stringResource(R.string.action_retry)) }
                }
                if (ps.loading && !ps.loaded) CircularProgressIndicator()
                if (ps.loaded && ps.posts.isEmpty() && ps.failure == null) {
                    Text(stringResource(R.string.profile_posts_empty), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                ps.posts.forEach { post ->
                    PostCard(
                        post = post,
                        onOpen = { onOpenPost(post.id) },
                        onReact = { postsViewModel.react(post, it) },
                        onUnreact = { postsViewModel.unreact(post) },
                        onToggleSave = { postsViewModel.toggleSave(post) },
                        onOpenAuthor = { id -> if (id != p.winkwinkId) onOpenUser(id) },
                    )
                }
                if (ps.nextCursor != null) {
                    if (ps.loadingMore) CircularProgressIndicator()
                    else TextButton(onClick = postsViewModel::loadMore) { Text(stringResource(R.string.ulist_load_more)) }
                }
            }
        }
    }

    if (confirmBlock) {
        AlertDialog(
            onDismissRequest = { confirmBlock = false },
            title = { Text(stringResource(R.string.block_confirm_title)) },
            text = { Text(stringResource(R.string.block_confirm_body)) },
            confirmButton = { TextButton(onClick = { confirmBlock = false; viewModel.block() }) { Text(stringResource(R.string.block_action)) } },
            dismissButton = { TextButton(onClick = { confirmBlock = false }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
}

@Composable
fun EditProfileScreen(onBack: () -> Unit, viewModel: EditProfileViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    var confirmRemove by rememberSaveable { mutableStateOf<String?>(null) }
    val pickAvatar = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.onImagePicked(ImageKind.AVATAR, uri.toString())
    }
    val pickBackground = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.onImagePicked(ImageKind.BACKGROUND, uri.toString())
    }
    val imageOnly = PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(WwSpacing.md),
        verticalArrangement = Arrangement.spacedBy(WwSpacing.md),
    ) {
        WwScreenHeader(title = stringResource(R.string.edit_profile_title), onBack = onBack)
        if (s.loading) { CircularProgressIndicator(); return@Column }
        val selfId = s.selfId
        if (selfId != null) {
            WwCard {
                Text(stringResource(R.string.profile_avatar_title), style = MaterialTheme.typography.titleMedium)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.md)) {
                    UserAvatar(selfId, s.avatarTag, s.displayName.ifBlank { selfId }, 72.dp)
                    Column {
                        TextButton(onClick = { pickAvatar.launch(imageOnly) }, enabled = s.imageBusy == null) {
                            Text(stringResource(if (s.avatarTag == null) R.string.image_choose else R.string.image_change))
                        }
                        if (s.avatarTag != null) {
                            TextButton(onClick = { confirmRemove = ImageKind.AVATAR.name }, enabled = s.imageBusy == null) { Text(stringResource(R.string.image_remove)) }
                        }
                    }
                    if (s.imageBusy == ImageKind.AVATAR) CircularProgressIndicator(Modifier.size(24.dp))
                }
            }
            WwCard {
                Text(stringResource(R.string.profile_background_title), style = MaterialTheme.typography.titleMedium)
                ProfileBackground(selfId, s.backgroundTag)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { pickBackground.launch(imageOnly) }, enabled = s.imageBusy == null) {
                        Text(stringResource(if (s.backgroundTag == null) R.string.image_choose else R.string.image_change))
                    }
                    if (s.backgroundTag != null) {
                        TextButton(onClick = { confirmRemove = ImageKind.BACKGROUND.name }, enabled = s.imageBusy == null) { Text(stringResource(R.string.image_remove)) }
                    }
                    if (s.imageBusy == ImageKind.BACKGROUND) CircularProgressIndicator(Modifier.size(24.dp))
                }
                Text(stringResource(R.string.image_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                s.imageFailure?.let { FailureBanner(it) }
            }
        }
        OutlinedTextField(
            value = s.displayName, onValueChange = viewModel::onName, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.field_display_name)) }, isError = s.nameTooLong,
            supportingText = { if (s.nameTooLong) Text(stringResource(R.string.err_display_name_long)) },
        )
        OutlinedTextField(
            value = s.bio, onValueChange = viewModel::onBio, minLines = 3, modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.field_bio)) }, isError = s.bioTooLong,
            supportingText = { Text(if (s.bioTooLong) stringResource(R.string.err_bio_long) else "${s.bio.trim().length}/280") },
        )
        OutlinedTextField(
            value = s.linksText, onValueChange = viewModel::onLinks, minLines = 2, modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.field_links)) }, isError = s.tooManyLinks,
            supportingText = { Text(stringResource(if (s.tooManyLinks) R.string.err_links_many else R.string.field_links_help)) },
        )
        Text(stringResource(R.string.field_visibility), style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            listOf("public" to R.string.vis_public, "followers" to R.string.vis_followers, "private" to R.string.vis_private).forEach { (v, res) ->
                FilterChip(selected = s.visibility == v, onClick = { viewModel.onVisibility(v) }, label = { Text(stringResource(res)) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.md)) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.field_hide_follow_lists), style = MaterialTheme.typography.bodyLarge)
                Text(stringResource(R.string.field_hide_follow_lists_help), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = s.hideFollowLists, onCheckedChange = viewModel::onHideFollowLists)
        }
        s.failure?.let { FailureBanner(it) }
        if (s.saved) Text(stringResource(R.string.edit_profile_saved), color = MaterialTheme.colorScheme.primary)
        WwPrimaryButton(text = stringResource(R.string.action_save), onClick = viewModel::save, loading = s.saving)
    }

    confirmRemove?.let { kindName ->
        AlertDialog(
            onDismissRequest = { confirmRemove = null },
            title = { Text(stringResource(R.string.image_remove_confirm_title)) },
            text = { Text(stringResource(R.string.image_remove_confirm_body)) },
            confirmButton = {
                TextButton(onClick = { confirmRemove = null; viewModel.removeImage(ImageKind.valueOf(kindName)) }) { Text(stringResource(R.string.image_remove)) }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = null }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
}

@Composable
fun MutedUsersScreen(onBack: () -> Unit, onOpenUser: (String) -> Unit, viewModel: MutedUsersViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.md)) {
        WwScreenHeader(title = stringResource(R.string.ulist_muted), onBack = onBack)
        Text(stringResource(R.string.muted_explainer), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        s.failure?.let {
            FailureBanner(it)
            TextButton(onClick = viewModel::refresh) { Text(stringResource(R.string.action_retry)) }
        }
        when {
            s.loading -> CircularProgressIndicator()
            s.users.isEmpty() && s.failure == null -> Text(
                stringResource(R.string.ulist_empty), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                items(s.users, key = { it.winkwinkId }) { u ->
                    WwCard(Modifier.clickable { onOpenUser(u.winkwinkId) }) {
                        UserHeaderRow(u)
                        OutlinedButton(onClick = { viewModel.unmute(u) }, enabled = s.busyId == null) { Text(stringResource(R.string.unmute_action)) }
                    }
                }
                if (s.nextCursor != null) {
                    item(key = "more") {
                        if (s.loadingMore) CircularProgressIndicator()
                        else TextButton(onClick = viewModel::loadMore) { Text(stringResource(R.string.ulist_load_more)) }
                    }
                }
            }
        }
    }
}

@Composable
fun UserListScreen(onBack: () -> Unit, onOpenUser: (String) -> Unit, viewModel: UserListViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    val titleRes = when (viewModel.kind) {
        UserListKind.FOLLOWERS -> R.string.ulist_followers
        UserListKind.FOLLOWING -> R.string.ulist_following
        UserListKind.REQUESTS -> R.string.ulist_requests
        UserListKind.BLOCKED -> R.string.ulist_blocked
    }
    Column(Modifier.fillMaxSize().padding(WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.md)) {
        WwScreenHeader(title = stringResource(titleRes), onBack = onBack)
        s.failure?.let {
            FailureBanner(it)
            TextButton(onClick = viewModel::refresh) { Text(stringResource(R.string.action_retry)) }
        }
        when {
            s.loading -> CircularProgressIndicator()
            s.users.isEmpty() && s.failure == null -> Text(
                stringResource(R.string.ulist_empty), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                items(s.users, key = { it.winkwinkId }) { u ->
                    WwCard(Modifier.clickable { onOpenUser(u.winkwinkId) }) {
                        UserHeaderRow(u)
                        val busy = s.busyId == u.winkwinkId
                        when (viewModel.kind) {
                            UserListKind.REQUESTS -> Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                                OutlinedButton(onClick = { viewModel.approve(u) }, enabled = s.busyId == null) { Text(stringResource(R.string.ulist_approve)) }
                                TextButton(onClick = { viewModel.reject(u) }, enabled = s.busyId == null) { Text(stringResource(R.string.ulist_reject)) }
                                if (busy) CircularProgressIndicator()
                            }
                            UserListKind.BLOCKED -> OutlinedButton(onClick = { viewModel.unblock(u) }, enabled = s.busyId == null) {
                                Text(stringResource(R.string.ulist_unblock))
                            }
                            else -> Unit
                        }
                    }
                }
                if (s.nextCursor != null) {
                    item(key = "more") {
                        if (s.loadingMore) CircularProgressIndicator()
                        else TextButton(onClick = viewModel::loadMore) { Text(stringResource(R.string.ulist_load_more)) }
                    }
                }
            }
        }
    }
}
