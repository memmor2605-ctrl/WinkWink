package app.winkwink.data.repository

import app.winkwink.data.remote.CreateCommentRequestDto
import app.winkwink.data.remote.CreatePostRequestDto
import app.winkwink.data.remote.FeedApi
import app.winkwink.data.remote.ReactionRequestDto
import app.winkwink.data.remote.SharePostRequestDto
import app.winkwink.data.remote.UpdatePostRequestDto
import app.winkwink.data.remote.apiCall
import app.winkwink.data.remote.streamBody
import app.winkwink.data.remote.streamToFile
import app.winkwink.data.remote.toDomain
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.Attachment
import app.winkwink.domain.model.Comment
import app.winkwink.domain.model.CommentPage
import app.winkwink.domain.model.FeedKind
import app.winkwink.domain.model.Post
import app.winkwink.domain.model.PostPage
import app.winkwink.domain.model.PreparedFile
import app.winkwink.domain.repository.FeedRepository
import app.winkwink.domain.validation.PostValidation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FeedRepositoryImpl @Inject constructor(
    private val api: FeedApi,
    private val json: Json,
) : FeedRepository {

    override suspend fun feed(kind: FeedKind, cursor: String?): Result<PostPage> = withContext(Dispatchers.IO) {
        apiCall(json) {
            when (kind) {
                FeedKind.Following -> api.following(PAGE_SIZE, cursor)
                FeedKind.Discover -> api.discover(PAGE_SIZE, cursor)
            }
        }.mapDomain { it.toDomain() }
    }

    override suspend fun saved(cursor: String?): Result<PostPage> = withContext(Dispatchers.IO) {
        apiCall(json) { api.saved(PAGE_SIZE, cursor) }.mapDomain { it.toDomain() }
    }

    override suspend fun post(id: String): Result<Post> = withContext(Dispatchers.IO) {
        apiCall(json) { api.post(id) }.mapDomain { it.toDomain() }
    }

    override suspend fun createPost(body: String, visibility: String, anonymous: Boolean, attachmentIds: List<String>): Result<Post> = withContext(Dispatchers.IO) {
        val request = CreatePostRequestDto(body.trim(), PostValidation.visibilityFor(anonymous, visibility), anonymous, attachmentIds = attachmentIds)
        apiCall(json) { api.createPost(request) }.mapDomain { it.toDomain() }
    }

    override suspend fun createCommunityPost(body: String, communityId: String, channelId: String, attachmentIds: List<String>): Result<Post> = withContext(Dispatchers.IO) {
        val request = CreatePostRequestDto(body.trim(), "community", false, communityId, channelId, attachmentIds)
        apiCall(json) { api.createPost(request) }.mapDomain { it.toDomain() }
    }

    override suspend fun updatePost(id: String, body: String): Result<Post> = withContext(Dispatchers.IO) {
        apiCall(json) { api.updatePost(id, UpdatePostRequestDto(body.trim())) }.mapDomain { it.toDomain() }
    }

    override suspend fun deletePost(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { api.deletePost(id) }.map { }
    }

    override suspend fun react(id: String, type: String): Result<Post> = withContext(Dispatchers.IO) {
        apiCall(json) { api.react(id, ReactionRequestDto(type)) }.mapDomain { it.toDomain() }
    }

    override suspend fun unreact(id: String): Result<Post> = withContext(Dispatchers.IO) {
        apiCall(json) { api.unreact(id) }.mapDomain { it.toDomain() }
    }

    override suspend fun setSaved(id: String, saved: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { if (saved) api.save(id) else api.unsave(id) }.map { }
    }

    override suspend fun comments(postId: String, parentId: String?, cursor: String?): Result<CommentPage> = withContext(Dispatchers.IO) {
        apiCall(json) {
            if (parentId == null) api.comments(postId, PAGE_SIZE, cursor) else api.replies(postId, parentId, PAGE_SIZE, cursor)
        }.mapDomain { it.toDomain() }
    }

    override suspend fun addComment(postId: String, parentId: String?, body: String): Result<Comment> = withContext(Dispatchers.IO) {
        apiCall(json) { api.addComment(postId, CreateCommentRequestDto(body.trim(), parentId)) }.mapDomain { it.toDomain() }
    }

    override suspend fun deleteComment(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { api.deleteComment(id) }.map { }
    }

    override suspend fun search(query: String, cursor: String?): Result<PostPage> = withContext(Dispatchers.IO) {
        apiCall(json) { api.search(query.trim(), PAGE_SIZE, cursor) }.mapDomain { it.toDomain() }
    }

    override suspend fun share(id: String, comment: String, visibility: String): Result<Post> = withContext(Dispatchers.IO) {
        apiCall(json) { api.share(id, SharePostRequestDto(comment.trim(), visibility)) }.mapDomain { it.toDomain() }
    }

    override suspend fun uploadAttachment(file: PreparedFile): Result<Attachment> = withContext(Dispatchers.IO) {
        val body = file.bytes.toRequestBody(file.mime.toMediaType())
        apiCall(json) { api.uploadAttachment(body, file.name) }.map { it.toDomain() }
    }

    override suspend fun deleteAttachment(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { api.deleteAttachment(id) }.map { }
    }

    override suspend fun downloadAttachment(id: String): Result<ByteArray> = withContext(Dispatchers.IO) {
        val out = java.io.ByteArrayOutputStream()
        streamBody({ api.downloadAttachment(id) }) { buf, n ->
            if (out.size() + n > 32 * 1024 * 1024) throw IOException("too large for memory")
            out.write(buf, 0, n)
        }.map { out.toByteArray() }
    }

    override suspend fun downloadAttachmentToFile(id: String, target: java.io.File): Result<Unit> = streamToFile({ api.downloadAttachment(id) }, target)

    /** Błąd mapowania (np. zły format daty) to „nieoczekiwana odpowiedź”, a nie wyjątek przeciekający do UI. */
    private inline fun <T, R> Result<T>.mapDomain(transform: (T) -> R): Result<R> = fold(
        onSuccess = { value ->
            try { Result.success(transform(value)) } catch (e: java.time.DateTimeException) {
                Result.failure(ApiFailure("invalid_response", "Unexpected response"))
            }
        },
        onFailure = { Result.failure(it) },
    )

    private companion object { const val PAGE_SIZE = 20 }
}
