package app.winkwink.data.remote

import app.winkwink.domain.model.ServerHealth
import kotlinx.serialization.Serializable

@Serializable
data class HealthDto(
    val status: String,
    val service: String,
    val apiVersion: String,
    val appVersion: String,
    val environment: String,
    val serverTime: String,
    val database: DatabaseHealthDto,
)

@Serializable
data class DatabaseHealthDto(
    val status: String,
    val latencyMs: Long? = null,
    val schemaVersion: String? = null,
)

fun HealthDto.toDomain(roundTripMs: Long) = ServerHealth(
    status = status,
    service = service,
    apiVersion = apiVersion,
    appVersion = appVersion,
    environment = environment,
    serverTime = serverTime,
    databaseUp = database.status == "up",
    databaseLatencyMs = database.latencyMs,
    schemaVersion = database.schemaVersion,
    roundTripMs = roundTripMs,
)
