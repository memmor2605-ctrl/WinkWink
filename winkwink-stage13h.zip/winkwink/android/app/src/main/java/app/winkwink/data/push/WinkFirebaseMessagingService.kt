package app.winkwink.data.push

import app.winkwink.domain.push.PushRegistrar
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class WinkFirebaseMessagingService : FirebaseMessagingService() {
    @Inject lateinit var presenter: PushNotificationPresenter
    @Inject lateinit var registrar: PushRegistrar
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** FCM odnowił token: rejestrujemy go od razu (bez zalogowanej sesji [PushRegistrar.register] nic nie robi). */
    override fun onNewToken(token: String) {
        scope.launch { registrar.register() }
    }

    /** Backend wysyła wyłącznie wiadomości danych, więc ta metoda działa także przy zamkniętej aplikacji. */
    override fun onMessageReceived(message: RemoteMessage) {
        presenter.handle(message.data)
    }
}
