package app.winkwink.domain.repository

import app.winkwink.domain.model.Channel
import app.winkwink.domain.model.Community
import app.winkwink.domain.model.InviteCandidate
import app.winkwink.domain.model.CommunityPage
import app.winkwink.domain.model.PersonPage
import app.winkwink.domain.model.PostPage

interface CommunityRepository {
    suspend fun mine(cursor: String?): Result<CommunityPage>
    suspend fun invites(cursor: String?): Result<CommunityPage>
    suspend fun search(query: String, cursor: String?): Result<CommunityPage>
    suspend fun create(name: String, description: String, rules: String, type: String): Result<Community>
    suspend fun get(id: String): Result<Community>
    /** Zmienia tylko podane (niepuste) pola; zmiana typu wymaga właściciela, reszta administratora (egzekwuje backend). */
    suspend fun update(id: String, name: String?, description: String?, rules: String?, type: String?): Result<Community>
    /** Zwraca stan: "member" albo "requested". */
    suspend fun join(id: String): Result<String>
    suspend fun leave(id: String): Result<Unit>
    suspend fun cancelRequest(id: String): Result<Unit>
    suspend fun respondToInvite(id: String, accept: Boolean): Result<Unit>
    suspend fun channels(id: String): Result<List<Channel>>
    suspend fun members(id: String, cursor: String?): Result<PersonPage>
    suspend fun setRole(id: String, userId: String, role: String): Result<Unit>
    suspend fun removeMember(id: String, userId: String): Result<Unit>
    suspend fun invite(id: String, userId: String): Result<Unit>
    /** Wyszukiwanie osób do zaproszenia (moderator+; min. 2 znaki); członkowie są pomijani. */
    suspend fun inviteCandidates(id: String, query: String): Result<List<InviteCandidate>>
    /** Tylko właściciel; dotychczasowy właściciel zostaje administratorem. */
    suspend fun transferOwnership(id: String, userId: String): Result<Unit>
    suspend fun setMuted(id: String, userId: String, muted: Boolean): Result<Unit>
    suspend fun requests(id: String, cursor: String?): Result<PersonPage>
    suspend fun decideRequest(id: String, userId: String, approve: Boolean): Result<Unit>
    suspend fun createChannel(id: String, name: String): Result<Channel>
    suspend fun deleteChannel(id: String, channelId: String): Result<Unit>
    suspend fun delete(id: String): Result<Unit>
    /** Posty społeczności (tylko dla członków); [channelId] = null → wszystkie kanały. */
    suspend fun posts(id: String, channelId: String?, cursor: String?): Result<PostPage>
}
