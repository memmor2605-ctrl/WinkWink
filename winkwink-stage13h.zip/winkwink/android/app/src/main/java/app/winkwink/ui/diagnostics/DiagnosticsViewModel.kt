package app.winkwink.ui.diagnostics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.winkwink.BuildConfig
import app.winkwink.domain.model.ConnectionFailure
import app.winkwink.domain.model.HealthCheckResult
import app.winkwink.domain.model.ServerHealth
import app.winkwink.domain.repository.DiagnosticsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface DiagnosticsUiState {
    data object Loading : DiagnosticsUiState
    data class Success(val health: ServerHealth) : DiagnosticsUiState
    data class Failure(val failure: ConnectionFailure) : DiagnosticsUiState
}

@HiltViewModel
class DiagnosticsViewModel @Inject constructor(
    private val repository: DiagnosticsRepository,
) : ViewModel() {

    val endpoint: String = BuildConfig.API_BASE_URL + "api/v1/health"

    private val _state = MutableStateFlow<DiagnosticsUiState>(DiagnosticsUiState.Loading)
    val state: StateFlow<DiagnosticsUiState> = _state.asStateFlow()

    private var job: Job? = null

    init {
        check()
    }

    fun check() {
        if (job?.isActive == true) return
        job = viewModelScope.launch {
            _state.value = DiagnosticsUiState.Loading
            _state.value = when (val result = repository.checkHealth()) {
                is HealthCheckResult.Success -> DiagnosticsUiState.Success(result.health)
                is HealthCheckResult.Failure -> DiagnosticsUiState.Failure(result.failure)
            }
        }
    }
}
