package app.winkwink.data.session

import android.content.Context
import android.util.Base64
import app.winkwink.domain.model.StoredSession
import app.winkwink.domain.repository.SessionStore
import com.google.crypto.tink.Aead
import com.google.crypto.tink.KeyTemplates
import com.google.crypto.tink.RegistryConfiguration
import com.google.crypto.tink.aead.AeadConfig
import com.google.crypto.tink.integration.android.AndroidKeysetManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.security.GeneralSecurityException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Tokeny sesji szyfrowane Tink AEAD (AES-256-GCM). Klucz główny nigdy nie opuszcza Android Keystore;
 * w SharedPreferences leży wyłącznie szyfrogram. Backup aplikacji jest wyłączony w manifeście.
 */
@Singleton
class SecureSessionStore @Inject constructor(
    @ApplicationContext private val context: Context,
) : SessionStore {

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private val aead: Aead by lazy {
        AeadConfig.register()
        AndroidKeysetManager.Builder()
            .withSharedPref(context, KEYSET_NAME, KEYSET_PREFS)
            .withKeyTemplate(KeyTemplates.get("AES256_GCM"))
            .withMasterKeyUri(MASTER_KEY_URI)
            .build()
            .keysetHandle
            .getPrimitive(RegistryConfiguration.get(), Aead::class.java)
    }

    private val state = MutableStateFlow(readStored())
    override val session: StateFlow<StoredSession?> = state

    override suspend fun save(session: StoredSession) = withContext(Dispatchers.IO) {
        val plain = listOf(session.sessionId, session.accessToken, session.refreshToken).joinToString("\n")
        val cipher = aead.encrypt(plain.toByteArray(Charsets.UTF_8), AAD)
        prefs.edit().putString(KEY, Base64.encodeToString(cipher, Base64.NO_WRAP)).commit()
        state.value = session
    }

    override suspend fun clear() = withContext(Dispatchers.IO) {
        prefs.edit().remove(KEY).commit()
        state.value = null
    }

    private fun readStored(): StoredSession? {
        val encoded = prefs.getString(KEY, null) ?: return null
        return try {
            val plain = aead.decrypt(Base64.decode(encoded, Base64.NO_WRAP), AAD).toString(Charsets.UTF_8)
            val parts = plain.split('\n')
            if (parts.size == 3) StoredSession(parts[0], parts[1], parts[2]) else null
        } catch (e: GeneralSecurityException) {
            // Klucz unieważniony lub dane uszkodzone: wymuszamy ponowne logowanie zamiast crashu.
            prefs.edit().remove(KEY).apply()
            null
        } catch (e: IllegalArgumentException) {
            prefs.edit().remove(KEY).apply()
            null
        }
    }

    private companion object {
        const val PREFS = "winkwink_session"
        const val KEY = "session_blob"
        const val KEYSET_NAME = "ww_session_keyset"
        const val KEYSET_PREFS = "ww_keyset_prefs"
        const val MASTER_KEY_URI = "android-keystore://winkwink_session_master"
        val AAD = "winkwink-session-v1".toByteArray(Charsets.UTF_8)
    }
}
