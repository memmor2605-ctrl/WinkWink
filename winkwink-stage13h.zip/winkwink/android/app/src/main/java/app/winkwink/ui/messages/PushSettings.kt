package app.winkwink.ui.messages

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import app.winkwink.R
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.push.PushSettings
import app.winkwink.domain.push.PushSettingsRepository
import app.winkwink.ui.auth.FailureBanner
import app.winkwink.ui.components.WwCard
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class PushSettingsUiState(val settings: PushSettings? = null, val loading: Boolean = true, val saving: Boolean = false, val failure: ApiFailure? = null)

@HiltViewModel
class PushSettingsViewModel @Inject constructor(private val repository: PushSettingsRepository) : ViewModel() {
    private val _state = MutableStateFlow(PushSettingsUiState())
    val state: StateFlow<PushSettingsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val r = repository.settings()
            _state.update { it.copy(loading = false, settings = r.getOrNull(), failure = r.exceptionOrNull() as? ApiFailure) }
        }
    }

    /** Przełączniki zmieniają się dopiero po potwierdzeniu serwera. */
    fun update(messages: Boolean? = null, previews: Boolean? = null) {
        if (_state.value.saving) return
        _state.update { it.copy(saving = true, failure = null) }
        viewModelScope.launch {
            val r = repository.update(messages, previews)
            _state.update { it.copy(saving = false, settings = r.getOrNull() ?: it.settings, failure = r.exceptionOrNull() as? ApiFailure) }
        }
    }
}

@Composable
fun PushSettingsCard(viewModel: PushSettingsViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    val settings = s.settings
    WwCard {
        Text(stringResource(R.string.push_title), style = MaterialTheme.typography.titleMedium)
        s.failure?.let { FailureBanner(it) }
        if (settings != null) {
            if (!settings.configured) Text(stringResource(R.string.push_not_configured), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.push_messages), modifier = Modifier.weight(1f))
                Switch(checked = settings.messages, onCheckedChange = { viewModel.update(messages = it) }, enabled = !s.saving)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.push_previews), modifier = Modifier.weight(1f))
                Switch(checked = settings.previews, onCheckedChange = { viewModel.update(previews = it) }, enabled = !s.saving && settings.messages)
            }
            Text(stringResource(R.string.push_previews_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
