package app.winkwink.ui.community

import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.winkwink.R
import app.winkwink.domain.model.Community
import app.winkwink.domain.validation.CommunityValidation
import app.winkwink.domain.validation.PostValidation
import app.winkwink.ui.auth.FailureBanner
import app.winkwink.ui.components.WwCard
import app.winkwink.ui.components.WwPrimaryButton
import app.winkwink.ui.components.WwScreenHeader
import app.winkwink.ui.feed.PostCard
import app.winkwink.ui.theme.WwSpacing

@StringRes
private fun typeRes(type: String) = when (type) {
    "private" -> R.string.community_type_private
    "invite" -> R.string.community_type_invite
    else -> R.string.community_type_public
}

@StringRes
private fun roleRes(role: String) = when (role) {
    "owner" -> R.string.community_role_owner
    "admin" -> R.string.community_role_admin
    "moderator" -> R.string.community_role_moderator
    else -> R.string.community_role_member
}

@Composable
private fun CommunityRow(c: Community, onClick: () -> Unit, trailing: @Composable (() -> Unit)? = null) {
    WwCard(Modifier.clickable(onClick = onClick)) {
        Text(c.name, style = MaterialTheme.typography.titleMedium)
        Text(
            "${stringResource(typeRes(c.type))} · ${stringResource(R.string.community_members_count, c.memberCount)}",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (c.description.isNotBlank()) Text(c.description, style = MaterialTheme.typography.bodyMedium, maxLines = 3)
        trailing?.invoke()
    }
}

// ---------- Zakładka Społeczności ----------

@Composable
fun CommunitiesHomeScreen(onOpen: (String) -> Unit, onCreate: () -> Unit, viewModel: CommunitiesViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(horizontal = WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
        WwScreenHeader(title = stringResource(R.string.communities_title))
        OutlinedTextField(
            value = s.query, onValueChange = viewModel::onQuery, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.communities_search_hint)) },
        )
        s.failure?.let { f ->
            FailureBanner(f)
            TextButton(onClick = viewModel::refresh) { Text(stringResource(R.string.action_retry)) }
        }
        s.actionFailure?.let { FailureBanner(it) }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm), contentPadding = PaddingValues(bottom = WwSpacing.md)) {
            if (s.searchActive) {
                if (s.searching) item { CircularProgressIndicator() }
                if (s.searched && !s.searching && s.results.isEmpty()) item {
                    Text(stringResource(R.string.communities_search_empty), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                items(s.results, key = { "s-" + it.id }) { c -> CommunityRow(c, onClick = { onOpen(c.id) }) }
            } else {
                if (s.loading && !s.loaded) item { CircularProgressIndicator() }
                if (s.invites.isNotEmpty()) {
                    item { Text(stringResource(R.string.communities_invites), style = MaterialTheme.typography.titleMedium) }
                    items(s.invites, key = { "i-" + it.id }) { c ->
                        CommunityRow(c, onClick = { onOpen(c.id) }) {
                            Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                                Button(onClick = { viewModel.respond(c, true) }) { Text(stringResource(R.string.community_accept)) }
                                OutlinedButton(onClick = { viewModel.respond(c, false) }) { Text(stringResource(R.string.community_decline)) }
                            }
                        }
                    }
                }
                item { Text(stringResource(R.string.communities_mine), style = MaterialTheme.typography.titleMedium) }
                if (s.loaded && s.failure == null && s.mine.isEmpty()) item {
                    WwCard {
                        Text(stringResource(R.string.communities_empty_title), style = MaterialTheme.typography.titleMedium)
                        Text(stringResource(R.string.communities_empty_body), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                items(s.mine, key = { "m-" + it.id }) { c ->
                    CommunityRow(c, onClick = { onOpen(c.id) }) {
                        c.myRole?.let { Text(stringResource(roleRes(it)), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary) }
                    }
                }
                if (s.loadingMore) item { CircularProgressIndicator() }
                if (s.mineCursor != null && !s.loadingMore) item(key = "more") { LaunchedEffect(s.mineCursor) { viewModel.loadMore() } }
            }
        }
        WwPrimaryButton(text = stringResource(R.string.communities_create), onClick = onCreate, modifier = Modifier.fillMaxWidth().padding(bottom = WwSpacing.md))
    }
}

// ---------- Tworzenie ----------

@Composable
fun CreateCommunityScreen(onBack: () -> Unit, onCreated: (String) -> Unit, viewModel: CreateCommunityViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(s.createdId) { s.createdId?.let(onCreated) }
    val nameBad = s.name.isNotBlank() && !CommunityValidation.nameValid(s.name)
    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(WwSpacing.md),
        verticalArrangement = Arrangement.spacedBy(WwSpacing.md),
    ) {
        WwScreenHeader(title = stringResource(R.string.create_community_title), onBack = onBack)
        OutlinedTextField(
            value = s.name, onValueChange = viewModel::onName, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.create_community_name)) }, isError = nameBad,
            supportingText = { if (nameBad) Text(stringResource(R.string.err_community_name)) },
        )
        val descBad = !CommunityValidation.descriptionValid(s.description)
        OutlinedTextField(
            value = s.description, onValueChange = viewModel::onDescription, minLines = 3, modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.create_community_description)) }, isError = descBad,
            supportingText = { Text(if (descBad) stringResource(R.string.err_community_description_long) else "${s.description.trim().length}/${CommunityValidation.DESCRIPTION_MAX}") },
        )
        val rulesBad = !CommunityValidation.rulesValid(s.rules)
        OutlinedTextField(
            value = s.rules, onValueChange = viewModel::onRules, minLines = 3, modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.create_community_rules)) }, isError = rulesBad,
            supportingText = { Text(if (rulesBad) stringResource(R.string.err_community_rules_long) else "${s.rules.trim().length}/${CommunityValidation.RULES_MAX}") },
        )
        Text(stringResource(R.string.create_community_type), style = MaterialTheme.typography.titleMedium)
        app.winkwink.domain.model.CommunityTypes.all.forEach { t ->
            FilterChip(selected = s.type == t, onClick = { viewModel.onType(t) }, label = { Text(stringResource(typeRes(t))) })
        }
        s.failure?.let { FailureBanner(it) }
        WwPrimaryButton(text = stringResource(R.string.create_community_submit), onClick = viewModel::submit, enabled = s.canSubmit, loading = s.saving)
    }
}

// ---------- Szczegóły ----------

@Composable
fun CommunityDetailScreen(
    onBack: () -> Unit,
    onOpenPost: (String) -> Unit,
    onOpenUser: (String) -> Unit,
    onManage: (String) -> Unit,
    viewModel: CommunityDetailViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(s.left) { if (s.left) onBack() }
    var confirmLeave by remember { mutableStateOf(false) }
    var postToRemove by remember { mutableStateOf<app.winkwink.domain.model.Post?>(null) }
    val c = s.community

    if (confirmLeave) {
        AlertDialog(
            onDismissRequest = { confirmLeave = false },
            title = { Text(stringResource(R.string.community_leave_confirm_title)) },
            text = { Text(stringResource(R.string.community_leave_confirm_body)) },
            confirmButton = { TextButton(onClick = { confirmLeave = false; viewModel.confirmLeave() }) { Text(stringResource(R.string.community_leave)) } },
            dismissButton = { TextButton(onClick = { confirmLeave = false }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
    postToRemove?.let { post ->
        AlertDialog(
            onDismissRequest = { postToRemove = null },
            title = { Text(stringResource(R.string.community_mod_delete_title)) },
            text = { Text(stringResource(R.string.community_mod_delete_body)) },
            confirmButton = { TextButton(onClick = { postToRemove = null; viewModel.moderatorDelete(post) }) { Text(stringResource(R.string.community_mod_delete)) } },
            dismissButton = { TextButton(onClick = { postToRemove = null }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
    if (s.composing && c != null) {
        AlertDialog(
            onDismissRequest = { if (!s.posting) viewModel.cancelCompose() },
            title = { Text(stringResource(R.string.community_post_title, c.name)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                    s.targetChannel?.let { Text("# ${it.name}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }
                    OutlinedTextField(
                        value = s.draft, onValueChange = viewModel::onDraft, minLines = 4, modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.compose_hint)) },
                        isError = s.draft.trim().length > PostValidation.POST_MAX,
                        supportingText = { Text("${s.draft.trim().length}/${PostValidation.POST_MAX}") },
                    )
                    s.actionFailure?.let { FailureBanner(it) }
                }
            },
            confirmButton = { TextButton(onClick = viewModel::publish, enabled = s.draftValid && !s.posting) { Text(stringResource(R.string.compose_publish)) } },
            dismissButton = { TextButton(onClick = viewModel::cancelCompose, enabled = !s.posting) { Text(stringResource(R.string.action_cancel)) } },
        )
    }

    Column(Modifier.fillMaxSize().padding(horizontal = WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
        WwScreenHeader(title = c?.name ?: stringResource(R.string.communities_title), onBack = onBack)
        if (s.loading && c == null) CircularProgressIndicator()
        s.failure?.let { f ->
            FailureBanner(f)
            TextButton(onClick = viewModel::load) { Text(stringResource(R.string.action_retry)) }
        }
        if (!s.composing) s.actionFailure?.let { FailureBanner(it) }
        if (c != null) {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm), contentPadding = PaddingValues(bottom = WwSpacing.md)) {
                item(key = "header") {
                    WwCard {
                        Text(
                            "${stringResource(typeRes(c.type))} · ${stringResource(R.string.community_members_count, c.memberCount)}",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        c.myRole?.let { Text(stringResource(roleRes(it)), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary) }
                        if (c.description.isNotBlank()) Text(c.description, style = MaterialTheme.typography.bodyMedium)
                        if (c.rules.isNotBlank()) {
                            Text(stringResource(R.string.community_rules), style = MaterialTheme.typography.titleSmall)
                            Text(c.rules, style = MaterialTheme.typography.bodyMedium)
                        }
                        if (app.winkwink.domain.model.CommunityRoles.isModeratorOrAbove(c.myRole) && c.isMember) {
                            OutlinedButton(onClick = { onManage(c.id) }) { Text(stringResource(R.string.community_manage)) }
                        }
                        MembershipActions(c, s.busy, onJoin = viewModel::join, onLeave = { confirmLeave = true }, onCancel = viewModel::cancelRequest)
                    }
                }
                if (c.isMember) {
                    item(key = "channels") {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                            FilterChip(selected = s.channelId == null, onClick = { viewModel.selectChannel(null) }, label = { Text(stringResource(R.string.community_channel_all)) })
                            s.channels.forEach { ch ->
                                FilterChip(selected = s.channelId == ch.id, onClick = { viewModel.selectChannel(ch.id) }, label = { Text("# ${ch.name}") })
                            }
                        }
                    }
                    item(key = "write") {
                        WwPrimaryButton(text = stringResource(R.string.community_write_post), onClick = viewModel::startCompose, enabled = s.targetChannel != null, modifier = Modifier.fillMaxWidth())
                    }
                    if (s.postsLoading) item(key = "pl") { CircularProgressIndicator() }
                    if (s.postsLoaded && !s.postsLoading && s.posts.isEmpty()) item(key = "pe") {
                        Text(stringResource(R.string.community_posts_empty), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    items(s.posts, key = { it.id }) { post ->
                        PostCard(
                            post = post, onOpen = { onOpenPost(post.id) },
                            onReact = { viewModel.react(post, it) }, onUnreact = { viewModel.unreact(post) },
                            onToggleSave = { viewModel.toggleSave(post) }, onOpenAuthor = onOpenUser,
                            onModeratorDelete = if (!post.mine && app.winkwink.domain.model.CommunityRoles.isModeratorOrAbove(c.myRole)) ({ postToRemove = post }) else null,
                        )
                    }
                    if (s.postsLoadingMore) item(key = "pm") { CircularProgressIndicator() }
                    if (s.postsCursor != null && !s.postsLoadingMore) item(key = "more") { LaunchedEffect(s.postsCursor) { viewModel.loadPosts() } }
                } else {
                    item(key = "hidden") {
                        Text(stringResource(R.string.community_posts_hidden), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun MembershipActions(c: Community, busy: Boolean, onJoin: () -> Unit, onLeave: () -> Unit, onCancel: () -> Unit) {
    when {
        c.isMember -> if (c.myRole != "owner") OutlinedButton(onClick = onLeave, enabled = !busy) { Text(stringResource(R.string.community_leave)) }
        c.myStatus == "requested" -> {
            Text(stringResource(R.string.community_requested), style = MaterialTheme.typography.bodyMedium)
            OutlinedButton(onClick = onCancel, enabled = !busy) { Text(stringResource(R.string.community_cancel_request)) }
        }
        else -> Button(onClick = onJoin, enabled = !busy) {
            Text(stringResource(if (c.type == "public" || c.myStatus == "invited") R.string.community_join else R.string.community_request))
        }
    }
}
