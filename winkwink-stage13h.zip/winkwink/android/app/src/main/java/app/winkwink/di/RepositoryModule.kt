package app.winkwink.di

import app.winkwink.data.repository.AuthRepositoryImpl
import app.winkwink.data.repository.DeviceNameProvider
import app.winkwink.data.repository.DiagnosticsRepositoryImpl
import app.winkwink.data.repository.CommunityRepositoryImpl
import app.winkwink.data.repository.FeedRepositoryImpl
import app.winkwink.data.realtime.OkHttpRealtimeClient
import app.winkwink.data.repository.MessageRepositoryImpl
import app.winkwink.domain.realtime.RealtimeClient
import app.winkwink.data.repository.NotificationRepositoryImpl
import app.winkwink.domain.repository.MessageRepository
import app.winkwink.domain.repository.NotificationRepository
import app.winkwink.domain.repository.CommunityRepository
import app.winkwink.data.repository.SocialRepositoryImpl
import app.winkwink.data.repository.ProfileExtrasRepositoryImpl
import app.winkwink.data.media.AndroidAttachmentPreparer
import app.winkwink.data.media.AndroidImagePreparer
import app.winkwink.domain.media.AttachmentPreparer
import app.winkwink.domain.media.ImagePreparer
import app.winkwink.domain.repository.ProfileExtrasRepository
import app.winkwink.domain.repository.FeedRepository
import app.winkwink.domain.repository.SocialRepository
import app.winkwink.data.session.SecureSessionStore
import app.winkwink.domain.repository.AuthRepository
import app.winkwink.domain.repository.SessionStore
import dagger.Provides
import app.winkwink.data.settings.ThemeSettingsRepositoryImpl
import app.winkwink.domain.repository.DiagnosticsRepository
import app.winkwink.domain.repository.ThemeSettingsRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds @Singleton
    abstract fun bindDiagnostics(impl: DiagnosticsRepositoryImpl): DiagnosticsRepository

    @Binds @Singleton
    abstract fun bindThemeSettings(impl: ThemeSettingsRepositoryImpl): ThemeSettingsRepository

    @Binds @Singleton
    abstract fun bindAuth(impl: AuthRepositoryImpl): AuthRepository

    @Binds @Singleton
    abstract fun bindSocial(impl: SocialRepositoryImpl): SocialRepository

    @Binds @Singleton
    abstract fun bindFeed(impl: FeedRepositoryImpl): FeedRepository

    @Binds @Singleton
    abstract fun bindCommunities(impl: CommunityRepositoryImpl): CommunityRepository

    @Binds @Singleton
    abstract fun bindNotifications(impl: NotificationRepositoryImpl): NotificationRepository

    @Binds @Singleton
    abstract fun bindMessages(impl: MessageRepositoryImpl): MessageRepository

    @Binds @Singleton
    abstract fun bindRealtime(impl: OkHttpRealtimeClient): RealtimeClient

    @Binds @Singleton
    abstract fun bindProfileExtras(impl: ProfileExtrasRepositoryImpl): ProfileExtrasRepository

    @Binds @Singleton
    abstract fun bindImagePreparer(impl: AndroidImagePreparer): ImagePreparer

    @Binds @Singleton
    abstract fun bindAttachmentPreparer(impl: AndroidAttachmentPreparer): AttachmentPreparer

    @Binds @Singleton
    abstract fun bindMessageFilePreparer(impl: app.winkwink.data.media.AndroidMessageFilePreparer): app.winkwink.domain.media.MessageFilePreparer

    @Binds @Singleton
    abstract fun bindVoiceRecorder(impl: app.winkwink.data.media.AndroidVoiceRecorder): app.winkwink.domain.media.VoiceRecorder

    @Binds @Singleton
    abstract fun bindVoicePlayback(impl: app.winkwink.data.media.AndroidVoicePlayback): app.winkwink.domain.media.VoicePlayback

    @Binds @Singleton
    abstract fun bindSessionStore(impl: SecureSessionStore): SessionStore

    companion object {
        @Provides
        fun provideDeviceName(): DeviceNameProvider = DeviceNameProvider {
            "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}".trim().take(100)
        }
    }
}
