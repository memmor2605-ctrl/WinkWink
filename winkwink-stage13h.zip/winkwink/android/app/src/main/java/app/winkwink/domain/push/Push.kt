package app.winkwink.domain.push

/** Rejestracja tokenu FCM tego urządzenia na backendzie. Bez konfiguracji Firebase wszystkie metody są bezpiecznymi no-op. */
interface PushRegistrar {
    /** Pobiera token FCM i rejestruje go dla zalogowanej sesji (PUT, idempotentne). */
    suspend fun register()
    /** Wylogowanie: wyrejestrowanie na serwerze ([remote]) i unieważnienie tokenu lokalnie (nowy powstanie przy kolejnym logowaniu). */
    suspend fun deregister(remote: Boolean)

    object None : PushRegistrar {
        override suspend fun register() = Unit
        override suspend fun deregister(remote: Boolean) = Unit
    }
}

data class PushSettings(val messages: Boolean, val previews: Boolean, val configured: Boolean)

interface PushSettingsRepository {
    suspend fun settings(): Result<PushSettings>
    suspend fun update(messages: Boolean?, previews: Boolean?): Result<PushSettings>
}

/** Cel otwarcia po stuknięciu powiadomienia. [notificationId] służy do oznaczenia powiadomienia jako przeczytanego. */
sealed interface DeepLink {
    val notificationId: String?
    data class Chat(val conversationId: String) : DeepLink { override val notificationId: String? = null }
    data class Post(val postId: String, override val notificationId: String?) : DeepLink
    data class User(val winkwinkId: String, override val notificationId: String?) : DeepLink
    data class Community(val communityId: String, override val notificationId: String?) : DeepLink
    data class FollowRequests(override val notificationId: String?) : DeepLink
    data object Activity : DeepLink { override val notificationId: String? = null }
}
