package app.winkwink.ui.screens

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.winkwink.R
import app.winkwink.domain.model.ThemeMode
import app.winkwink.ui.account.AccountViewModel
import app.winkwink.ui.auth.FailureBanner
import app.winkwink.ui.components.WwCard
import app.winkwink.ui.components.WwDetailRow
import app.winkwink.ui.components.WwPrimaryButton
import app.winkwink.ui.components.WwScreenHeader
import app.winkwink.ui.theme.WwSpacing

@Composable
fun ProfileScreen(
    onOpenDiagnostics: () -> Unit,
    onChangePassword: () -> Unit,
    onOpenSessions: () -> Unit,
    onSearchUsers: () -> Unit,
    onEditProfile: () -> Unit,
    onOpenSaved: () -> Unit,
    onOpenFollowRequests: () -> Unit,
    onOpenBlocked: () -> Unit,
    onOpenMuted: () -> Unit,
    onOpenMyProfile: (String) -> Unit,
    onDeleteAccount: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel(),
    accountViewModel: AccountViewModel = hiltViewModel(),
) {
    val mode by viewModel.themeMode.collectAsStateWithLifecycle()
    val account by accountViewModel.state.collectAsStateWithLifecycle()
    var confirmSignOut by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(WwSpacing.md),
        verticalArrangement = Arrangement.spacedBy(WwSpacing.md),
    ) {
        WwScreenHeader(
            title = stringResource(R.string.tab_profile),
            subtitle = stringResource(R.string.profile_subtitle),
        )
        WwCard {
            Text(stringResource(R.string.profile_account_title), style = MaterialTheme.typography.titleMedium)
            account.account?.let {
                WwDetailRow(stringResource(R.string.field_nickname), it.profile.nickname)
                WwDetailRow(stringResource(R.string.profile_winkwink_id), it.profile.winkwinkId)
                WwDetailRow(stringResource(R.string.field_email), it.email)
            }
            if (account.loading && account.account == null) {
                Text(stringResource(R.string.diagnostics_checking), style = MaterialTheme.typography.bodyMedium)
            }
            account.failure?.let {
                FailureBanner(it)
                TextButton(onClick = accountViewModel::load) { Text(stringResource(R.string.action_retry)) }
            }
            account.account?.let { acc ->
                TextButton(onClick = { onOpenMyProfile(acc.profile.winkwinkId) }) { Text(stringResource(R.string.profile_open_mine)) }
            }
            TextButton(onClick = onEditProfile) { Text(stringResource(R.string.edit_profile_title)) }
            TextButton(onClick = onOpenSaved) { Text(stringResource(R.string.saved_title)) }
            TextButton(onClick = onOpenFollowRequests) { Text(stringResource(R.string.ulist_requests)) }
            TextButton(onClick = onOpenMuted) { Text(stringResource(R.string.ulist_muted)) }
            TextButton(onClick = onOpenBlocked) { Text(stringResource(R.string.ulist_blocked)) }
            TextButton(onClick = onSearchUsers) { Text(stringResource(R.string.search_users_title)) }
            TextButton(onClick = onChangePassword) { Text(stringResource(R.string.account_change_password)) }
            TextButton(onClick = onOpenSessions) { Text(stringResource(R.string.account_sessions)) }
            TextButton(onClick = { confirmSignOut = true }) { Text(stringResource(R.string.account_sign_out)) }
            TextButton(onClick = onDeleteAccount) { Text(stringResource(R.string.delete_account_action), color = MaterialTheme.colorScheme.error) }
        }
        WwCard {
            Text(stringResource(R.string.appearance_title), style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                ThemeMode.entries.forEach { option ->
                    FilterChip(
                        selected = mode == option,
                        onClick = { viewModel.setThemeMode(option) },
                        label = { Text(stringResource(option.labelRes())) },
                    )
                }
            }
        }
        // Diagnostyka połączenia to narzędzie deweloperskie — w wydaniu nie jest pokazywana.
        if (app.winkwink.BuildConfig.DEBUG) WwCard {
            Text(stringResource(R.string.connection_title), style = MaterialTheme.typography.titleMedium)
            Text(
                stringResource(R.string.connection_body),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            WwPrimaryButton(text = stringResource(R.string.connection_open), onClick = onOpenDiagnostics)
        }
    }

    if (confirmSignOut) {
        AlertDialog(
            onDismissRequest = { confirmSignOut = false },
            title = { Text(stringResource(R.string.signout_confirm_title)) },
            text = { Text(stringResource(R.string.signout_confirm_body)) },
            confirmButton = {
                TextButton(onClick = { confirmSignOut = false; accountViewModel.signOut() }) { Text(stringResource(R.string.account_sign_out)) }
            },
            dismissButton = { TextButton(onClick = { confirmSignOut = false }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
}

@StringRes
private fun ThemeMode.labelRes(): Int = when (this) {
    ThemeMode.SYSTEM -> R.string.theme_system
    ThemeMode.LIGHT -> R.string.theme_light
    ThemeMode.DARK -> R.string.theme_dark
}
