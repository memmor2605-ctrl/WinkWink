package app.winkwink.domain.model

/** Widok profilu innego użytkownika (lub własnego). [restricted] = true: bio, linki i liczniki są ukryte przez serwer. */
data class UserProfile(
    val winkwinkId: String,
    val nickname: String,
    val displayName: String?,
    val bio: String?,
    val links: List<String>,
    val visibility: String,
    val restricted: Boolean,
    val followers: Int?,
    val following: Int?,
    val isSelf: Boolean,
    /** none | pending | accepted */
    val followState: String,
    val followedByThem: Boolean,
    /** Znacznik wersji obrazu: zmienia się po każdej zmianie, null = brak obrazu. */
    val avatarTag: String? = null,
    val backgroundTag: String? = null,
    /** Czy zalogowany użytkownik wyciszył ten profil (widoczne tylko dla niego). */
    val muted: Boolean = false,
    val followListsHidden: Boolean = false,
)

data class UserSummary(val winkwinkId: String, val nickname: String, val displayName: String?, val avatarTag: String? = null)

/** Strona listy użytkowników; [nextCursor] == null oznacza koniec listy. */
data class UserPage(val users: List<UserSummary>, val nextCursor: String?)
