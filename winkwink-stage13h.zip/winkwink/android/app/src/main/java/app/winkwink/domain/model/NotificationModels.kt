package app.winkwink.domain.model

import java.time.Instant

/** Kontrakt: docs/API.md, „Etap 6”. [actor] jest null, gdy autorem jest anonimowy autor posta — konta nie da się wtedy poznać. */
data class NotificationActor(val winkwinkId: String, val nickname: String, val displayName: String?, val hasAvatar: Boolean) {
    val name get() = displayName?.takeIf { it.isNotBlank() } ?: nickname
}

data class AppNotification(
    val id: String,
    /** new_follower | follow_request | reaction | comment | reply | community_invite | community_invite_accepted | community_request_approved */
    val type: String,
    val actor: NotificationActor?,
    val postId: String?,
    val commentId: String?,
    val communityId: String?,
    val createdAt: Instant,
    val read: Boolean,
)

data class NotificationPage(val items: List<AppNotification>, val nextCursor: String?, val unreadCount: Int)

object NotificationKinds {
    val all = listOf("new_follower", "follow_request", "reaction", "comment", "reply", "community_invite")
}
