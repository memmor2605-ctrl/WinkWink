package app.winkwink.data.push

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import app.winkwink.MainActivity
import app.winkwink.R
import app.winkwink.domain.push.DeepLink
import app.winkwink.domain.repository.SessionStore
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Zamienia wiadomość FCM (data-only) na powiadomienie systemowe. Serwer wysyła tylko dane (typ, identyfikatory, imię nadawcy);
 * teksty budujemy tu — w języku urządzenia. Treść wiadomości pojawia się wyłącznie, gdy użytkownik włączył podgląd (serwer
 * wtedy dołącza `preview`); na ekranie blokady zawsze widać wersję publiczną bez treści i nadawcy.
 */
@Singleton
class PushNotificationPresenter @Inject constructor(
    @ApplicationContext private val context: Context,
    private val session: SessionStore,
) {
    companion object {
        private const val ID_MESSAGE = 1
        private const val ID_SOCIAL = 2
        private const val ID_ACCOUNT = 3
        const val CH_MESSAGES = "messages"
        const val CH_ACTIVITY = "activity"
        const val CH_COMMUNITY = "community"
        const val CH_ACCOUNT = "account"
        const val EXTRA_TYPE = "dl_type"
        const val EXTRA_ID = "dl_id"
        const val EXTRA_NOTIFICATION = "dl_notification"

        fun parse(extras: android.os.Bundle?): DeepLink? {
            val type = extras?.getString(EXTRA_TYPE) ?: return null
            val id = extras.getString(EXTRA_ID)
            val n = extras.getString(EXTRA_NOTIFICATION)
            return when (type) {
                "chat" -> id?.let { DeepLink.Chat(it) }
                "post" -> id?.let { DeepLink.Post(it, n) }
                "user" -> id?.let { DeepLink.User(it, n) }
                "community" -> id?.let { DeepLink.Community(it, n) }
                "requests" -> DeepLink.FollowRequests(n)
                "activity" -> DeepLink.Activity
                else -> null
            }
        }
    }

    fun ensureChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java)
        fun ch(id: String, name: Int, desc: Int, importance: Int) =
            nm.createNotificationChannel(NotificationChannel(id, context.getString(name), importance).apply { description = context.getString(desc) })
        ch(CH_MESSAGES, R.string.channel_messages, R.string.channel_messages_desc, NotificationManager.IMPORTANCE_HIGH)
        ch(CH_ACTIVITY, R.string.channel_activity, R.string.channel_activity_desc, NotificationManager.IMPORTANCE_DEFAULT)
        ch(CH_COMMUNITY, R.string.channel_community, R.string.channel_community_desc, NotificationManager.IMPORTANCE_DEFAULT)
        ch(CH_ACCOUNT, R.string.channel_account, R.string.channel_account_desc, NotificationManager.IMPORTANCE_HIGH)
    }

    fun handle(data: Map<String, String>) {
        // Powiadomienia nie istnieją bez zalogowanej sesji (np. spóźniony push po wylogowaniu).
        if (session.session.value == null) return
        ensureChannels()
        val nm = NotificationManagerCompat.from(context)
        val type = data["type"] ?: return
        if (type == "dismiss") { dismiss(nm, data); return }
        // areNotificationsEnabled uwzględnia brak zgody POST_NOTIFICATIONS (Android 13+) i wyłączenie w ustawieniach systemu.
        if (!nm.areNotificationsEnabled()) return
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val built = build(type, data) ?: return
        @Suppress("MissingPermission") // sprawdzone powyżej
        nm.notify(built.tag, built.id, built.notification)
    }

    private fun dismiss(nm: NotificationManagerCompat, data: Map<String, String>) {
        data["conversationId"]?.let { nm.cancel("c-$it", ID_MESSAGE) }
        val n = data["notificationId"] ?: return
        if (n == "all") {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.activeNotifications.filter { it.tag?.startsWith("n-") == true }.forEach { manager.cancel(it.tag, it.id) }
        } else nm.cancel("n-$n", ID_SOCIAL)
    }

    private class Built(val tag: String, val id: Int, val notification: android.app.Notification)

    private fun build(type: String, d: Map<String, String>): Built? {
        val actor = d["actor"] ?: context.getString(R.string.notif_someone)
        return when (type) {
            "message" -> {
                val convId = d["conversationId"] ?: return null
                val sender = d["sender"] ?: context.getString(R.string.notif_someone)
                val group = d["group"] == "true"
                val title = if (group) (d["title"] ?: sender) else sender
                val preview = d["preview"]
                val text = when {
                    preview != null -> if (group) "$sender: $preview" else preview
                    d["attachment"] != null -> context.getString(attachmentLabel(d["attachment"]!!))
                    else -> context.getString(R.string.notif_new_message)
                }
                make("c-$convId", ID_MESSAGE, CH_MESSAGES, title, text, context.getString(R.string.notif_new_message), link("chat", convId, null), NotificationCompat.CATEGORY_MESSAGE)
            }
            "account" -> {
                val text = context.getString(if (d["event"] == "password_changed") R.string.notif_account_password_changed else R.string.notif_account_new_login)
                make("account-${d["event"]}", ID_ACCOUNT, CH_ACCOUNT, context.getString(R.string.app_name), text, text, link("activity", null, null), NotificationCompat.CATEGORY_STATUS)
            }
            else -> {
                val nid = d["notificationId"] ?: return null
                val (res, channel) = when (type) {
                    "new_follower" -> R.string.notif_new_follower to CH_ACTIVITY
                    "follow_request" -> R.string.notif_follow_request to CH_ACTIVITY
                    "reaction" -> R.string.notif_reaction to CH_ACTIVITY
                    "comment" -> R.string.notif_comment to CH_ACTIVITY
                    "reply" -> R.string.notif_reply to CH_ACTIVITY
                    "community_invite" -> R.string.notif_community_invite to CH_COMMUNITY
                    "community_invite_accepted" -> R.string.notif_community_invite_accepted to CH_COMMUNITY
                    "community_request_approved" -> R.string.notif_community_request_approved to CH_COMMUNITY
                    else -> return null
                }
                val target = when (type) {
                    "new_follower" -> d["actorId"]?.let { link("user", it, nid) }
                    "follow_request" -> link("requests", null, nid)
                    "community_invite", "community_invite_accepted", "community_request_approved" -> d["communityId"]?.let { link("community", it, nid) }
                    else -> d["postId"]?.let { link("post", it, nid) }
                } ?: link("activity", null, nid)
                val text = context.getString(res, actor)
                make("n-$nid", ID_SOCIAL, channel, context.getString(R.string.app_name), text, text, target, NotificationCompat.CATEGORY_SOCIAL)
            }
        }
    }

    private fun attachmentLabel(kind: String) = when (kind) {
        "image" -> R.string.notif_attachment_image
        "video" -> R.string.notif_attachment_video
        "voice", "audio" -> R.string.notif_attachment_voice
        else -> R.string.notif_attachment_file
    }

    private fun link(type: String, id: String?, notificationId: String?): Intent =
        Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_TYPE, type); id?.let { putExtra(EXTRA_ID, it) }; notificationId?.let { putExtra(EXTRA_NOTIFICATION, it) }
        }

    private fun make(tag: String, id: Int, channel: String, title: String, text: String, publicText: String, intent: Intent, category: String): Built {
        val pending = PendingIntent.getActivity(context, tag.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        // Wersja publiczna (ekran blokady przy „ukryj wrażliwe”): bez nadawcy i treści.
        val public = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_stat_winkwink).setContentTitle(context.getString(R.string.app_name)).setContentText(publicText).build()
        val n = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_stat_winkwink)
            .setContentTitle(title).setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pending).setAutoCancel(true).setCategory(category)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setPublicVersion(public)
            .setOnlyAlertOnce(true).setPriority(if (channel == CH_MESSAGES || channel == CH_ACCOUNT) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .build()
        return Built(tag, id, n)
    }

}
