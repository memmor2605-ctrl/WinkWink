package app.winkwink.data.remote

import app.winkwink.domain.model.ApiFailure
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import retrofit2.Response
import java.io.IOException
import java.net.SocketTimeoutException
import javax.net.ssl.SSLException

/** Zamienia odpowiedź Retrofit / wyjątki sieciowe na Result z [ApiFailure]. */
suspend fun <T> apiCall(json: Json, block: suspend () -> Response<T>): Result<T> = try {
    val response = block()
    if (response.isSuccessful) {
        @Suppress("UNCHECKED_CAST")
        val body = response.body() ?: (Unit as? T)
        if (body != null) Result.success(body) else Result.failure(ApiFailure("invalid_response", "Empty response", httpStatus = response.code()))
    } else {
        Result.failure(parseError(json, response))
    }
} catch (e: CleartextBlockedException) {
    Result.failure(ApiFailure("insecure", "Cleartext blocked"))
} catch (e: SocketTimeoutException) {
    Result.failure(ApiFailure("timeout", "Timeout"))
} catch (e: SSLException) {
    Result.failure(ApiFailure("tls", "TLS failure"))
} catch (e: IOException) {
    Result.failure(ApiFailure("network", "Network unreachable"))
} catch (e: SerializationException) {
    Result.failure(ApiFailure("invalid_response", "Unexpected response"))
}

private fun parseError(json: Json, response: Response<*>): ApiFailure {
    val retryAfter = response.headers()["Retry-After"]?.toLongOrNull()
    val parsed = runCatching {
        response.errorBody()?.string()?.let { json.decodeFromString<ApiErrorDto>(it).error }
    }.getOrNull()
    return ApiFailure(
        code = parsed?.code ?: "http_${response.code()}",
        message = parsed?.message ?: "HTTP ${response.code()}",
        details = parsed?.details.orEmpty(),
        retryAfterSeconds = retryAfter,
        httpStatus = response.code(),
    )
}
