package app.winkwink.domain.model

enum class ThemeMode { SYSTEM, LIGHT, DARK }
