package app.winkwink.data.media

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import app.winkwink.domain.media.PlaybackState
import app.winkwink.domain.media.PlaybackStatus
import app.winkwink.domain.media.VoicePlayback
import app.winkwink.domain.repository.MessageRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Jeden odtwarzacz na całą aplikację ([MediaPlayer]): kliknięcie innej głosówki zatrzymuje poprzednią, bo stan ma jeden [PlaybackState.key].
 * Głosówki z serwera są pobierane przez REST do `cache/voice-in/<id>.m4a` (id załącznika to UUID, więc nazwa jest bezpieczna)
 * i odtwarzane lokalnie; pamięć podręczna jest przycinana do [MAX_CACHED] najnowszych plików.
 * Odtwarzacz ma fokus audio (przerwa przy rozmowie/innej aplikacji = pauza) i pauzuje się przy odłączeniu słuchawek (BECOMING_NOISY
 * obsługuje system przez fokus; tu pauzujemy przy utracie fokusu).
 */
@Singleton
class AndroidVoicePlayback @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: MessageRepository,
) : VoicePlayback {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(PlaybackState())
    override val state: StateFlow<PlaybackState> = _state.asStateFlow()

    private var player: MediaPlayer? = null
    private var ticker: Job? = null
    private var loading: Job? = null
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focus: AudioFocusRequest? = null

    override fun toggleRemote(attachmentId: String, durationHintMs: Long) {
        val cur = _state.value
        if (cur.key == attachmentId) {
            when (cur.status) {
                PlaybackStatus.PLAYING -> { pause(); return }
                PlaybackStatus.PAUSED -> { resume(); return }
                PlaybackStatus.LOADING -> return
                else -> Unit // IDLE/ERROR: spróbuj od nowa
            }
        }
        release()
        _state.value = PlaybackState(attachmentId, PlaybackStatus.LOADING, 0, durationHintMs)
        loading = scope.launch {
            val file = cachedFile(attachmentId) ?: downloadToCache(attachmentId)
            if (file == null) {
                if (_state.value.key == attachmentId) _state.value = PlaybackState(attachmentId, PlaybackStatus.ERROR, 0, durationHintMs)
                return@launch
            }
            // Użytkownik mógł w międzyczasie włączyć inną głosówkę.
            if (_state.value.key == attachmentId && _state.value.status == PlaybackStatus.LOADING) startPlayer(attachmentId, file.absolutePath, durationHintMs)
        }
    }

    override fun toggleLocal(key: String, path: String, durationHintMs: Long) {
        val cur = _state.value
        if (cur.key == key) {
            when (cur.status) {
                PlaybackStatus.PLAYING -> { pause(); return }
                PlaybackStatus.PAUSED -> { resume(); return }
                else -> Unit
            }
        }
        release()
        _state.value = PlaybackState(key, PlaybackStatus.LOADING, 0, durationHintMs)
        startPlayer(key, path, durationHintMs)
    }

    override fun seekTo(key: String, fraction: Float) {
        val p = player ?: return
        val cur = _state.value
        if (cur.key != key || cur.durationMs <= 0) return
        val target = (cur.durationMs * fraction.coerceIn(0f, 1f)).toInt()
        runCatching { p.seekTo(target) }
        _state.update { it.copy(positionMs = target.toLong()) }
    }

    override fun stop() {
        release()
        _state.value = PlaybackState()
    }

    private fun startPlayer(key: String, path: String, durationHint: Long) {
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).setUsage(AudioAttributes.USAGE_MEDIA).build(),
            )
            mp.setDataSource(path)
            mp.setOnCompletionListener {
                ticker?.cancel()
                abandonFocus()
                _state.update { s -> if (s.key == key) s.copy(status = PlaybackStatus.PAUSED, positionMs = 0) else s }
                runCatching { it.seekTo(0) }
            }
            mp.setOnErrorListener { _, _, _ ->
                release()
                _state.value = PlaybackState(key, PlaybackStatus.ERROR, 0, durationHint)
                true
            }
            mp.prepare()
            if (!requestFocus()) { mp.release(); _state.value = PlaybackState(key, PlaybackStatus.PAUSED, 0, mp.safeDuration(durationHint)); return }
            player = mp
            mp.start()
            _state.value = PlaybackState(key, PlaybackStatus.PLAYING, 0, mp.safeDuration(durationHint))
            startTicker(key)
        } catch (e: Exception) {
            runCatching { mp.release() }
            player = null
            _state.value = PlaybackState(key, PlaybackStatus.ERROR, 0, durationHint)
        }
    }

    private fun MediaPlayer.safeDuration(fallback: Long): Long = runCatching { duration.toLong() }.getOrDefault(0L).takeIf { it > 0 } ?: fallback

    private fun pause() {
        val p = player ?: return
        runCatching { if (p.isPlaying) p.pause() }
        ticker?.cancel()
        abandonFocus()
        _state.update { it.copy(status = PlaybackStatus.PAUSED, positionMs = runCatching { p.currentPosition.toLong() }.getOrDefault(it.positionMs)) }
    }

    private fun resume() {
        val p = player ?: return
        val key = _state.value.key ?: return
        if (!requestFocus()) return
        runCatching { p.start() }
        _state.update { it.copy(status = PlaybackStatus.PLAYING) }
        startTicker(key)
    }

    private fun startTicker(key: String) {
        ticker?.cancel()
        ticker = scope.launch {
            while (isActive) {
                val p = player ?: break
                if (_state.value.key != key) break
                val pos = runCatching { p.currentPosition.toLong() }.getOrDefault(0L)
                _state.update { if (it.key == key && it.status == PlaybackStatus.PLAYING) it.copy(positionMs = pos) else it }
                delay(TICK_MS)
            }
        }
    }

    private fun release() {
        loading?.cancel(); loading = null
        ticker?.cancel(); ticker = null
        player?.let { runCatching { it.stop() }; runCatching { it.release() } }
        player = null
        abandonFocus()
    }

    private fun requestFocus(): Boolean {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).setUsage(AudioAttributes.USAGE_MEDIA).build())
            .setOnAudioFocusChangeListener { change ->
                if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) scope.launch { pause() }
            }
            .build()
        focus = req
        return audio.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        focus?.let { audio.abandonAudioFocusRequest(it) }
        focus = null
    }

    // ---- pamięć podręczna głosówek ----

    private fun cacheDir() = File(context.cacheDir, DIR).apply { mkdirs() }

    private fun cachedFile(id: String): File? = File(cacheDir(), "$id.m4a").takeIf { it.isFile && it.length() > 0 }

    /** Pobiera głosówkę strumieniowo do cache (anulowanie przy przełączeniu na inną przerywa pobieranie); trzyma [MAX_CACHED] ostatnich. */
    private suspend fun downloadToCache(id: String): File? {
        val dir = cacheDir()
        val target = File(dir, "$id.m4a")
        if (repository.downloadAttachmentToFile(id, target).isFailure) return null
        withContext(Dispatchers.IO) {
            dir.listFiles { f -> f.extension == "m4a" }?.sortedByDescending { it.lastModified() }?.drop(MAX_CACHED)?.forEach { it.delete() }
        }
        return target
    }

    private companion object {
        const val DIR = "voice-in"
        const val MAX_CACHED = 30
        const val TICK_MS = 100L
    }
}
