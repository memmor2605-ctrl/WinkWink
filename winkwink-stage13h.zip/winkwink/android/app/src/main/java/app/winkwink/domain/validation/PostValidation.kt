package app.winkwink.domain.validation

/** Limity zgodne z backendem (docs/API.md); serwer pozostaje źródłem prawdy. */
object PostValidation {
    const val POST_MAX = 5000
    const val COMMENT_MAX = 2000
    const val SEARCH_MIN = 3
    const val SEARCH_MAX = 60

    fun postBodyValid(body: String) = body.trim().let { it.isNotEmpty() && it.length <= POST_MAX }
    /** Edycja: post z załącznikami albo udostępnienie może mieć pustą treść. */
    fun editBodyValid(body: String, mayBeEmpty: Boolean) = body.trim().let { it.length <= POST_MAX && (mayBeEmpty || it.isNotEmpty()) }
    fun commentBodyValid(body: String) = body.trim().let { it.isNotEmpty() && it.length <= COMMENT_MAX }

    /** Anonimowy post jest dozwolony wyłącznie jako publiczny (reguła backendu). */
    fun visibilityFor(anonymous: Boolean, requested: String) = if (anonymous) "public" else requested
}
