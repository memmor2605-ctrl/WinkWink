package app.winkwink.data.remote

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

/** Endpointy chronione. Kontrakt: docs/API.md, „Etap 4”. */
interface CommunityApi {
    @GET("api/v1/me/communities") suspend fun mine(@Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<CommunityListDto>
    @GET("api/v1/me/community-invites") suspend fun invites(@Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<CommunityListDto>
    @GET("api/v1/communities/search") suspend fun search(@Query("q") q: String, @Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<CommunityListDto>
    @POST("api/v1/communities") suspend fun create(@Body body: CreateCommunityRequestDto): Response<CommunityDto>
    @PATCH("api/v1/communities/{id}") suspend fun update(@Path("id") id: String, @Body body: UpdateCommunityRequestDto): Response<CommunityDto>
    @GET("api/v1/communities/{id}") suspend fun get(@Path("id") id: String): Response<CommunityDto>
    @POST("api/v1/communities/{id}/membership") suspend fun join(@Path("id") id: String): Response<JoinResponseDto>
    @DELETE("api/v1/communities/{id}/membership") suspend fun leave(@Path("id") id: String): Response<Unit>
    @DELETE("api/v1/communities/{id}/join-request") suspend fun cancelRequest(@Path("id") id: String): Response<Unit>
    @POST("api/v1/communities/{id}/invitation/accept") suspend fun acceptInvite(@Path("id") id: String): Response<Unit>
    @POST("api/v1/communities/{id}/invitation/decline") suspend fun declineInvite(@Path("id") id: String): Response<Unit>
    @GET("api/v1/communities/{id}/channels") suspend fun channels(@Path("id") id: String): Response<ChannelListDto>
    @GET("api/v1/communities/{id}/members") suspend fun members(@Path("id") id: String, @Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<PersonListDto>
    @PUT("api/v1/communities/{id}/members/{user}/role") suspend fun setRole(@Path("id") id: String, @Path("user") user: String, @Body body: RoleRequestDto): Response<Unit>
    @DELETE("api/v1/communities/{id}/members/{user}") suspend fun removeMember(@Path("id") id: String, @Path("user") user: String): Response<Unit>
    @POST("api/v1/communities/{id}/transfer-ownership") suspend fun transferOwnership(@Path("id") id: String, @Body body: TransferOwnershipRequestDto): Response<Unit>
    @PUT("api/v1/communities/{id}/members/{user}/mute") suspend fun mute(@Path("id") id: String, @Path("user") user: String): Response<Unit>
    @DELETE("api/v1/communities/{id}/members/{user}/mute") suspend fun unmute(@Path("id") id: String, @Path("user") user: String): Response<Unit>
    @GET("api/v1/communities/{id}/invite-candidates") suspend fun inviteCandidates(@Path("id") id: String, @Query("q") q: String): Response<InviteCandidateListDto>
    @POST("api/v1/communities/{id}/invites") suspend fun invite(@Path("id") id: String, @Body body: InviteRequestDto): Response<Unit>
    @GET("api/v1/communities/{id}/requests") suspend fun requests(@Path("id") id: String, @Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<PersonListDto>
    @POST("api/v1/communities/{id}/requests/{user}/approve") suspend fun approveRequest(@Path("id") id: String, @Path("user") user: String): Response<Unit>
    @POST("api/v1/communities/{id}/requests/{user}/reject") suspend fun rejectRequest(@Path("id") id: String, @Path("user") user: String): Response<Unit>
    @POST("api/v1/communities/{id}/channels") suspend fun createChannel(@Path("id") id: String, @Body body: CreateChannelRequestDto): Response<ChannelDto>
    @DELETE("api/v1/communities/{id}/channels/{channelId}") suspend fun deleteChannel(@Path("id") id: String, @Path("channelId") channelId: String): Response<Unit>
    @DELETE("api/v1/communities/{id}") suspend fun delete(@Path("id") id: String): Response<Unit>
    @GET("api/v1/communities/{id}/posts")
    suspend fun posts(@Path("id") id: String, @Query("channel") channel: String?, @Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<PostListDto>
}
