package app.winkwink.domain.media

import app.winkwink.domain.model.PreparedFile

/**
 * Dokumenty dozwolone w wiadomościach — lista zgodna z backendem (`MessageMedia`). To tylko wstępny filtr po stronie
 * urządzenia (szybki komunikat zamiast wysyłania pliku, który serwer i tak odrzuci); o przyjęciu decyduje zawartość sprawdzana na serwerze.
 */
object MessageDocumentTypes {
    /** Rozszerzenie → typ MIME wysyłany w Content-Type. */
    private val byExtension = mapOf(
        "pdf" to "application/pdf",
        "docx" to "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "xlsx" to "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "pptx" to "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "odt" to "application/vnd.oasis.opendocument.text",
        "ods" to "application/vnd.oasis.opendocument.spreadsheet",
        "odp" to "application/vnd.oasis.opendocument.presentation",
        "rtf" to "application/rtf",
        "txt" to "text/plain",
        "csv" to "text/csv",
    )

    /** Rozszerzenia, których nie wysyłamy nigdy (pliki wykonywalne, skrypty, HTML, makra). */
    val blockedExtensions = setOf(
        "exe", "dll", "bat", "cmd", "com", "msi", "scr", "pif", "vbs", "vbe", "js", "jse", "mjs", "wsf", "wsh", "ps1", "psm1",
        "sh", "bash", "jar", "apk", "aab", "ipa", "app", "dmg", "iso", "html", "htm", "xhtml", "svg", "xml", "php", "py", "rb",
        "pl", "lnk", "reg", "hta", "cpl", "docm", "xlsm", "pptm", "dotm", "xlam", "swf",
    )

    /** Typy podawane wybierakowi dokumentów (SAF). */
    val pickerMimeTypes: Array<String> = byExtension.values.toTypedArray()

    fun extension(name: String?): String? = name?.substringAfterLast('.', "")?.lowercase()?.takeIf { it.isNotEmpty() }

    /** Nazwa z zakazanym rozszerzeniem w dowolnym segmencie (np. „raport.exe.pdf”). */
    fun hasBlockedExtension(name: String?): Boolean {
        val parts = name?.split('.') ?: return false
        return parts.drop(1).any { it.lowercase() in blockedExtensions }
    }

    /**
     * Typ MIME dla dokumentu albo null, gdy format nie jest dozwolony. Rozszerzenie z nazwy ma pierwszeństwo, bo systemowy
     * typ bywa ogólny (`application/octet-stream`); gdy nazwy brak, używamy typu zgłoszonego przez system, jeśli jest na liście.
     */
    fun mimeFor(name: String?, reportedMime: String?): String? {
        if (hasBlockedExtension(name)) return null
        extension(name)?.let { ext -> byExtension[ext]?.let { return it } }
        val reported = reportedMime?.lowercase()?.substringBefore(';')?.trim()
        return reported?.takeIf { it in byExtension.values }
    }
}

/**
 * Zamienia Uri z systemowych wybieraków na pliki gotowe do wysłania w wiadomości: zdjęcia (zmniejszone, JPEG bez EXIF/GPS)
 * i dokumenty (bez zmian, z nazwą i typem). Kody błędów jak w [AttachmentPrepareException].
 */
interface MessageFilePreparer {
    suspend fun prepareImage(uri: String): Result<PreparedFile>
    suspend fun prepareDocument(uri: String): Result<PreparedFile>
}
