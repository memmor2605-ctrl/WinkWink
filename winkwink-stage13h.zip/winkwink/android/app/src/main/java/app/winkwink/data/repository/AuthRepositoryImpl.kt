package app.winkwink.data.repository

import app.winkwink.data.remote.AccountApi
import app.winkwink.data.remote.ChangePasswordRequestDto
import app.winkwink.data.remote.DeleteAccountRequestDto
import app.winkwink.data.remote.ForgotPasswordRequestDto
import app.winkwink.data.remote.LoginRequestDto
import app.winkwink.data.remote.PublicAuthApi
import app.winkwink.data.remote.RegisterRequestDto
import app.winkwink.data.remote.ResetPasswordRequestDto
import app.winkwink.data.remote.apiCall
import app.winkwink.data.remote.toDomain
import app.winkwink.data.remote.toStored
import app.winkwink.domain.model.SessionInfo
import app.winkwink.domain.model.UserAccount
import app.winkwink.domain.repository.AuthRepository
import app.winkwink.domain.repository.SessionStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

fun interface DeviceNameProvider { fun deviceName(): String }

@Singleton
class AuthRepositoryImpl @Inject constructor(
    private val publicApi: PublicAuthApi,
    private val accountApi: AccountApi,
    private val store: SessionStore,
    private val json: Json,
    private val device: DeviceNameProvider,
    private val push: app.winkwink.domain.push.PushRegistrar = app.winkwink.domain.push.PushRegistrar.None,
) : AuthRepository {

    override suspend fun register(email: String, password: String, nickname: String): Result<UserAccount> = withContext(Dispatchers.IO) {
        apiCall(json) { publicApi.register(RegisterRequestDto(email.trim(), password, nickname.trim(), deviceName = device.deviceName())) }
            .mapCatching { store.save(it.tokens.toStored()); it.me.toDomain() }
    }

    override suspend fun login(email: String, password: String): Result<UserAccount> = withContext(Dispatchers.IO) {
        apiCall(json) { publicApi.login(LoginRequestDto(email.trim(), password, deviceName = device.deviceName())) }
            .mapCatching { store.save(it.tokens.toStored()); it.me.toDomain() }
    }

    override suspend fun logout() {
        withContext(Dispatchers.IO) {
            // Best-effort unieważnienie po stronie serwera; lokalna sesja znika zawsze.
            // Najpierw token push (potrzebuje jeszcze ważnej sesji), potem sesja — inaczej serwer wysyłałby powiadomienia po wylogowaniu.
            runCatching { push.deregister(remote = true) }
            if (store.session.value != null) apiCall(json) { accountApi.logout() }
            store.clear()
        }
    }

    /** Prawdziwe usunięcie konta na serwerze; po sukcesie lokalna sesja znika (SessionCleaner czyści resztę danych). */
    override suspend fun deleteAccount(password: String): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { accountApi.deleteAccount(DeleteAccountRequestDto(password)) }.map {
            runCatching { push.deregister(remote = false) }
            store.clear()
        }
    }

    override suspend fun me(): Result<UserAccount> = withContext(Dispatchers.IO) {
        apiCall(json) { accountApi.me() }.map { it.toDomain() }
    }

    override suspend fun requestPasswordReset(email: String): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { publicApi.forgot(ForgotPasswordRequestDto(email.trim())) }.map { }
    }

    override suspend fun resetPassword(token: String, newPassword: String): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { publicApi.reset(ResetPasswordRequestDto(token.trim(), newPassword)) }.map { }
    }

    override suspend fun changePassword(currentPassword: String, newPassword: String): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { accountApi.changePassword(ChangePasswordRequestDto(currentPassword, newPassword)) }.map { }
    }

    override suspend fun sessions(): Result<List<SessionInfo>> = withContext(Dispatchers.IO) {
        apiCall(json) { accountApi.sessions() }.map { r -> r.sessions.map { it.toDomain() } }
    }

    override suspend fun revokeSession(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { accountApi.revokeSession(id) }.map { }
    }

    override suspend fun revokeOtherSessions(): Result<Int> = withContext(Dispatchers.IO) {
        apiCall(json) { accountApi.revokeOthers() }.map { it.revoked }
    }
}
