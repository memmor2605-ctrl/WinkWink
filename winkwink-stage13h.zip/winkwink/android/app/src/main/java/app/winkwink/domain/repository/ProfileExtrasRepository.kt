package app.winkwink.domain.repository

import app.winkwink.domain.media.ImageKind
import app.winkwink.domain.model.PostPage
import app.winkwink.domain.model.UserPage
import app.winkwink.domain.model.UserProfile

/** Avatar, zdjęcie w tle, wyciszanie i posty profilu (Etap A). */
interface ProfileExtrasRepository {
    /** Przygotowuje obraz z [uri] (systemowy wybierak) i wysyła go; zwraca zaktualizowany profil z nowym znacznikiem wersji. */
    suspend fun setImage(kind: ImageKind, uri: String): Result<UserProfile>
    suspend fun removeImage(kind: ImageKind): Result<UserProfile>

    suspend fun mute(identifier: String): Result<Unit>
    suspend fun unmute(identifier: String): Result<Unit>
    suspend fun muted(cursor: String?): Result<UserPage>

    suspend fun setHideFollowLists(hide: Boolean): Result<UserProfile>

    /** Posty widoczne dla zalogowanego na profilu [identifier] (anonimowe nigdy się tu nie pojawiają — serwer ich nie zwraca). */
    suspend fun userPosts(identifier: String, cursor: String?): Result<PostPage>
}
