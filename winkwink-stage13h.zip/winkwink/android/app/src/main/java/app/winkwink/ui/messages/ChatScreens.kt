package app.winkwink.ui.messages

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.text.format.DateFormat
import android.text.format.DateUtils
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import app.winkwink.domain.media.MessageDocumentTypes
import app.winkwink.domain.media.PlaybackState
import app.winkwink.domain.model.MessageAttachment
import app.winkwink.domain.model.MessageMediaLimits
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.winkwink.R
import app.winkwink.domain.model.ChatMember
import app.winkwink.domain.model.ChatMessage
import app.winkwink.domain.model.ChatReaction
import app.winkwink.domain.model.ChatReactions
import app.winkwink.domain.model.Conversation
import app.winkwink.domain.realtime.RealtimeState
import app.winkwink.domain.validation.MessageValidation
import app.winkwink.ui.auth.FailureBanner
import app.winkwink.ui.auth.text
import app.winkwink.ui.components.UserAvatar
import app.winkwink.ui.components.WwCard
import app.winkwink.ui.components.WwScreenHeader
import app.winkwink.ui.theme.WwSpacing
import java.time.Instant
import java.util.Date

@Composable
private fun formatMessageTime(at: Instant): String {
    val ctx = LocalContext.current
    val ms = at.toEpochMilli()
    val time = DateFormat.getTimeFormat(ctx).format(Date(ms))
    return if (DateUtils.isToday(ms)) time else DateUtils.formatDateTime(ctx, ms, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_MONTH) + " " + time
}

@Composable
private fun statusLabel(status: String): String = when (status) {
    "read" -> stringResource(R.string.msg_status_read)
    "delivered" -> stringResource(R.string.msg_status_delivered)
    else -> stringResource(R.string.msg_status_sent)
}

private fun snippet(m: ChatMessage): String? = m.body?.replace('\n', ' ')?.take(120)

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
private fun ReactionPill(r: ChatReaction, onClick: () -> Unit) {
    Surface(
        shape = CircleShape,
        color = if (r.mine) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.clip(CircleShape).clickable(onClick = onClick),
    ) {
        Text("${ChatReactions.emoji(r.kind)} ${r.count}", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
    }
}

@Composable
private fun MessageBubble(
    m: ChatMessage,
    showSender: Boolean,
    replyPreview: String?,
    playback: PlaybackState,
    actions: MessageAttachmentActionState,
    onClick: () -> Unit,
    onReact: (String) -> Unit,
    onOpenImage: (Int) -> Unit,
    onToggleVoice: (MessageAttachment) -> Unit,
    onSeekVoice: (MessageAttachment, Float) -> Unit,
    onSaveDocument: (MessageAttachment) -> Unit,
) {
    val mine = m.mine
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = MaterialTheme.shapes.medium,
            color = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.widthIn(max = 300.dp).clip(MaterialTheme.shapes.medium).clickable(enabled = !m.deleted, onClick = onClick),
        ) {
            Column(Modifier.padding(WwSpacing.sm), verticalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                if (showSender && !mine) Text(m.sender.name, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                if (replyPreview != null) {
                    Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)) {
                        Text(
                            replyPreview, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = WwSpacing.sm, vertical = WwSpacing.xs),
                        )
                    }
                }
                if (m.deleted) {
                    Text(stringResource(R.string.msg_deleted), style = MaterialTheme.typography.bodyMedium, fontStyle = FontStyle.Italic, color = LocalContentColor.current.copy(alpha = 0.7f))
                } else {
                    if (m.attachments.isNotEmpty()) {
                        MessageMediaContent(m, playback, actions, onOpenImage, onToggleVoice, onSeekVoice, onSaveDocument)
                    }
                    if (!m.body.isNullOrBlank() || m.attachments.isEmpty()) Text(m.body.orEmpty(), style = MaterialTheme.typography.bodyLarge)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm), verticalAlignment = Alignment.CenterVertically) {
                    val dim = LocalContentColor.current.copy(alpha = 0.7f)
                    Text(formatMessageTime(m.createdAt), style = MaterialTheme.typography.labelSmall, color = dim)
                    if (m.editedAt != null && !m.deleted) Text(stringResource(R.string.msg_edited), style = MaterialTheme.typography.labelSmall, color = dim)
                    if (mine && m.status != null) Text(statusLabel(m.status), style = MaterialTheme.typography.labelSmall, color = dim)
                }
                if (m.reactions.isNotEmpty()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                        m.reactions.forEach { r -> ReactionPill(r) { onReact(r.kind) } }
                    }
                }
            }
        }
    }
}

@Composable
private fun PendingBubble(p: PendingMessage, onRetry: () -> Unit, onDiscard: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Surface(
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
            border = BorderStroke(1.dp, if (p.failed) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline),
            modifier = Modifier.widthIn(max = 300.dp),
        ) {
            Column(Modifier.padding(WwSpacing.sm), verticalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                if (p.media.isNotEmpty()) PendingMediaContent(p)
                if (p.body.isNotBlank() || p.media.isEmpty()) Text(p.body, style = MaterialTheme.typography.bodyLarge)
                if (p.failed) {
                    Text(stringResource(R.string.msg_status_failed), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                    p.failure?.let { Text(it.text(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error) }
                    Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                        TextButton(onClick = onRetry) { Text(stringResource(R.string.action_retry)) }
                        TextButton(onClick = onDiscard) { Text(stringResource(R.string.msg_discard)) }
                    }
                } else {
                    Text(
                        stringResource(if (p.uploading) R.string.msg_status_uploading else R.string.msg_status_sending),
                        style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = 0.7f),
                    )
                }
            }
        }
    }
}

@Composable
private fun MessageActionsDialog(
    m: ChatMessage,
    canDelete: Boolean,
    onReact: (String) -> Unit,
    onReply: () -> Unit,
    onCopy: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) } },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    ChatReactions.kinds.forEach { kind ->
                        Box(
                            Modifier.size(34.dp).clip(CircleShape)
                                .background(if (m.myReaction == kind) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { onReact(kind) },
                            contentAlignment = Alignment.Center,
                        ) { Text(ChatReactions.emoji(kind), fontSize = 18.sp) }
                    }
                }
                TextButton(onClick = onReply) { Text(stringResource(R.string.msg_reply)) }
                if (!m.body.isNullOrBlank()) TextButton(onClick = onCopy) { Text(stringResource(R.string.msg_copy)) }
                if (m.mine && m.voice == null) TextButton(onClick = onEdit) { Text(stringResource(R.string.msg_edit)) }
                if (canDelete) TextButton(onClick = onDelete) { Text(stringResource(R.string.msg_delete), color = MaterialTheme.colorScheme.error) }
            }
        },
    )
}

// ---------- Ekran czatu ----------

@Composable
fun ChatScreen(
    onBack: () -> Unit,
    onOpenMembers: (String) -> Unit,
    viewModel: ChatViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    var actionsFor by remember { mutableStateOf<ChatMessage?>(null) }
    var confirmDelete by remember { mutableStateOf<ChatMessage?>(null) }
    val clipboard = LocalClipboardManager.current
    val connection by viewModel.connection.collectAsStateWithLifecycle()
    val playback by viewModel.playback.collectAsStateWithLifecycle()
    val actionsVm: MessageAttachmentActionsViewModel = hiltViewModel()
    val actions by actionsVm.state.collectAsStateWithLifecycle()
    var viewer by remember { mutableStateOf<Pair<List<MessageAttachment>, Int>?>(null) }
    var pendingSave by remember { mutableStateOf<MessageAttachment?>(null) }
    var attachMenu by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val saveLauncher = rememberLauncherForActivityResult(CreateTypedDocument()) { uri ->
        val doc = pendingSave
        pendingSave = null
        if (uri != null && doc != null) actionsVm.saveDocument(doc, uri)
    }
    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(MessageMediaLimits.MAX_IMAGES)) { uris ->
        if (uris.isNotEmpty()) viewModel.addImages(uris.map { it.toString() })
    }
    val documentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) viewModel.addDocuments(uris.map { it.toString() })
    }
    // Mikrofon: uprawnienie jest proszone dopiero po stuknięciu „Wiadomość głosowa”; odmowa daje czytelny komunikat,
    // a przy trwałej odmowie (system nie pokaże już okna) — skrót do ustawień aplikacji.
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) viewModel.startRecording()
        else {
            val canAskAgain = context.findActivity()?.let { ActivityCompat.shouldShowRequestPermissionRationale(it, Manifest.permission.RECORD_AUDIO) } ?: false
            viewModel.showNotice(if (canAskAgain) "mic_denied" else "mic_denied_forever")
        }
    }
    fun onRecordClick() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) viewModel.startRecording()
        else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
    // Zejście w tło: kończymy nagrywanie (trafia do podglądu) i zatrzymujemy odtwarzanie.
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { viewModel.onBackgrounded(); viewModel.stopPlayback() }
    PollWhileResumed(if (connection == RealtimeState.ONLINE) POLL_ONLINE_MS else POLL_OFFLINE_MS) { viewModel.refreshLatest() }

    val conv = s.conversation
    val byId = remember(s.messages) { s.messages.associateBy { it.id } }
    val deletedLabel = stringResource(R.string.msg_deleted)
    val earlierLabel = stringResource(R.string.msg_reply_earlier)
    val voiceLabel = stringResource(R.string.msg_media_voice)
    val photoLabel = stringResource(R.string.msg_media_photo)
    val documentLabel = stringResource(R.string.msg_media_document)
    /** Krótki opis wiadomości w podglądach (odpowiedź, cytat): tekst albo rodzaj załącznika. */
    fun preview(m: ChatMessage): String = snippet(m)?.takeIf { it.isNotBlank() } ?: when {
        m.voice != null -> voiceLabel
        m.images.isNotEmpty() -> photoLabel
        m.documents.isNotEmpty() -> documentLabel
        else -> ""
    }

    fun replyText(m: ChatMessage): String? {
        val id = m.replyToId ?: return null
        val parent = byId[id] ?: return earlierLabel
        return if (parent.deleted) deletedLabel else "${parent.sender.name}: ${preview(parent)}"
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Column(Modifier.padding(horizontal = WwSpacing.md)) {
            WwScreenHeader(
                title = conv?.displayName ?: stringResource(R.string.msg_title),
                subtitle = stringResource(R.string.msg_encryption_short),
                onBack = onBack,
            )
            ConnectionBanner(connection)
            if (conv != null) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                    TextButton(onClick = viewModel::toggleMute) { Text(stringResource(if (conv.muted) R.string.msg_unmute else R.string.msg_mute)) }
                    TextButton(onClick = viewModel::toggleArchive) { Text(stringResource(if (conv.archived) R.string.msg_unarchive else R.string.msg_archive)) }
                    if (conv.isGroup) TextButton(onClick = { onOpenMembers(conv.id) }) { Text(stringResource(R.string.msg_members)) }
                }
            }
            if (s.loading && !s.loaded) CircularProgressIndicator()
            s.failure?.let { f ->
                FailureBanner(f)
                TextButton(onClick = viewModel::load) { Text(stringResource(R.string.action_retry)) }
            }
        }

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            reverseLayout = true,
            verticalArrangement = Arrangement.spacedBy(WwSpacing.sm),
            contentPadding = PaddingValues(horizontal = WwSpacing.md, vertical = WwSpacing.sm),
        ) {
            items(s.pending.asReversed(), key = { "pending-${it.localId}" }) { p ->
                PendingBubble(p, onRetry = { viewModel.retry(p.localId) }, onDiscard = { viewModel.discard(p.localId) })
            }
            items(s.messages, key = { it.id }) { m ->
                MessageBubble(
                    m = m, showSender = conv?.isGroup == true, replyPreview = replyText(m),
                    playback = playback, actions = actions,
                    onClick = { actionsFor = m }, onReact = { kind -> viewModel.react(m, kind) },
                    onOpenImage = { index -> viewer = m.images to index },
                    onToggleVoice = viewModel::toggleVoice,
                    onSeekVoice = viewModel::seekVoice,
                    onSaveDocument = { d -> pendingSave = d; saveLauncher.launch(d.mime to (d.fileName ?: "document")) },
                )
            }
            if (s.cursor != null && !s.loadingMore) item(key = "more") { LaunchedEffect(s.cursor) { viewModel.loadMore() } }
            if (s.loadingMore) item(key = "more-loading") { CircularProgressIndicator() }
            if (s.loaded && s.messages.isEmpty() && s.pending.isEmpty() && s.failure == null) item(key = "empty") {
                Text(stringResource(R.string.msg_chat_empty), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Pole pisania. Blokada rozmowy (konto zablokowane) kończy się błędem serwera po próbie wysłania — komunikat jest pokazany tu.
        Column(Modifier.fillMaxWidth().padding(horizontal = WwSpacing.md, vertical = WwSpacing.sm), verticalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
            s.actionFailure?.let {
                FailureBanner(it)
            }
            if (s.typing.isNotEmpty()) {
                Text(
                    if (s.typing.size == 1) stringResource(R.string.msg_typing_one, s.typing.first()) else stringResource(R.string.msg_typing_many),
                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            s.editing?.let {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.msg_editing), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                    TextButton(onClick = viewModel::cancelEdit) { Text(stringResource(R.string.action_cancel)) }
                }
            }
            s.replyTo?.let { r ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.msg_replying_to, r.sender.name, preview(r)),
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = viewModel::cancelReply) { Text(stringResource(R.string.action_cancel)) }
                }
            }
            s.notice?.let { NoticeRow(it, viewModel::dismissNotice) }
            actions.message?.let { code ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(when (code) { "saved" -> R.string.attachment_saved; "save_failed" -> R.string.attachment_save_failed; else -> R.string.attachment_download_failed }),
                        Modifier.weight(1f), style = MaterialTheme.typography.bodySmall,
                        color = if (code == "saved") MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                    )
                    TextButton(onClick = actionsVm::dismissMessage) { Text(stringResource(R.string.action_dismiss)) }
                }
            }
            if (s.draftAttachments.isNotEmpty() || s.preparing > 0) {
                DraftAttachmentsStrip(s.draftAttachments, s.preparing, onRetry = viewModel::retryAttachment, onRemove = viewModel::removeAttachment)
            }
            val tooLong = s.draft.length > MessageValidation.BODY_MAX
            val mediaBusy = s.recording || s.voiceDraft != null
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                if (s.editing == null && !mediaBusy) {
                    Box {
                        IconButton(onClick = { attachMenu = true }, enabled = conv != null) {
                            Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.msg_attach))
                        }
                        DropdownMenu(expanded = attachMenu, onDismissRequest = { attachMenu = false }) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.msg_attach_photo)) },
                                onClick = { attachMenu = false; photoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.msg_attach_document)) },
                                onClick = { attachMenu = false; documentLauncher.launch(MessageDocumentTypes.pickerMimeTypes) },
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.msg_attach_voice)) },
                                onClick = { attachMenu = false; onRecordClick() },
                            )
                        }
                    }
                }
                when {
                    s.recording -> RecordingBar(s.recordingMs, onCancel = viewModel::cancelRecording, onStop = viewModel::stopRecording, modifier = Modifier.weight(1f))
                    s.voiceDraft != null -> VoicePreviewBar(
                        s.voiceDraft!!, playback, onToggle = viewModel::togglePreview, onSeek = viewModel::seekPreview,
                        onDiscard = viewModel::discardVoice, modifier = Modifier.weight(1f),
                    )
                    else -> OutlinedTextField(
                        value = s.draft, onValueChange = viewModel::onDraft, maxLines = 5, isError = tooLong,
                        placeholder = { Text(stringResource(if (s.draftAttachments.isNotEmpty()) R.string.msg_caption_hint else R.string.msg_input_hint)) },
                        supportingText = if (s.draft.length > MessageValidation.BODY_MAX - 500) {
                            { Text("${s.draft.length}/${MessageValidation.BODY_MAX}") }
                        } else null,
                        modifier = Modifier.weight(1f),
                    )
                }
                if (!s.recording) {
                    IconButton(onClick = viewModel::send, enabled = s.canSend) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = stringResource(R.string.msg_send))
                    }
                }
            }
            if (s.uploading) Text(stringResource(R.string.msg_wait_uploads), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (s.hasFailedUpload) Text(stringResource(R.string.msg_failed_uploads), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
        }
    }

    viewer?.let { (images, start) -> MessageImageViewer(images, start) { viewer = null } }
    actionsFor?.let { m ->
        MessageActionsDialog(
            m = m,
            canDelete = m.mine || conv?.canManageMembers == true,
            onReact = { kind -> viewModel.react(m, kind); actionsFor = null },
            onReply = { viewModel.startReply(m); actionsFor = null },
            onCopy = { clipboard.setText(AnnotatedString(m.body.orEmpty())); actionsFor = null },
            onEdit = { viewModel.startEdit(m); actionsFor = null },
            onDelete = { confirmDelete = m; actionsFor = null },
            onDismiss = { actionsFor = null },
        )
    }
    confirmDelete?.let { m ->
        ConfirmDialog(
            title = stringResource(R.string.msg_delete_title),
            text = stringResource(R.string.msg_delete_body),
            confirmLabel = stringResource(R.string.msg_delete),
            onConfirm = { viewModel.delete(m); confirmDelete = null },
            onDismiss = { confirmDelete = null },
        )
    }
}

// ---------- Członkowie grupy ----------

private fun rank(role: String?) = when (role) { "owner" -> 3; "admin" -> 2; "member" -> 1; else -> 0 }

@Composable
private fun roleLabel(role: String): String = when (role) {
    "owner" -> stringResource(R.string.msg_role_owner)
    "admin" -> stringResource(R.string.msg_role_admin)
    else -> stringResource(R.string.msg_role_member)
}

@Composable
fun GroupMembersScreen(
    onBack: () -> Unit,
    onOpenUser: (String) -> Unit,
    onLeft: () -> Unit,
    viewModel: GroupMembersViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    var confirmRemove by remember { mutableStateOf<ChatMember?>(null) }
    var confirmLeave by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(s.left) { if (s.left) onLeft() }
    val conv: Conversation? = s.conversation
    val myRole = conv?.myRole

    Column(Modifier.fillMaxSize().imePadding().padding(horizontal = WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
        WwScreenHeader(
            title = conv?.displayName ?: stringResource(R.string.msg_members),
            subtitle = conv?.let { stringResource(R.string.msg_group_members_count, it.memberCount) },
            onBack = onBack,
        )
        if (s.loading) CircularProgressIndicator()
        s.failure?.let { f ->
            FailureBanner(f)
            TextButton(onClick = viewModel::load) { Text(stringResource(R.string.action_retry)) }
        }
        s.actionFailure?.let { FailureBanner(it) }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm), contentPadding = PaddingValues(bottom = WwSpacing.md)) {
            items(s.members, key = { it.person.winkwinkId }) { m ->
                val isSelf = m.person.winkwinkId == s.selfId
                WwCard {
                    Row(
                        Modifier.fillMaxWidth().clickable(enabled = !isSelf) { onOpenUser(m.person.winkwinkId) },
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm),
                    ) {
                        UserAvatar(m.person.winkwinkId, m.person.avatarTag, m.person.name, 44.dp)
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (isSelf) stringResource(R.string.msg_member_you, m.person.name) else m.person.name,
                                style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                            Text("@${m.person.nickname}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(roleLabel(m.role), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    }
                    // UI tylko odzwierciedla uprawnienia; egzekwuje je backend.
                    if (!isSelf && m.role != "owner") {
                        Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                            if (myRole == "owner") {
                                TextButton(onClick = { viewModel.setRole(m, if (m.role == "admin") "member" else "admin") }, enabled = !s.busy) {
                                    Text(stringResource(if (m.role == "admin") R.string.msg_demote_admin else R.string.msg_make_admin))
                                }
                            }
                            if (rank(myRole) > rank(m.role)) {
                                TextButton(onClick = { confirmRemove = m }, enabled = !s.busy) {
                                    Text(stringResource(R.string.msg_remove_member), color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
            if (conv?.canManageMembers == true) {
                item(key = "add-title") { Text(stringResource(R.string.msg_add_member), style = MaterialTheme.typography.titleMedium) }
                item(key = "add-search") {
                    OutlinedTextField(
                        value = s.query, onValueChange = viewModel::onQuery, singleLine = true,
                        label = { Text(stringResource(R.string.search_users_hint)) }, modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (s.searching) item(key = "searching") { CircularProgressIndicator() }
                if (s.searched && s.results.isEmpty() && !s.searching) item(key = "no-results") {
                    Text(stringResource(R.string.search_users_empty_title), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                items(s.results, key = { "result-${it.winkwinkId}" }) { u ->
                    val already = s.members.any { it.person.winkwinkId == u.winkwinkId }
                    WwCard {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                            UserAvatar(u.winkwinkId, u.avatarTag, u.displayName ?: u.nickname, 40.dp)
                            Column(Modifier.weight(1f)) {
                                Text(u.displayName ?: u.nickname, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("@${u.nickname}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (already) Text(stringResource(R.string.msg_already_member), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            else TextButton(onClick = { viewModel.add(u) }, enabled = !s.busy) { Text(stringResource(R.string.msg_add)) }
                        }
                    }
                }
            }
            if (conv != null) item(key = "leave") {
                if (myRole == "owner") {
                    Text(stringResource(R.string.msg_owner_cannot_leave), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    OutlinedButton(onClick = { confirmLeave = true }, enabled = !s.busy && s.selfId != null, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.msg_leave_group), color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }

    confirmRemove?.let { m ->
        ConfirmDialog(
            title = stringResource(R.string.msg_remove_title),
            text = stringResource(R.string.msg_remove_body, m.person.name),
            confirmLabel = stringResource(R.string.msg_remove_member),
            onConfirm = { viewModel.remove(m); confirmRemove = null },
            onDismiss = { confirmRemove = null },
        )
    }
    if (confirmLeave) {
        ConfirmDialog(
            title = stringResource(R.string.msg_leave_title),
            text = stringResource(R.string.msg_leave_body),
            confirmLabel = stringResource(R.string.msg_leave_group),
            onConfirm = { viewModel.leave(); confirmLeave = false },
            onDismiss = { confirmLeave = false },
        )
    }
}
