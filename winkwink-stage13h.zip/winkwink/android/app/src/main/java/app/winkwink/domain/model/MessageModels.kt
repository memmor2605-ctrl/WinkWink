package app.winkwink.domain.model

import java.time.Instant

/** Kontrakt: docs/API.md, „Etap 5”. Treść wiadomości NIE jest szyfrowana end-to-end (patrz [EncryptionState]). */
data class ChatPerson(val winkwinkId: String, val nickname: String, val displayName: String?, val avatarTag: String? = null) {
    val name get() = displayName?.takeIf { it.isNotBlank() } ?: nickname
}

data class ChatReaction(val kind: String, val count: Int, val mine: Boolean)

/**
 * Załącznik wiadomości (Etap F). Treść pliku NIE jest częścią wiadomości ani zdarzeń WSS — pobiera się ją po [id]
 * z `GET /message-attachments/{id}` (z kontrolą członkostwa w rozmowie po stronie backendu). [kind] = image | document | voice.
 */
data class MessageAttachment(
    val id: String,
    val kind: String,
    val mime: String,
    val sizeBytes: Long,
    val fileName: String?,
    val width: Int?,
    val height: Int?,
    /** Tylko głosówki; liczone przez serwer z kontenera audio. */
    val durationMs: Long?,
) {
    val isImage get() = kind == "image"
    val isDocument get() = kind == "document"
    val isVoice get() = kind == "voice"
}

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val sender: ChatPerson,
    /** null dla usuniętej wiadomości. */
    val body: String?,
    val replyToId: String?,
    val createdAt: Instant,
    val editedAt: Instant?,
    val deleted: Boolean,
    val mine: Boolean,
    /** Tylko własne wiadomości: sent | delivered | read (dwa ostatnie tylko przy włączonych potwierdzeniach obu stron). */
    val status: String?,
    val reactions: List<ChatReaction> = emptyList(),
    val attachments: List<MessageAttachment> = emptyList(),
) {
    val myReaction: String? get() = reactions.firstOrNull { it.mine }?.kind
    val images get() = attachments.filter { it.isImage }
    val documents get() = attachments.filter { it.isDocument }
    val voice get() = attachments.firstOrNull { it.isVoice }
}

/** Limity zgodne z backendem (`MessageMedia`); serwer pozostaje źródłem prawdy. */
object MessageMediaLimits {
    const val MAX_IMAGES = 10
    const val MAX_DOCUMENTS = 5
    const val DOCUMENT_MAX_BYTES = 10 * 1024 * 1024
    const val VOICE_MAX_MS = 10 * 60 * 1000L
    const val VOICE_MIN_MS = 500L
}

data class Conversation(
    val id: String,
    /** direct | group */
    val kind: String,
    val title: String?,
    val peer: ChatPerson?,
    val memberCount: Int,
    val muted: Boolean,
    val archived: Boolean,
    val unreadCount: Int,
    /** owner | admin | member */
    val myRole: String,
    val lastMessage: ChatMessage?,
    val activityAt: Instant,
) {
    val isGroup get() = kind == "group"
    val displayName get() = if (isGroup) title.orEmpty() else peer?.name.orEmpty()
    val canManageMembers get() = isGroup && (myRole == "owner" || myRole == "admin")
}

data class ConversationPage(val items: List<Conversation>, val nextCursor: String?)
/** Strona zmian wiadomości; [serverTime] z zegara serwera jest punktem odniesienia kolejnej synchronizacji. */
data class ChatChangesPage(val items: List<ChatMessage>, val nextCursor: String?, val serverTime: Instant)
data class ChatMessagePage(val items: List<ChatMessage>, val nextCursor: String?)
data class ChatMember(val person: ChatPerson, val role: String, val joinedAt: Instant)

object ChatReactions {
    /** Zestaw ustalony z backendem (`REACTION_KINDS`); kolejność = kolejność w menu. */
    val kinds = listOf("like", "love", "laugh", "wow", "sad", "thanks")
    fun emoji(kind: String) = when (kind) {
        "like" -> "\uD83D\uDC4D"
        "love" -> "\u2764\uFE0F"
        "laugh" -> "\uD83D\uDE02"
        "wow" -> "\uD83D\uDE2E"
        "sad" -> "\uD83D\uDE22"
        "thanks" -> "\uD83D\uDE4F"
        else -> "\u2753"
    }
}

/** Stan szyfrowania komunikatora widoczny w UI. HTTPS/WSS chroni transport, ale NIE oznacza E2EE. */
enum class EncryptionState { TRANSPORT_ONLY }

object MessagingStatus {
    /** Zmienić dopiero po wdrożeniu i weryfikacji protokołu E2EE (Etap G). */
    val encryption = EncryptionState.TRANSPORT_ONLY
}
