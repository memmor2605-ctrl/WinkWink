package app.winkwink.ui.messages

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.Formatter
import androidx.activity.result.contract.ActivityResultContract
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.winkwink.R
import app.winkwink.domain.media.PlaybackState
import app.winkwink.domain.media.PlaybackStatus
import app.winkwink.domain.model.ChatMessage
import app.winkwink.domain.model.MessageAttachment
import app.winkwink.domain.repository.MessageRepository
import app.winkwink.ui.components.LocalWinkImageLoader
import app.winkwink.ui.components.MediaUrls
import app.winkwink.ui.theme.WwSpacing
import coil.compose.SubcomposeAsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

// ---------- formatowanie ----------

/** m:ss dla czasu trwania/pozycji nagrania. */
internal fun formatDuration(ms: Long): String {
    val total = (ms.coerceAtLeast(0) + 500) / 1000
    return "%d:%02d".format(total / 60, total % 60)
}

// ---------- zapis dokumentu (pobieranie) ----------

data class MessageAttachmentActionState(
    /** Identyfikator załącznika, który jest właśnie pobierany. */
    val busyId: String? = null,
    /** Kod komunikatu: saved | save_failed | download_failed. */
    val message: String? = null,
)

/**
 * Bezpieczne pobieranie dokumentu: plik jest pobierany strumieniowo z REST (z kontrolą dostępu na backendzie) do prywatnego pliku tymczasowego, a kopiujemy go tylko w miejscu
 * wskazanym przez użytkownika w systemowym wybieraku (SAF) — aplikacja nie otwiera pliku ani nie zapisuje go w pamięci publicznej.
 */
@HiltViewModel
class MessageAttachmentActionsViewModel @Inject constructor(
    private val repository: MessageRepository,
    @ApplicationContext private val context: Context,
) : ViewModel() {
    private val _state = MutableStateFlow(MessageAttachmentActionState())
    val state: StateFlow<MessageAttachmentActionState> = _state.asStateFlow()

    fun saveDocument(a: MessageAttachment, destination: Uri) {
        if (_state.value.busyId != null) return
        _state.update { it.copy(busyId = a.id, message = null) }
        viewModelScope.launch {
            val tmp = java.io.File(java.io.File(context.cacheDir, "downloads").apply { mkdirs() }, "${a.id}.tmp")
            if (repository.downloadAttachmentToFile(a.id, tmp).isFailure) { _state.update { it.copy(busyId = null, message = "download_failed") }; return@launch }
            val ok = withContext(Dispatchers.IO) {
                try { runCatching { context.contentResolver.openOutputStream(destination)?.use { out -> tmp.inputStream().use { it.copyTo(out) } } != null }.getOrDefault(false) } finally { tmp.delete() }
            }
            _state.update { it.copy(busyId = null, message = if (ok) "saved" else "save_failed") }
        }
    }

    fun dismissMessage() = _state.update { it.copy(message = null) }
}

/** Wybierak miejsca zapisu z typem i proponowaną nazwą pliku podawanymi przy każdym uruchomieniu. */
internal class CreateTypedDocument : ActivityResultContract<Pair<String, String>, Uri?>() {
    override fun createIntent(context: Context, input: Pair<String, String>): Intent =
        Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(input.first).putExtra(Intent.EXTRA_TITLE, input.second)

    override fun parseResult(resultCode: Int, intent: Intent?): Uri? = intent?.takeIf { resultCode == Activity.RESULT_OK }?.data
}

// ---------- obrazy ----------

@Composable
internal fun MessageImage(a: MessageAttachment, scale: ContentScale, modifier: Modifier) {
    val context = LocalContext.current
    val loader = LocalWinkImageLoader.current ?: context.imageLoader
    // Zmiana `attempt` tworzy nowe żądanie, więc nieudane ładowanie (brak internetu) można ponowić stuknięciem.
    var attempt by remember(a.id) { mutableIntStateOf(0) }
    val request = remember(a.id, attempt) { ImageRequest.Builder(context).data(MediaUrls.messageAttachment(a.id)).build() }
    SubcomposeAsyncImage(
        model = request,
        contentDescription = stringResource(R.string.attachment_image),
        imageLoader = loader,
        contentScale = scale,
        modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant),
        loading = { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp) } },
        error = {
            Box(Modifier.fillMaxSize().clickable { attempt++ }, contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.msg_media_load_failed), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(WwSpacing.xs))
            }
        },
    )
}

@Composable
private fun ImageGallery(images: List<MessageAttachment>, onOpen: (Int) -> Unit) {
    val shape = MaterialTheme.shapes.small
    if (images.size == 1) {
        val a = images.first()
        val w = a.width; val h = a.height
        val ratio = if (w != null && h != null && h > 0) (w.toFloat() / h).coerceIn(0.75f, 1.8f) else 1.5f
        MessageImage(a, ContentScale.Crop, Modifier.fillMaxWidth().aspectRatio(ratio).clip(shape).clickable { onOpen(0) })
        return
    }
    val shown = images.take(4)
    val extra = images.size - shown.size
    Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
        shown.chunked(2).forEachIndexed { rowIndex, row ->
            Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                row.forEachIndexed { colIndex, a ->
                    val index = rowIndex * 2 + colIndex
                    Box(Modifier.weight(1f).aspectRatio(1f).clip(shape).clickable { onOpen(index) }) {
                        MessageImage(a, ContentScale.Crop, Modifier.fillMaxSize())
                        if (extra > 0 && index == shown.lastIndex) {
                            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)), contentAlignment = Alignment.Center) {
                                Text("+$extra", color = Color.White, style = MaterialTheme.typography.titleLarge)
                            }
                        }
                    }
                }
                if (row.size == 1) Box(Modifier.weight(1f)) // wyrównanie samotnego kafelka
            }
        }
    }
}

/** Pełny ekran: przewijana galeria wszystkich zdjęć wiadomości. */
@Composable
internal fun MessageImageViewer(images: List<MessageAttachment>, start: Int, onDismiss: () -> Unit) {
    val pager = rememberPagerState(initialPage = start.coerceIn(0, images.lastIndex)) { images.size }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            HorizontalPager(pager, Modifier.fillMaxSize()) { page ->
                MessageImage(images[page], ContentScale.Fit, Modifier.fillMaxSize())
            }
            Row(Modifier.fillMaxWidth().padding(WwSpacing.sm), verticalAlignment = Alignment.CenterVertically) {
                Text("${pager.currentPage + 1}/${images.size}", Modifier.weight(1f).padding(start = WwSpacing.sm), color = Color.White)
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close), color = Color.White) }
            }
        }
    }
}

// ---------- dokumenty ----------

@Composable
private fun DocumentRow(a: MessageAttachment, busy: Boolean, onSave: () -> Unit) {
    val context = LocalContext.current
    Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)) {
        Row(Modifier.fillMaxWidth().padding(WwSpacing.sm), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            Column(Modifier.weight(1f)) {
                Text(a.fileName ?: stringResource(R.string.attachment_document), style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                val ext = a.fileName?.substringAfterLast('.', "")?.uppercase().orEmpty()
                Text(
                    listOf(ext, Formatter.formatShortFileSize(context, a.sizeBytes)).filter { it.isNotEmpty() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (busy) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp) else TextButton(onClick = onSave) { Text(stringResource(R.string.attachment_save)) }
        }
    }
}

// ---------- głosówki ----------

/** Odtwarzacz głosówki: odtwórz/pauza, pasek postępu z przewijaniem, czas (pozycja / całość). Stan jest wspólny dla całej aplikacji. */
@Composable
internal fun VoicePlayer(
    key: String,
    durationMs: Long,
    playback: PlaybackState,
    onToggle: () -> Unit,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val active = playback.isActive(key)
    val status = if (active) playback.status else PlaybackStatus.IDLE
    val total = if (active && playback.durationMs > 0) playback.durationMs else durationMs
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
        Box(Modifier.size(width = 72.dp, height = 40.dp), contentAlignment = Alignment.Center) {
            if (status == PlaybackStatus.LOADING) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            else TextButton(onClick = onToggle) {
                Text(stringResource(if (status == PlaybackStatus.PLAYING) R.string.voice_pause else R.string.voice_play))
            }
        }
        Column(Modifier.weight(1f)) {
            Slider(
                value = playback.fraction(key, durationMs), onValueChange = onSeek,
                enabled = status == PlaybackStatus.PLAYING || status == PlaybackStatus.PAUSED,
            )
            val position = if (active) playback.positionMs else 0L
            if (status == PlaybackStatus.ERROR) {
                Text(stringResource(R.string.voice_play_failed), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
            } else {
                Text("${formatDuration(position)} / ${formatDuration(total)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ---------- zawartość bąbelka ----------

/** Zdjęcia (galeria), dokumenty i głosówka wiadomości; wywoływane wewnątrz bąbelka. */
@Composable
internal fun MessageMediaContent(
    m: ChatMessage,
    playback: PlaybackState,
    actions: MessageAttachmentActionState,
    onOpenImage: (Int) -> Unit,
    onToggleVoice: (MessageAttachment) -> Unit,
    onSeekVoice: (MessageAttachment, Float) -> Unit,
    onSaveDocument: (MessageAttachment) -> Unit,
) {
    val images = m.images
    if (images.isNotEmpty()) ImageGallery(images, onOpenImage)
    m.documents.forEach { d -> DocumentRow(d, busy = actions.busyId == d.id, onSave = { onSaveDocument(d) }) }
    m.voice?.let { v ->
        VoicePlayer(v.id, v.durationMs ?: 0L, playback, onToggle = { onToggleVoice(v) }, onSeek = { f -> onSeekVoice(v, f) })
    }
}
