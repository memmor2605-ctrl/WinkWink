package app.winkwink.domain.repository

import app.winkwink.domain.model.NotificationPage

interface NotificationRepository {
    suspend fun list(type: String?, unreadOnly: Boolean, cursor: String?): Result<NotificationPage>
    suspend fun unreadCount(): Result<Int>
    suspend fun markRead(id: String): Result<Unit>
    /** [type] ogranicza operację do jednego typu; null = wszystkie. */
    suspend fun markAllRead(type: String?): Result<Unit>
    /** Mapa typ → włączony (stan z serwera). */
    suspend fun settings(): Result<Map<String, Boolean>>
    /** Aktualizacja częściowa; zwraca pełną mapę z serwera. */
    suspend fun updateSettings(changes: Map<String, Boolean>): Result<Map<String, Boolean>>
}
