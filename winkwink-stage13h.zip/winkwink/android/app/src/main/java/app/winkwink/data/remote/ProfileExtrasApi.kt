package app.winkwink.data.remote

import kotlinx.serialization.Serializable
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

@Serializable data class HideFollowListsRequestDto(val hideFollowLists: Boolean)

/** Etap A: avatar, tło, wyciszanie, posty profilu. Kontrakt: docs/API.md, „Etap A”. */
interface ProfileExtrasApi {
    /** Surowe ciało = JPEG; Content-Length ustawia OkHttp (serwer go wymaga). */
    @PUT("api/v1/me/avatar") suspend fun putAvatar(@Body body: RequestBody): Response<UserProfileDto>
    @DELETE("api/v1/me/avatar") suspend fun deleteAvatar(): Response<UserProfileDto>
    @PUT("api/v1/me/background") suspend fun putBackground(@Body body: RequestBody): Response<UserProfileDto>
    @DELETE("api/v1/me/background") suspend fun deleteBackground(): Response<UserProfileDto>

    @POST("api/v1/users/{id}/mute") suspend fun mute(@Path("id") id: String): Response<Unit>
    @DELETE("api/v1/users/{id}/mute") suspend fun unmute(@Path("id") id: String): Response<Unit>
    @GET("api/v1/me/mutes") suspend fun mutes(@Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<UserListDto>

    @PATCH("api/v1/me/profile") suspend fun setHideFollowLists(@Body body: HideFollowListsRequestDto): Response<UserProfileDto>

    @GET("api/v1/users/{id}/posts") suspend fun userPosts(@Path("id") id: String, @Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<PostListDto>
}
