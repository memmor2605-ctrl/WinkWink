package app.winkwink.data.remote

import app.winkwink.domain.model.UserProfile
import app.winkwink.domain.model.UserSummary
import kotlinx.serialization.Serializable

@Serializable
data class UserProfileDto(
    val winkwinkId: String,
    val nickname: String,
    val displayName: String? = null,
    val bio: String? = null,
    val links: List<String>? = null,
    val visibility: String,
    val hasAvatar: Boolean = false,
    val hasBackground: Boolean = false,
    val restricted: Boolean = false,
    val followers: Int? = null,
    val following: Int? = null,
    val isSelf: Boolean = false,
    val followState: String = "none",
    val followedByThem: Boolean = false,
    val avatarTag: String? = null,
    val backgroundTag: String? = null,
    val muted: Boolean = false,
    val followListsHidden: Boolean = false,
)

@Serializable data class UserSummaryDto(val winkwinkId: String, val nickname: String, val displayName: String? = null, val avatarTag: String? = null)
@Serializable data class UserListDto(val users: List<UserSummaryDto>, val nextCursor: String? = null)
@Serializable data class FollowDto(val state: String)

@Serializable
data class UpdateProfileRequestDto(
    val displayName: String? = null,
    val clearDisplayName: Boolean = false,
    val bio: String? = null,
    val links: List<String>? = null,
    val visibility: String? = null,
)

fun UserProfileDto.toDomain() = UserProfile(
    winkwinkId, nickname, displayName, bio, links.orEmpty(), visibility, restricted, followers, following, isSelf, followState, followedByThem,
    avatarTag = avatarTag, backgroundTag = backgroundTag, muted = muted, followListsHidden = followListsHidden,
)
fun UserSummaryDto.toDomain() = UserSummary(winkwinkId, nickname, displayName, avatarTag)
