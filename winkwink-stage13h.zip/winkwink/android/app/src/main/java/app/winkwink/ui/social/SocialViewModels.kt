package app.winkwink.ui.social

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.UserProfile
import app.winkwink.domain.model.UserSummary
import app.winkwink.domain.media.ImageKind
import app.winkwink.domain.repository.AuthRepository
import app.winkwink.domain.repository.ProfileExtrasRepository
import app.winkwink.domain.repository.SocialRepository
import app.winkwink.domain.validation.ProfileValidation
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

// ---------- Wyszukiwanie użytkowników ----------

data class SearchUiState(
    val query: String = "",
    val loading: Boolean = false,
    val results: List<UserSummary> = emptyList(),
    /** true, gdy zapytanie ma ≥ 2 znaki i wynik został pobrany (pozwala odróżnić „brak wyników” od „nic jeszcze nie wpisano”). */
    val searched: Boolean = false,
    val failure: ApiFailure? = null,
)

@OptIn(FlowPreview::class)
@HiltViewModel
class UserSearchViewModel @Inject constructor(private val repository: SocialRepository) : ViewModel() {
    private val _state = MutableStateFlow(SearchUiState())
    val state: StateFlow<SearchUiState> = _state.asStateFlow()
    private val queries = MutableStateFlow("")

    init {
        viewModelScope.launch {
            queries.debounce(300).collectLatest { q ->
                if (q.trim().removePrefix("@").length < 2) {
                    _state.update { it.copy(loading = false, results = emptyList(), searched = false, failure = null) }
                    return@collectLatest
                }
                _state.update { it.copy(loading = true, failure = null) }
                val r = repository.search(q)
                _state.update {
                    it.copy(loading = false, results = r.getOrDefault(emptyList()), searched = r.isSuccess, failure = r.exceptionOrNull() as? ApiFailure)
                }
            }
        }
    }

    fun onQuery(v: String) {
        _state.update { it.copy(query = v) }
        queries.value = v
    }
}

// ---------- Profil użytkownika ----------

data class UserProfileUiState(
    val loading: Boolean = true,
    val profile: UserProfile? = null,
    val actionInProgress: Boolean = false,
    val failure: ApiFailure? = null,
    val blocked: Boolean = false,
)

@HiltViewModel
class UserProfileViewModel @Inject constructor(
    private val repository: SocialRepository,
    private val extras: ProfileExtrasRepository,
    savedState: SavedStateHandle,
) : ViewModel() {
    private val identifier: String = checkNotNull(savedState["id"])
    private val _state = MutableStateFlow(UserProfileUiState())
    val state: StateFlow<UserProfileUiState> = _state.asStateFlow()

    init { load() }

    fun load() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val r = repository.profile(identifier)
            _state.update { it.copy(loading = false, profile = r.getOrNull() ?: it.profile, failure = r.exceptionOrNull() as? ApiFailure) }
        }
    }

    /** Obserwuj / anuluj prośbę / przestań obserwować — zależnie od aktualnego stanu. Po sukcesie profil jest pobierany ponownie z serwera. */
    fun toggleFollow() {
        val p = _state.value.profile ?: return
        if (_state.value.actionInProgress || p.isSelf) return
        runAction { if (p.followState == "none") repository.follow(identifier).map { } else repository.unfollow(identifier) }
    }

    /** Wycisz / cofnij wyciszenie. Prywatne: druga strona nie dostaje żadnego sygnału. Stan po akcji pochodzi z serwera. */
    fun toggleMute() {
        val p = _state.value.profile ?: return
        if (_state.value.actionInProgress || p.isSelf) return
        runAction { if (p.muted) extras.unmute(identifier) else extras.mute(identifier) }
    }

    fun block() {
        if (_state.value.actionInProgress) return
        _state.update { it.copy(actionInProgress = true, failure = null) }
        viewModelScope.launch {
            val r = repository.block(identifier)
            _state.update { it.copy(actionInProgress = false, blocked = r.isSuccess, failure = r.exceptionOrNull() as? ApiFailure) }
        }
    }

    private fun runAction(call: suspend () -> Result<Unit>) {
        _state.update { it.copy(actionInProgress = true, failure = null) }
        viewModelScope.launch {
            val r = call()
            if (r.isSuccess) {
                val fresh = repository.profile(identifier)
                _state.update { it.copy(actionInProgress = false, profile = fresh.getOrNull() ?: it.profile, failure = fresh.exceptionOrNull() as? ApiFailure) }
            } else {
                _state.update { it.copy(actionInProgress = false, failure = r.exceptionOrNull() as? ApiFailure) }
            }
        }
    }
}

// ---------- Edycja własnego profilu ----------

data class EditProfileUiState(
    val loading: Boolean = true,
    val displayName: String = "",
    val bio: String = "",
    val linksText: String = "",
    val visibility: String = "public",
    val saving: Boolean = false,
    val saved: Boolean = false,
    val bioTooLong: Boolean = false,
    val nameTooLong: Boolean = false,
    val tooManyLinks: Boolean = false,
    val failure: ApiFailure? = null,
    val selfId: String? = null,
    val avatarTag: String? = null,
    val backgroundTag: String? = null,
    val hideFollowLists: Boolean = false,
    /** Trwa wysyłanie/usuwanie obrazu danego rodzaju. */
    val imageBusy: ImageKind? = null,
    val imageFailure: ApiFailure? = null,
)

@HiltViewModel
class EditProfileViewModel @Inject constructor(
    private val social: SocialRepository,
    private val auth: AuthRepository,
    private val extras: ProfileExtrasRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(EditProfileUiState())
    val state: StateFlow<EditProfileUiState> = _state.asStateFlow()

    init { load() }

    fun load() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val me = auth.me()
            val id = me.getOrNull()?.profile?.winkwinkId
            if (id == null) {
                _state.update { it.copy(loading = false, failure = me.exceptionOrNull() as? ApiFailure) }
                return@launch
            }
            val r = social.profile(id)
            val p = r.getOrNull()
            _state.update {
                if (p == null) it.copy(loading = false, failure = r.exceptionOrNull() as? ApiFailure)
                else it.copy(
                    loading = false, displayName = p.displayName.orEmpty(), bio = p.bio.orEmpty(),
                    linksText = p.links.joinToString("\n"), visibility = p.visibility,
                    selfId = p.winkwinkId, avatarTag = p.avatarTag, backgroundTag = p.backgroundTag, hideFollowLists = p.followListsHidden,
                )
            }
        }
    }

    fun onName(v: String) = _state.update { it.copy(displayName = v, nameTooLong = false, saved = false, failure = null) }
    fun onBio(v: String) = _state.update { it.copy(bio = v, bioTooLong = false, saved = false, failure = null) }
    fun onLinks(v: String) = _state.update { it.copy(linksText = v, tooManyLinks = false, saved = false, failure = null) }
    fun onVisibility(v: String) = _state.update { it.copy(visibility = v, saved = false, failure = null) }

    /** [uri] pochodzi z systemowego wybieraka zdjęć; obraz jest zmniejszany i kodowany do JPEG (bez EXIF) przed wysłaniem. */
    fun onImagePicked(kind: ImageKind, uri: String) {
        if (_state.value.imageBusy != null) return
        _state.update { it.copy(imageBusy = kind, imageFailure = null) }
        viewModelScope.launch {
            val r = extras.setImage(kind, uri)
            applyImageResult(r)
        }
    }

    fun removeImage(kind: ImageKind) {
        if (_state.value.imageBusy != null) return
        _state.update { it.copy(imageBusy = kind, imageFailure = null) }
        viewModelScope.launch { applyImageResult(extras.removeImage(kind)) }
    }

    private fun applyImageResult(r: Result<app.winkwink.domain.model.UserProfile>) {
        val p = r.getOrNull()
        _state.update {
            if (p == null) it.copy(imageBusy = null, imageFailure = r.exceptionOrNull() as? ApiFailure)
            else it.copy(imageBusy = null, avatarTag = p.avatarTag, backgroundTag = p.backgroundTag)
        }
    }

    /** Ustawienie zapisywane od razu; stan przełącznika pochodzi z odpowiedzi serwera. */
    fun onHideFollowLists(hide: Boolean) {
        viewModelScope.launch {
            val r = extras.setHideFollowLists(hide)
            _state.update {
                r.getOrNull()?.let { p -> it.copy(hideFollowLists = p.followListsHidden, failure = null) }
                    ?: it.copy(failure = r.exceptionOrNull() as? ApiFailure)
            }
        }
    }

    fun save() {
        val s = _state.value
        if (s.saving || s.loading) return
        val links = ProfileValidation.splitLinks(s.linksText)
        val bioBad = ProfileValidation.bioTooLong(s.bio)
        val nameBad = ProfileValidation.displayNameTooLong(s.displayName)
        val linksBad = ProfileValidation.tooManyLinks(links)
        if (bioBad || nameBad || linksBad) {
            _state.update { it.copy(bioTooLong = bioBad, nameTooLong = nameBad, tooManyLinks = linksBad) }
            return
        }
        _state.update { it.copy(saving = true, failure = null) }
        viewModelScope.launch {
            val r = social.updateProfile(s.displayName, s.bio, links, s.visibility)
            _state.update { it.copy(saving = false, saved = r.isSuccess, failure = r.exceptionOrNull() as? ApiFailure) }
        }
    }
}
