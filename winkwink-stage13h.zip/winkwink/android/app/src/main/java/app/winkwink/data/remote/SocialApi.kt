package app.winkwink.data.remote

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

/** Endpointy chronione (klient z tokenem). Kontrakt: docs/API.md, „Etap 2”. */
interface SocialApi {
    @GET("api/v1/users/{id}") suspend fun profile(@Path("id") id: String): Response<UserProfileDto>
    @GET("api/v1/users/search") suspend fun search(@Query("q") q: String, @Query("limit") limit: Int): Response<UserListDto>
    @POST("api/v1/users/{id}/follow") suspend fun follow(@Path("id") id: String): Response<FollowDto>
    @DELETE("api/v1/users/{id}/follow") suspend fun unfollow(@Path("id") id: String): Response<Unit>
    @POST("api/v1/users/{id}/block") suspend fun block(@Path("id") id: String): Response<Unit>
    @DELETE("api/v1/users/{id}/block") suspend fun unblock(@Path("id") id: String): Response<Unit>
    @GET("api/v1/users/{id}/followers") suspend fun followers(@Path("id") id: String, @Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<UserListDto>
    @GET("api/v1/users/{id}/following") suspend fun following(@Path("id") id: String, @Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<UserListDto>
    @GET("api/v1/me/follow-requests") suspend fun followRequests(@Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<UserListDto>
    @POST("api/v1/me/follow-requests/{id}/approve") suspend fun approveRequest(@Path("id") id: String): Response<Unit>
    @DELETE("api/v1/me/follow-requests/{id}") suspend fun rejectRequest(@Path("id") id: String): Response<Unit>
    @GET("api/v1/me/blocks") suspend fun blocks(@Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<UserListDto>
    @PATCH("api/v1/me/profile") suspend fun updateProfile(@Body body: UpdateProfileRequestDto): Response<UserProfileDto>
}
