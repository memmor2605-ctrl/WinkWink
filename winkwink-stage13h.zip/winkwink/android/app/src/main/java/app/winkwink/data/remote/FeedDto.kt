package app.winkwink.data.remote

import app.winkwink.domain.model.Attachment
import app.winkwink.domain.model.Comment
import app.winkwink.domain.model.CommentPage
import app.winkwink.domain.model.Post
import app.winkwink.domain.model.PostAuthor
import app.winkwink.domain.model.PostPage
import kotlinx.serialization.Serializable
import java.time.Instant

@Serializable data class AuthorDto(val winkwinkId: String, val nickname: String, val displayName: String? = null, val hasAvatar: Boolean = false, val avatarTag: String? = null)

/** Kontrakt: docs/API.md, „Etap 3”. Dla postów anonimowych [author] jest zawsze null. */
@Serializable
data class PostDto(
    val id: String,
    val author: AuthorDto? = null,
    val anonymous: Boolean,
    val mine: Boolean,
    val body: String,
    val visibility: String,
    val createdAt: String,
    val editedAt: String? = null,
    val reactions: Int,
    val comments: Int,
    val myReaction: String? = null,
    val saved: Boolean,
    val communityId: String? = null,
    val channelId: String? = null,
    val attachments: List<AttachmentDto> = emptyList(),
    val shares: Int = 0,
    val isShare: Boolean = false,
    val shared: PostDto? = null,
    val sharedUnavailable: Boolean = false,
)

@Serializable
data class AttachmentDto(
    val id: String,
    val kind: String,
    val mime: String,
    val sizeBytes: Long,
    val fileName: String? = null,
    val width: Int? = null,
    val height: Int? = null,
)

@Serializable data class PostListDto(val posts: List<PostDto>, val nextCursor: String? = null)

@Serializable
data class CommentDto(
    val id: String,
    val postId: String,
    val parentId: String? = null,
    val author: AuthorDto? = null,
    val authorHidden: Boolean = false,
    val mine: Boolean,
    val body: String,
    val createdAt: String,
    val replyCount: Int = 0,
)

@Serializable data class CommentListDto(val comments: List<CommentDto>, val nextCursor: String? = null)

@Serializable data class CreatePostRequestDto(
    val body: String, val visibility: String, val anonymous: Boolean,
    val communityId: String? = null, val channelId: String? = null,
    val attachmentIds: List<String> = emptyList(),
)
@Serializable data class SharePostRequestDto(val comment: String, val visibility: String)
@Serializable data class UpdatePostRequestDto(val body: String)
@Serializable data class ReactionRequestDto(val type: String)
@Serializable data class CreateCommentRequestDto(val body: String, val parentId: String? = null)

private fun AuthorDto.toDomain() = PostAuthor(winkwinkId, nickname, displayName, avatarTag)

fun PostDto.toDomain() = Post(
    id = id,
    author = author?.toDomain(),
    anonymous = anonymous,
    mine = mine,
    body = body,
    visibility = visibility,
    createdAt = Instant.parse(createdAt),
    edited = editedAt != null,
    reactions = reactions,
    comments = comments,
    myReaction = myReaction,
    saved = saved,
    communityId = communityId,
    channelId = channelId,
    attachments = attachments.map { it.toDomain() },
    shares = shares,
    isShare = isShare,
    shared = shared?.toDomain(),
    sharedUnavailable = sharedUnavailable,
)

fun AttachmentDto.toDomain() = Attachment(id, kind, mime, sizeBytes, fileName, width, height)

fun PostListDto.toDomain() = PostPage(posts.map { it.toDomain() }, nextCursor)

fun CommentDto.toDomain() = Comment(
    id = id,
    postId = postId,
    parentId = parentId,
    author = author?.toDomain(),
    authorHidden = authorHidden,
    mine = mine,
    body = body,
    createdAt = Instant.parse(createdAt),
    replyCount = replyCount,
)

fun CommentListDto.toDomain() = CommentPage(comments.map { it.toDomain() }, nextCursor)
