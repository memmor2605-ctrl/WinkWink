package app.winkwink.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.winkwink.BuildConfig
import coil.ImageLoader
import coil.compose.AsyncImage

/** Ładowarka obrazów z tokenem sesji (dostarczana w MainActivity). Bez niej wyświetlane są tylko inicjały. */
val LocalWinkImageLoader = staticCompositionLocalOf<ImageLoader?> { null }

object MediaUrls {
    private fun enc(s: String) = android.net.Uri.encode(s)

    /** Znacznik wersji w adresie unieważnia cache po zmianie obrazu. */
    fun avatar(winkwinkId: String, tag: String) = "${BuildConfig.API_BASE_URL}api/v1/users/${enc(winkwinkId)}/avatar?v=${enc(tag)}"
    /** Załączniki są niezmienne (identyfikator = treść), więc URL może być cache'owany bez znacznika wersji. */
    fun attachment(id: String) = "${BuildConfig.API_BASE_URL}api/v1/attachments/${enc(id)}"
    /** Pliki wiadomości są niezmienne (id = treść), ale dostęp wymaga członkostwa w rozmowie — ładowarka dodaje token sesji. */
    fun messageAttachment(id: String) = "${BuildConfig.API_BASE_URL}api/v1/message-attachments/${enc(id)}"
    fun background(winkwinkId: String, tag: String) = "${BuildConfig.API_BASE_URL}api/v1/users/${enc(winkwinkId)}/background?v=${enc(tag)}"
}

/**
 * Avatar użytkownika. [winkwinkId] == null (autor anonimowy / ukryty) → neutralny znak zapytania, nigdy żadne zapytanie sieciowe.
 * Brak [avatarTag] → inicjał nazwy.
 */
@Composable
fun UserAvatar(winkwinkId: String?, avatarTag: String?, name: String, size: Dp = 40.dp, modifier: Modifier = Modifier) {
    val loader = LocalWinkImageLoader.current
    val shape = CircleShape
    val base = modifier.size(size).clip(shape)
    if (winkwinkId != null && avatarTag != null && loader != null) {
        AsyncImage(
            model = MediaUrls.avatar(winkwinkId, avatarTag),
            contentDescription = null,
            imageLoader = loader,
            contentScale = ContentScale.Crop,
            modifier = base.background(MaterialTheme.colorScheme.surfaceVariant),
        )
    } else {
        Box(base.background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
            val initial = if (winkwinkId == null) "?" else name.trim().firstOrNull()?.uppercase() ?: "?"
            Text(initial, color = MaterialTheme.colorScheme.onPrimaryContainer, fontSize = (size.value * 0.42f).sp)
        }
    }
}

/** Zdjęcie w tle profilu w stałych proporcjach (przycinane), dzięki czemu wygląda poprawnie na każdym ekranie. */
@Composable
fun ProfileBackground(winkwinkId: String, backgroundTag: String?, modifier: Modifier = Modifier) {
    val loader = LocalWinkImageLoader.current
    val box = modifier.fillMaxWidth().aspectRatio(3f).clip(MaterialTheme.shapes.medium).background(MaterialTheme.colorScheme.surfaceVariant)
    if (backgroundTag != null && loader != null) {
        AsyncImage(
            model = MediaUrls.background(winkwinkId, backgroundTag),
            contentDescription = null,
            imageLoader = loader,
            contentScale = ContentScale.Crop,
            modifier = box,
        )
    } else {
        Box(box)
    }
}
