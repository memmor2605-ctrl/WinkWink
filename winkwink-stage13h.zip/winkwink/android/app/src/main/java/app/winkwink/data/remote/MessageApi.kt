package app.winkwink.data.remote

import app.winkwink.domain.model.ChatMember
import app.winkwink.domain.model.ChatMessage
import app.winkwink.domain.model.ChatChangesPage
import app.winkwink.domain.model.ChatMessagePage
import app.winkwink.domain.model.ChatPerson
import app.winkwink.domain.model.ChatReaction
import app.winkwink.domain.model.Conversation
import app.winkwink.domain.model.ConversationPage
import app.winkwink.domain.model.MessageAttachment
import kotlinx.serialization.Serializable
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.Header
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Streaming
import java.time.Instant

@Serializable data class ChatPersonDto(val winkwinkId: String, val nickname: String, val displayName: String? = null, val avatarTag: String? = null)
@Serializable data class ChatReactionDto(val kind: String, val count: Int, val mine: Boolean)

@Serializable
data class MessageAttachmentDto(
    val id: String,
    val kind: String,
    val mime: String,
    val sizeBytes: Long,
    val fileName: String? = null,
    val width: Int? = null,
    val height: Int? = null,
    val durationMs: Long? = null,
)

@Serializable
data class ChatMessageDto(
    val id: String,
    val conversationId: String,
    val sender: ChatPersonDto,
    val body: String? = null,
    val replyToId: String? = null,
    val createdAt: String,
    val editedAt: String? = null,
    val deleted: Boolean = false,
    val mine: Boolean = false,
    val status: String? = null,
    val reactions: List<ChatReactionDto> = emptyList(),
    val attachments: List<MessageAttachmentDto> = emptyList(),
)

@Serializable
data class ConversationDto(
    val id: String,
    val kind: String,
    val title: String? = null,
    val peer: ChatPersonDto? = null,
    val memberCount: Int,
    val muted: Boolean = false,
    val archived: Boolean = false,
    val unreadCount: Int = 0,
    val myRole: String,
    val lastMessage: ChatMessageDto? = null,
    val activityAt: String,
)

@Serializable data class ConversationListDto(val conversations: List<ConversationDto>, val nextCursor: String? = null)
@Serializable data class ChatMessageListDto(val messages: List<ChatMessageDto>, val nextCursor: String? = null)
@Serializable data class ChatChangesDto(val messages: List<ChatMessageDto>, val nextCursor: String? = null, val serverTime: String)
@Serializable data class ChatMemberDto(val person: ChatPersonDto, val role: String, val joinedAt: String)
@Serializable data class ChatMemberListDto(val members: List<ChatMemberDto>)

@Serializable data class StartDirectRequestDto(val user: String)
@Serializable data class CreateGroupRequestDto(val title: String, val members: List<String>)
@Serializable data class SendMessageRequestDto(val body: String, val replyToId: String? = null, val attachmentIds: List<String> = emptyList(), val clientId: String? = null)
@Serializable data class EditMessageRequestDto(val body: String)
@Serializable data class ConversationSettingsRequestDto(val muted: Boolean? = null, val archived: Boolean? = null)
@Serializable data class AddMemberRequestDto(val user: String)
@Serializable data class MemberRoleRequestDto(val role: String)
@Serializable data class SetReactionRequestDto(val kind: String)
@Serializable data class MessageSettingsDto(val readReceipts: Boolean)

fun ChatPersonDto.toDomain() = ChatPerson(winkwinkId, nickname, displayName, avatarTag)
fun MessageAttachmentDto.toDomain() = MessageAttachment(id, kind, mime, sizeBytes, fileName, width, height, durationMs)

/** Zły format daty zgłasza [java.time.DateTimeException] — repozytorium zamienia go na `invalid_response`. */
fun ChatMessageDto.toDomain() = ChatMessage(
    id = id, conversationId = conversationId, sender = sender.toDomain(),
    body = if (deleted) null else body, replyToId = replyToId,
    createdAt = Instant.parse(createdAt), editedAt = editedAt?.let(Instant::parse),
    deleted = deleted, mine = mine, status = if (mine) status else null,
    reactions = reactions.map { ChatReaction(it.kind, it.count, it.mine) },
    attachments = if (deleted) emptyList() else attachments.map { it.toDomain() },
)

fun ConversationDto.toDomain() = Conversation(
    id = id, kind = kind, title = title, peer = peer?.toDomain(), memberCount = memberCount, muted = muted, archived = archived,
    unreadCount = unreadCount, myRole = myRole, lastMessage = lastMessage?.toDomain(), activityAt = Instant.parse(activityAt),
)

fun ConversationListDto.toDomain() = ConversationPage(conversations.map { it.toDomain() }, nextCursor)
fun ChatChangesDto.toDomain() = ChatChangesPage(messages.map { it.toDomain() }, nextCursor, Instant.parse(serverTime))
fun ChatMessageListDto.toDomain() = ChatMessagePage(messages.map { it.toDomain() }, nextCursor)
fun ChatMemberDto.toDomain() = ChatMember(person.toDomain(), role, Instant.parse(joinedAt))

/** Endpointy chronione. Kontrakt: docs/API.md, „Etap 5”. */
interface MessageApi {
    @GET("api/v1/conversations")
    suspend fun conversations(
        @Query("archived") archived: Boolean,
        @Query("q") q: String?,
        @Query("limit") limit: Int,
        @Query("cursor") cursor: String?,
    ): Response<ConversationListDto>

    @POST("api/v1/conversations/direct") suspend fun startDirect(@Body body: StartDirectRequestDto): Response<ConversationDto>
    @POST("api/v1/conversations/group") suspend fun createGroup(@Body body: CreateGroupRequestDto): Response<ConversationDto>
    @GET("api/v1/conversations/{id}") suspend fun conversation(@Path("id") id: String): Response<ConversationDto>
    @PATCH("api/v1/conversations/{id}/settings") suspend fun settings(@Path("id") id: String, @Body body: ConversationSettingsRequestDto): Response<ConversationDto>
    @POST("api/v1/conversations/{id}/read") suspend fun markRead(@Path("id") id: String): Response<Unit>

    @GET("api/v1/conversations/{id}/messages")
    suspend fun messages(@Path("id") id: String, @Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<ChatMessageListDto>

    /** Synchronizacja różnicowa: wiadomości zmienione od [since] (ISO-8601) albo od [cursor]; rosnąco. */
    @GET("api/v1/conversations/{id}/messages/changes")
    suspend fun changes(@Path("id") id: String, @Query("since") since: String?, @Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<ChatChangesDto>

    @POST("api/v1/conversations/{id}/messages") suspend fun send(@Path("id") id: String, @Body body: SendMessageRequestDto): Response<ChatMessageDto>
    @PATCH("api/v1/messages/{id}") suspend fun edit(@Path("id") id: String, @Body body: EditMessageRequestDto): Response<ChatMessageDto>
    @DELETE("api/v1/messages/{id}") suspend fun delete(@Path("id") id: String): Response<Unit>
    @PUT("api/v1/messages/{id}/reaction") suspend fun react(@Path("id") id: String, @Body body: SetReactionRequestDto): Response<ChatMessageDto>
    @DELETE("api/v1/messages/{id}/reaction") suspend fun unreact(@Path("id") id: String): Response<ChatMessageDto>

    @GET("api/v1/conversations/{id}/members") suspend fun members(@Path("id") id: String): Response<ChatMemberListDto>
    @POST("api/v1/conversations/{id}/members") suspend fun addMember(@Path("id") id: String, @Body body: AddMemberRequestDto): Response<ChatMemberListDto>
    @DELETE("api/v1/conversations/{id}/members/{user}") suspend fun removeMember(@Path("id") id: String, @Path("user") user: String): Response<Unit>
    @PUT("api/v1/conversations/{id}/members/{user}/role")
    suspend fun setMemberRole(@Path("id") id: String, @Path("user") user: String, @Body body: MemberRoleRequestDto): Response<ChatMemberListDto>

    /**
     * Wysyłanie pliku do rozmowy: surowe ciało = plik, Content-Type i Content-Length ustawia OkHttp na podstawie [RequestBody].
     * Plik jest „niedołączony” do czasu wysłania wiadomości z jego identyfikatorem.
     */
    @POST("api/v1/message-attachments")
    suspend fun uploadAttachment(
        @Query("conversationId") conversationId: String,
        @Query("name") name: String?,
        @Body body: RequestBody,
        @Header("Idempotency-Key") idempotencyKey: String?,
    ): Response<MessageAttachmentDto>

    @DELETE("api/v1/message-attachments/{id}") suspend fun deleteAttachment(@Path("id") id: String): Response<Unit>
    @Streaming @GET("api/v1/message-attachments/{id}") suspend fun downloadAttachment(@Path("id") id: String): Response<ResponseBody>

    @GET("api/v1/messages/settings") suspend fun readReceipts(): Response<MessageSettingsDto>
    @PUT("api/v1/messages/settings") suspend fun setReadReceipts(@Body body: MessageSettingsDto): Response<MessageSettingsDto>
}
