package app.winkwink.domain.repository

import app.winkwink.domain.model.HealthCheckResult

interface DiagnosticsRepository {
    suspend fun checkHealth(): HealthCheckResult
}
