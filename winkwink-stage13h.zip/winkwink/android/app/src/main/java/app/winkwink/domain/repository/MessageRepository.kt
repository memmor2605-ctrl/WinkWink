package app.winkwink.domain.repository

import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.ChatChangesPage
import app.winkwink.domain.model.ChatMember
import app.winkwink.domain.model.ChatMessage
import app.winkwink.domain.model.ChatMessagePage
import app.winkwink.domain.model.Conversation
import app.winkwink.domain.model.ConversationPage
import app.winkwink.domain.model.MessageAttachment
import app.winkwink.domain.model.PreparedFile

/** Wiadomości przez REST (historia i synchronizacja awaryjna). Etap E doda WSS obok, nie zamiast. */
interface MessageRepository {
    suspend fun conversations(archived: Boolean, query: String?, cursor: String?): Result<ConversationPage>
    suspend fun startDirect(user: String): Result<Conversation>
    suspend fun createGroup(title: String, members: List<String>): Result<Conversation>
    suspend fun conversation(id: String): Result<Conversation>
    /** Pola null = bez zmiany. Zwraca stan rozmowy z serwera. */
    suspend fun setFlags(id: String, muted: Boolean?, archived: Boolean?): Result<Conversation>
    suspend fun markRead(id: String): Result<Unit>
    /** Od najnowszych; [cursor] == null = pierwsza strona. */
    suspend fun messages(id: String, cursor: String?): Result<ChatMessagePage>
    /** [attachmentIds] — wcześniej wysłane pliki ([uploadAttachment]); wiadomość z załącznikami może mieć pustą treść. */
    suspend fun send(id: String, body: String, replyToId: String?, attachmentIds: List<String> = emptyList()): Result<ChatMessage>
    /** Wysyła plik do rozmowy (zdjęcie, dokument lub głosówkę). Zwraca niedołączony załącznik. */
    suspend fun uploadAttachment(conversationId: String, file: PreparedFile): Result<MessageAttachment>
    /** Wycofuje niedołączony plik z serwera (best effort — serwer i tak sprząta porzucone po 24 h). */
    suspend fun deleteAttachment(id: String): Result<Unit>
    /** Pobiera treść załącznika (REST z tokenem sesji). */
    suspend fun downloadAttachment(id: String): Result<ByteArray>
    /**
     * Pobiera załącznik strumieniowo do pliku (bez całości w pamięci); anulowanie korutyny przerywa pobieranie, a niepełny plik jest usuwany.
     * Domyślnie przez [downloadAttachment].
     */
    suspend fun downloadAttachmentToFile(id: String, target: java.io.File): Result<Unit> =
        downloadAttachment(id).mapCatching { target.writeBytes(it) }
    /** Zmiany wiadomości od [since] albo od [cursor] (synchronizacja po utracie połączenia). */
    suspend fun changes(id: String, since: java.time.Instant?, cursor: String?): Result<ChatChangesPage> =
        Result.failure(ApiFailure("unsupported", "Not supported"))
    suspend fun edit(messageId: String, body: String): Result<ChatMessage>
    suspend fun delete(messageId: String): Result<Unit>
    suspend fun react(messageId: String, kind: String): Result<ChatMessage>
    suspend fun unreact(messageId: String): Result<ChatMessage>
    suspend fun members(id: String): Result<List<ChatMember>>
    suspend fun addMember(id: String, user: String): Result<List<ChatMember>>
    /** [user] równy własnemu kontu = opuszczenie grupy. */
    suspend fun removeMember(id: String, user: String): Result<Unit>
    suspend fun setMemberRole(id: String, user: String, role: String): Result<List<ChatMember>>
    suspend fun readReceipts(): Result<Boolean>
    suspend fun setReadReceipts(enabled: Boolean): Result<Boolean>
}
