package app.winkwink.data.repository

import app.winkwink.data.remote.HideFollowListsRequestDto
import app.winkwink.data.remote.ProfileExtrasApi
import app.winkwink.data.remote.apiCall
import app.winkwink.data.remote.toDomain
import app.winkwink.domain.media.ImageKind
import app.winkwink.domain.media.ImagePreparer
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.PostPage
import app.winkwink.domain.model.UserPage
import app.winkwink.domain.model.UserProfile
import app.winkwink.domain.repository.ProfileExtrasRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.time.format.DateTimeParseException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProfileExtrasRepositoryImpl @Inject constructor(
    private val api: ProfileExtrasApi,
    private val images: ImagePreparer,
    private val json: Json,
) : ProfileExtrasRepository {

    override suspend fun setImage(kind: ImageKind, uri: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        val bytes = images.prepare(uri, kind).getOrElse {
            return@withContext Result.failure(ApiFailure("image_unreadable", it.message ?: "Cannot read image"))
        }
        val body = bytes.toRequestBody("image/jpeg".toMediaType())
        apiCall(json) { if (kind == ImageKind.AVATAR) api.putAvatar(body) else api.putBackground(body) }.map { it.toDomain() }
    }

    override suspend fun removeImage(kind: ImageKind): Result<UserProfile> = withContext(Dispatchers.IO) {
        apiCall(json) { if (kind == ImageKind.AVATAR) api.deleteAvatar() else api.deleteBackground() }.map { it.toDomain() }
    }

    override suspend fun mute(identifier: String): Result<Unit> = withContext(Dispatchers.IO) { apiCall(json) { api.mute(identifier) }.map { } }
    override suspend fun unmute(identifier: String): Result<Unit> = withContext(Dispatchers.IO) { apiCall(json) { api.unmute(identifier) }.map { } }

    override suspend fun muted(cursor: String?): Result<UserPage> = withContext(Dispatchers.IO) {
        apiCall(json) { api.mutes(PAGE, cursor) }.map { r -> UserPage(r.users.map { it.toDomain() }, r.nextCursor) }
    }

    override suspend fun setHideFollowLists(hide: Boolean): Result<UserProfile> = withContext(Dispatchers.IO) {
        apiCall(json) { api.setHideFollowLists(HideFollowListsRequestDto(hide)) }.map { it.toDomain() }
    }

    override suspend fun userPosts(identifier: String, cursor: String?): Result<PostPage> = withContext(Dispatchers.IO) {
        apiCall(json) { api.userPosts(identifier, PAGE, cursor) }.mapCatching {
            try { it.toDomain() } catch (e: DateTimeParseException) { throw ApiFailure("invalid_response", "Unexpected response") }
        }
    }

    private companion object { const val PAGE = 20 }
}
