package app.winkwink.ui.feed

import android.content.Context
import android.net.Uri
import android.text.format.Formatter
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import app.winkwink.R
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.Attachment
import app.winkwink.domain.repository.FeedRepository
import app.winkwink.ui.components.LocalWinkImageLoader
import app.winkwink.ui.components.MediaUrls
import app.winkwink.ui.components.WwCard
import app.winkwink.ui.theme.WwSpacing
import coil.compose.AsyncImage
import coil.imageLoader
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

data class AttachmentActionState(
    /** Identyfikator załącznika, który jest właśnie pobierany. */
    val busyId: String? = null,
    /** Ścieżka pliku wideo w cache do odtworzenia. */
    val videoPath: String? = null,
    /** Kod komunikatu: saved | save_failed | download_failed. */
    val message: String? = null,
)

/**
 * Pobieranie załączników wymagających pliku lokalnie: film (do odtworzenia z cache aplikacji) i dokument (zapis w miejscu wskazanym przez użytkownika).
 * Zdjęcia są wczytywane bezpośrednio przez Coil (z tokenem sesji). Plik filmu leży w cache aplikacji, nie w pamięci publicznej.
 */
@HiltViewModel
class AttachmentActionsViewModel @Inject constructor(
    private val repository: FeedRepository,
    @ApplicationContext private val context: Context,
) : ViewModel() {
    private val _state = MutableStateFlow(AttachmentActionState())
    val state: StateFlow<AttachmentActionState> = _state.asStateFlow()

    fun playVideo(a: Attachment) {
        if (_state.value.busyId != null) return
        _state.update { it.copy(busyId = a.id, message = null) }
        viewModelScope.launch {
            val dir = File(context.cacheDir, "videos").apply { mkdirs() }
            val target = File(dir, "${a.id}.mp4")
            if (!target.exists()) {
                // Cache trzyma tylko aktualnie oglądany film — poprzednie pliki są usuwane.
                withContext(Dispatchers.IO) { dir.listFiles()?.forEach { it.delete() } }
                // Strumieniowo do pliku (film może mieć dziesiątki MB); anulowanie/opuszczenie ekranu przerywa pobieranie.
                if (repository.downloadAttachmentToFile(a.id, target).isFailure) { _state.update { it.copy(busyId = null, message = "download_failed") }; return@launch }
            }
            _state.update { it.copy(busyId = null, videoPath = target.absolutePath) }
        }
    }

    fun closeVideo() = _state.update { it.copy(videoPath = null) }

    fun saveDocument(a: Attachment, destination: Uri) {
        if (_state.value.busyId != null) return
        _state.update { it.copy(busyId = a.id, message = null) }
        viewModelScope.launch {
            val tmp = File(File(context.cacheDir, "downloads").apply { mkdirs() }, "${a.id}.tmp")
            if (repository.downloadAttachmentToFile(a.id, tmp).isFailure) { _state.update { it.copy(busyId = null, message = "download_failed") }; return@launch }
            val ok = withContext(Dispatchers.IO) {
                try { runCatching { context.contentResolver.openOutputStream(destination)?.use { out -> tmp.inputStream().use { it.copyTo(out) } } != null }.getOrDefault(false) } finally { tmp.delete() }
            }
            _state.update { it.copy(busyId = null, message = if (ok) "saved" else "save_failed") }
        }
    }

    fun dismissMessage() = _state.update { it.copy(message = null) }
}

/** Załączniki posta: galeria zdjęć (siatka + pełny ekran), film (odtwarzany po pobraniu) i dokumenty (zapis przez systemowy wybierak). */
@Composable
fun PostAttachments(attachments: List<Attachment>, modifier: Modifier = Modifier, viewModel: AttachmentActionsViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val images = attachments.filter { it.isImage }
    var viewerStart by remember { mutableStateOf<Int?>(null) }
    var pendingDocument by remember { mutableStateOf<Attachment?>(null) }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val doc = pendingDocument
        pendingDocument = null
        if (uri != null && doc != null) viewModel.saveDocument(doc, uri)
    }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
        if (images.isNotEmpty()) ImageGallery(images, onOpen = { viewerStart = it })
        attachments.filter { it.isVideo }.forEach { v ->
            AttachmentRow(
                title = stringResource(R.string.attachment_video),
                size = Formatter.formatShortFileSize(context, v.sizeBytes),
                action = stringResource(R.string.attachment_play),
                busy = state.busyId == v.id,
                onAction = { viewModel.playVideo(v) },
            )
        }
        attachments.filter { it.isDocument }.forEach { d ->
            AttachmentRow(
                title = d.fileName ?: stringResource(R.string.attachment_document),
                size = Formatter.formatShortFileSize(context, d.sizeBytes),
                action = stringResource(R.string.attachment_save),
                busy = state.busyId == d.id,
                onAction = { pendingDocument = d; saveLauncher.launch(d.fileName ?: "document.pdf") },
            )
        }
        state.message?.let { code ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(when (code) { "saved" -> R.string.attachment_saved; "save_failed" -> R.string.attachment_save_failed; else -> R.string.attachment_download_failed }),
                    Modifier.weight(1f), style = MaterialTheme.typography.bodySmall,
                    color = if (code == "saved") MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                )
                TextButton(onClick = viewModel::dismissMessage) { Text(stringResource(R.string.action_dismiss)) }
            }
        }
    }
    viewerStart?.let { ImageViewerDialog(images, it) { viewerStart = null } }
    state.videoPath?.let { VideoDialog(it, viewModel::closeVideo) }
}

@Composable
private fun AttachmentRow(title: String, size: String, action: String, busy: Boolean, onAction: () -> Unit) {
    WwCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                Text(size, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (busy) CircularProgressIndicator(Modifier.size(24.dp)) else TextButton(onClick = onAction) { Text(action) }
        }
    }
}

@Composable
private fun RemoteAttachmentImage(a: Attachment, scale: ContentScale, modifier: Modifier) {
    val context = LocalContext.current
    val loader = LocalWinkImageLoader.current ?: context.imageLoader
    AsyncImage(
        model = MediaUrls.attachment(a.id),
        contentDescription = stringResource(R.string.attachment_image),
        imageLoader = loader,
        contentScale = scale,
        modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant),
    )
}

@Composable
private fun ImageGallery(images: List<Attachment>, onOpen: (Int) -> Unit) {
    val shape = MaterialTheme.shapes.medium
    if (images.size == 1) {
        val a = images.first()
        val ratio = if (a.width != null && a.height != null && a.height > 0) (a.width.toFloat() / a.height).coerceIn(0.75f, 1.8f) else 1.5f
        RemoteAttachmentImage(a, ContentScale.Crop, Modifier.fillMaxWidth().aspectRatio(ratio).clip(shape).clickable { onOpen(0) })
        return
    }
    val shown = images.take(4)
    val extra = images.size - shown.size
    Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
        shown.chunked(2).forEachIndexed { rowIndex, row ->
            Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                row.forEachIndexed { colIndex, a ->
                    val index = rowIndex * 2 + colIndex
                    Box(Modifier.weight(1f).aspectRatio(1f).clip(shape).clickable { onOpen(index) }) {
                        RemoteAttachmentImage(a, ContentScale.Crop, Modifier.fillMaxSize())
                        if (extra > 0 && index == shown.lastIndex) {
                            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)), contentAlignment = Alignment.Center) {
                                Text("+$extra", color = Color.White, style = MaterialTheme.typography.titleLarge)
                            }
                        }
                    }
                }
                if (row.size == 1) Box(Modifier.weight(1f)) // wyrównanie ostatniego, samotnego kafelka
            }
        }
    }
}

@Composable
private fun ImageViewerDialog(images: List<Attachment>, start: Int, onDismiss: () -> Unit) {
    val pager = rememberPagerState(initialPage = start.coerceIn(0, images.lastIndex)) { images.size }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            HorizontalPager(pager, Modifier.fillMaxSize()) { page ->
                RemoteAttachmentImage(images[page], ContentScale.Fit, Modifier.fillMaxSize())
            }
            Row(Modifier.fillMaxWidth().padding(WwSpacing.sm), verticalAlignment = Alignment.CenterVertically) {
                Text("${pager.currentPage + 1}/${images.size}", Modifier.weight(1f).padding(start = WwSpacing.sm), color = Color.White)
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close), color = Color.White) }
            }
        }
    }
}

@Composable
private fun VideoDialog(path: String, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    VideoView(ctx).apply {
                        setVideoPath(path)
                        setMediaController(MediaController(ctx).also { it.setAnchorView(this) })
                        setOnPreparedListener { start() }
                    }
                },
                onRelease = { it.stopPlayback() },
            )
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.TopEnd).padding(WwSpacing.sm)) {
                Text(stringResource(R.string.action_close), color = Color.White)
            }
        }
    }
}
