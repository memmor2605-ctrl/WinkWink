package app.winkwink.data.push

import app.winkwink.domain.push.DeepLink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/** Oczekujące otwarcie ekranu po stuknięciu powiadomienia. Jednorazowe: [consume] czyści wartość, a stan przeżywa rekompozycję. */
@Singleton
class DeepLinkBus @Inject constructor() {
    private val _pending = MutableStateFlow<DeepLink?>(null)
    val pending: StateFlow<DeepLink?> = _pending.asStateFlow()
    fun post(link: DeepLink) { _pending.value = link }
    fun clear() { _pending.value = null }
    fun consume(link: DeepLink) { _pending.compareAndSet(link, null) }
}
