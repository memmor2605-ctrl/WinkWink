package app.winkwink.ui.auth

import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.foundation.layout.fillMaxWidth
import app.winkwink.R
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.validation.FieldError

@Composable
fun WwTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    error: FieldError?,
    modifier: Modifier = Modifier,
    password: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Next,
    enabled: Boolean = true,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        isError = error != null,
        supportingText = error?.let { { Text(it.text()) } },
        singleLine = true,
        enabled = enabled,
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboardType, imeAction = imeAction),
        modifier = modifier.fillMaxWidth(),
    )
}

@Composable
fun FieldError.text(): String = when (this) {
    FieldError.EMAIL_INVALID -> stringResource(R.string.err_email_invalid)
    FieldError.PASSWORD_TOO_SHORT -> stringResource(R.string.err_password_short)
    FieldError.PASSWORD_TOO_LONG -> stringResource(R.string.err_password_long)
    FieldError.PASSWORD_SAME_AS_EMAIL -> stringResource(R.string.err_password_same)
    FieldError.NICKNAME_INVALID -> stringResource(R.string.err_nickname_invalid)
    FieldError.REQUIRED -> stringResource(R.string.err_required)
}

@Composable
fun ApiFailure.text(): String = when (code) {
    "invalid_credentials" -> stringResource(R.string.fail_invalid_credentials)
    "email_taken" -> stringResource(R.string.fail_email_taken)
    "nickname_taken" -> stringResource(R.string.fail_nickname_taken)
    "too_many_attempts" -> stringResource(R.string.fail_too_many, ((retryAfterSeconds ?: 900L) + 59L).div(60L).toInt())
    "validation_failed" -> stringResource(R.string.fail_validation)
    "account_unavailable" -> stringResource(R.string.fail_account_unavailable)
    "refresh_token_reused", "invalid_refresh_token", "unauthorized" -> stringResource(R.string.fail_session_expired)
    "email_delivery_unavailable" -> stringResource(R.string.fail_email_unavailable)
    "invalid_or_expired_token" -> stringResource(R.string.fail_invalid_token)
    "user_not_found" -> stringResource(R.string.fail_user_not_found)
    "profile_restricted" -> stringResource(R.string.user_profile_restricted)
    "follow_lists_hidden" -> stringResource(R.string.user_profile_lists_hidden)
    "image_unreadable", "invalid_image" -> stringResource(R.string.fail_image_unreadable)
    "payload_too_large", "image_too_large" -> stringResource(R.string.fail_image_too_large)
    "unsupported_media_type" -> stringResource(R.string.fail_file_unsupported)
    "cannot_mute_self" -> stringResource(R.string.fail_generic)
    "conversation_not_found" -> stringResource(R.string.fail_conversation_not_found)
    "message_not_found" -> stringResource(R.string.fail_message_not_found)
    "user_unavailable" -> stringResource(R.string.fail_user_unavailable)
    "owner_cannot_leave" -> stringResource(R.string.fail_owner_cannot_leave)
    "group_full" -> stringResource(R.string.fail_group_full)
    "forbidden" -> stringResource(R.string.fail_forbidden)
    "wrong_password" -> stringResource(R.string.fail_wrong_password)
    "upload_rate_limited" -> stringResource(R.string.fail_upload_rate_limited)
    "too_many_pending" -> stringResource(R.string.fail_too_many_pending)
    "attachments_unavailable" -> stringResource(R.string.fail_attachments_unavailable)
    "attachment_not_found" -> stringResource(R.string.fail_attachment_not_found)
    "recording_too_short" -> stringResource(R.string.fail_recording_too_short)
    "recording_too_long" -> stringResource(R.string.fail_recording_too_long)
    "file_unreadable" -> stringResource(R.string.fail_file_unreadable)
    "network" -> stringResource(R.string.failure_unreachable)
    "timeout" -> stringResource(R.string.failure_timeout)
    "tls" -> stringResource(R.string.failure_tls)
    "insecure" -> stringResource(R.string.failure_insecure)
    "invalid_response" -> stringResource(R.string.failure_invalid_response)
    else -> if (httpStatus >= 500) stringResource(R.string.failure_server_error, httpStatus) else stringResource(R.string.fail_generic)
}

@Composable
fun FailureBanner(failure: ApiFailure, modifier: Modifier = Modifier) {
    Text(
        text = failure.text(),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.error,
        modifier = modifier.fillMaxWidth(),
    )
}
