package app.winkwink.domain.repository

import app.winkwink.domain.model.UserPage
import app.winkwink.domain.model.UserProfile
import app.winkwink.domain.model.UserSummary

interface SocialRepository {
    suspend fun profile(identifier: String): Result<UserProfile>
    suspend fun search(query: String): Result<List<UserSummary>>
    /** @return nowy stan relacji: "accepted" albo "pending". */
    suspend fun follow(identifier: String): Result<String>
    suspend fun unfollow(identifier: String): Result<Unit>
    suspend fun block(identifier: String): Result<Unit>
    suspend fun unblock(identifier: String): Result<Unit>
    suspend fun followers(identifier: String, cursor: String?): Result<UserPage>
    suspend fun following(identifier: String, cursor: String?): Result<UserPage>
    suspend fun followRequests(cursor: String?): Result<UserPage>
    suspend fun approveRequest(identifier: String): Result<Unit>
    suspend fun rejectRequest(identifier: String): Result<Unit>
    suspend fun blocked(cursor: String?): Result<UserPage>
    /** [displayName] puste = usunięcie nazwy wyświetlanej. */
    suspend fun updateProfile(displayName: String, bio: String, links: List<String>, visibility: String): Result<UserProfile>
}
