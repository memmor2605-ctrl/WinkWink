package app.winkwink.data.remote

import app.winkwink.domain.model.AppNotification
import app.winkwink.domain.model.NotificationActor
import app.winkwink.domain.model.NotificationPage
import kotlinx.serialization.Serializable
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query
import java.time.Instant

@Serializable data class NotificationActorDto(val winkwinkId: String, val nickname: String, val displayName: String? = null, val hasAvatar: Boolean = false)

@Serializable
data class NotificationDto(
    val id: String,
    val type: String,
    val actor: NotificationActorDto? = null,
    val actorAnonymous: Boolean = false,
    val postId: String? = null,
    val commentId: String? = null,
    val communityId: String? = null,
    val createdAt: String,
    val read: Boolean,
)

@Serializable data class NotificationListDto(val notifications: List<NotificationDto>, val nextCursor: String? = null, val unreadCount: Int = 0)
@Serializable data class UnreadCountDto(val unreadCount: Int)
@Serializable data class NotificationSettingsDto(val types: Map<String, Boolean>)

fun NotificationDto.toDomain() = AppNotification(
    id = id, type = type,
    // Anonimowy aktor: nawet gdyby serwer przysłał dane, nie pokazujemy ich.
    actor = if (actorAnonymous) null else actor?.let { NotificationActor(it.winkwinkId, it.nickname, it.displayName, it.hasAvatar) },
    postId = postId, commentId = commentId, communityId = communityId,
    createdAt = Instant.parse(createdAt), read = read,
)

fun NotificationListDto.toDomain() = NotificationPage(notifications.map { it.toDomain() }, nextCursor, unreadCount)

/** Endpointy chronione. Kontrakt: docs/API.md, „Etap 6”. */
interface NotificationApi {
    @GET("api/v1/notifications")
    suspend fun list(
        @Query("type") type: String?,
        @Query("unread") unread: Boolean?,
        @Query("limit") limit: Int,
        @Query("cursor") cursor: String?,
    ): Response<NotificationListDto>

    @GET("api/v1/notifications/unread-count") suspend fun unreadCount(): Response<UnreadCountDto>
    @POST("api/v1/notifications/{id}/read") suspend fun markRead(@Path("id") id: String): Response<Unit>
    @POST("api/v1/notifications/read-all") suspend fun markAllRead(@Query("type") type: String?): Response<Unit>
    @GET("api/v1/notifications/settings") suspend fun settings(): Response<NotificationSettingsDto>
    @PUT("api/v1/notifications/settings") suspend fun updateSettings(@Body body: NotificationSettingsDto): Response<NotificationSettingsDto>
}
