package app.winkwink.ui.social

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.UserPage
import app.winkwink.domain.model.UserSummary
import app.winkwink.domain.repository.SocialRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class UserListKind(val route: String) {
    FOLLOWERS("followers"), FOLLOWING("following"), REQUESTS("requests"), BLOCKED("blocked");

    companion object {
        fun fromRoute(value: String): UserListKind = entries.firstOrNull { it.route == value }
            ?: throw IllegalArgumentException("Unknown user list kind: $value")
    }
}

data class UserListUiState(
    val loading: Boolean = true,
    val loadingMore: Boolean = false,
    val users: List<UserSummary> = emptyList(),
    val nextCursor: String? = null,
    /** Identyfikator użytkownika, dla którego trwa akcja (akceptacja / odrzucenie / odblokowanie). */
    val busyId: String? = null,
    val failure: ApiFailure? = null,
)

/**
 * Jedna lista, cztery źródła. Akcje (akceptuj / odrzuć / odblokuj) usuwają wiersz dopiero po potwierdzeniu serwera.
 * Uprawnienia egzekwuje backend (np. 403 `profile_restricted` dla list obcego, ograniczonego profilu).
 */
@HiltViewModel
class UserListViewModel @Inject constructor(
    private val repository: SocialRepository,
    savedState: SavedStateHandle,
) : ViewModel() {
    val kind: UserListKind = UserListKind.fromRoute(checkNotNull(savedState["kind"]))
    private val identifier: String = checkNotNull(savedState["id"])
    private val _state = MutableStateFlow(UserListUiState())
    val state: StateFlow<UserListUiState> = _state.asStateFlow()

    init { refresh() }

    private suspend fun fetch(cursor: String?): Result<UserPage> = when (kind) {
        UserListKind.FOLLOWERS -> repository.followers(identifier, cursor)
        UserListKind.FOLLOWING -> repository.following(identifier, cursor)
        UserListKind.REQUESTS -> repository.followRequests(cursor)
        UserListKind.BLOCKED -> repository.blocked(cursor)
    }

    fun refresh() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            fetch(null).fold(
                onSuccess = { p -> _state.update { it.copy(users = p.users, nextCursor = p.nextCursor, loading = false) } },
                onFailure = { e -> _state.update { it.copy(loading = false, failure = e.asFailure()) } },
            )
        }
    }

    fun loadMore() {
        val cursor = _state.value.nextCursor ?: return
        if (_state.value.loading || _state.value.loadingMore) return
        _state.update { it.copy(loadingMore = true, failure = null) }
        viewModelScope.launch {
            fetch(cursor).fold(
                onSuccess = { p ->
                    _state.update { st ->
                        val known = st.users.mapTo(HashSet()) { u -> u.winkwinkId }
                        st.copy(users = st.users + p.users.filter { u -> u.winkwinkId !in known }, nextCursor = p.nextCursor, loadingMore = false)
                    }
                },
                onFailure = { e -> _state.update { it.copy(loadingMore = false, failure = e.asFailure()) } },
            )
        }
    }

    fun approve(user: UserSummary) = act(user) { repository.approveRequest(user.winkwinkId) }
    fun reject(user: UserSummary) = act(user) { repository.rejectRequest(user.winkwinkId) }
    fun unblock(user: UserSummary) = act(user) { repository.unblock(user.winkwinkId) }

    private fun act(user: UserSummary, call: suspend () -> Result<Unit>) {
        if (_state.value.busyId != null) return
        _state.update { it.copy(busyId = user.winkwinkId, failure = null) }
        viewModelScope.launch {
            call().fold(
                onSuccess = { _state.update { st -> st.copy(busyId = null, users = st.users.filter { u -> u.winkwinkId != user.winkwinkId }) } },
                onFailure = { e -> _state.update { it.copy(busyId = null, failure = e.asFailure()) } },
            )
        }
    }

    private fun Throwable.asFailure(): ApiFailure = this as? ApiFailure ?: ApiFailure("unknown", "Unknown error")
}
