package app.winkwink.ui.activity

import android.text.format.DateUtils
import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.winkwink.R
import app.winkwink.domain.model.AppNotification
import app.winkwink.domain.model.NotificationKinds
import app.winkwink.ui.auth.FailureBanner
import app.winkwink.ui.components.WwCard
import app.winkwink.ui.components.WwScreenHeader
import app.winkwink.ui.theme.WwSpacing

@StringRes
private fun typeLabelRes(type: String) = when (type) {
    "new_follower" -> R.string.activity_type_new_follower
    "follow_request" -> R.string.activity_type_follow_request
    "reaction" -> R.string.activity_type_reaction
    "comment" -> R.string.activity_type_comment
    "reply" -> R.string.activity_type_reply
    "community_invite_accepted", "community_request_approved" -> R.string.activity_type_community_activity
    else -> R.string.activity_type_community_invite
}

@Composable
private fun notificationText(n: AppNotification): String {
    val name = n.actor?.name ?: stringResource(R.string.activity_actor_anonymous)
    return when (n.type) {
        "new_follower" -> stringResource(R.string.activity_text_new_follower, name)
        "follow_request" -> stringResource(R.string.activity_text_follow_request, name)
        "reaction" -> stringResource(R.string.activity_text_reaction, name)
        "comment" -> stringResource(R.string.activity_text_comment, name)
        "reply" -> stringResource(R.string.activity_text_reply, name)
        "community_invite" -> stringResource(R.string.activity_text_community_invite, name)
        "community_invite_accepted" -> stringResource(R.string.activity_text_invite_accepted, name)
        "community_request_approved" -> stringResource(R.string.activity_text_request_approved, name)
        else -> stringResource(R.string.activity_text_unknown)
    }
}

@Composable
private fun NotificationRow(n: AppNotification, onClick: () -> Unit) {
    WwCard(Modifier.clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(
                notificationText(n),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (n.read) FontWeight.Normal else FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            if (!n.read) Text(stringResource(R.string.activity_new_badge), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = WwSpacing.sm))
        }
        Text(
            DateUtils.getRelativeTimeSpanString(n.createdAt.toEpochMilli(), System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ---------- Zakładka Aktywność ----------

@Composable
fun ActivityHomeScreen(
    onOpenUser: (String) -> Unit,
    onOpenPost: (String) -> Unit,
    onOpenCommunity: (String) -> Unit,
    onSettings: () -> Unit,
    viewModel: ActivityViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()

    fun open(n: AppNotification) {
        viewModel.markRead(n)
        when (n.type) {
            "new_follower", "follow_request" -> n.actor?.let { onOpenUser(it.winkwinkId) }
            "reaction", "comment", "reply" -> n.postId?.let(onOpenPost)
            "community_invite", "community_invite_accepted", "community_request_approved" -> n.communityId?.let(onOpenCommunity)
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
        WwScreenHeader(
            title = stringResource(R.string.activity_title),
            subtitle = if (s.unreadCount > 0) stringResource(R.string.activity_unread_subtitle, s.unreadCount) else null,
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
            TextButton(onClick = viewModel::markAllRead, enabled = s.unreadCount > 0) { Text(stringResource(R.string.activity_mark_all_read)) }
            TextButton(onClick = onSettings) { Text(stringResource(R.string.activity_settings)) }
            TextButton(onClick = viewModel::refresh, enabled = !s.loading) { Text(stringResource(R.string.activity_refresh)) }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            FilterChip(selected = s.type == null && !s.unreadOnly, onClick = { viewModel.setType(null) }, label = { Text(stringResource(R.string.activity_filter_all)) })
            FilterChip(selected = s.unreadOnly, onClick = viewModel::setUnreadOnly, label = { Text(stringResource(R.string.activity_filter_unread)) })
            NotificationKinds.all.forEach { t ->
                FilterChip(selected = s.type == t, onClick = { viewModel.setType(t) }, label = { Text(stringResource(typeLabelRes(t))) })
            }
        }
        s.failure?.let { f ->
            FailureBanner(f)
            TextButton(onClick = viewModel::refresh) { Text(stringResource(R.string.action_retry)) }
        }
        s.actionFailure?.let { FailureBanner(it) }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm), contentPadding = PaddingValues(bottom = WwSpacing.md)) {
            if (s.loading && !s.loaded) item(key = "loading") { CircularProgressIndicator() }
            if (s.loaded && !s.loading && s.failure == null && s.items.isEmpty()) item(key = "empty") {
                val filtered = s.type != null || s.unreadOnly
                Text(
                    stringResource(if (filtered) R.string.activity_empty_filtered else R.string.activity_empty),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            items(s.items, key = { it.id }) { n -> NotificationRow(n, onClick = { open(n) }) }
            if (s.cursor != null && !s.loadingMore) item(key = "more") { LaunchedEffect(s.cursor) { viewModel.loadMore() } }
            if (s.loadingMore) item(key = "more-loading") { CircularProgressIndicator() }
        }
    }
}

// ---------- Ustawienia powiadomień ----------

@Composable
fun NotificationSettingsScreen(onBack: () -> Unit, viewModel: NotificationSettingsViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(horizontal = WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
        WwScreenHeader(title = stringResource(R.string.activity_settings_title), onBack = onBack)
        Text(stringResource(R.string.activity_settings_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        s.failure?.let { f ->
            FailureBanner(f)
            if (s.types.isEmpty()) TextButton(onClick = viewModel::load) { Text(stringResource(R.string.action_retry)) }
        }
        if (s.loading) CircularProgressIndicator()
        NotificationKinds.all.filter { it in s.types }.forEach { t ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(typeLabelRes(t)), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                Switch(checked = s.types[t] == true, onCheckedChange = { viewModel.toggle(t, it) }, enabled = t !in s.saving)
            }
        }
    }
}
