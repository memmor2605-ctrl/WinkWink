package app.winkwink.domain.model

import java.time.Instant

data class PostAuthor(val winkwinkId: String, val nickname: String, val displayName: String?, val avatarTag: String? = null)

/** [author] == null przy [anonymous] — klient nigdy nie zna autora anonimowego posta (także własnego; patrz [mine]). */
data class Post(
    val id: String,
    val author: PostAuthor?,
    val anonymous: Boolean,
    val mine: Boolean,
    val body: String,
    /** public | followers | private | community */
    val visibility: String,
    val createdAt: Instant,
    val edited: Boolean,
    val reactions: Int,
    val comments: Int,
    /** like | love | laugh | wow | sad albo null */
    val myReaction: String?,
    val saved: Boolean,
    /** Ustawione tylko dla visibility = "community". */
    val communityId: String? = null,
    val channelId: String? = null,
    val attachments: List<Attachment> = emptyList(),
    /** Liczba publicznych udostępnień. */
    val shares: Int = 0,
    /** Post jest udostępnieniem; [shared] to oryginał (autor anonimowego oryginału pozostaje ukryty), [sharedUnavailable] — oryginał niedostępny. */
    val isShare: Boolean = false,
    val shared: Post? = null,
    val sharedUnavailable: Boolean = false,
)

/** Załącznik posta. Plik pobiera się z backendu po [id] (dostęp = dostęp do posta). [kind] = image | video | document. */
data class Attachment(
    val id: String,
    val kind: String,
    val mime: String,
    val sizeBytes: Long,
    val fileName: String?,
    val width: Int?,
    val height: Int?,
) {
    val isImage get() = kind == "image"
    val isVideo get() = kind == "video"
    val isDocument get() = kind == "document"
}

/** Plik przygotowany do wysłania (obraz już zmniejszony i bez EXIF). */
class PreparedFile(val bytes: ByteArray, val mime: String, val name: String?, val kind: String)

data class Comment(
    val id: String,
    val postId: String,
    val parentId: String?,
    val author: PostAuthor?,
    val authorHidden: Boolean,
    val mine: Boolean,
    val body: String,
    val createdAt: Instant,
    val replyCount: Int,
)

data class PostPage(val posts: List<Post>, val nextCursor: String?)
data class CommentPage(val comments: List<Comment>, val nextCursor: String?)

enum class FeedKind { Following, Discover }

object ReactionTypes {
    val all = listOf("like", "love", "laugh", "wow", "sad")
}
