package app.winkwink.domain.model

data class ServerHealth(
    val status: String,
    val service: String,
    val apiVersion: String,
    val appVersion: String,
    val environment: String,
    val serverTime: String,
    val databaseUp: Boolean,
    val databaseLatencyMs: Long?,
    val schemaVersion: String?,
    val roundTripMs: Long,
) {
    val isHealthy: Boolean get() = status == "ok" && databaseUp
}

sealed interface ConnectionFailure {
    data object Unreachable : ConnectionFailure
    data object Timeout : ConnectionFailure
    data object TlsError : ConnectionFailure
    data object InsecureEndpoint : ConnectionFailure
    data object InvalidResponse : ConnectionFailure
    data class ServerError(val httpCode: Int) : ConnectionFailure
}

sealed interface HealthCheckResult {
    data class Success(val health: ServerHealth) : HealthCheckResult
    data class Failure(val failure: ConnectionFailure) : HealthCheckResult
}
