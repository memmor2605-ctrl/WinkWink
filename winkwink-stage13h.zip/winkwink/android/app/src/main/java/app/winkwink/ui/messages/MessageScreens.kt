package app.winkwink.ui.messages

import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.winkwink.R
import app.winkwink.domain.model.Conversation
import app.winkwink.domain.model.MessagingStatus
import app.winkwink.domain.model.UserSummary
import app.winkwink.domain.realtime.RealtimeState
import app.winkwink.ui.auth.FailureBanner
import app.winkwink.ui.components.UserAvatar
import app.winkwink.ui.components.WwCard
import app.winkwink.ui.components.WwScreenHeader
import app.winkwink.ui.theme.WwSpacing
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Synchronizacja awaryjna przez REST, dopóki ekran jest na pierwszym planie (po wejściu i co [intervalMs]).
 * Przy działającym WSS wystarczy rzadkie odpytywanie (zdarzenia przychodzą na żywo); bez niego — częste.
 */
@Composable
internal fun PollWhileResumed(intervalMs: Long = 8_000L, onTick: () -> Unit) {
    val current by rememberUpdatedState(onTick)
    val scope = rememberCoroutineScope()
    LifecycleResumeEffect(intervalMs) {
        val job = scope.launch {
            current()
            while (true) { delay(intervalMs); current() }
        }
        onPauseOrDispose { job.cancel() }
    }
}

internal const val POLL_ONLINE_MS = 60_000L
internal const val POLL_OFFLINE_MS = 8_000L

/** Uczciwa informacja o braku połączenia na żywo (przy łączeniu nic nie pokazujemy, żeby nie migało). */
@Composable
internal fun ConnectionBanner(state: RealtimeState) {
    if (state == RealtimeState.OFFLINE) {
        Text(stringResource(R.string.msg_offline), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
internal fun ConfirmDialog(title: String, text: String, confirmLabel: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } },
    )
}

/** Awatar grupy: inicjał nazwy na tle koloru akcentu (grupy nie mają obrazów). */
@Composable
internal fun GroupAvatar(name: String, size: Dp = 44.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
        Text(name.trim().firstOrNull()?.uppercase() ?: "#", color = MaterialTheme.colorScheme.onPrimaryContainer, fontSize = (size.value * 0.42f).sp)
    }
}

@Composable
internal fun EncryptionNotice() {
    // Jedyny obecnie możliwy stan; po wdrożeniu E2EE (Etap G) `when` musi dostać drugą gałąź.
    when (MessagingStatus.encryption) {
        app.winkwink.domain.model.EncryptionState.TRANSPORT_ONLY -> WwCard {
            Text(stringResource(R.string.msg_encryption_title), style = MaterialTheme.typography.titleMedium)
            Text(stringResource(R.string.msg_encryption_body), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun conversationPreview(c: Conversation): String {
    val last = c.lastMessage ?: return stringResource(R.string.msg_no_messages_yet)
    if (last.deleted) return stringResource(R.string.msg_deleted)
    val text = last.body.orEmpty().replace('\n', ' ')
    val media = when {
        last.voice != null -> stringResource(R.string.msg_media_voice)
        last.images.isNotEmpty() -> stringResource(R.string.msg_media_photo)
        last.documents.isNotEmpty() -> last.documents.first().fileName ?: stringResource(R.string.msg_media_document)
        else -> null
    }
    // Wiadomość z plikiem: tekst (podpis) albo rodzaj załącznika.
    val body = if (text.isNotBlank()) text else media ?: text
    return when {
        last.mine -> stringResource(R.string.msg_preview_mine, body)
        c.isGroup -> stringResource(R.string.msg_preview_other, last.sender.name, body)
        else -> body
    }
}

@Composable
private fun ConversationRow(c: Conversation, onOpen: () -> Unit, onMute: () -> Unit, onArchive: () -> Unit) {
    WwCard(Modifier.clickable(onClick = onOpen)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            if (c.isGroup) GroupAvatar(c.displayName) else UserAvatar(c.peer?.winkwinkId, c.peer?.avatarTag, c.displayName, 44.dp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        c.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (c.unreadCount > 0) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                    )
                    Text(
                        DateUtils.getRelativeTimeSpanString(c.activityAt.toEpochMilli(), System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(),
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = WwSpacing.sm),
                    )
                }
                Text(
                    conversationPreview(c), style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = if (c.unreadCount > 0) FontWeight.SemiBold else FontWeight.Normal,
                )
                if (c.isGroup) Text(stringResource(R.string.msg_group_members_count, c.memberCount), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (c.unreadCount > 0) Badge { Text(if (c.unreadCount > 99) "99+" else c.unreadCount.toString()) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onMute) { Text(stringResource(if (c.muted) R.string.msg_unmute else R.string.msg_mute)) }
            TextButton(onClick = onArchive) { Text(stringResource(if (c.archived) R.string.msg_unarchive else R.string.msg_archive)) }
            if (c.muted) Text(stringResource(R.string.msg_muted_label), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---------- Zakładka Wiadomości ----------

@Composable
fun ConversationListScreen(
    onOpen: (String) -> Unit,
    onNewChat: () -> Unit,
    onNewGroup: () -> Unit,
    onSettings: () -> Unit,
    viewModel: ConversationListViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    val connection by viewModel.connection.collectAsStateWithLifecycle()
    PollWhileResumed(if (connection == RealtimeState.ONLINE) POLL_ONLINE_MS else POLL_OFFLINE_MS) { viewModel.refreshSilently() }

    Column(Modifier.fillMaxSize().padding(horizontal = WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
        WwScreenHeader(title = stringResource(R.string.msg_title))
        ConnectionBanner(connection)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
            TextButton(onClick = onNewChat) { Text(stringResource(R.string.msg_new_chat)) }
            TextButton(onClick = onNewGroup) { Text(stringResource(R.string.msg_new_group)) }
            TextButton(onClick = onSettings) { Text(stringResource(R.string.msg_settings)) }
            TextButton(onClick = viewModel::refresh, enabled = !s.loading) { Text(stringResource(R.string.activity_refresh)) }
        }
        OutlinedTextField(
            value = s.query, onValueChange = viewModel::onQuery, singleLine = true,
            label = { Text(stringResource(R.string.msg_search_hint)) }, modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            FilterChip(selected = !s.archived, onClick = { viewModel.setArchived(false) }, label = { Text(stringResource(R.string.msg_filter_active)) })
            FilterChip(selected = s.archived, onClick = { viewModel.setArchived(true) }, label = { Text(stringResource(R.string.msg_filter_archived)) })
        }
        s.failure?.let { f ->
            FailureBanner(f)
            TextButton(onClick = viewModel::refresh) { Text(stringResource(R.string.action_retry)) }
        }
        s.actionFailure?.let { FailureBanner(it) }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm), contentPadding = PaddingValues(bottom = WwSpacing.md)) {
            if (s.loading && !s.loaded) item(key = "loading") { CircularProgressIndicator() }
            if (s.loaded && !s.loading && s.failure == null && s.items.isEmpty()) item(key = "empty") {
                val text = when {
                    s.query.isNotBlank() -> R.string.msg_empty_search
                    s.archived -> R.string.msg_empty_archived
                    else -> R.string.msg_empty
                }
                Text(stringResource(text), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(s.items, key = { it.id }) { c ->
                ConversationRow(c, onOpen = { onOpen(c.id) }, onMute = { viewModel.toggleMute(c) }, onArchive = { viewModel.toggleArchive(c) })
            }
            if (s.cursor != null && !s.loadingMore) item(key = "more") { LaunchedEffect(s.cursor) { viewModel.loadMore() } }
            if (s.loadingMore) item(key = "more-loading") { CircularProgressIndicator() }
        }
    }
}

// ---------- Nowa rozmowa / grupa ----------

@Composable
private fun UserPickRow(u: UserSummary, selected: Boolean?, onClick: () -> Unit) {
    WwCard(Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            UserAvatar(u.winkwinkId, u.avatarTag, u.displayName ?: u.nickname, 44.dp)
            Column(Modifier.weight(1f)) {
                Text(u.displayName ?: u.nickname, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("@${u.nickname}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (selected == true) Text(stringResource(R.string.msg_selected), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun NewConversationScreen(
    group: Boolean,
    onBack: () -> Unit,
    onOpened: (String) -> Unit,
    viewModel: NewConversationViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(s.openedId) { s.openedId?.let { onOpened(it); viewModel.openedHandled() } }

    Column(Modifier.fillMaxSize().imePadding().padding(horizontal = WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
        WwScreenHeader(title = stringResource(if (group) R.string.msg_new_group else R.string.msg_new_chat), onBack = onBack)
        if (group) {
            OutlinedTextField(
                value = s.title, onValueChange = viewModel::onTitle, singleLine = true,
                label = { Text(stringResource(R.string.msg_group_title_hint)) }, modifier = Modifier.fillMaxWidth(),
            )
            if (s.selected.isNotEmpty()) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                    s.selected.forEach { u ->
                        FilterChip(selected = true, onClick = { viewModel.toggleSelected(u) }, label = { Text(u.displayName ?: u.nickname) })
                    }
                }
            }
        }
        OutlinedTextField(
            value = s.query, onValueChange = viewModel::onQuery, singleLine = true,
            label = { Text(stringResource(R.string.search_users_hint)) }, modifier = Modifier.fillMaxWidth(),
        )
        s.failure?.let { FailureBanner(it) }
        if (s.loading || s.creating) CircularProgressIndicator()
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
            if (s.searched && s.results.isEmpty() && !s.loading) item(key = "empty") {
                Text(stringResource(R.string.search_users_empty_title), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(s.results, key = { it.winkwinkId }) { u ->
                if (group) UserPickRow(u, s.selected.any { it.winkwinkId == u.winkwinkId }) { viewModel.toggleSelected(u) }
                else UserPickRow(u, null) { viewModel.startDirect(u.winkwinkId) }
            }
        }
        if (group) {
            Text(stringResource(R.string.msg_group_hint, s.selected.size), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = viewModel::createGroup, enabled = s.canCreateGroup, modifier = Modifier.fillMaxWidth().padding(bottom = WwSpacing.md)) {
                Text(stringResource(R.string.msg_create_group))
            }
        }
    }
}

/** Wejście z profilu użytkownika („Napisz wiadomość”): otwiera istniejącą rozmowę 1:1 albo tworzy ją po stronie serwera. */
@Composable
fun StartDirectScreen(
    user: String,
    onBack: () -> Unit,
    onOpened: (String) -> Unit,
    viewModel: NewConversationViewModel = hiltViewModel(),
) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(user) { viewModel.startDirect(user) }
    LaunchedEffect(s.openedId) { s.openedId?.let { onOpened(it); viewModel.openedHandled() } }
    Column(Modifier.fillMaxSize().padding(horizontal = WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.md)) {
        WwScreenHeader(title = stringResource(R.string.msg_title), onBack = onBack)
        if (s.creating) CircularProgressIndicator()
        s.failure?.let { f ->
            FailureBanner(f)
            TextButton(onClick = { viewModel.startDirect(user) }) { Text(stringResource(R.string.action_retry)) }
        }
    }
}

// ---------- Ustawienia wiadomości ----------

@Composable
fun MessageSettingsScreen(onBack: () -> Unit, viewModel: MessageSettingsViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(horizontal = WwSpacing.md), verticalArrangement = Arrangement.spacedBy(WwSpacing.md)) {
        WwScreenHeader(title = stringResource(R.string.msg_settings_title), onBack = onBack)
        s.failure?.let { f ->
            FailureBanner(f)
            TextButton(onClick = viewModel::load) { Text(stringResource(R.string.action_retry)) }
        }
        if (s.loading) CircularProgressIndicator()
        WwCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.msg_read_receipts), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Switch(checked = s.readReceipts, onCheckedChange = viewModel::setReadReceipts, enabled = !s.loading && !s.saving)
            }
            Text(stringResource(R.string.msg_read_receipts_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        PushSettingsCard()
        EncryptionNotice()
    }
}
