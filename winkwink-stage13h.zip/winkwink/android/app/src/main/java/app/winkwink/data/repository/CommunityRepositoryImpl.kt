package app.winkwink.data.repository

import app.winkwink.data.remote.CommunityApi
import app.winkwink.data.remote.CreateChannelRequestDto
import app.winkwink.data.remote.CreateCommunityRequestDto
import app.winkwink.data.remote.InviteRequestDto
import app.winkwink.data.remote.RoleRequestDto
import app.winkwink.data.remote.UpdateCommunityRequestDto
import app.winkwink.data.remote.apiCall
import app.winkwink.data.remote.toDomain
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.Channel
import app.winkwink.domain.model.InviteCandidate
import app.winkwink.data.remote.TransferOwnershipRequestDto
import app.winkwink.domain.model.Community
import app.winkwink.domain.model.CommunityPage
import app.winkwink.domain.model.PersonPage
import app.winkwink.domain.model.PostPage
import app.winkwink.domain.repository.CommunityRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CommunityRepositoryImpl @Inject constructor(
    private val api: CommunityApi,
    private val json: Json,
) : CommunityRepository {

    override suspend fun mine(cursor: String?): Result<CommunityPage> = io { apiCall(json) { api.mine(PAGE_SIZE, cursor) }.mapDomain { it.toDomain() } }
    override suspend fun invites(cursor: String?): Result<CommunityPage> = io { apiCall(json) { api.invites(PAGE_SIZE, cursor) }.mapDomain { it.toDomain() } }
    override suspend fun search(query: String, cursor: String?): Result<CommunityPage> =
        io { apiCall(json) { api.search(query.trim(), PAGE_SIZE, cursor) }.mapDomain { it.toDomain() } }

    override suspend fun create(name: String, description: String, rules: String, type: String): Result<Community> = io {
        val request = CreateCommunityRequestDto(name.trim(), description.trim(), rules.trim(), type)
        apiCall(json) { api.create(request) }.mapDomain { it.toDomain() }
    }

    override suspend fun update(id: String, name: String?, description: String?, rules: String?, type: String?): Result<Community> = io {
        val request = UpdateCommunityRequestDto(name?.trim(), description?.trim(), rules?.trim(), type)
        apiCall(json) { api.update(id, request) }.mapDomain { it.toDomain() }
    }

    override suspend fun get(id: String): Result<Community> = io { apiCall(json) { api.get(id) }.mapDomain { it.toDomain() } }
    override suspend fun join(id: String): Result<String> = io { apiCall(json) { api.join(id) }.map { it.state } }
    override suspend fun leave(id: String): Result<Unit> = io { apiCall(json) { api.leave(id) }.map { } }
    override suspend fun cancelRequest(id: String): Result<Unit> = io { apiCall(json) { api.cancelRequest(id) }.map { } }
    override suspend fun respondToInvite(id: String, accept: Boolean): Result<Unit> =
        io { apiCall(json) { if (accept) api.acceptInvite(id) else api.declineInvite(id) }.map { } }

    override suspend fun channels(id: String): Result<List<Channel>> = io { apiCall(json) { api.channels(id) }.map { r -> r.channels.map { it.toDomain() } } }

    override suspend fun members(id: String, cursor: String?): Result<PersonPage> = io { apiCall(json) { api.members(id, PAGE_SIZE, cursor) }.mapDomain { it.toDomain() } }
    override suspend fun setRole(id: String, userId: String, role: String): Result<Unit> = io { apiCall(json) { api.setRole(id, userId, RoleRequestDto(role)) }.map { } }
    override suspend fun removeMember(id: String, userId: String): Result<Unit> = io { apiCall(json) { api.removeMember(id, userId) }.map { } }
    override suspend fun invite(id: String, userId: String): Result<Unit> = io { apiCall(json) { api.invite(id, InviteRequestDto(userId.trim())) }.map { } }
    override suspend fun inviteCandidates(id: String, query: String): Result<List<InviteCandidate>> =
        io { apiCall(json) { api.inviteCandidates(id, query.trim().removePrefix("@")) }.map { r -> r.candidates.map { it.toDomain() } } }
    override suspend fun transferOwnership(id: String, userId: String): Result<Unit> = io { apiCall(json) { api.transferOwnership(id, TransferOwnershipRequestDto(userId)) }.map { } }
    override suspend fun setMuted(id: String, userId: String, muted: Boolean): Result<Unit> =
        io { apiCall(json) { if (muted) api.mute(id, userId) else api.unmute(id, userId) }.map { } }
    override suspend fun requests(id: String, cursor: String?): Result<PersonPage> = io { apiCall(json) { api.requests(id, PAGE_SIZE, cursor) }.mapDomain { it.toDomain() } }
    override suspend fun decideRequest(id: String, userId: String, approve: Boolean): Result<Unit> =
        io { apiCall(json) { if (approve) api.approveRequest(id, userId) else api.rejectRequest(id, userId) }.map { } }
    override suspend fun createChannel(id: String, name: String): Result<Channel> = io { apiCall(json) { api.createChannel(id, CreateChannelRequestDto(name.trim())) }.map { it.toDomain() } }
    override suspend fun deleteChannel(id: String, channelId: String): Result<Unit> = io { apiCall(json) { api.deleteChannel(id, channelId) }.map { } }
    override suspend fun delete(id: String): Result<Unit> = io { apiCall(json) { api.delete(id) }.map { } }

    override suspend fun posts(id: String, channelId: String?, cursor: String?): Result<PostPage> =
        io { apiCall(json) { api.posts(id, channelId, PAGE_SIZE, cursor) }.mapDomain { it.toDomain() } }

    private suspend fun <T> io(block: suspend () -> Result<T>): Result<T> = withContext(Dispatchers.IO) { block() }

    /** Błąd mapowania (np. zły format daty) to „nieoczekiwana odpowiedź”, a nie wyjątek przeciekający do UI. */
    private inline fun <T, R> Result<T>.mapDomain(transform: (T) -> R): Result<R> = fold(
        onSuccess = { value ->
            try { Result.success(transform(value)) } catch (e: java.time.DateTimeException) {
                Result.failure(ApiFailure("invalid_response", "Unexpected response"))
            }
        },
        onFailure = { Result.failure(it) },
    )

    private companion object { const val PAGE_SIZE = 20 }
}
