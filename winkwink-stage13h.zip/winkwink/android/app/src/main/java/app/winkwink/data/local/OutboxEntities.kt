package app.winkwink.data.local

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Relation
import androidx.room.RoomDatabase
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

/**
 * Wiadomość czekająca na wysłanie. [id] to `clientId` wysyłany na serwer — dzięki niemu ponowienie po utracie odpowiedzi
 * nie tworzy duplikatu. [seq] gwarantuje kolejność w rozmowie. [status]: QUEUED | SENDING | FAILED.
 */
@Entity(tableName = "outbox_messages", indices = [Index("conversationId", "seq")])
data class OutboxMessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val seq: Long,
    val body: String,
    val replyToId: String?,
    val status: String,
    val attempts: Int,
    val failureCode: String?,
    val failureHttp: Int,
    val createdAt: Long,
)

/** Plik wiadomości: [path] to lokalna kopia (prywatny katalog aplikacji), [remoteId] — id niedołączonego załącznika na serwerze po uploadzie. */
@Entity(
    tableName = "outbox_files",
    foreignKeys = [ForeignKey(OutboxMessageEntity::class, ["id"], ["messageId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("messageId")],
)
data class OutboxFileEntity(
    @PrimaryKey val id: String,
    val messageId: String,
    val position: Int,
    val kind: String,
    val path: String,
    val mime: String,
    val name: String?,
    val sizeBytes: Long,
    val remoteId: String?,
)

data class OutboxMessageWithFiles(
    @Embedded val message: OutboxMessageEntity,
    @Relation(parentColumn = "id", entityColumn = "messageId") val files: List<OutboxFileEntity>,
)

@Dao
abstract class OutboxDao {
    @Transaction @Query("SELECT * FROM outbox_messages WHERE conversationId = :conversationId ORDER BY seq")
    abstract fun observe(conversationId: String): Flow<List<OutboxMessageWithFiles>>

    @Transaction @Query("SELECT * FROM outbox_messages WHERE conversationId = :conversationId AND status = 'QUEUED' ORDER BY seq")
    abstract suspend fun queued(conversationId: String): List<OutboxMessageWithFiles>

    @Query("SELECT DISTINCT conversationId FROM outbox_messages WHERE status = 'QUEUED'")
    abstract suspend fun conversationsWithQueued(): List<String>

    @Query("SELECT COUNT(*) FROM outbox_messages WHERE status = 'QUEUED'")
    abstract suspend fun queuedCount(): Int

    @Query("SELECT COALESCE(MAX(seq), 0) FROM outbox_messages")
    abstract suspend fun maxSeq(): Long

    @Query("SELECT * FROM outbox_messages WHERE id = :id")
    abstract suspend fun message(id: String): OutboxMessageEntity?

    @Query("SELECT * FROM outbox_files WHERE messageId = :id ORDER BY position")
    abstract suspend fun files(id: String): List<OutboxFileEntity>

    @Query("SELECT path FROM outbox_files")
    abstract suspend fun allPaths(): List<String>

    @Insert abstract suspend fun insertMessage(m: OutboxMessageEntity)
    @Insert abstract suspend fun insertFiles(files: List<OutboxFileEntity>)

    @Query("UPDATE outbox_messages SET status = 'QUEUED' WHERE status = 'SENDING'")
    abstract suspend fun resetSending()

    @Query("UPDATE outbox_messages SET status = 'SENDING' WHERE id = :id")
    abstract suspend fun markSending(id: String)

    @Query("UPDATE outbox_messages SET status = 'QUEUED', attempts = :attempts, failureCode = :code, failureHttp = :http WHERE id = :id")
    abstract suspend fun markRetry(id: String, attempts: Int, code: String?, http: Int)

    @Query("UPDATE outbox_messages SET status = 'FAILED', failureCode = :code, failureHttp = :http WHERE id = :id")
    abstract suspend fun markFailed(id: String, code: String, http: Int)

    @Query("UPDATE outbox_messages SET status = 'QUEUED', attempts = 0, failureCode = NULL, failureHttp = 0 WHERE id = :id AND status = 'FAILED'")
    abstract suspend fun requeue(id: String)

    @Query("UPDATE outbox_files SET remoteId = :remoteId WHERE id = :id")
    abstract suspend fun setRemoteId(id: String, remoteId: String)

    @Query("UPDATE outbox_files SET remoteId = NULL WHERE messageId = :messageId")
    abstract suspend fun clearRemoteIds(messageId: String)

    @Query("DELETE FROM outbox_messages WHERE id = :id")
    abstract suspend fun delete(id: String)

    @Query("DELETE FROM outbox_messages")
    abstract suspend fun deleteAll()

    @Transaction
    open suspend fun enqueue(m: OutboxMessageEntity, files: List<OutboxFileEntity>) {
        insertMessage(m.copy(seq = maxSeq() + 1))
        if (files.isNotEmpty()) insertFiles(files)
    }
}

@Database(entities = [OutboxMessageEntity::class, OutboxFileEntity::class], version = 1, exportSchema = false)
abstract class WinkDatabase : RoomDatabase() {
    abstract fun outboxDao(): OutboxDao
}
