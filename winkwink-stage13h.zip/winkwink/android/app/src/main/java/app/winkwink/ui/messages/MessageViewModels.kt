package app.winkwink.ui.messages

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.winkwink.domain.media.AttachmentPrepareException
import app.winkwink.domain.media.MessageFilePreparer
import app.winkwink.domain.media.PlaybackState
import app.winkwink.domain.media.VoicePlayback
import app.winkwink.domain.media.VoiceRecordException
import app.winkwink.domain.media.VoiceRecorder
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.MessageAttachment
import app.winkwink.domain.model.MessageMediaLimits
import app.winkwink.domain.model.PreparedFile
import app.winkwink.ui.feed.UploadStatus
import app.winkwink.domain.model.ChatMember
import app.winkwink.domain.model.ChatMessage
import app.winkwink.domain.model.ChatPerson
import app.winkwink.domain.model.Conversation
import app.winkwink.domain.model.UserSummary
import app.winkwink.domain.repository.AuthRepository
import app.winkwink.domain.repository.MessageRepository
import app.winkwink.domain.realtime.RealtimeClient
import app.winkwink.domain.realtime.RealtimeEvent
import app.winkwink.domain.realtime.RealtimeState
import app.winkwink.domain.realtime.RealtimeTypes
import app.winkwink.domain.repository.SocialRepository
import app.winkwink.domain.outbox.OutboxDraft
import app.winkwink.domain.outbox.OutboxFileDraft
import app.winkwink.domain.outbox.OutboxFiles
import app.winkwink.domain.outbox.OutboxMessage
import app.winkwink.domain.outbox.OutboxRepository
import app.winkwink.domain.outbox.OutboxStatus
import app.winkwink.domain.validation.MessageValidation
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID
import javax.inject.Inject

private fun Throwable?.asFailure(): ApiFailure? = this?.let { it as? ApiFailure ?: ApiFailure("unknown", "Unknown error") }

// ---------- Lista rozmów ----------

data class ConversationListUiState(
    val items: List<Conversation> = emptyList(),
    val cursor: String? = null,
    val query: String = "",
    /** false = aktywne, true = zarchiwizowane. */
    val archived: Boolean = false,
    val loading: Boolean = false,
    val loadingMore: Boolean = false,
    val loaded: Boolean = false,
    val failure: ApiFailure? = null,
    val actionFailure: ApiFailure? = null,
)

@HiltViewModel
class ConversationListViewModel @Inject constructor(
    private val repository: MessageRepository,
    private val realtime: RealtimeClient,
) : ViewModel() {
    val connection: StateFlow<RealtimeState> = realtime.state
    private val _state = MutableStateFlow(ConversationListUiState())
    val state: StateFlow<ConversationListUiState> = _state.asStateFlow()

    /** Odrzuca spóźnione odpowiedzi po zmianie filtra, zapytania lub ponownym odświeżeniu. */
    private var generation = 0
    private var queryJob: Job? = null
    private var extraPages = 0
    private var silentInFlight = false
    private var silentAgain = false

    init {
        refresh()
        // Zdarzenia z WSS (i każde ponowne połączenie) → ciche odświeżenie; REST pozostaje źródłem prawdy.
        viewModelScope.launch { realtime.events.collect { if (RealtimeTypes.affectsLists(it.type)) refreshSilently() } }
    }

    fun refresh() {
        val gen = ++generation
        val s = _state.value
        extraPages = 0
        _state.update { it.copy(loading = true, loadingMore = false, failure = null, actionFailure = null) }
        viewModelScope.launch {
            val r = repository.conversations(s.archived, s.query, null)
            if (gen != generation) return@launch
            _state.update { cur ->
                r.fold(
                    onSuccess = { p -> cur.copy(items = p.items, cursor = p.nextCursor, loading = false, loaded = true) },
                    onFailure = { cur.copy(loading = false, failure = it.asFailure()) },
                )
            }
        }
    }

    /**
     * Ciche odświeżenie (powrót na ekran, tymczasowe odpytywanie REST do czasu WSS): bez wskaźnika ładowania, a błąd sieci
     * nie psuje istniejącej listy. Pomijane, gdy użytkownik doładował kolejne strony (wtedy lista zostałaby przycięta).
     */
    fun refreshSilently() {
        val s = _state.value
        if (s.loading || s.loadingMore || extraPages > 0) return
        // Serie zdarzeń zlewają się w jedno dodatkowe odświeżenie.
        if (silentInFlight) { silentAgain = true; return }
        silentInFlight = true
        val gen = generation
        viewModelScope.launch {
            val r = repository.conversations(s.archived, s.query, null)
            silentInFlight = false
            if (gen == generation) {
                r.onSuccess { p -> _state.update { cur -> if (extraPages > 0) cur else cur.copy(items = p.items, cursor = p.nextCursor, loaded = true, failure = null) } }
            }
            if (silentAgain) { silentAgain = false; refreshSilently() }
        }
    }

    fun loadMore() {
        val s = _state.value
        val cursor = s.cursor ?: return
        if (s.loading || s.loadingMore) return
        val gen = generation
        _state.update { it.copy(loadingMore = true) }
        viewModelScope.launch {
            val r = repository.conversations(s.archived, s.query, cursor)
            if (gen != generation) return@launch
            _state.update { cur ->
                r.fold(
                    onSuccess = { p ->
                        extraPages++
                        val known = cur.items.map { it.id }.toSet()
                        cur.copy(items = cur.items + p.items.filter { it.id !in known }, cursor = p.nextCursor, loadingMore = false)
                    },
                    onFailure = { cur.copy(loadingMore = false, actionFailure = it.asFailure()) },
                )
            }
        }
    }

    fun onQuery(v: String) {
        _state.update { it.copy(query = v) }
        queryJob?.cancel()
        queryJob = viewModelScope.launch { delay(350); refresh() }
    }

    fun setArchived(archived: Boolean) {
        if (_state.value.archived == archived) return
        _state.update { it.copy(archived = archived, items = emptyList(), cursor = null, loaded = false) }
        refresh()
    }

    /** Zmiana dopiero po potwierdzeniu serwera. */
    fun toggleMute(c: Conversation) {
        viewModelScope.launch {
            repository.setFlags(c.id, muted = !c.muted, archived = null).fold(
                onSuccess = { updated -> _state.update { cur -> cur.copy(items = cur.items.map { if (it.id == c.id) updated else it }) } },
                onFailure = { e -> _state.update { it.copy(actionFailure = e.asFailure()) } },
            )
        }
    }

    /** Po potwierdzeniu serwera rozmowa znika z bieżącej listy (przechodzi do drugiej). */
    fun toggleArchive(c: Conversation) {
        viewModelScope.launch {
            repository.setFlags(c.id, muted = null, archived = !c.archived).fold(
                onSuccess = { _state.update { cur -> cur.copy(items = cur.items.filter { it.id != c.id }) } },
                onFailure = { e -> _state.update { it.copy(actionFailure = e.asFailure()) } },
            )
        }
    }
}

// ---------- Czat ----------

/** Miniatura/etykieta załącznika w bąbelku wiadomości, która jeszcze nie dotarła na serwer. */
data class PendingMedia(val kind: String, val uri: String?, val name: String?)

/** Nagranie głosowe czekające na wysłanie; [attachmentId] ustawiane po udanym uploadzie (ponowienie wysyła tylko wiadomość). */
data class PendingVoice(val path: String, val durationMs: Long, val attachmentId: String? = null)

/**
 * Wiadomość wysyłana z tego urządzenia, jeszcze niepotwierdzona przez serwer (status „wysyłanie” / „nie wysłano”).
 * Zdjęcia i dokumenty są wysyłane na serwer już przy wyborze ([attachmentIds]); głosówka — przy wysyłaniu ([voice]).
 */
data class PendingMessage(
    val localId: String,
    val body: String,
    val replyToId: String?,
    val failed: Boolean = false,
    val failure: ApiFailure? = null,
    val attachmentIds: List<String> = emptyList(),
    val media: List<PendingMedia> = emptyList(),
    val voice: PendingVoice? = null,
    /** Trwa wysyłanie pliku (głosówki) — inny napis niż samo „wysyłanie”. */
    val uploading: Boolean = false,
)

/** Plik wybrany do wiadomości: wysyłany od razu po wyborze; do wiadomości trafiają tylko identyfikatory ([remoteId]). */
data class DraftMessageAttachment(
    val localId: Int,
    val uri: String,
    val kind: String,
    val name: String?,
    val status: UploadStatus,
    val remoteId: String? = null,
    val errorCode: String? = null,
    /** Lokalna kopia w magazynie kolejki wysyłania (przeżywa restart); null przed przygotowaniem pliku. */
    val path: String? = null,
    val mime: String? = null,
    val sizeBytes: Long = 0,
)

/** Nagranie głosowe w podglądzie (przed wysłaniem). */
data class VoiceDraft(val path: String, val durationMs: Long)

data class ChatUiState(
    val conversation: Conversation? = null,
    /** Od najnowszych (kolejność serwera). */
    val messages: List<ChatMessage> = emptyList(),
    val cursor: String? = null,
    val loading: Boolean = true,
    val loadingMore: Boolean = false,
    val loaded: Boolean = false,
    val failure: ApiFailure? = null,
    val actionFailure: ApiFailure? = null,
    val pending: List<PendingMessage> = emptyList(),
    val draft: String = "",
    val replyTo: ChatMessage? = null,
    val editing: ChatMessage? = null,
    val busy: Boolean = false,
    /** Imiona osób, które teraz piszą (wygasa po kilku sekundach bez nowego sygnału). */
    val typing: List<String> = emptyList(),
    /** Zdjęcia/dokumenty w szkicu. */
    val draftAttachments: List<DraftMessageAttachment> = emptyList(),
    /** Liczba plików w trakcie przygotowania (zmniejszanie / czytanie) — zanim pojawią się na liście. */
    val preparing: Int = 0,
    /** Kod komunikatu o załączniku/nagrywaniu (mapowany na tekst w UI): too_many, too_many_documents, mixed_kinds, unsupported_type, file_too_large, file_unreadable, voice_busy, mic_denied, record_start_failed, record_failed, record_too_short. */
    val notice: String? = null,
    val recording: Boolean = false,
    val recordingMs: Long = 0,
    val voiceDraft: VoiceDraft? = null,
) {
    val uploading get() = preparing > 0 || draftAttachments.any { it.status == UploadStatus.Uploading }
    val hasFailedUpload get() = draftAttachments.any { it.status == UploadStatus.Failed }
    val hasMediaDraft get() = draftAttachments.isNotEmpty() || voiceDraft != null || recording
    val canSend: Boolean
        get() = conversation != null && !busy && !recording && when {
            editing != null -> MessageValidation.cleanBody(draft) != null
            voiceDraft != null -> true
            draftAttachments.isNotEmpty() -> !uploading && !hasFailedUpload && draft.trim().length <= MessageValidation.BODY_MAX
            else -> MessageValidation.cleanBody(draft) != null
        }
}

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val repository: MessageRepository,
    private val realtime: RealtimeClient,
    private val files: MessageFilePreparer,
    private val recorder: VoiceRecorder,
    private val voicePlayback: VoicePlayback,
    private val outbox: OutboxRepository,
    private val outboxFiles: OutboxFiles,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {
    val conversationId: String = checkNotNull(savedStateHandle["id"])
    val connection: StateFlow<RealtimeState> = realtime.state
    /** Jedno, wspólne odtwarzanie głosówek (nowe zatrzymuje poprzednie). */
    val playback: StateFlow<PlaybackState> = voicePlayback.state
    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()
    /** Punkt odniesienia synchronizacji różnicowej (czas serwera); null = jeszcze nie ustalony. */
    private var syncSince: java.time.Instant? = null
    private var syncing = false
    private var generation = 0
    private var latestInFlight = false
    private var latestAgain = false
    private val typers = LinkedHashMap<String, Pair<String, Job>>()
    private var lastTypingSentAt = 0L
    private var nextLocalId = 1
    private var recordingTicker: Job? = null

    init {
        load()
        viewModelScope.launch { realtime.events.collect(::onRealtime) }
        // Kolejka wysyłania jest w Room: lista „wysyłanych” wiadomości zawsze pochodzi stamtąd, nie z pamięci ViewModelu.
        viewModelScope.launch { outbox.observe(conversationId).collect { list -> _state.update { it.copy(pending = list.map(::toPending)) } } }
        viewModelScope.launch { outbox.sent.collect { m -> if (m.conversationId == conversationId) onSent(m) } }
    }

    private fun toPending(m: OutboxMessage): PendingMessage {
        val voice = m.files.firstOrNull { it.kind == "voice" }
        return PendingMessage(
            localId = m.id, body = m.body, replyToId = m.replyToId,
            failed = m.status == OutboxStatus.FAILED, failure = if (m.status == OutboxStatus.FAILED) m.failure else null,
            attachmentIds = m.files.mapNotNull { it.remoteId },
            media = m.files.map { PendingMedia(it.kind, if (it.kind == "image") java.io.File(it.path).toURI().toString() else null, it.name) },
            voice = voice?.let { PendingVoice(it.path, 0, it.remoteId) },
            uploading = m.status == OutboxStatus.SENDING && m.files.any { it.remoteId == null },
        )
    }

    private fun onSent(m: ChatMessage) {
        _state.update { cur ->
            val without = cur.messages.filter { it.id != m.id }
            cur.copy(messages = listOf(m) + without, conversation = cur.conversation?.copy(lastMessage = m, activityAt = m.createdAt))
        }
    }

    private fun onRealtime(e: RealtimeEvent) {
        when {
            // Po (ponownym) połączeniu: dogonienie stanu (strona najnowszych + zmiany od ostatniej synchronizacji).
            e.type == RealtimeTypes.CONNECTED -> { refreshLatest(); syncChanges(); retryNetworkFailures() }
            e.conversationId != conversationId -> Unit
            e.type == RealtimeTypes.TYPING -> e.actor?.let(::showTyping)
            else -> {
                if (e.type == RealtimeTypes.MESSAGE_NEW) e.actor?.let { clearTyping(it.winkwinkId) }
                refreshLatest()
            }
        }
    }

    private fun showTyping(p: ChatPerson) {
        typers[p.winkwinkId]?.second?.cancel()
        val job = viewModelScope.launch {
            delay(TYPING_TTL_MS)
            typers.remove(p.winkwinkId)
            publishTyping()
        }
        typers[p.winkwinkId] = p.name to job
        publishTyping()
    }

    private fun clearTyping(id: String) {
        typers.remove(id)?.second?.cancel()
        publishTyping()
    }

    private fun publishTyping() = _state.update { it.copy(typing = typers.values.map { v -> v.first }) }

    private fun retryNetworkFailures() {
        // Zdjęcia i dokumenty, które nie wyszły przez brak internetu, ponawiamy po odzyskaniu połączenia.
        _state.value.draftAttachments.filter { it.status == UploadStatus.Failed && it.errorCode in OFFLINE_CODES }.forEach { retryAttachment(it.localId) }
    }

    fun load() {
        val gen = ++generation
        _state.update { it.copy(loading = true, failure = null, actionFailure = null) }
        viewModelScope.launch {
            // Punkt odniesienia PRZED pobraniem strony: zmiany, które zajdą w trakcie, zbierze synchronizacja różnicowa.
            val t0 = repository.changes(conversationId, java.time.Instant.now(), null).getOrNull()?.serverTime
            val conv = repository.conversation(conversationId)
            val page = if (conv.isSuccess) repository.messages(conversationId, null) else null
            if (gen != generation) return@launch
            val failure = conv.exceptionOrNull() ?: page?.exceptionOrNull()
            if (failure != null || page == null) {
                _state.update { it.copy(loading = false, failure = failure.asFailure()) }
                return@launch
            }
            val p = page.getOrThrow()
            if (t0 != null) syncSince = t0
            _state.update { it.copy(conversation = conv.getOrThrow(), messages = p.items, cursor = p.nextCursor, loading = false, loaded = true) }
            markReadIfNeeded()
        }
    }

    /**
     * Pobiera najnowszą stronę i scala ją z tym, co już widać (statusy, reakcje, edycje, usunięcia, nowe wiadomości).
     * Tymczasowe odpytywanie REST — po wdrożeniu WSS pozostaje jako synchronizacja awaryjna. Błąd sieci jest cichy.
     */
    fun refreshLatest() {
        val s = _state.value
        if (s.loading || s.loadingMore || !s.loaded) return
        // Serie zdarzeń zlewają się w jedno dodatkowe odświeżenie.
        if (latestInFlight) { latestAgain = true; return }
        latestInFlight = true
        val gen = generation
        viewModelScope.launch {
            val r = repository.messages(conversationId, null)
            latestInFlight = false
            if (gen == generation) applyLatest(r)
            if (latestAgain) { latestAgain = false; refreshLatest() }
        }
    }

    private suspend fun applyLatest(r: Result<app.winkwink.domain.model.ChatMessagePage>) {
        val page = r.getOrNull()
        if (page == null) {
            // Utrata dostępu (np. usunięcie z grupy) ma być widoczna; zwykły błąd sieci jest cichy.
            (r.exceptionOrNull() as? ApiFailure)?.takeIf { it.code == "conversation_not_found" }?.let { f -> _state.update { it.copy(failure = f) } }
            return
        }
        var hasNewIncoming = false
        _state.update { cur ->
            val known = cur.messages.map { it.id }.toSet()
            hasNewIncoming = page.items.any { !it.mine && it.id !in known }
            val pageIds = page.items.map { it.id }.toSet()
            val oldest = page.items.lastOrNull()?.createdAt
            // Brak części wspólnej z tym, co już mamy, a jest dalsza historia = przerwa dłuższa niż strona: zastępujemy listę
            // (inaczej między nową stroną a starą listą zostałaby luka bez możliwości doczytania).
            val gap = known.isNotEmpty() && page.nextCursor != null && page.items.none { it.id in known }
            val older = if (oldest == null || gap) emptyList() else cur.messages.filter { it.id !in pageIds && it.createdAt < oldest }
            cur.copy(messages = page.items + older, cursor = if (older.isNotEmpty()) cur.cursor else page.nextCursor)
        }
        if (hasNewIncoming) markReadIfNeeded(force = true)
        // Serwer może zmienić rozmowę (wyciszenie na innym urządzeniu, rola) — odśwież stan nagłówka.
        repository.conversation(conversationId).onSuccess { c -> _state.update { it.copy(conversation = c) } }
    }

    /**
     * Synchronizacja różnicowa po utracie połączenia: pobiera wiadomości zmienione od ostatniego punktu odniesienia
     * (nowe, edytowane, usunięte, z nową reakcją) i scala je z listą. Zapas 10 s chroni przed równoległymi zapisami na serwerze;
     * duplikaty są wykluczone przez scalanie po id. Zbyt duża zaległość → pełne przeładowanie.
     */
    fun syncChanges() {
        val since = syncSince ?: return
        if (syncing || !_state.value.loaded) return
        syncing = true
        val gen = generation
        viewModelScope.launch {
            var cursor: String? = null
            var serverTime: java.time.Instant? = null
            var pages = 0
            var failed = false
            do {
                val r = repository.changes(conversationId, if (cursor == null) since.minusSeconds(SYNC_SKEW_S) else null, cursor)
                val p = r.getOrNull()
                if (p == null) { failed = true; break }
                if (serverTime == null) serverTime = p.serverTime
                if (gen == generation) mergeChanges(p.items)
                cursor = p.nextCursor
                pages++
            } while (cursor != null && pages < MAX_SYNC_PAGES)
            syncing = false
            if (!failed && cursor == null && serverTime != null) syncSince = serverTime
            else if (!failed && cursor != null) load() // za daleko w tyle — zaczynamy od świeżej strony
        }
    }

    private fun mergeChanges(items: List<ChatMessage>) {
        if (items.isEmpty()) return
        _state.update { cur ->
            val byId = items.associateBy { it.id }
            val known = cur.messages.map { it.id }.toSet()
            val oldest = cur.messages.lastOrNull()?.createdAt
            val fresh = items.filter { it.id !in known && (oldest == null || it.createdAt >= oldest) }
            val merged = (cur.messages.map { byId[it.id] ?: it } + fresh)
                .sortedWith(compareByDescending<ChatMessage> { it.createdAt }.thenByDescending { it.id })
            cur.copy(messages = merged)
        }
        if (items.any { !it.mine && !it.deleted }) markReadIfNeeded(force = true)
    }

    fun loadMore() {
        val s = _state.value
        val cursor = s.cursor ?: return
        if (s.loading || s.loadingMore) return
        val gen = generation
        _state.update { it.copy(loadingMore = true) }
        viewModelScope.launch {
            val r = repository.messages(conversationId, cursor)
            if (gen != generation) return@launch
            _state.update { cur ->
                r.fold(
                    onSuccess = { p ->
                        val known = cur.messages.map { it.id }.toSet()
                        cur.copy(messages = cur.messages + p.items.filter { it.id !in known }, cursor = p.nextCursor, loadingMore = false)
                    },
                    onFailure = { cur.copy(loadingMore = false, actionFailure = it.asFailure()) },
                )
            }
        }
    }

    private fun markReadIfNeeded(force: Boolean = false) {
        val unread = _state.value.conversation?.unreadCount ?: 0
        if (unread == 0 && !force) return
        viewModelScope.launch {
            repository.markRead(conversationId).onSuccess {
                _state.update { cur -> cur.copy(conversation = cur.conversation?.copy(unreadCount = 0)) }
            }
        }
    }

    // ---- pisanie ----

    fun onDraft(v: String) {
        _state.update { it.copy(draft = v) }
        notifyTyping(v)
    }

    /** Sygnał „pisze…” co najwyżej raz na kilka sekund, tylko przy zwykłym pisaniu (nie przy edycji). */
    private fun notifyTyping(v: String) {
        if (v.isBlank() || _state.value.editing != null) return
        val now = System.currentTimeMillis()
        if (now - lastTypingSentAt < TYPING_SEND_GAP_MS) return
        if (realtime.sendTyping(conversationId)) lastTypingSentAt = now
    }

    fun startReply(m: ChatMessage) = _state.update { it.copy(replyTo = m, editing = null) }
    fun cancelReply() = _state.update { it.copy(replyTo = null) }
    fun startEdit(m: ChatMessage) {
        if (!m.mine || m.deleted || m.voice != null) return
        _state.update { it.copy(editing = m, replyTo = null, draft = m.body.orEmpty()) }
    }
    fun cancelEdit() = _state.update { it.copy(editing = null, draft = "") }
    fun dismissActionFailure() = _state.update { it.copy(actionFailure = null) }

    fun send() {
        val s = _state.value
        if (!s.canSend) return
        val editing = s.editing
        if (editing != null) { submitEdit(editing, MessageValidation.cleanBody(s.draft) ?: return); return }
        val voice = s.voiceDraft
        if (voice != null) { sendVoice(voice); return }
        val body = s.draft.trim()
        if (s.draftAttachments.isEmpty() && MessageValidation.cleanBody(s.draft) == null) return
        val files = s.draftAttachments.mapNotNull { a ->
            val path = a.path ?: return@mapNotNull null
            OutboxFileDraft(a.kind, path, a.mime ?: "application/octet-stream", a.name, a.sizeBytes, a.remoteId)
        }
        if (files.size != s.draftAttachments.size) { _state.update { it.copy(notice = "file_unreadable") }; return }
        val replyId = s.replyTo?.id
        _state.update { it.copy(draft = "", replyTo = null, draftAttachments = emptyList(), notice = null) }
        // Wiadomość trafia do Room i jest wysyłana przez WorkManager — zamknięcie ekranu czy ubicie procesu jej nie gubi.
        viewModelScope.launch { outbox.enqueue(OutboxDraft(conversationId, body, replyId, files)) }
    }

    private fun sendVoice(voice: VoiceDraft) {
        val s = _state.value
        voicePlayback.stop()
        val replyId = s.replyTo?.id
        _state.update { it.copy(voiceDraft = null, replyTo = null, notice = null) }
        viewModelScope.launch {
            val path = outboxFiles.adopt(voice.path)
            if (path == null) { _state.update { it.copy(notice = "record_failed") }; return@launch }
            val size = java.io.File(path).length()
            outbox.enqueue(OutboxDraft(conversationId, "", replyId, listOf(OutboxFileDraft("voice", path, "audio/mp4", "voice.m4a", size, null))))
        }
    }

    fun retry(localId: String) { viewModelScope.launch { outbox.retry(localId) } }

    /** Odrzuca niewysłaną wiadomość razem z jej plikami: lokalnymi i wgranymi, a niedołączonymi. */
    fun discard(localId: String) { viewModelScope.launch { outbox.discard(localId) } }

    private fun submitEdit(target: ChatMessage, body: String) {
        if (_state.value.busy) return
        if (body == target.body) { cancelEdit(); return }
        _state.update { it.copy(busy = true, actionFailure = null) }
        viewModelScope.launch {
            repository.edit(target.id, body).fold(
                onSuccess = { m -> _state.update { cur -> cur.copy(busy = false, editing = null, draft = "", messages = cur.messages.map { if (it.id == m.id) m else it }) } },
                // Szkic zostaje, żeby nie stracić poprawki.
                onFailure = { e -> _state.update { it.copy(busy = false, actionFailure = e.asFailure()) } },
            )
        }
    }

    /** Wywołać po potwierdzeniu w UI. Wiadomość zmienia się w „usuniętą” dopiero po odpowiedzi serwera. */
    fun delete(m: ChatMessage) {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, actionFailure = null) }
        viewModelScope.launch {
            repository.delete(m.id).fold(
                onSuccess = {
                    _state.update { cur ->
                        cur.copy(
                            busy = false,
                            messages = cur.messages.map { if (it.id == m.id) it.copy(deleted = true, body = null, reactions = emptyList(), attachments = emptyList()) else it },
                            editing = if (cur.editing?.id == m.id) null else cur.editing,
                            replyTo = if (cur.replyTo?.id == m.id) null else cur.replyTo,
                            draft = if (cur.editing?.id == m.id) "" else cur.draft,
                        )
                    }
                },
                onFailure = { e -> _state.update { it.copy(busy = false, actionFailure = e.asFailure()) } },
            )
        }
    }

    /** Ta sama reakcja drugi raz = cofnięcie; inna = zmiana. Stan pochodzi z odpowiedzi serwera. */
    fun react(m: ChatMessage, kind: String) {
        viewModelScope.launch {
            val r = if (m.myReaction == kind) repository.unreact(m.id) else repository.react(m.id, kind)
            r.fold(
                onSuccess = { updated -> _state.update { cur -> cur.copy(messages = cur.messages.map { if (it.id == updated.id) updated else it }) } },
                onFailure = { e -> _state.update { it.copy(actionFailure = e.asFailure()) } },
            )
        }
    }

    // ---- zdjęcia i dokumenty ----

    fun dismissNotice() = _state.update { it.copy(notice = null) }
    fun showNotice(code: String) = _state.update { it.copy(notice = code) }

    fun addImages(uris: List<String>) = addFiles(uris, "image")
    fun addDocuments(uris: List<String>) = addFiles(uris, "document")

    private fun addFiles(uris: List<String>, kind: String) {
        if (uris.isEmpty()) return
        val s = _state.value
        if (s.editing != null) return
        if (s.recording || s.voiceDraft != null) { _state.update { it.copy(notice = "voice_busy") }; return }
        viewModelScope.launch { uris.forEach { addOne(it, kind) } }
    }

    private suspend fun addOne(uri: String, kind: String) {
        _state.update { it.copy(preparing = it.preparing + 1, notice = null) }
        val prepared = if (kind == "image") files.prepareImage(uri) else files.prepareDocument(uri)
        _state.update { it.copy(preparing = it.preparing - 1) }
        val file = prepared.getOrNull() ?: run {
            val code = (prepared.exceptionOrNull() as? AttachmentPrepareException)?.code ?: AttachmentPrepareException.UNREADABLE
            _state.update { it.copy(notice = code) }
            return
        }
        val s = _state.value
        val same = s.draftAttachments.count { it.kind == kind }
        val violation = when {
            s.draftAttachments.any { it.kind != kind } -> "mixed_kinds"
            kind == "image" && same >= MessageMediaLimits.MAX_IMAGES -> "too_many"
            kind == "document" && same >= MessageMediaLimits.MAX_DOCUMENTS -> "too_many_documents"
            else -> null
        }
        if (violation != null) { _state.update { it.copy(notice = violation) }; return }
        val localId = nextLocalId++
        val path = try { outboxFiles.save(file.bytes, file.mime.substringAfter('/').substringBefore('+').take(5)) } catch (e: java.io.IOException) {
            _state.update { it.copy(notice = "file_unreadable") }; return
        }
        _state.update { it.copy(draftAttachments = it.draftAttachments + DraftMessageAttachment(localId, uri, kind, file.name, UploadStatus.Uploading, path = path, mime = file.mime, sizeBytes = file.bytes.size.toLong())) }
        repository.uploadAttachment(conversationId, file).fold(
            onSuccess = { a -> updateDraft(localId) { it.copy(status = UploadStatus.Done, remoteId = a.id, errorCode = null) } },
            onFailure = { e -> updateDraft(localId) { it.copy(status = UploadStatus.Failed, errorCode = (e as? ApiFailure)?.code ?: "unknown") } },
        )
    }

    fun retryAttachment(localId: Int) {
        val a = _state.value.draftAttachments.firstOrNull { it.localId == localId && it.status == UploadStatus.Failed } ?: return
        _state.update { s -> s.copy(draftAttachments = s.draftAttachments.filter { it.localId != localId }) }
        a.path?.let(outboxFiles::delete)
        addFiles(listOf(a.uri), a.kind)
    }

    fun removeAttachment(localId: Int) {
        val a = _state.value.draftAttachments.firstOrNull { it.localId == localId } ?: return
        _state.update { s -> s.copy(draftAttachments = s.draftAttachments.filter { it.localId != localId }, notice = null) }
        // Wycofanie niedołączonego pliku jest „best effort”; porzucone wysyłki serwer i tak sprząta po 24 h.
        a.path?.let(outboxFiles::delete)
        a.remoteId?.let { id -> viewModelScope.launch { repository.deleteAttachment(id) } }
    }

    private fun updateDraft(localId: Int, f: (DraftMessageAttachment) -> DraftMessageAttachment) =
        _state.update { s -> s.copy(draftAttachments = s.draftAttachments.map { if (it.localId == localId) f(it) else it }) }

    // ---- wiadomości głosowe ----

    /** Wywoływać dopiero po przyznaniu uprawnienia RECORD_AUDIO (sprawdza je UI). */
    fun startRecording() {
        val s = _state.value
        if (s.recording || s.voiceDraft != null || s.editing != null) return
        if (s.draftAttachments.isNotEmpty() || s.preparing > 0) { _state.update { it.copy(notice = "voice_busy") }; return }
        voicePlayback.stop()
        recorder.start().fold(
            onSuccess = {
                _state.update { it.copy(recording = true, recordingMs = 0, notice = null) }
                val t0 = System.currentTimeMillis()
                recordingTicker?.cancel()
                recordingTicker = viewModelScope.launch {
                    while (true) {
                        delay(RECORD_TICK_MS)
                        val ms = System.currentTimeMillis() - t0
                        _state.update { it.copy(recordingMs = ms) }
                        // Limit długości: nagranie kończy się samo i trafia do podglądu.
                        if (ms >= MessageMediaLimits.VOICE_MAX_MS) { stopRecording(); break }
                    }
                }
            },
            onFailure = { e -> _state.update { it.copy(notice = (e as? VoiceRecordException)?.code ?: VoiceRecordException.START_FAILED) } },
        )
    }

    /** Zatrzymuje nagrywanie i przechodzi do podglądu (odsłuch, wysłanie albo usunięcie). */
    fun stopRecording() {
        if (!_state.value.recording) return
        recordingTicker?.cancel()
        recorder.stop().fold(
            onSuccess = { r -> _state.update { it.copy(recording = false, recordingMs = 0, voiceDraft = VoiceDraft(r.path, r.durationMs), notice = null) } },
            onFailure = { e -> _state.update { it.copy(recording = false, recordingMs = 0, notice = (e as? VoiceRecordException)?.code ?: VoiceRecordException.STOP_FAILED) } },
        )
    }

    fun cancelRecording() {
        recordingTicker?.cancel()
        recorder.cancel()
        _state.update { it.copy(recording = false, recordingMs = 0) }
    }

    /** Odrzuca nagranie z podglądu i kasuje plik. */
    fun discardVoice() {
        val v = _state.value.voiceDraft ?: return
        voicePlayback.stop()
        recorder.discard(v.path)
        _state.update { it.copy(voiceDraft = null) }
    }

    /** Aplikacja schodzi w tło: trwające nagrywanie nie może trwać bez wiedzy użytkownika — kończymy je i zostawiamy w podglądzie. */
    fun onBackgrounded() {
        if (_state.value.recording) stopRecording()
    }

    // ---- odtwarzanie ----

    fun stopPlayback() = voicePlayback.stop()
    fun toggleVoice(a: MessageAttachment) = voicePlayback.toggleRemote(a.id, a.durationMs ?: 0L)
    fun seekVoice(a: MessageAttachment, fraction: Float) = voicePlayback.seekTo(a.id, fraction)
    fun togglePreview() {
        val v = _state.value.voiceDraft ?: return
        voicePlayback.toggleLocal(PREVIEW_KEY, v.path, v.durationMs)
    }
    fun seekPreview(fraction: Float) = voicePlayback.seekTo(PREVIEW_KEY, fraction)

    override fun onCleared() {
        recordingTicker?.cancel()
        recorder.cancel()
        voicePlayback.stop()
        _state.value.voiceDraft?.let { recorder.discard(it.path) }
        super.onCleared()
    }

    // ---- ustawienia rozmowy ----

    fun toggleMute() {
        val c = _state.value.conversation ?: return
        viewModelScope.launch {
            repository.setFlags(c.id, muted = !c.muted, archived = null).fold(
                onSuccess = { u -> _state.update { it.copy(conversation = u) } },
                onFailure = { e -> _state.update { it.copy(actionFailure = e.asFailure()) } },
            )
        }
    }

    fun toggleArchive() {
        val c = _state.value.conversation ?: return
        viewModelScope.launch {
            repository.setFlags(c.id, muted = null, archived = !c.archived).fold(
                onSuccess = { u -> _state.update { it.copy(conversation = u) } },
                onFailure = { e -> _state.update { it.copy(actionFailure = e.asFailure()) } },
            )
        }
    }
}

private const val TYPING_TTL_MS = 6_000L
private const val RECORD_TICK_MS = 200L
/** Klucz odtwarzacza dla podglądu nagrania przed wysłaniem (id załączników to UUID, więc nie koliduje). */
const val PREVIEW_KEY = "voice-preview"
private const val TYPING_SEND_GAP_MS = 3_000L
private val OFFLINE_CODES = setOf("network", "timeout")
private const val SYNC_SKEW_S = 10L
private const val MAX_SYNC_PAGES = 20

// ---------- Licznik wiadomości i połączenie (zakres aktywności) ----------

/**
 * Działa na poziomie całej powłoki aplikacji: utrzymuje WSS, gdy aplikacja jest na pierwszym planie, i liczy
 * nieprzeczytane wiadomości do znaczka na zakładce (pierwsza strona rozmów, bez wyciszonych — przy >30 rozmowach
 * liczba jest przybliżona). Pobranie listy oznacza też wiadomości jako dostarczone na to urządzenie.
 */
@HiltViewModel
class MessagingBackgroundViewModel @Inject constructor(
    private val repository: MessageRepository,
    private val realtime: RealtimeClient,
) : ViewModel() {
    private val _unread = MutableStateFlow(0)
    val unread: StateFlow<Int> = _unread.asStateFlow()
    private var inFlight = false
    private var again = false

    init {
        viewModelScope.launch { realtime.events.collect { if (RealtimeTypes.affectsLists(it.type)) refreshUnread() } }
    }

    fun start() { realtime.start(); refreshUnread() }
    fun stop() = realtime.stop()

    fun refreshUnread() {
        if (inFlight) { again = true; return }
        inFlight = true
        viewModelScope.launch {
            repository.conversations(archived = false, query = null, cursor = null)
                .onSuccess { p -> _unread.value = p.items.filter { !it.muted }.sumOf { it.unreadCount } }
            inFlight = false
            if (again) { again = false; refreshUnread() }
        }
    }
}

// ---------- Nowa rozmowa / grupa ----------

data class NewConversationUiState(
    val query: String = "",
    val loading: Boolean = false,
    val results: List<UserSummary> = emptyList(),
    val searched: Boolean = false,
    val selected: List<UserSummary> = emptyList(),
    val title: String = "",
    val creating: Boolean = false,
    val failure: ApiFailure? = null,
    /** Identyfikator utworzonej/otwartej rozmowy — ekran nawiguje i zeruje to pole. */
    val openedId: String? = null,
) {
    val canCreateGroup get() = MessageValidation.cleanTitle(title) != null && selected.isNotEmpty() && !creating
}

@OptIn(FlowPreview::class)
@HiltViewModel
class NewConversationViewModel @Inject constructor(
    private val repository: MessageRepository,
    private val social: SocialRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(NewConversationUiState())
    val state: StateFlow<NewConversationUiState> = _state.asStateFlow()
    private val queries = MutableStateFlow("")

    init {
        viewModelScope.launch {
            queries.debounce(300).collectLatest { q ->
                if (q.trim().removePrefix("@").length < 2) {
                    _state.update { it.copy(loading = false, results = emptyList(), searched = false) }
                    return@collectLatest
                }
                _state.update { it.copy(loading = true, failure = null) }
                val r = social.search(q)
                _state.update { it.copy(loading = false, results = r.getOrDefault(emptyList()), searched = r.isSuccess, failure = r.exceptionOrNull().asFailure()) }
            }
        }
    }

    fun onQuery(v: String) { _state.update { it.copy(query = v) }; queries.value = v }
    fun onTitle(v: String) = _state.update { it.copy(title = v.take(MessageValidation.TITLE_MAX)) }

    fun toggleSelected(u: UserSummary) = _state.update { cur ->
        val has = cur.selected.any { it.winkwinkId == u.winkwinkId }
        when {
            has -> cur.copy(selected = cur.selected.filter { it.winkwinkId != u.winkwinkId })
            cur.selected.size >= MessageValidation.GROUP_OTHERS_MAX -> cur
            else -> cur.copy(selected = cur.selected + u)
        }
    }

    fun startDirect(user: String) {
        if (_state.value.creating) return
        _state.update { it.copy(creating = true, failure = null) }
        viewModelScope.launch {
            repository.startDirect(user).fold(
                onSuccess = { c -> _state.update { it.copy(creating = false, openedId = c.id) } },
                onFailure = { e -> _state.update { it.copy(creating = false, failure = e.asFailure()) } },
            )
        }
    }

    fun createGroup() {
        val s = _state.value
        val title = MessageValidation.cleanTitle(s.title) ?: return
        if (!s.canCreateGroup) return
        _state.update { it.copy(creating = true, failure = null) }
        viewModelScope.launch {
            repository.createGroup(title, s.selected.map { it.winkwinkId }).fold(
                onSuccess = { c -> _state.update { it.copy(creating = false, openedId = c.id) } },
                onFailure = { e -> _state.update { it.copy(creating = false, failure = e.asFailure()) } },
            )
        }
    }

    fun openedHandled() = _state.update { it.copy(openedId = null) }
}

// ---------- Członkowie grupy ----------

data class GroupMembersUiState(
    val conversation: Conversation? = null,
    val members: List<ChatMember> = emptyList(),
    val loading: Boolean = true,
    val busy: Boolean = false,
    /** WinkWink ID zalogowanego użytkownika (z /auth/me); null, dopóki nie pobrano. */
    val selfId: String? = null,
    val failure: ApiFailure? = null,
    val actionFailure: ApiFailure? = null,
    val query: String = "",
    val searching: Boolean = false,
    val results: List<UserSummary> = emptyList(),
    val searched: Boolean = false,
    /** Użytkownik opuścił grupę — ekran wraca do listy rozmów. */
    val left: Boolean = false,
)

@OptIn(FlowPreview::class)
@HiltViewModel
class GroupMembersViewModel @Inject constructor(
    private val repository: MessageRepository,
    private val social: SocialRepository,
    private val auth: AuthRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {
    private val conversationId: String = checkNotNull(savedStateHandle["id"])
    private val _state = MutableStateFlow(GroupMembersUiState())
    val state: StateFlow<GroupMembersUiState> = _state.asStateFlow()
    private val queries = MutableStateFlow("")

    init {
        load()
        viewModelScope.launch {
            queries.debounce(300).collectLatest { q ->
                if (q.trim().removePrefix("@").length < 2) {
                    _state.update { it.copy(searching = false, results = emptyList(), searched = false) }
                    return@collectLatest
                }
                _state.update { it.copy(searching = true) }
                val r = social.search(q)
                _state.update { it.copy(searching = false, results = r.getOrDefault(emptyList()), searched = r.isSuccess, actionFailure = r.exceptionOrNull().asFailure()) }
            }
        }
    }

    fun load() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val me = auth.me()
            val conv = repository.conversation(conversationId)
            val members = if (conv.isSuccess) repository.members(conversationId) else null
            val failure = me.exceptionOrNull() ?: conv.exceptionOrNull() ?: members?.exceptionOrNull()
            if (failure != null || members == null) {
                _state.update { it.copy(loading = false, failure = failure.asFailure()) }
            } else {
                _state.update {
                    it.copy(loading = false, selfId = me.getOrThrow().profile.winkwinkId, conversation = conv.getOrThrow(), members = members.getOrThrow())
                }
            }
        }
    }

    fun onQuery(v: String) { _state.update { it.copy(query = v) }; queries.value = v }

    private fun applyMembers(r: Result<List<ChatMember>>) = r.fold(
        onSuccess = { m -> _state.update { it.copy(busy = false, members = m, conversation = it.conversation?.copy(memberCount = m.size)) } },
        onFailure = { e -> _state.update { it.copy(busy = false, actionFailure = e.asFailure()) } },
    )

    fun add(u: UserSummary) {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, actionFailure = null) }
        viewModelScope.launch { applyMembers(repository.addMember(conversationId, u.winkwinkId)) }
    }

    fun setRole(m: ChatMember, role: String) {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, actionFailure = null) }
        viewModelScope.launch { applyMembers(repository.setMemberRole(conversationId, m.person.winkwinkId, role)) }
    }

    /** Usunięcie cudzego konta (wywołać po potwierdzeniu w UI). Lista pochodzi z serwera. */
    fun remove(m: ChatMember) {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, actionFailure = null) }
        viewModelScope.launch {
            repository.removeMember(conversationId, m.person.winkwinkId).fold(
                onSuccess = { _state.update { it.copy(busy = false) }; reloadMembers() },
                onFailure = { e -> _state.update { it.copy(busy = false, actionFailure = e.asFailure()) } },
            )
        }
    }

    private suspend fun reloadMembers() {
        repository.members(conversationId).onSuccess { m -> _state.update { it.copy(members = m, conversation = it.conversation?.copy(memberCount = m.size)) } }
    }

    /** Opuszczenie grupy własnym kontem (wywołać po potwierdzeniu w UI). Właściciel nie może opuścić grupy — odrzuci to backend. */
    fun leave() {
        val selfId = _state.value.selfId ?: return
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, actionFailure = null) }
        viewModelScope.launch {
            repository.removeMember(conversationId, selfId).fold(
                onSuccess = { _state.update { it.copy(busy = false, left = true) } },
                onFailure = { e -> _state.update { it.copy(busy = false, actionFailure = e.asFailure()) } },
            )
        }
    }
}

// ---------- Ustawienia wiadomości ----------

data class MessageSettingsUiState(
    val readReceipts: Boolean = true,
    val loading: Boolean = true,
    val saving: Boolean = false,
    val failure: ApiFailure? = null,
)

@HiltViewModel
class MessageSettingsViewModel @Inject constructor(private val repository: MessageRepository) : ViewModel() {
    private val _state = MutableStateFlow(MessageSettingsUiState())
    val state: StateFlow<MessageSettingsUiState> = _state.asStateFlow()

    init { load() }

    fun load() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            repository.readReceipts().fold(
                onSuccess = { v -> _state.update { it.copy(readReceipts = v, loading = false) } },
                onFailure = { e -> _state.update { it.copy(loading = false, failure = e.asFailure()) } },
            )
        }
    }

    /** Przełącznik zmienia się dopiero po potwierdzeniu serwera. */
    fun setReadReceipts(enabled: Boolean) {
        if (_state.value.saving) return
        _state.update { it.copy(saving = true, failure = null) }
        viewModelScope.launch {
            repository.setReadReceipts(enabled).fold(
                onSuccess = { v -> _state.update { it.copy(readReceipts = v, saving = false) } },
                onFailure = { e -> _state.update { it.copy(saving = false, failure = e.asFailure()) } },
            )
        }
    }
}
