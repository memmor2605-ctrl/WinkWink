package app.winkwink.data.outbox

import android.content.Context
import app.winkwink.domain.outbox.OutboxFiles
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OutboxFileStore @Inject constructor(@ApplicationContext context: Context) : OutboxFiles {
    private val dir = File(context.filesDir, "outbox").apply { mkdirs() }

    override suspend fun save(bytes: ByteArray, extension: String): String = withContext(Dispatchers.IO) {
        dir.mkdirs()
        val target = File(dir, UUID.randomUUID().toString() + "." + extension.filter { it.isLetterOrDigit() }.take(8).ifEmpty { "bin" })
        val tmp = File(dir, target.name + ".tmp")
        tmp.writeBytes(bytes)
        if (!tmp.renameTo(target)) { tmp.delete(); throw java.io.IOException("cannot store file") }
        target.absolutePath
    }

    override suspend fun adopt(sourcePath: String): String? = withContext(Dispatchers.IO) {
        val src = File(sourcePath)
        if (!src.isFile) return@withContext null
        dir.mkdirs()
        val target = File(dir, UUID.randomUUID().toString() + "." + src.extension.ifEmpty { "bin" })
        if (src.renameTo(target)) return@withContext target.absolutePath
        try { src.copyTo(target); src.delete(); target.absolutePath } catch (e: java.io.IOException) { target.delete(); null }
    }

    override fun delete(path: String) {
        val f = File(path)
        // Kasujemy wyłącznie pliki z katalogu kolejki.
        if (f.parentFile?.canonicalPath == dir.canonicalPath) f.delete()
    }

    override fun clear() { dir.listFiles()?.forEach { it.delete() } }

    /** Usuwa pliki niewskazywane przez kolejkę i starsze niż [olderThanMs] (porzucone szkice, resztki po awarii). */
    suspend fun sweep(referenced: Set<String>, olderThanMs: Long) = withContext(Dispatchers.IO) {
        val limit = System.currentTimeMillis() - olderThanMs
        dir.listFiles()?.forEach { if (it.absolutePath !in referenced && it.lastModified() < limit) it.delete() }
    }
}
