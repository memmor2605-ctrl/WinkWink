package app.winkwink.domain.model

import java.time.Instant

/** Kontrakt: docs/API.md, „Etap 4”. [myRole] = owner | admin | moderator | member albo null; [myStatus] = member | requested | invited | none. */
data class Community(
    val id: String,
    val name: String,
    val description: String,
    val rules: String,
    /** public | private | invite */
    val type: String,
    val memberCount: Int,
    val myRole: String?,
    val myStatus: String,
    val createdAt: Instant,
) {
    val isMember get() = myStatus == "member"
}

data class CommunityPage(val communities: List<Community>, val nextCursor: String?)
data class Channel(val id: String, val name: String)

/** Członek lub osoba z prośbą o dołączenie ([role] = null dla próśb). */
data class Person(val winkwinkId: String, val nickname: String, val displayName: String?, val role: String?, val at: Instant, val muted: Boolean = false)

/** Osoba znaleziona przy zapraszaniu; [invited] = zaproszenie już czeka. */
data class InviteCandidate(val winkwinkId: String, val nickname: String, val displayName: String?, val invited: Boolean)
data class PersonPage(val people: List<Person>, val nextCursor: String?)

/** Hierarchia ról; zgodna z backendem (który i tak sprawdza uprawnienia samodzielnie). */
object CommunityRoles {
    fun rank(role: String?) = when (role) { "owner" -> 4; "admin" -> 3; "moderator" -> 2; "member" -> 1; else -> 0 }
    fun isModeratorOrAbove(role: String?) = rank(role) >= 2
    fun isAdminOrAbove(role: String?) = rank(role) >= 3
    /** Usuwać można tylko osoby o niższej randze, i tylko jako moderator+. */
    fun canRemove(myRole: String?, targetRole: String?) = isModeratorOrAbove(myRole) && rank(myRole) > rank(targetRole)
    val assignable = listOf("admin", "moderator", "member")
    /** Wyciszać można tylko osoby o niższej randze, jako moderator+ (właściciela nigdy). */
    fun canMute(myRole: String?, targetRole: String?) = canRemove(myRole, targetRole)
    /** Własność przekazuje wyłącznie właściciel i tylko innemu członkowi. */
    fun canTransfer(myRole: String?, targetRole: String?) = myRole == "owner" && targetRole != null && targetRole != "owner"
}

object CommunityTypes {
    val all = listOf("public", "private", "invite")
}
