package app.winkwink.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.repository.AuthRepository
import app.winkwink.domain.repository.SessionStore
import app.winkwink.domain.validation.AuthValidation
import app.winkwink.domain.validation.FieldError
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Jedyne źródło prawdy o tym, czy użytkownik ma aktywną sesję (zmiana sesji natychmiast przełącza ekran główny). */
@HiltViewModel
class AuthGateViewModel @Inject constructor(store: SessionStore) : ViewModel() {
    val signedIn: StateFlow<Boolean> = store.session.map { it != null }
        .stateIn(viewModelScope, SharingStarted.Eagerly, store.session.value != null)
}

enum class AuthMode { LOGIN, REGISTER }

data class AuthUiState(
    val mode: AuthMode = AuthMode.LOGIN,
    val email: String = "",
    val password: String = "",
    val nickname: String = "",
    val emailError: FieldError? = null,
    val passwordError: FieldError? = null,
    val nicknameError: FieldError? = null,
    val loading: Boolean = false,
    val failure: ApiFailure? = null,
)

@HiltViewModel
class AuthViewModel @Inject constructor(private val repository: AuthRepository) : ViewModel() {
    private val _state = MutableStateFlow(AuthUiState())
    val state: StateFlow<AuthUiState> = _state.asStateFlow()

    fun setMode(mode: AuthMode) = _state.update { it.copy(mode = mode, failure = null, emailError = null, passwordError = null, nicknameError = null) }
    fun onEmail(v: String) = _state.update { it.copy(email = v, emailError = null, failure = null) }
    fun onPassword(v: String) = _state.update { it.copy(password = v, passwordError = null, failure = null) }
    fun onNickname(v: String) = _state.update { it.copy(nickname = v, nicknameError = null, failure = null) }

    fun submit() {
        val s = _state.value
        if (s.loading) return
        val register = s.mode == AuthMode.REGISTER
        val emailError = AuthValidation.email(s.email)
        val passwordError = if (register) AuthValidation.newPassword(s.password, s.email) else AuthValidation.required(s.password)
        val nicknameError = if (register) AuthValidation.nickname(s.nickname) else null
        if (emailError != null || passwordError != null || nicknameError != null) {
            _state.update { it.copy(emailError = emailError, passwordError = passwordError, nicknameError = nicknameError) }
            return
        }
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val result = if (register) repository.register(s.email, s.password, s.nickname) else repository.login(s.email, s.password)
            // Sukces: zapisana sesja przełącza ekran główny przez AuthGateViewModel; hasło czyścimy z pamięci stanu.
            _state.update {
                it.copy(loading = false, password = if (result.isSuccess) "" else it.password, failure = result.exceptionOrNull() as? ApiFailure)
            }
        }
    }
}

enum class ForgotStep { REQUEST, RESET, DONE }

data class ForgotUiState(
    val step: ForgotStep = ForgotStep.REQUEST,
    val email: String = "",
    val token: String = "",
    val newPassword: String = "",
    val emailError: FieldError? = null,
    val tokenError: FieldError? = null,
    val passwordError: FieldError? = null,
    val requestSent: Boolean = false,
    val loading: Boolean = false,
    val failure: ApiFailure? = null,
)

@HiltViewModel
class ForgotPasswordViewModel @Inject constructor(private val repository: AuthRepository) : ViewModel() {
    private val _state = MutableStateFlow(ForgotUiState())
    val state: StateFlow<ForgotUiState> = _state.asStateFlow()

    fun onEmail(v: String) = _state.update { it.copy(email = v, emailError = null, failure = null) }
    fun onToken(v: String) = _state.update { it.copy(token = v, tokenError = null, failure = null) }
    fun onNewPassword(v: String) = _state.update { it.copy(newPassword = v, passwordError = null, failure = null) }
    fun haveCode() = _state.update { it.copy(step = ForgotStep.RESET, failure = null) }

    fun sendCode() {
        val s = _state.value
        if (s.loading) return
        AuthValidation.email(s.email)?.let { e -> _state.update { it.copy(emailError = e) }; return }
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val result = repository.requestPasswordReset(s.email)
            _state.update {
                it.copy(
                    loading = false,
                    requestSent = result.isSuccess,
                    step = if (result.isSuccess) ForgotStep.RESET else it.step,
                    failure = result.exceptionOrNull() as? ApiFailure,
                )
            }
        }
    }

    fun reset() {
        val s = _state.value
        if (s.loading) return
        val tokenError = AuthValidation.required(s.token)
        val passwordError = AuthValidation.newPassword(s.newPassword)
        if (tokenError != null || passwordError != null) {
            _state.update { it.copy(tokenError = tokenError, passwordError = passwordError) }
            return
        }
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val result = repository.resetPassword(s.token, s.newPassword)
            _state.update {
                it.copy(
                    loading = false,
                    newPassword = "",
                    step = if (result.isSuccess) ForgotStep.DONE else it.step,
                    failure = result.exceptionOrNull() as? ApiFailure,
                )
            }
        }
    }
}
