package app.winkwink.data.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import app.winkwink.domain.media.ImageKind
import app.winkwink.domain.media.ImagePrepareException
import app.winkwink.domain.media.ImagePreparer
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.max

@Singleton
class AndroidImagePreparer @Inject constructor(@ApplicationContext private val context: Context) : ImagePreparer {

    override suspend fun prepare(uri: String, kind: ImageKind): Result<ByteArray> = withContext(Dispatchers.IO) {
        try {
            Result.success(encode(Uri.parse(uri), kind))
        } catch (e: ImagePrepareException) {
            Result.failure(e)
        } catch (e: OutOfMemoryError) {
            Result.failure(ImagePrepareException("Image too large to process"))
        } catch (e: Exception) {
            Result.failure(ImagePrepareException("Cannot read image"))
        }
    }

    private fun encode(uri: Uri, kind: ImageKind): ByteArray {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: throw ImagePrepareException("Cannot open image")
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw ImagePrepareException("Not an image")

        // Dekodowanie od razu w zmniejszonej wersji (potęgi dwójki), żeby nie ładować wielkiego zdjęcia w całości do pamięci.
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= kind.maxEdge) sample *= 2
        val decoded = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: throw ImagePrepareException("Cannot decode image")

        val oriented = applyOrientation(decoded, readOrientation(uri))
        val scaled = scaleDown(oriented, kind.maxEdge)
        // Przezroczystość nie jest potrzebna w zdjęciach; JPEG składa ją na białe tło.
        val flat = if (scaled.hasAlpha()) flatten(scaled) else scaled

        var quality = 85
        var bytes = compress(flat, quality)
        while (bytes.size > kind.maxBytes && quality > 40) {
            quality -= 15
            bytes = compress(flat, quality)
        }
        if (bytes.size > kind.maxBytes) throw ImagePrepareException("Image too large")
        return bytes
    }

    private fun readOrientation(uri: Uri): Int = runCatching {
        context.contentResolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
    }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL

    private fun applyOrientation(src: Bitmap, orientation: Int): Bitmap {
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            else -> return src
        }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun scaleDown(src: Bitmap, maxEdge: Int): Bitmap {
        val longest = max(src.width, src.height)
        if (longest <= maxEdge) return src
        val f = maxEdge.toFloat() / longest
        return Bitmap.createScaledBitmap(src, max(1, (src.width * f).toInt()), max(1, (src.height * f).toInt()), true)
    }

    private fun flatten(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(out)
        canvas.drawColor(android.graphics.Color.WHITE)
        canvas.drawBitmap(src, 0f, 0f, null)
        return out
    }

    private fun compress(bmp: Bitmap, quality: Int): ByteArray =
        ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }.toByteArray()
}
