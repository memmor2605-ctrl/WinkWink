package app.winkwink.data.remote

import kotlinx.serialization.Serializable
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.PUT

@Serializable data class RegisterPushTokenDto(val token: String, val deviceName: String? = null)
@Serializable data class PushSettingsUpdateDto(val messages: Boolean? = null, val previews: Boolean? = null)
@Serializable data class PushSettingsDto(val messages: Boolean, val previews: Boolean, val configured: Boolean)

interface PushApi {
    /** Idempotentne: rejestruje albo odświeża token bieżącego urządzenia (przypięty do sesji). */
    @PUT("api/v1/push/token") suspend fun register(@Body body: RegisterPushTokenDto): Response<Unit>
    /** Token w nagłówku (nie w URL) — nie trafia do logów dostępu. */
    @DELETE("api/v1/push/token") suspend fun unregister(@Header("X-Push-Token") token: String): Response<Unit>
    @GET("api/v1/push/settings") suspend fun settings(): Response<PushSettingsDto>
    @PUT("api/v1/push/settings") suspend fun updateSettings(@Body body: PushSettingsUpdateDto): Response<PushSettingsDto>
}
