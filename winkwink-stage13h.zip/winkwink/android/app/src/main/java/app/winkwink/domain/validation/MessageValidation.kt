package app.winkwink.domain.validation

/** Lustrzane odbicie limitów backendu (`MessageService`); backend i tak sprawdza je samodzielnie. */
object MessageValidation {
    const val BODY_MAX = 4000
    const val TITLE_MAX = 80
    /** Liczba osób poza twórcą (backend: grupa maks. 50 osób). */
    const val GROUP_OTHERS_MAX = 49

    /** Zwraca przycięty tekst albo null, gdy jest pusty, za długi lub zawiera znak NUL. */
    fun cleanBody(raw: String): String? = raw.trim().takeIf { it.isNotEmpty() && it.length <= BODY_MAX && '\u0000' !in it }
    fun cleanTitle(raw: String): String? = raw.trim().takeIf { it.isNotEmpty() && it.length <= TITLE_MAX && '\u0000' !in it }
}
