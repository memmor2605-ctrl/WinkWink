package app.winkwink.domain.realtime

import app.winkwink.domain.model.ChatPerson
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

enum class RealtimeState { OFFLINE, CONNECTING, ONLINE }

/**
 * Zdarzenie czasu rzeczywistego. To tylko wskazówka „coś się zmieniło” (bez treści wiadomości) — stan zawsze pobieramy
 * przez REST. Poza typami z serwera jest lokalny [RealtimeTypes.CONNECTED] (po każdym (ponownym) połączeniu → synchronizacja).
 */
data class RealtimeEvent(val type: String, val conversationId: String? = null, val messageId: String? = null, val actor: ChatPerson? = null)

object RealtimeTypes {
    const val CONNECTED = "connected"
    const val MESSAGE_NEW = "message.new"
    const val MESSAGE_UPDATED = "message.updated"
    const val MESSAGE_DELETED = "message.deleted"
    const val RECEIPT = "receipt"
    const val CONVERSATION_NEW = "conversation.new"
    const val CONVERSATION_UPDATED = "conversation.updated"
    const val MEMBER_CHANGED = "member.changed"
    const val TYPING = "typing"

    /** Czy zdarzenie może zmienić listę rozmów / liczniki (wszystko poza wskaźnikiem pisania). */
    fun affectsLists(type: String) = type != TYPING
}

/**
 * Połączenie WSS z automatycznym ponownym łączeniem. REST pozostaje źródłem prawdy i zapasem: wiadomości są
 * wysyłane i pobierane przez REST, a to połączenie tylko przyspiesza odświeżanie i niesie wskaźnik pisania.
 */
interface RealtimeClient {
    val state: StateFlow<RealtimeState>
    val events: SharedFlow<RealtimeEvent>
    /** Idempotentne. Wywoływane, gdy aplikacja jest na pierwszym planie i użytkownik jest zalogowany. */
    fun start()
    fun stop()
    /** @return false, gdy połączenie nie jest aktywne (zdarzenie jest wtedy pomijane). */
    fun sendTyping(conversationId: String): Boolean
}
