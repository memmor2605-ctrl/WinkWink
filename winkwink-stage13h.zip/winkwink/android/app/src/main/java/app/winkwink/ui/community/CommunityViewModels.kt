package app.winkwink.ui.community

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.Channel
import app.winkwink.domain.model.Community
import app.winkwink.domain.model.Post
import app.winkwink.domain.repository.CommunityRepository
import app.winkwink.domain.repository.FeedRepository
import app.winkwink.domain.validation.CommunityValidation
import app.winkwink.domain.validation.PostValidation
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

private fun Throwable?.asFailure(): ApiFailure? = this?.let { it as? ApiFailure ?: ApiFailure("unknown", "Unknown error") }

// ---------- Lista: moje społeczności, zaproszenia, wyszukiwanie ----------

data class CommunitiesUiState(
    val mine: List<Community> = emptyList(),
    val mineCursor: String? = null,
    val invites: List<Community> = emptyList(),
    val loading: Boolean = false,
    val loadingMore: Boolean = false,
    val loaded: Boolean = false,
    val query: String = "",
    val searching: Boolean = false,
    val results: List<Community> = emptyList(),
    val searched: Boolean = false,
    val failure: ApiFailure? = null,
    val actionFailure: ApiFailure? = null,
) {
    val searchActive get() = query.trim().length >= MIN_QUERY
    companion object { const val MIN_QUERY = 2 }
}

@OptIn(FlowPreview::class)
@HiltViewModel
class CommunitiesViewModel @Inject constructor(private val repository: CommunityRepository) : ViewModel() {
    private val _state = MutableStateFlow(CommunitiesUiState())
    val state: StateFlow<CommunitiesUiState> = _state.asStateFlow()
    private val queries = MutableStateFlow("")

    init {
        refresh()
        viewModelScope.launch {
            queries.debounce(300).collectLatest { q ->
                if (q.trim().length < CommunitiesUiState.MIN_QUERY) {
                    _state.update { it.copy(searching = false, results = emptyList(), searched = false) }
                    return@collectLatest
                }
                _state.update { it.copy(searching = true, failure = null) }
                val r = repository.search(q, null)
                _state.update {
                    it.copy(searching = false, results = r.getOrNull()?.communities ?: emptyList(), searched = r.isSuccess, failure = r.exceptionOrNull().asFailure())
                }
            }
        }
    }

    fun onQuery(q: String) { _state.update { it.copy(query = q) }; queries.value = q }

    fun refresh() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val mine = repository.mine(null)
            val invites = repository.invites(null)
            _state.update {
                it.copy(
                    loading = false, loaded = mine.isSuccess,
                    mine = mine.getOrNull()?.communities ?: it.mine, mineCursor = mine.getOrNull()?.nextCursor,
                    invites = invites.getOrNull()?.communities ?: it.invites,
                    failure = (mine.exceptionOrNull() ?: invites.exceptionOrNull()).asFailure(),
                )
            }
        }
    }

    fun loadMore() {
        val s = _state.value
        val cursor = s.mineCursor ?: return
        if (s.loading || s.loadingMore) return
        _state.update { it.copy(loadingMore = true) }
        viewModelScope.launch {
            val r = repository.mine(cursor)
            _state.update { st ->
                r.fold(
                    onSuccess = { page ->
                        val known = st.mine.mapTo(HashSet()) { c -> c.id }
                        st.copy(mine = st.mine + page.communities.filter { c -> c.id !in known }, mineCursor = page.nextCursor, loadingMore = false)
                    },
                    onFailure = { e -> st.copy(loadingMore = false, actionFailure = e.asFailure()) },
                )
            }
        }
    }

    /** Odpowiedź na zaproszenie; lista odświeża się dopiero po potwierdzeniu serwera. */
    fun respond(community: Community, accept: Boolean) {
        viewModelScope.launch {
            repository.respondToInvite(community.id, accept).fold(
                onSuccess = { refresh() },
                onFailure = { e -> _state.update { it.copy(actionFailure = e.asFailure()) } },
            )
        }
    }

    fun dismissActionFailure() = _state.update { it.copy(actionFailure = null) }
}

// ---------- Tworzenie ----------

data class CreateCommunityUiState(
    val name: String = "",
    val description: String = "",
    val rules: String = "",
    val type: String = "public",
    val saving: Boolean = false,
    /** Id utworzonej społeczności — ekran przechodzi do jej szczegółów. */
    val createdId: String? = null,
    val failure: ApiFailure? = null,
) {
    val canSubmit get() = CommunityValidation.nameValid(name) && CommunityValidation.descriptionValid(description) &&
        CommunityValidation.rulesValid(rules) && !saving
}

@HiltViewModel
class CreateCommunityViewModel @Inject constructor(private val repository: CommunityRepository) : ViewModel() {
    private val _state = MutableStateFlow(CreateCommunityUiState())
    val state: StateFlow<CreateCommunityUiState> = _state.asStateFlow()

    fun onName(v: String) = _state.update { it.copy(name = v, failure = null) }
    fun onDescription(v: String) = _state.update { it.copy(description = v, failure = null) }
    fun onRules(v: String) = _state.update { it.copy(rules = v, failure = null) }
    fun onType(v: String) = _state.update { it.copy(type = v) }

    fun submit() {
        val s = _state.value
        if (!s.canSubmit) return
        _state.update { it.copy(saving = true, failure = null) }
        viewModelScope.launch {
            val r = repository.create(s.name, s.description, s.rules, s.type)
            _state.update { it.copy(saving = false, createdId = r.getOrNull()?.id, failure = r.exceptionOrNull().asFailure()) }
        }
    }
}

// ---------- Szczegóły społeczności ----------

data class CommunityDetailUiState(
    val loading: Boolean = true,
    val community: Community? = null,
    val channels: List<Channel> = emptyList(),
    /** null = wszystkie kanały. */
    val channelId: String? = null,
    val posts: List<Post> = emptyList(),
    val postsLoading: Boolean = false,
    val postsLoadingMore: Boolean = false,
    val postsCursor: String? = null,
    val postsLoaded: Boolean = false,
    val busy: Boolean = false,
    val composing: Boolean = false,
    val draft: String = "",
    val posting: Boolean = false,
    /** true po opuszczeniu społeczności — ekran wraca do listy. */
    val left: Boolean = false,
    val failure: ApiFailure? = null,
    val actionFailure: ApiFailure? = null,
) {
    val draftValid get() = PostValidation.postBodyValid(draft)
    /** Kanał docelowy nowego posta: wybrany filtr albo pierwszy kanał społeczności. */
    val targetChannel get() = channels.firstOrNull { it.id == channelId } ?: channels.firstOrNull()
}

@HiltViewModel
class CommunityDetailViewModel @Inject constructor(
    private val repository: CommunityRepository,
    private val feed: FeedRepository,
    savedState: SavedStateHandle,
) : ViewModel() {
    private val communityId: String = checkNotNull(savedState["id"])
    private val _state = MutableStateFlow(CommunityDetailUiState())
    val state: StateFlow<CommunityDetailUiState> = _state.asStateFlow()

    init { load() }

    fun load() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val c = repository.get(communityId)
            val community = c.getOrNull()
            if (community == null) {
                _state.update { it.copy(loading = false, failure = c.exceptionOrNull().asFailure()) }
                return@launch
            }
            val ch = repository.channels(communityId)
            _state.update { it.copy(loading = false, community = community, channels = ch.getOrNull() ?: it.channels) }
            if (community.isMember) loadPosts(reset = true) else _state.update { it.copy(posts = emptyList(), postsLoaded = false, postsCursor = null) }
        }
    }

    fun selectChannel(id: String?) {
        if (_state.value.channelId == id) return
        _state.update { it.copy(channelId = id) }
        loadPosts(reset = true)
    }

    fun loadPosts(reset: Boolean = false) {
        val s = _state.value
        if (s.community?.isMember != true) return
        if (!reset && (s.postsLoading || s.postsLoadingMore || s.postsCursor == null)) return
        val cursor = if (reset) null else s.postsCursor
        _state.update { if (reset) it.copy(postsLoading = true, actionFailure = null) else it.copy(postsLoadingMore = true) }
        val channel = s.channelId
        viewModelScope.launch {
            val r = repository.posts(communityId, channel, cursor)
            _state.update { st ->
                if (st.channelId != channel) return@update st // użytkownik zmienił kanał w trakcie — porzucamy spóźnioną odpowiedź
                r.fold(
                    onSuccess = { page ->
                        val base = if (reset) emptyList() else st.posts
                        val known = base.mapTo(HashSet()) { p -> p.id }
                        st.copy(posts = base + page.posts.filter { p -> p.id !in known }, postsCursor = page.nextCursor, postsLoading = false, postsLoadingMore = false, postsLoaded = true)
                    },
                    onFailure = { e -> st.copy(postsLoading = false, postsLoadingMore = false, actionFailure = e.asFailure()) },
                )
            }
        }
    }

    fun join() = membership { repository.join(communityId).map { } }
    fun cancelRequest() = membership { repository.cancelRequest(communityId) }

    private fun membership(action: suspend () -> Result<Unit>) {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, actionFailure = null) }
        viewModelScope.launch {
            action().fold(
                onSuccess = {
                    _state.update { it.copy(busy = false) }
                    load() // stan członkostwa i rola zawsze pochodzą z serwera
                },
                onFailure = { e -> _state.update { it.copy(busy = false, actionFailure = e.asFailure()) } },
            )
        }
    }

    /** Opuszczenie kończy się powrotem do listy (a nie ponownym ładowaniem szczegółów, które mogą być już niedostępne). */
    fun confirmLeave() {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, actionFailure = null) }
        viewModelScope.launch {
            repository.leave(communityId).fold(
                onSuccess = { _state.update { it.copy(busy = false, left = true) } },
                onFailure = { e -> _state.update { it.copy(busy = false, actionFailure = e.asFailure()) } },
            )
        }
    }

    fun startCompose() = _state.update { it.copy(composing = true) }
    fun cancelCompose() = _state.update { it.copy(composing = false, draft = "") }
    fun onDraft(v: String) = _state.update { it.copy(draft = v, actionFailure = null) }

    fun publish() {
        val s = _state.value
        val channel = s.targetChannel ?: return
        if (!s.draftValid || s.posting) return
        _state.update { it.copy(posting = true, actionFailure = null) }
        viewModelScope.launch {
            feed.createCommunityPost(s.draft, communityId, channel.id, emptyList()).fold(
                onSuccess = {
                    _state.update { it.copy(posting = false, composing = false, draft = "") }
                    loadPosts(reset = true)
                },
                onFailure = { e -> _state.update { it.copy(posting = false, actionFailure = e.asFailure()) } },
            )
        }
    }

    fun react(post: Post, type: String) = viewModelScope.launch { applyPost(feed.react(post.id, type)) }
    fun unreact(post: Post) = viewModelScope.launch { applyPost(feed.unreact(post.id)) }
    fun toggleSave(post: Post) = viewModelScope.launch {
        feed.setSaved(post.id, !post.saved).fold(
            onSuccess = { replace(post.copy(saved = !post.saved)) },
            onFailure = { e -> _state.update { it.copy(actionFailure = e.asFailure()) } },
        )
    }

    /** Moderator+ usuwa cudzy post; z listy znika dopiero po potwierdzeniu serwera. */
    fun moderatorDelete(post: Post) {
        if (!app.winkwink.domain.model.CommunityRoles.isModeratorOrAbove(_state.value.community?.myRole) || post.mine) return
        viewModelScope.launch {
            feed.deletePost(post.id).fold(
                onSuccess = { _state.update { s -> s.copy(posts = s.posts.filter { it.id != post.id }, actionFailure = null) } },
                onFailure = { e -> _state.update { it.copy(actionFailure = e.asFailure()) } },
            )
        }
    }

    fun dismissActionFailure() = _state.update { it.copy(actionFailure = null) }

    private fun applyPost(r: Result<Post>) = r.fold(
        onSuccess = { replace(it) },
        onFailure = { e -> _state.update { it.copy(actionFailure = e.asFailure()) } },
    )

    private fun replace(updated: Post) = _state.update { s ->
        s.copy(posts = s.posts.map { if (it.id == updated.id) updated else it }, actionFailure = null)
    }
}
