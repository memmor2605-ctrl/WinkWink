package app.winkwink.ui.navigation

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import app.winkwink.data.push.DeepLinkBus
import app.winkwink.domain.push.DeepLink
import app.winkwink.domain.repository.NotificationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DeepLinkViewModel @Inject constructor(
    private val bus: DeepLinkBus,
    private val notifications: NotificationRepository,
) : ViewModel() {
    val pending: StateFlow<DeepLink?> = bus.pending

    /** Otwarcie z powiadomienia = przeczytanie go (stan odczytu jest na serwerze, więc synchronizuje się między urządzeniami). */
    fun consume(link: DeepLink) {
        bus.consume(link)
        link.notificationId?.let { id -> viewModelScope.launch { notifications.markRead(id) } }
    }
}

/** Po stuknięciu powiadomienia push otwiera właściwy ekran (rozmowa, post, profil, społeczność, prośby o obserwowanie). */
@Composable
fun DeepLinkEffect(navController: NavHostController, viewModel: DeepLinkViewModel = hiltViewModel()) {
    val link by viewModel.pending.collectAsStateWithLifecycle()
    LaunchedEffect(link) {
        val l = link ?: return@LaunchedEffect
        val route = when (l) {
            is DeepLink.Chat -> Routes.chat(l.conversationId)
            is DeepLink.Post -> Routes.post(l.postId)
            is DeepLink.User -> Routes.user(l.winkwinkId)
            is DeepLink.Community -> Routes.community(l.communityId)
            is DeepLink.FollowRequests -> Routes.userList("requests")
            DeepLink.Activity -> MainTab.Activity.route
        }
        navController.navigate(route) { launchSingleTop = true }
        viewModel.consume(l)
    }
}

/** Android 13+: jednorazowa prośba o zgodę na powiadomienia po wejściu do aplikacji (system sam ogranicza powtórne pytania). */
@Composable
fun NotificationPermissionEffect() {
    if (Build.VERSION.SDK_INT < 33) return
    val context = LocalContext.current
    var asked by rememberSaveable { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (!asked && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            asked = true
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
