package app.winkwink.data.remote

import app.winkwink.domain.model.StoredSession
import app.winkwink.domain.repository.SessionStore
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Jedno, serializowane odświeżenie tokenu na raz (refresh tokeny są rotowane — równoległe odświeżenia
 * wywołałyby wykrycie ponownego użycia po stronie serwera). Definitywne odrzucenie => wylogowanie lokalne.
 */
@Singleton
class SessionRefresher @Inject constructor(
    private val api: PublicAuthApi,
    private val store: SessionStore,
) {
    private val mutex = Mutex()

    suspend fun refreshIfStale(staleAccessToken: String?): StoredSession? = mutex.withLock {
        val current = store.session.value ?: return null
        // Inny wątek już odświeżył token, odkąd nieudane żądanie zostało wysłane.
        if (staleAccessToken != null && current.accessToken != staleAccessToken) return current
        try {
            val response = api.refresh(RefreshRequestDto(current.refreshToken))
            val body = response.body()
            when {
                response.isSuccessful && body != null -> body.toStored().also { store.save(it) }
                response.code() == 401 || response.code() == 403 -> { store.clear(); null }
                else -> null // błąd przejściowy serwera: sesja zostaje, spróbujemy później
            }
        } catch (e: IOException) {
            null // brak sieci nie wylogowuje użytkownika
        }
    }
}
