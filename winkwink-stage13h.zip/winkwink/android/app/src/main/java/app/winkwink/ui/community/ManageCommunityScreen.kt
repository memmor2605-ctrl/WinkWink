package app.winkwink.ui.community

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.winkwink.R
import app.winkwink.domain.model.Channel
import app.winkwink.domain.model.CommunityRoles
import app.winkwink.domain.model.CommunityTypes
import app.winkwink.domain.validation.CommunityValidation
import androidx.compose.material3.FilterChip
import app.winkwink.domain.model.Person
import app.winkwink.ui.auth.FailureBanner
import app.winkwink.ui.components.WwCard
import app.winkwink.ui.components.WwScreenHeader
import app.winkwink.ui.theme.WwSpacing

private fun typeLabel(type: String) = when (type) {
    "private" -> R.string.community_type_private
    "invite" -> R.string.community_type_invite
    else -> R.string.community_type_public
}

private fun roleLabel(role: String?) = when (role) {
    "owner" -> R.string.community_role_owner
    "admin" -> R.string.community_role_admin
    "moderator" -> R.string.community_role_moderator
    else -> R.string.community_role_member
}

@Composable
fun ManageCommunityScreen(onBack: () -> Unit, onDeleted: () -> Unit, viewModel: ManageCommunityViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(s.deleted) { if (s.deleted) onDeleted() }
    var removing by remember { mutableStateOf<Person?>(null) }
    var transferring by remember { mutableStateOf<Person?>(null) }
    var deletingChannel by remember { mutableStateOf<Channel?>(null) }
    var deletingCommunity by remember { mutableStateOf(false) }

    removing?.let { p ->
        AlertDialog(
            onDismissRequest = { removing = null },
            title = { Text(stringResource(R.string.manage_remove_title, p.displayName ?: p.nickname)) },
            text = { Text(stringResource(R.string.manage_remove_body)) },
            confirmButton = { TextButton(onClick = { removing = null; viewModel.remove(p) }) { Text(stringResource(R.string.manage_remove)) } },
            dismissButton = { TextButton(onClick = { removing = null }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
    transferring?.let { p ->
        AlertDialog(
            onDismissRequest = { transferring = null },
            title = { Text(stringResource(R.string.manage_transfer_title, p.displayName ?: p.nickname)) },
            text = { Text(stringResource(R.string.manage_transfer_body)) },
            confirmButton = { TextButton(onClick = { transferring = null; viewModel.transferOwnership(p) }) { Text(stringResource(R.string.manage_transfer_confirm)) } },
            dismissButton = { TextButton(onClick = { transferring = null }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
    deletingChannel?.let { ch ->
        AlertDialog(
            onDismissRequest = { deletingChannel = null },
            title = { Text(stringResource(R.string.manage_channel_delete_title, ch.name)) },
            text = { Text(stringResource(R.string.manage_channel_delete_body)) },
            confirmButton = { TextButton(onClick = { deletingChannel = null; viewModel.deleteChannel(ch) }) { Text(stringResource(R.string.manage_channel_delete)) } },
            dismissButton = { TextButton(onClick = { deletingChannel = null }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
    if (deletingCommunity) {
        AlertDialog(
            onDismissRequest = { deletingCommunity = false },
            title = { Text(stringResource(R.string.manage_delete_title)) },
            text = { Text(stringResource(R.string.manage_delete_body)) },
            confirmButton = { TextButton(onClick = { deletingCommunity = false; viewModel.deleteCommunity() }) { Text(stringResource(R.string.manage_delete)) } },
            dismissButton = { TextButton(onClick = { deletingCommunity = false }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }

    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(WwSpacing.md),
        verticalArrangement = Arrangement.spacedBy(WwSpacing.md),
    ) {
        WwScreenHeader(title = stringResource(R.string.manage_title), subtitle = s.community?.name, onBack = onBack)
        if (s.loading) CircularProgressIndicator()
        s.failure?.let { f ->
            FailureBanner(f)
            if (f.httpStatus != 403) TextButton(onClick = viewModel::load) { Text(stringResource(R.string.action_retry)) }
        }
        if (s.community == null || !s.canModerate) return@Column

        // Edycja (admin+; typ tylko właściciel)
        if (s.canManageChannels) {
            WwCard {
                Text(stringResource(R.string.manage_edit_title), style = MaterialTheme.typography.titleMedium)
                val nameBad = !CommunityValidation.nameValid(s.editName)
                OutlinedTextField(
                    value = s.editName, onValueChange = viewModel::onEditName, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.create_community_name)) }, isError = nameBad,
                    supportingText = { if (nameBad) Text(stringResource(R.string.err_community_name)) },
                )
                val descBad = !CommunityValidation.descriptionValid(s.editDescription)
                OutlinedTextField(
                    value = s.editDescription, onValueChange = viewModel::onEditDescription, minLines = 2, modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.create_community_description)) }, isError = descBad,
                    supportingText = { if (descBad) Text(stringResource(R.string.err_community_description_long)) },
                )
                val rulesBad = !CommunityValidation.rulesValid(s.editRules)
                OutlinedTextField(
                    value = s.editRules, onValueChange = viewModel::onEditRules, minLines = 2, modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.create_community_rules)) }, isError = rulesBad,
                    supportingText = { if (rulesBad) Text(stringResource(R.string.err_community_rules_long)) },
                )
                if (s.isOwner) {
                    CommunityTypes.all.forEach { t ->
                        FilterChip(selected = s.editType == t, onClick = { viewModel.onEditType(t) }, label = { Text(stringResource(typeLabel(t))) })
                    }
                }
                if (s.saved) Text(stringResource(R.string.manage_edit_saved), color = MaterialTheme.colorScheme.primary)
                Button(onClick = viewModel::saveEdit, enabled = s.editDirty && s.editValid && !s.busy) { Text(stringResource(R.string.manage_edit_save)) }
            }
        }

        // Zaproszenia: wyszukiwanie osób (min. 2 znaki), członkowie są pomijani, zaproszone osoby oznaczone
        WwCard {
            Text(stringResource(R.string.manage_invite_title), style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = s.inviteDraft, onValueChange = viewModel::onInviteDraft, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.manage_invite_hint)) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { viewModel.searchNow() }),
            )
            if (s.notice == ManageUiState.Notice.InviteSent) Text(stringResource(R.string.manage_invite_sent), color = MaterialTheme.colorScheme.primary)
            if (s.candidatesLoading) CircularProgressIndicator()
            val candidateFailure = s.candidatesFailure
            if (candidateFailure != null) {
                FailureBanner(candidateFailure)
                TextButton(onClick = viewModel::searchNow) { Text(stringResource(R.string.action_retry)) }
            }
            if (s.candidatesSearched && s.candidates.isEmpty() && !s.candidatesLoading) {
                Text(stringResource(R.string.manage_invite_no_results), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            s.candidates.forEach { c ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                    Column(Modifier.weight(1f)) {
                        Text(c.displayName ?: c.nickname, style = MaterialTheme.typography.bodyLarge)
                        Text("@${c.nickname}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (c.invited) Text(stringResource(R.string.manage_invite_pending), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else Button(onClick = { viewModel.inviteCandidate(c) }, enabled = !s.busy) { Text(stringResource(R.string.manage_invite_send)) }
                }
            }
        }

        // Prośby o dołączenie
        if (s.requests.isNotEmpty()) {
            WwCard {
                Text(stringResource(R.string.manage_requests_title), style = MaterialTheme.typography.titleMedium)
                s.requests.forEach { p ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.sm)) {
                        Column(Modifier.weight(1f)) {
                            Text(p.displayName ?: p.nickname, style = MaterialTheme.typography.bodyLarge)
                            Text("@${p.nickname}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(onClick = { viewModel.decide(p, true) }, enabled = !s.busy) { Text(stringResource(R.string.community_accept)) }
                        OutlinedButton(onClick = { viewModel.decide(p, false) }, enabled = !s.busy) { Text(stringResource(R.string.community_decline)) }
                    }
                }
            }
        }

        // Członkowie
        WwCard {
            Text(stringResource(R.string.manage_members_title), style = MaterialTheme.typography.titleMedium)
            s.members.forEach { p ->
                Column(verticalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                    Text(p.displayName ?: p.nickname, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "@${p.nickname} · ${stringResource(roleLabel(p.role))}" + if (p.muted) " · ${stringResource(R.string.manage_muted_badge)}" else "",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                        if (s.isOwner && p.role != "owner") {
                            CommunityRoles.assignable.filter { it != p.role }.forEach { r ->
                                OutlinedButton(onClick = { viewModel.setRole(p, r) }, enabled = !s.busy) { Text(stringResource(roleLabel(r))) }
                            }
                        }
                        if (CommunityRoles.canMute(s.myRole, p.role)) {
                            TextButton(onClick = { viewModel.setMuted(p, !p.muted) }, enabled = !s.busy) {
                                Text(stringResource(if (p.muted) R.string.manage_unmute else R.string.manage_mute))
                            }
                        }
                        if (CommunityRoles.canTransfer(s.myRole, p.role)) {
                            TextButton(onClick = { transferring = p }, enabled = !s.busy) { Text(stringResource(R.string.manage_transfer)) }
                        }
                        if (CommunityRoles.canRemove(s.myRole, p.role)) {
                            TextButton(onClick = { removing = p }, enabled = !s.busy) { Text(stringResource(R.string.manage_remove)) }
                        }
                    }
                }
            }
            if (s.membersCursor != null) TextButton(onClick = viewModel::loadMoreMembers) { Text(stringResource(R.string.manage_load_more)) }
        }

        // Kanały (admin+)
        if (s.canManageChannels) {
            WwCard {
                Text(stringResource(R.string.manage_channels_title), style = MaterialTheme.typography.titleMedium)
                s.channels.forEach { ch ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("# ${ch.name}", Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                        TextButton(onClick = { deletingChannel = ch }, enabled = !s.busy && s.channels.size > 1) { Text(stringResource(R.string.manage_channel_delete)) }
                    }
                }
                OutlinedTextField(
                    value = s.channelDraft, onValueChange = viewModel::onChannelDraft, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.manage_channel_hint)) },
                )
                Button(onClick = viewModel::addChannel, enabled = s.channelDraft.isNotBlank() && !s.busy) { Text(stringResource(R.string.manage_channel_add)) }
            }
        }

        // Usuwanie (tylko właściciel)
        if (s.isOwner) {
            OutlinedButton(onClick = { deletingCommunity = true }, enabled = !s.busy, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.manage_delete), color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
