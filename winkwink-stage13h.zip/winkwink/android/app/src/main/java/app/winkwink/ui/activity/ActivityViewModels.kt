package app.winkwink.ui.activity

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.AppNotification
import app.winkwink.domain.repository.NotificationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

private fun Throwable?.asFailure(): ApiFailure? = this?.let { it as? ApiFailure ?: ApiFailure("unknown", "Unknown error") }

// ---------- Lista powiadomień ----------

data class ActivityUiState(
    val items: List<AppNotification> = emptyList(),
    val cursor: String? = null,
    val unreadCount: Int = 0,
    /** Filtr typu; null = wszystkie. */
    val type: String? = null,
    val unreadOnly: Boolean = false,
    val loading: Boolean = false,
    val loadingMore: Boolean = false,
    val loaded: Boolean = false,
    val failure: ApiFailure? = null,
    val actionFailure: ApiFailure? = null,
)

@HiltViewModel
class ActivityViewModel @Inject constructor(private val repository: NotificationRepository) : ViewModel() {
    private val _state = MutableStateFlow(ActivityUiState())
    val state: StateFlow<ActivityUiState> = _state.asStateFlow()

    /** Odrzuca spóźnione odpowiedzi po zmianie filtra lub ponownym odświeżeniu. */
    private var generation = 0

    init { refresh() }

    fun refresh() {
        val gen = ++generation
        val s = _state.value
        _state.update { it.copy(loading = true, loadingMore = false, failure = null, actionFailure = null) }
        viewModelScope.launch {
            val r = repository.list(s.type, s.unreadOnly, null)
            if (gen != generation) return@launch
            _state.update { cur ->
                r.fold(
                    onSuccess = { p -> cur.copy(items = p.items, cursor = p.nextCursor, unreadCount = p.unreadCount, loading = false, loaded = true) },
                    onFailure = { cur.copy(loading = false, failure = it.asFailure()) },
                )
            }
        }
    }

    fun loadMore() {
        val s = _state.value
        val cursor = s.cursor ?: return
        if (s.loading || s.loadingMore) return
        val gen = generation
        _state.update { it.copy(loadingMore = true) }
        viewModelScope.launch {
            val r = repository.list(s.type, s.unreadOnly, cursor)
            if (gen != generation) return@launch
            _state.update { cur ->
                r.fold(
                    onSuccess = { p ->
                        val known = cur.items.map { it.id }.toSet()
                        cur.copy(items = cur.items + p.items.filter { it.id !in known }, cursor = p.nextCursor, unreadCount = p.unreadCount, loadingMore = false)
                    },
                    onFailure = { cur.copy(loadingMore = false, actionFailure = it.asFailure()) },
                )
            }
        }
    }

    fun setType(type: String?) {
        if (_state.value.type == type && !_state.value.unreadOnly) return
        _state.update { it.copy(type = type, unreadOnly = false, items = emptyList(), cursor = null) }
        refresh()
    }

    fun setUnreadOnly() {
        if (_state.value.unreadOnly) return
        _state.update { it.copy(type = null, unreadOnly = true, items = emptyList(), cursor = null) }
        refresh()
    }

    /** Stan „przeczytane” zmienia się dopiero po potwierdzeniu serwera; element zostaje na liście do następnego odświeżenia. */
    fun markRead(n: AppNotification) {
        if (n.read) return
        viewModelScope.launch {
            repository.markRead(n.id).fold(
                onSuccess = {
                    _state.update { cur ->
                        cur.copy(
                            items = cur.items.map { if (it.id == n.id) it.copy(read = true) else it },
                            unreadCount = (cur.unreadCount - 1).coerceAtLeast(0),
                        )
                    }
                },
                onFailure = { e -> _state.update { it.copy(actionFailure = e.asFailure()) } },
            )
        }
    }

    /** Przy aktywnym filtrze typu oznacza tylko ten typ. Lista i licznik są potem pobierane z serwera. */
    fun markAllRead() {
        val type = _state.value.type
        viewModelScope.launch {
            repository.markAllRead(type).fold(
                onSuccess = { refresh() },
                onFailure = { e -> _state.update { it.copy(actionFailure = e.asFailure()) } },
            )
        }
    }
}

// ---------- Licznik na zakładce ----------

@HiltViewModel
class UnreadBadgeViewModel @Inject constructor(private val repository: NotificationRepository) : ViewModel() {
    private val _count = MutableStateFlow(0)
    val count: StateFlow<Int> = _count.asStateFlow()

    /** Błąd sieci nie jest pokazywany — licznik po prostu zostaje bez zmian. */
    fun refresh() {
        viewModelScope.launch { repository.unreadCount().onSuccess { _count.value = it } }
    }
}

// ---------- Ustawienia powiadomień ----------

data class NotificationSettingsUiState(
    /** Stan z serwera; przełącznik zmienia się dopiero po potwierdzeniu. */
    val types: Map<String, Boolean> = emptyMap(),
    val loading: Boolean = true,
    val saving: Set<String> = emptySet(),
    val failure: ApiFailure? = null,
)

@HiltViewModel
class NotificationSettingsViewModel @Inject constructor(private val repository: NotificationRepository) : ViewModel() {
    private val _state = MutableStateFlow(NotificationSettingsUiState())
    val state: StateFlow<NotificationSettingsUiState> = _state.asStateFlow()

    init { load() }

    fun load() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            repository.settings().fold(
                onSuccess = { m -> _state.update { it.copy(types = m, loading = false) } },
                onFailure = { e -> _state.update { it.copy(loading = false, failure = e.asFailure()) } },
            )
        }
    }

    fun toggle(type: String, enabled: Boolean) {
        if (type in _state.value.saving) return
        _state.update { it.copy(saving = it.saving + type, failure = null) }
        viewModelScope.launch {
            repository.updateSettings(mapOf(type to enabled)).fold(
                onSuccess = { m -> _state.update { it.copy(types = m, saving = it.saving - type) } },
                onFailure = { e -> _state.update { it.copy(saving = it.saving - type, failure = e.asFailure()) } },
            )
        }
    }
}
