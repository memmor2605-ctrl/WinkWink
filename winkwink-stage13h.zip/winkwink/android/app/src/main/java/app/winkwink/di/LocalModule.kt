package app.winkwink.di

import android.content.Context
import androidx.room.Room
import app.winkwink.data.local.OutboxDao
import app.winkwink.data.local.WinkDatabase
import app.winkwink.data.outbox.OutboxFileStore
import app.winkwink.data.outbox.OutboxRepositoryImpl
import app.winkwink.data.outbox.WorkManagerOutboxScheduler
import app.winkwink.domain.outbox.OutboxFiles
import app.winkwink.domain.outbox.OutboxRepository
import app.winkwink.domain.outbox.OutboxScheduler
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class OutboxBindingsModule {
    @Binds @Singleton abstract fun bindOutbox(impl: OutboxRepositoryImpl): OutboxRepository
    @Binds @Singleton abstract fun bindScheduler(impl: WorkManagerOutboxScheduler): OutboxScheduler
    @Binds @Singleton abstract fun bindFiles(impl: OutboxFileStore): OutboxFiles
}

@Module
@InstallIn(SingletonComponent::class)
abstract class PushBindingsModule {
    @Binds @Singleton abstract fun bindPushRegistrar(impl: app.winkwink.data.push.FcmPushRegistrar): app.winkwink.domain.push.PushRegistrar
    @Binds @Singleton abstract fun bindPushSettings(impl: app.winkwink.data.push.PushSettingsRepositoryImpl): app.winkwink.domain.push.PushSettingsRepository
}

@Module
@InstallIn(SingletonComponent::class)
object LocalModule {
    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): WinkDatabase =
        Room.databaseBuilder(context, WinkDatabase::class.java, "winkwink.db").build()

    @Provides fun provideOutboxDao(db: WinkDatabase): OutboxDao = db.outboxDao()
}
