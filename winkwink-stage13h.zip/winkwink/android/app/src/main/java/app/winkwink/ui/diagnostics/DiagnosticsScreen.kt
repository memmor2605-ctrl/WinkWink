package app.winkwink.ui.diagnostics

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.winkwink.R
import app.winkwink.domain.model.ConnectionFailure
import app.winkwink.domain.model.ServerHealth
import app.winkwink.ui.components.StatusKind
import app.winkwink.ui.components.WwCard
import app.winkwink.ui.components.WwDetailRow
import app.winkwink.ui.components.WwPrimaryButton
import app.winkwink.ui.components.WwScreenHeader
import app.winkwink.ui.components.WwStatusChip
import app.winkwink.ui.theme.WwSpacing

@Composable
fun DiagnosticsScreen(onBack: () -> Unit, viewModel: DiagnosticsViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(WwSpacing.md),
        verticalArrangement = Arrangement.spacedBy(WwSpacing.md),
    ) {
        WwScreenHeader(title = stringResource(R.string.diagnostics_title), onBack = onBack)

        WwCard {
            Text(
                stringResource(R.string.diagnostics_endpoint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(viewModel.endpoint, style = MaterialTheme.typography.bodyMedium)
        }

        when (val current = state) {
            DiagnosticsUiState.Loading -> WwCard {
                WwStatusChip(stringResource(R.string.diagnostics_checking), StatusKind.NEUTRAL)
            }
            is DiagnosticsUiState.Success -> HealthCard(current.health)
            is DiagnosticsUiState.Failure -> WwCard {
                WwStatusChip(stringResource(R.string.diagnostics_failed), StatusKind.NEGATIVE)
                Text(failureMessage(current.failure), style = MaterialTheme.typography.bodyMedium)
            }
        }

        WwPrimaryButton(
            text = stringResource(R.string.diagnostics_check_again),
            onClick = viewModel::check,
            loading = state is DiagnosticsUiState.Loading,
        )
    }
}

@Composable
private fun HealthCard(health: ServerHealth) {
    WwCard {
        if (health.isHealthy) {
            WwStatusChip(stringResource(R.string.diagnostics_reachable), StatusKind.POSITIVE)
        } else {
            WwStatusChip(stringResource(R.string.diagnostics_degraded), StatusKind.NEGATIVE)
        }
        WwDetailRow(
            stringResource(R.string.diagnostics_database),
            stringResource(if (health.databaseUp) R.string.diagnostics_db_up else R.string.diagnostics_db_down),
        )
        WwDetailRow(stringResource(R.string.diagnostics_environment), health.environment)
        WwDetailRow(stringResource(R.string.diagnostics_api_version), health.apiVersion)
        WwDetailRow(stringResource(R.string.diagnostics_server_version), health.appVersion)
        health.schemaVersion?.let { WwDetailRow(stringResource(R.string.diagnostics_schema_version), it) }
        health.databaseLatencyMs?.let {
            WwDetailRow(stringResource(R.string.diagnostics_db_latency), stringResource(R.string.unit_ms, it.toInt()))
        }
        WwDetailRow(stringResource(R.string.diagnostics_round_trip), stringResource(R.string.unit_ms, health.roundTripMs.toInt()))
        WwDetailRow(stringResource(R.string.diagnostics_server_time), health.serverTime)
    }
}

@Composable
private fun failureMessage(failure: ConnectionFailure): String = when (failure) {
    ConnectionFailure.Unreachable -> stringResource(R.string.failure_unreachable)
    ConnectionFailure.Timeout -> stringResource(R.string.failure_timeout)
    ConnectionFailure.TlsError -> stringResource(R.string.failure_tls)
    ConnectionFailure.InsecureEndpoint -> stringResource(R.string.failure_insecure)
    ConnectionFailure.InvalidResponse -> stringResource(R.string.failure_invalid_response)
    is ConnectionFailure.ServerError -> stringResource(R.string.failure_server_error, failure.httpCode)
}
