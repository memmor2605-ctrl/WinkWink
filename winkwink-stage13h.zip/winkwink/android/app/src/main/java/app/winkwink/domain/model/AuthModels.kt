package app.winkwink.domain.model

data class Profile(val nickname: String, val winkwinkId: String, val bio: String?, val visibility: String)

data class UserAccount(val email: String, val profile: Profile)

data class SessionInfo(
    val id: String,
    val platform: String?,
    val deviceName: String?,
    val createdAt: String,
    val lastUsedAt: String,
    val current: Boolean,
)

/** Sesja przechowywana lokalnie (szyfrowana). Access token jest krótkotrwały, refresh token rotowany przez serwer. */
data class StoredSession(val sessionId: String, val accessToken: String, val refreshToken: String)

/** Błąd API lub sieci w postaci zrozumiałej dla UI. [code] pochodzi z backendu albo jest kodem lokalnym (network, timeout, tls, insecure, invalid_response). */
class ApiFailure(
    val code: String,
    override val message: String,
    val details: List<String> = emptyList(),
    val retryAfterSeconds: Long? = null,
    val httpStatus: Int = 0,
) : Exception(message)
