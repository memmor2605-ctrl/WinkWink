package app.winkwink.ui.account

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.SessionInfo
import app.winkwink.domain.model.UserAccount
import app.winkwink.domain.repository.AuthRepository
import app.winkwink.domain.validation.AuthValidation
import app.winkwink.domain.validation.FieldError
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AccountUiState(val loading: Boolean = true, val account: UserAccount? = null, val failure: ApiFailure? = null)

@HiltViewModel
class AccountViewModel @Inject constructor(private val repository: AuthRepository) : ViewModel() {
    private val _state = MutableStateFlow(AccountUiState())
    val state: StateFlow<AccountUiState> = _state.asStateFlow()

    init { load() }

    fun load() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val r = repository.me()
            _state.update { it.copy(loading = false, account = r.getOrNull() ?: it.account, failure = r.exceptionOrNull() as? ApiFailure) }
        }
    }

    fun signOut() {
        viewModelScope.launch { repository.logout() }
    }
}

data class ChangePasswordUiState(
    val current: String = "",
    val new: String = "",
    val currentError: FieldError? = null,
    val newError: FieldError? = null,
    val loading: Boolean = false,
    val done: Boolean = false,
    val failure: ApiFailure? = null,
)

@HiltViewModel
class ChangePasswordViewModel @Inject constructor(private val repository: AuthRepository) : ViewModel() {
    private val _state = MutableStateFlow(ChangePasswordUiState())
    val state: StateFlow<ChangePasswordUiState> = _state.asStateFlow()

    fun onCurrent(v: String) = _state.update { it.copy(current = v, currentError = null, failure = null, done = false) }
    fun onNew(v: String) = _state.update { it.copy(new = v, newError = null, failure = null, done = false) }

    fun submit() {
        val s = _state.value
        if (s.loading) return
        val currentError = AuthValidation.required(s.current)
        val newError = AuthValidation.newPassword(s.new)
        if (currentError != null || newError != null) {
            _state.update { it.copy(currentError = currentError, newError = newError) }
            return
        }
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val r = repository.changePassword(s.current, s.new)
            _state.update {
                if (r.isSuccess) ChangePasswordUiState(done = true)
                else it.copy(loading = false, failure = r.exceptionOrNull() as? ApiFailure)
            }
        }
    }
}

data class SessionsUiState(
    val loading: Boolean = true,
    val sessions: List<SessionInfo> = emptyList(),
    val failure: ApiFailure? = null,
    val revokedOthers: Int? = null,
    val busyId: String? = null,
)

@HiltViewModel
class SessionsViewModel @Inject constructor(private val repository: AuthRepository) : ViewModel() {
    private val _state = MutableStateFlow(SessionsUiState())
    val state: StateFlow<SessionsUiState> = _state.asStateFlow()

    init { load() }

    fun load() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val r = repository.sessions()
            _state.update { it.copy(loading = false, sessions = r.getOrNull() ?: it.sessions, failure = r.exceptionOrNull() as? ApiFailure) }
        }
    }

    fun revoke(id: String) {
        _state.update { it.copy(busyId = id, failure = null, revokedOthers = null) }
        viewModelScope.launch {
            val r = repository.revokeSession(id)
            if (r.isSuccess) load()
            _state.update { it.copy(busyId = null, failure = r.exceptionOrNull() as? ApiFailure) }
        }
    }

    fun revokeOthers() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val r = repository.revokeOtherSessions()
            _state.update { it.copy(revokedOthers = r.getOrNull(), failure = r.exceptionOrNull() as? ApiFailure) }
            load()
        }
    }
}

data class DeleteAccountUiState(
    val password: String = "",
    val understood: Boolean = false,
    val passwordError: FieldError? = null,
    val confirming: Boolean = false,
    val loading: Boolean = false,
    val failure: ApiFailure? = null,
)

/** Usunięcie konta: hasło + świadome potwierdzenie + dialog. Po sukcesie sesja znika, a aplikacja wraca do ekranu logowania. */
@HiltViewModel
class DeleteAccountViewModel @Inject constructor(private val repository: AuthRepository) : ViewModel() {
    private val _state = MutableStateFlow(DeleteAccountUiState())
    val state: StateFlow<DeleteAccountUiState> = _state.asStateFlow()

    fun onPassword(v: String) = _state.update { it.copy(password = v, passwordError = null, failure = null) }
    fun onUnderstood(v: Boolean) = _state.update { it.copy(understood = v) }

    /** Walidacja i otwarcie ostatecznego potwierdzenia. */
    fun requestConfirm() {
        val s = _state.value
        if (s.loading) return
        val error = AuthValidation.required(s.password)
        if (error != null || !s.understood) { _state.update { it.copy(passwordError = error) }; return }
        _state.update { it.copy(confirming = true) }
    }

    fun dismissConfirm() = _state.update { it.copy(confirming = false) }

    fun delete() {
        val s = _state.value
        if (s.loading) return
        _state.update { it.copy(confirming = false, loading = true, failure = null) }
        viewModelScope.launch {
            val r = repository.deleteAccount(s.password)
            // Sukces: sesja została wyczyszczona w repozytorium — nawigacja wraca do logowania sama; hasła nie trzymamy dłużej.
            _state.update { if (r.isSuccess) DeleteAccountUiState() else it.copy(loading = false, failure = r.exceptionOrNull() as? ApiFailure) }
        }
    }
}
