package app.winkwink.data.realtime

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import app.winkwink.BuildConfig
import app.winkwink.data.remote.ChatPersonDto
import app.winkwink.data.remote.toDomain
import app.winkwink.domain.realtime.RealtimeClient
import app.winkwink.domain.realtime.RealtimeEvent
import app.winkwink.domain.realtime.RealtimeState
import app.winkwink.domain.realtime.RealtimeTypes
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton

@Serializable internal data class RealtimeEventDto(val type: String, val conversationId: String? = null, val messageId: String? = null, val actor: ChatPersonDto? = null)
@Serializable internal data class ClientFrameDto(val type: String, val conversationId: String? = null)

/** Zwraca null dla nieczytelnych ramek (ignorujemy je — REST i tak da właściwy stan). */
internal fun parseRealtimeEvent(json: Json, text: String): RealtimeEvent? =
    runCatching { json.decodeFromString<RealtimeEventDto>(text) }.getOrNull()
        ?.let { RealtimeEvent(it.type, it.conversationId, it.messageId, it.actor?.toDomain()) }

/** Wykładniczy backoff 1 s → 30 s z losowym rozrzutem (50–100 %), żeby klienci nie łączyli się jednocześnie. */
internal fun reconnectDelayMs(attempt: Int, random: () -> Double = { Math.random() }): Long {
    val base = minOf(30_000L, 1_000L shl minOf(attempt.coerceAtLeast(0), 5))
    return (base * (0.5 + random() * 0.5)).toLong()
}

/**
 * WSS przez OkHttp z klientem „authed” (token Bearer w nagłówku uchwytu, TLS 1.2+, wyłącznie HTTPS). Odświeżenie tokenu po 401
 * robi [app.winkwink.data.remote.TokenAuthenticator]. Po utracie połączenia czeka z backoffem, ale powrót sieci
 * ([ConnectivityManager]) przerywa czekanie. Każde udane połączenie emituje [RealtimeTypes.CONNECTED].
 */
@Singleton
class OkHttpRealtimeClient @Inject constructor(
    @Named("authed") authed: OkHttpClient,
    private val json: Json,
    @ApplicationContext private val context: Context,
) : RealtimeClient {
    // Gniazdo jest długotrwałe: bez limitu odczytu/wywołania, za to z pingiem wykrywającym martwe połączenie.
    private val client = authed.newBuilder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .callTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(25, TimeUnit.SECONDS)
        .build()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow(RealtimeState.OFFLINE)
    override val state: StateFlow<RealtimeState> = _state.asStateFlow()
    private val _events = MutableSharedFlow<RealtimeEvent>(extraBufferCapacity = 64, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    override val events: SharedFlow<RealtimeEvent> = _events.asSharedFlow()
    private val networkUp = MutableSharedFlow<Unit>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    @Volatile private var socket: WebSocket? = null
    private var loop: Job? = null
    private var callback: ConnectivityManager.NetworkCallback? = null

    @Synchronized override fun start() {
        if (loop?.isActive == true) return
        registerNetworkCallback()
        loop = scope.launch { runLoop() }
    }

    @Synchronized override fun stop() {
        loop?.cancel(); loop = null
        socket?.close(1000, "stop"); socket = null
        unregisterNetworkCallback()
        _state.value = RealtimeState.OFFLINE
    }

    override fun sendTyping(conversationId: String): Boolean =
        socket?.send(json.encodeToString(ClientFrameDto("typing", conversationId))) ?: false

    private suspend fun runLoop() {
        var attempt = 0
        while (currentCoroutineContext().isActive) {
            _state.value = RealtimeState.CONNECTING
            val opened = connectOnce()
            _state.value = RealtimeState.OFFLINE
            attempt = if (opened) 0 else attempt + 1
            withTimeoutOrNull(reconnectDelayMs(attempt)) { networkUp.first() }
        }
    }

    /** Zwraca po zamknięciu/awarii połączenia; true, jeśli udało się je w ogóle otworzyć. */
    private suspend fun connectOnce(): Boolean {
        val done = CompletableDeferred<Unit>()
        val opened = AtomicBoolean(false)
        val request = Request.Builder().url("${BuildConfig.API_BASE_URL}api/v1/ws").build()
        val ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                opened.set(true)
                _state.value = RealtimeState.ONLINE
                _events.tryEmit(RealtimeEvent(RealtimeTypes.CONNECTED))
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val e = parseRealtimeEvent(json, text) ?: return
                if (e.type == "hello" || e.type == "pong") return
                _events.tryEmit(e)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) { webSocket.close(1000, null) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { done.complete(Unit) }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { done.complete(Unit) }
        })
        socket = ws
        try {
            done.await()
        } finally {
            if (socket === ws) socket = null
            ws.cancel()
        }
        return opened.get()
    }

    private fun registerNetworkCallback() {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { networkUp.tryEmit(Unit) }
        }
        try { cm.registerDefaultNetworkCallback(cb); callback = cb } catch (_: SecurityException) {} catch (_: RuntimeException) {}
    }

    private fun unregisterNetworkCallback() {
        val cb = callback ?: return
        callback = null
        runCatching { context.getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(cb) }
    }
}
