package app.winkwink.data.session

import android.content.Context
import app.winkwink.domain.outbox.OutboxRepository
import app.winkwink.domain.outbox.OutboxScheduler
import app.winkwink.domain.realtime.RealtimeClient
import app.winkwink.domain.repository.SessionStore
import coil.ImageLoader
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Gdy sesja znika (wylogowanie albo definitywnie odrzucony refresh token), kasujemy wszystko, co należało do konta:
 * zamykamy WebSocket, anulujemy zadania w tle, czyścimy kolejkę wysyłania i jej pliki, cache obrazów i pobrane załączniki.
 * Dzięki temu po wylogowaniu (i po zalogowaniu na inne konto) nie ma dostępu do danych poprzedniego konta.
 * Kompromis: niewysłane wiadomości przepadają razem z sesją — wysłanie ich po wygaśnięciu sesji w imieniu niezalogowanego nie jest możliwe.
 */
@Singleton
class SessionCleaner @Inject constructor(
    private val store: SessionStore,
    private val realtime: RealtimeClient,
    private val outbox: OutboxRepository,
    private val scheduler: OutboxScheduler,
    private val imageLoader: ImageLoader,
    private val push: app.winkwink.domain.push.PushRegistrar,
    private val deepLinks: app.winkwink.data.push.DeepLinkBus,
    @ApplicationContext private val context: Context,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun start() {
        scope.launch {
            store.session.map { it != null }.distinctUntilChanged().collect { signedIn ->
                if (!signedIn) wipe()
            }
        }
    }

    private suspend fun wipe() {
        realtime.stop()
        deepLinks.clear() // oczekujące otwarcie z powiadomienia należało do poprzedniego konta
        scheduler.cancel()
        runCatching { push.deregister(remote = false) } // sesji już nie ma — serwer odfiltruje token po unieważnionej sesji
        runCatching { outbox.clearAll() }
        runCatching { imageLoader.memoryCache?.clear(); imageLoader.diskCache?.clear() }
        runCatching { context.cacheDir.listFiles()?.forEach { if (it.isFile) it.delete() else it.deleteRecursively() } }
    }
}
