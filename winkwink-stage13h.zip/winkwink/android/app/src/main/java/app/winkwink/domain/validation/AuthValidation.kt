package app.winkwink.domain.validation

/** Walidacja po stronie klienta wyłącznie dla szybkiej informacji zwrotnej — źródłem prawdy jest backend. */
enum class FieldError { EMAIL_INVALID, PASSWORD_TOO_SHORT, PASSWORD_TOO_LONG, PASSWORD_SAME_AS_EMAIL, NICKNAME_INVALID, REQUIRED }

object AuthValidation {
    private val EMAIL = Regex("^[A-Za-z0-9._%+\\-]+@[A-Za-z0-9\\-]+(\\.[A-Za-z0-9\\-]+)*\\.[A-Za-z]{2,}$")
    private val NICKNAME = Regex("^[A-Za-z0-9_.]{3,30}$")
    const val PASSWORD_MIN = 10
    const val PASSWORD_MAX = 128

    fun email(raw: String): FieldError? {
        val e = raw.trim()
        return if (e.length <= 254 && !e.contains("..") && EMAIL.matches(e)) null else FieldError.EMAIL_INVALID
    }

    fun newPassword(password: String, email: String? = null): FieldError? = when {
        password.length < PASSWORD_MIN -> FieldError.PASSWORD_TOO_SHORT
        password.length > PASSWORD_MAX -> FieldError.PASSWORD_TOO_LONG
        email != null && password.equals(email.trim(), ignoreCase = true) -> FieldError.PASSWORD_SAME_AS_EMAIL
        else -> null
    }

    fun nickname(raw: String): FieldError? = if (NICKNAME.matches(raw)) null else FieldError.NICKNAME_INVALID

    fun required(raw: String): FieldError? = if (raw.isBlank()) FieldError.REQUIRED else null
}
