package app.winkwink.data.push

import app.winkwink.data.remote.PushApi
import app.winkwink.data.remote.PushSettingsDto
import app.winkwink.data.remote.PushSettingsUpdateDto
import app.winkwink.data.remote.apiCall
import app.winkwink.domain.push.PushSettings
import app.winkwink.domain.push.PushSettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PushSettingsRepositoryImpl @Inject constructor(private val api: PushApi, private val json: Json) : PushSettingsRepository {
    override suspend fun settings(): Result<PushSettings> = withContext(Dispatchers.IO) { apiCall(json) { api.settings() }.map { it.toDomain() } }
    override suspend fun update(messages: Boolean?, previews: Boolean?): Result<PushSettings> = withContext(Dispatchers.IO) {
        apiCall(json) { api.updateSettings(PushSettingsUpdateDto(messages, previews)) }.map { it.toDomain() }
    }
    private fun PushSettingsDto.toDomain() = PushSettings(messages, previews, configured)
}
