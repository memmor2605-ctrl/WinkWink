package app.winkwink.domain.outbox

import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.ChatMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharedFlow

enum class OutboxStatus { QUEUED, SENDING, FAILED }

data class OutboxFile(val id: String, val kind: String, val path: String, val mime: String, val name: String?, val sizeBytes: Long, val remoteId: String?)

/** Wiadomość w trwałej kolejce wysyłania (przeżywa zamknięcie aplikacji, ubicie procesu i restart telefonu). */
data class OutboxMessage(
    val id: String, val conversationId: String, val body: String, val replyToId: String?,
    val files: List<OutboxFile>, val status: OutboxStatus, val failure: ApiFailure?,
)

/** Plik już zapisany lokalnie przez [OutboxFiles]; [remoteId] != null, gdy został już wysłany na serwer (szkic wysyła od razu po wyborze). */
data class OutboxFileDraft(val kind: String, val path: String, val mime: String, val name: String?, val sizeBytes: Long, val remoteId: String?)

data class OutboxDraft(val conversationId: String, val body: String, val replyToId: String?, val files: List<OutboxFileDraft>)

interface OutboxRepository {
    fun observe(conversationId: String): Flow<List<OutboxMessage>>
    /** Wiadomości, które serwer właśnie potwierdził (do wstawienia na ekran czatu). */
    val sent: SharedFlow<ChatMessage>
    /** Zapisuje wiadomość lokalnie i planuje wysyłanie. Zwraca `clientId`. */
    suspend fun enqueue(draft: OutboxDraft): String
    suspend fun retry(id: String)
    /** Usuwa niewysłaną wiadomość z jej plikami lokalnymi i (best effort) wycofuje wgrane, niedołączone pliki z serwera. */
    suspend fun discard(id: String)
    /** Wylogowanie / koniec sesji: usuwa całą kolejkę i lokalne pliki. */
    suspend fun clearAll()
    /** Jedno przejście kolejki; wołane przez [OutboxScheduler] (WorkManager) i bezpośrednio po dodaniu. */
    suspend fun process(): OutboxRun
}

enum class OutboxRun { DONE, RETRY_LATER }

interface OutboxScheduler {
    fun schedule()
    fun cancel()
}

/** Prywatny magazyn plików kolejki (poza cache — system nie może ich skasować przed wysłaniem). */
interface OutboxFiles {
    suspend fun save(bytes: ByteArray, extension: String): String
    /** Przenosi istniejący plik (np. nagranie) do magazynu kolejki. */
    suspend fun adopt(sourcePath: String): String?
    fun delete(path: String)
    fun clear()
}
