package app.winkwink.data.repository

import app.winkwink.data.remote.AddMemberRequestDto
import app.winkwink.data.remote.ConversationSettingsRequestDto
import app.winkwink.data.remote.CreateGroupRequestDto
import app.winkwink.data.remote.EditMessageRequestDto
import app.winkwink.data.remote.MemberRoleRequestDto
import app.winkwink.data.remote.MessageApi
import app.winkwink.data.remote.MessageSettingsDto
import app.winkwink.data.remote.SendMessageRequestDto
import app.winkwink.data.remote.SetReactionRequestDto
import app.winkwink.data.remote.StartDirectRequestDto
import app.winkwink.data.remote.apiCall
import app.winkwink.data.remote.streamBody
import app.winkwink.data.remote.streamToFile
import app.winkwink.data.remote.toDomain
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.ChatChangesPage
import app.winkwink.domain.model.ChatMember
import app.winkwink.domain.model.ChatMessage
import app.winkwink.domain.model.ChatMessagePage
import app.winkwink.domain.model.Conversation
import app.winkwink.domain.model.ConversationPage
import app.winkwink.domain.model.MessageAttachment
import app.winkwink.domain.model.PreparedFile
import app.winkwink.domain.repository.MessageRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.SocketTimeoutException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MessageRepositoryImpl @Inject constructor(
    private val api: MessageApi,
    private val json: Json,
) : MessageRepository {

    private suspend fun <D, T> call(block: suspend () -> retrofit2.Response<D>, map: (D) -> T): Result<T> = withContext(Dispatchers.IO) {
        apiCall(json, block).fold(
            onSuccess = { dto ->
                try { Result.success(map(dto)) } catch (e: java.time.DateTimeException) {
                    Result.failure(ApiFailure("invalid_response", "Unexpected response"))
                }
            },
            onFailure = { Result.failure(it) },
        )
    }

    override suspend fun conversations(archived: Boolean, query: String?, cursor: String?): Result<ConversationPage> =
        call({ api.conversations(archived, query?.trim()?.takeIf { it.isNotEmpty() }, PAGE_SIZE, cursor) }) { it.toDomain() }

    override suspend fun startDirect(user: String): Result<Conversation> =
        call({ api.startDirect(StartDirectRequestDto(user)) }) { it.toDomain() }

    override suspend fun createGroup(title: String, members: List<String>): Result<Conversation> =
        call({ api.createGroup(CreateGroupRequestDto(title, members)) }) { it.toDomain() }

    override suspend fun conversation(id: String): Result<Conversation> = call({ api.conversation(id) }) { it.toDomain() }

    override suspend fun setFlags(id: String, muted: Boolean?, archived: Boolean?): Result<Conversation> =
        call({ api.settings(id, ConversationSettingsRequestDto(muted, archived)) }) { it.toDomain() }

    override suspend fun markRead(id: String): Result<Unit> = call({ api.markRead(id) }) { }

    override suspend fun messages(id: String, cursor: String?): Result<ChatMessagePage> =
        call({ api.messages(id, PAGE_SIZE, cursor) }) { it.toDomain() }

    override suspend fun send(id: String, body: String, replyToId: String?, attachmentIds: List<String>): Result<ChatMessage> =
        call({ api.send(id, SendMessageRequestDto(body, replyToId, attachmentIds)) }) { it.toDomain() }

    override suspend fun uploadAttachment(conversationId: String, file: PreparedFile): Result<MessageAttachment> {
        val body = file.bytes.toRequestBody(file.mime.toMediaType())
        return call({ api.uploadAttachment(conversationId, file.name, body, null) }) { it.toDomain() }
    }

    override suspend fun deleteAttachment(id: String): Result<Unit> = call({ api.deleteAttachment(id) }) { }

    override suspend fun downloadAttachment(id: String): Result<ByteArray> = withContext(Dispatchers.IO) {
        val out = java.io.ByteArrayOutputStream()
        streamBody({ api.downloadAttachment(id) }) { buf, n ->
            if (out.size() + n > MAX_IN_MEMORY) throw java.io.IOException("too large for memory")
            out.write(buf, 0, n)
        }.map { out.toByteArray() }
    }

    override suspend fun downloadAttachmentToFile(id: String, target: java.io.File): Result<Unit> = streamToFile({ api.downloadAttachment(id) }, target)

    override suspend fun changes(id: String, since: java.time.Instant?, cursor: String?): Result<ChatChangesPage> =
        call({ api.changes(id, since?.toString(), CHANGES_PAGE, cursor) }) { it.toDomain() }

    override suspend fun edit(messageId: String, body: String): Result<ChatMessage> =
        call({ api.edit(messageId, EditMessageRequestDto(body)) }) { it.toDomain() }

    override suspend fun delete(messageId: String): Result<Unit> = call({ api.delete(messageId) }) { }

    override suspend fun react(messageId: String, kind: String): Result<ChatMessage> =
        call({ api.react(messageId, SetReactionRequestDto(kind)) }) { it.toDomain() }

    override suspend fun unreact(messageId: String): Result<ChatMessage> = call({ api.unreact(messageId) }) { it.toDomain() }

    override suspend fun members(id: String): Result<List<ChatMember>> = call({ api.members(id) }) { dto -> dto.members.map { it.toDomain() } }

    override suspend fun addMember(id: String, user: String): Result<List<ChatMember>> =
        call({ api.addMember(id, AddMemberRequestDto(user)) }) { dto -> dto.members.map { it.toDomain() } }

    override suspend fun removeMember(id: String, user: String): Result<Unit> = call({ api.removeMember(id, user) }) { }

    override suspend fun setMemberRole(id: String, user: String, role: String): Result<List<ChatMember>> =
        call({ api.setMemberRole(id, user, MemberRoleRequestDto(role)) }) { dto -> dto.members.map { it.toDomain() } }

    override suspend fun readReceipts(): Result<Boolean> = call({ api.readReceipts() }) { it.readReceipts }

    override suspend fun setReadReceipts(enabled: Boolean): Result<Boolean> =
        call({ api.setReadReceipts(MessageSettingsDto(enabled)) }) { it.readReceipts }

    private companion object { const val PAGE_SIZE = 30; const val CHANGES_PAGE = 100; const val MAX_IN_MEMORY = 32 * 1024 * 1024 }
}
