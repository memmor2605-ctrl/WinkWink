package app.winkwink.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import app.winkwink.domain.model.ThemeMode

// ---- Kolory marki (Dark Graphite + jasny odpowiednik) ----
private val Background = Color(0xFF101116)
private val Surface = Color(0xFF1B1E27)
private val SurfaceHigh = Color(0xFF252936)
private val OutlineDark = Color(0xFF343949)
private val TextSecondary = Color(0xFFA5A9B5)
private val Accent = Color(0xFF8B7CFF)
private val Notification = Color(0xFFFF647C)

private val LightBackground = Color(0xFFF7F6FC)
private val LightSurface = Color(0xFFFFFFFF)
private val LightSurfaceHigh = Color(0xFFEEECF8)
private val LightOutline = Color(0xFFD9D6EA)
private val LightTextPrimary = Color(0xFF101116)
private val LightTextSecondary = Color(0xFF5B5F6E)
private val LightAccent = Color(0xFF6A58F2) // ciemniejszy akcent: kontrast na jasnym tle

private val DarkScheme = darkColorScheme(
    primary = Accent, onPrimary = Background,
    primaryContainer = Color(0xFF2E2A57), onPrimaryContainer = Color.White,
    background = Background, onBackground = Color.White,
    surface = Surface, onSurface = Color.White,
    surfaceVariant = SurfaceHigh, onSurfaceVariant = TextSecondary,
    outline = OutlineDark, outlineVariant = OutlineDark,
    error = Notification, onError = Background,
)

private val LightScheme = lightColorScheme(
    primary = LightAccent, onPrimary = Color.White,
    primaryContainer = Color(0xFFE4E0FF), onPrimaryContainer = LightTextPrimary,
    background = LightBackground, onBackground = LightTextPrimary,
    surface = LightSurface, onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceHigh, onSurfaceVariant = LightTextSecondary,
    outline = LightOutline, outlineVariant = LightOutline,
    error = Color(0xFFD93A56), onError = Color.White,
)

/** Kolory spoza palety Material: powiadomienia, sukces, miękki akcent. */
@Immutable
data class WinkWinkExtraColors(
    val notification: Color,
    val success: Color,
    val accentSoft: Color,
)

private val DarkExtra = WinkWinkExtraColors(Notification, Color(0xFF4ADE9C), Color(0xFFC4BCFF))
private val LightExtra = WinkWinkExtraColors(Color(0xFFE5395A), Color(0xFF14935F), Color(0xFFA394FF))

private val LocalExtraColors = staticCompositionLocalOf { DarkExtra }

// ---- Typografia, odstępy, kształty, ruch ----
private val WinkWinkTypography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 38.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 32.sp, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
)

private val WinkWinkShapes = Shapes(
    small = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
)

object WwSpacing {
    val xs = 4.dp
    val sm = 8.dp
    val md = 16.dp
    val lg = 24.dp
    val xl = 32.dp
}

object WwMotion {
    const val SHORT_MS = 180
    const val MEDIUM_MS = 300
}

object WinkWinkTheme {
    val extraColors: WinkWinkExtraColors
        @Composable @ReadOnlyComposable get() = LocalExtraColors.current
}

@Composable
fun WinkWinkTheme(themeMode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }
    CompositionLocalProvider(LocalExtraColors provides if (dark) DarkExtra else LightExtra) {
        MaterialTheme(
            colorScheme = if (dark) DarkScheme else LightScheme,
            typography = WinkWinkTypography,
            shapes = WinkWinkShapes,
            content = content,
        )
    }
}
