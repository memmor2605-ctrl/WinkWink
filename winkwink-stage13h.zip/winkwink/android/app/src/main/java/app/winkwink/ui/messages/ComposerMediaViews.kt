package app.winkwink.ui.messages

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.winkwink.R
import app.winkwink.domain.media.PlaybackState
import app.winkwink.ui.components.LocalWinkImageLoader
import app.winkwink.ui.feed.UploadStatus
import app.winkwink.ui.theme.WwSpacing
import coil.compose.AsyncImage
import coil.imageLoader

/** Teksty komunikatów o załącznikach i nagrywaniu (kody z [ChatUiState.notice]). */
@StringRes
internal fun noticeRes(code: String): Int = when (code) {
    "too_many" -> R.string.msg_notice_too_many
    "too_many_documents" -> R.string.msg_notice_too_many_documents
    "mixed_kinds" -> R.string.msg_notice_mixed_kinds
    "unsupported_type" -> R.string.msg_notice_unsupported
    "file_too_large" -> R.string.msg_notice_too_large
    "voice_busy" -> R.string.msg_notice_voice_busy
    "mic_denied" -> R.string.msg_notice_mic_denied
    "mic_denied_forever" -> R.string.msg_notice_mic_denied_forever
    "record_start_failed" -> R.string.msg_notice_record_start_failed
    "record_too_short" -> R.string.msg_notice_record_too_short
    "record_failed" -> R.string.msg_notice_record_failed
    else -> R.string.msg_notice_unreadable
}

internal fun openAppSettings(context: Context) {
    context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
internal fun NoticeRow(code: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(noticeRes(code)), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        if (code == "mic_denied_forever") TextButton(onClick = { openAppSettings(context) }) { Text(stringResource(R.string.msg_open_settings)) }
        TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_dismiss)) }
    }
}

/** Pasek wybranych zdjęć/dokumentów nad polem tekstowym: miniatura lub nazwa, stan wysyłania, ponów i usuń. */
@Composable
internal fun DraftAttachmentsStrip(
    items: List<DraftMessageAttachment>,
    preparing: Int,
    onRetry: (Int) -> Unit,
    onRemove: (Int) -> Unit,
) {
    val context = LocalContext.current
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs), verticalAlignment = Alignment.Top) {
        items.forEach { a ->
            Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)) {
                Column(Modifier.width(112.dp).padding(WwSpacing.xs), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    if (a.kind == "image") {
                        AsyncImage(
                            model = a.uri, contentDescription = null, imageLoader = LocalWinkImageLoader.current ?: context.imageLoader,
                            contentScale = ContentScale.Crop, modifier = Modifier.size(96.dp).clip(MaterialTheme.shapes.small),
                        )
                    } else {
                        Text(a.name ?: stringResource(R.string.attachment_document), style = MaterialTheme.typography.labelMedium, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(vertical = WwSpacing.xs))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
                        if (a.status == UploadStatus.Uploading) CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp)
                        Text(
                            stringResource(
                                when {
                                    a.status == UploadStatus.Uploading -> R.string.compose_uploading
                                    a.status == UploadStatus.Done -> R.string.compose_uploaded
                                    a.errorCode == "network" || a.errorCode == "timeout" -> R.string.msg_upload_offline
                                    else -> R.string.compose_upload_failed
                                },
                            ),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (a.status == UploadStatus.Failed) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Row {
                        if (a.status == UploadStatus.Failed) TextButton(onClick = { onRetry(a.localId) }) { Text(stringResource(R.string.action_retry), style = MaterialTheme.typography.labelSmall) }
                        TextButton(onClick = { onRemove(a.localId) }) { Text(stringResource(R.string.compose_remove_attachment), style = MaterialTheme.typography.labelSmall) }
                    }
                }
            }
        }
        if (preparing > 0) Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) }
    }
}

/** Trwa nagrywanie: czas, anuluj (kasuje nagranie) i zatrzymaj (przechodzi do podglądu). */
@Composable
internal fun RecordingBar(elapsedMs: Long, onCancel: () -> Unit, onStop: () -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
        Box(Modifier.size(10.dp).clip(androidx.compose.foundation.shape.CircleShape).background(MaterialTheme.colorScheme.error))
        Text(stringResource(R.string.voice_recording, formatDuration(elapsedMs)), Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        TextButton(onClick = onCancel) { Text(stringResource(R.string.action_cancel), color = MaterialTheme.colorScheme.error) }
        TextButton(onClick = onStop) { Text(stringResource(R.string.voice_stop)) }
    }
}

/** Podgląd nagrania przed wysłaniem: odsłuch z paskiem postępu oraz usunięcie. Wysyła przycisk wysyłania obok. */
@Composable
internal fun VoicePreviewBar(
    draft: VoiceDraft,
    playback: PlaybackState,
    onToggle: () -> Unit,
    onSeek: (Float) -> Unit,
    onDiscard: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        VoicePlayer(PREVIEW_KEY, draft.durationMs, playback, onToggle, onSeek, Modifier.weight(1f))
        TextButton(onClick = onDiscard) { Text(stringResource(R.string.msg_discard), color = MaterialTheme.colorScheme.error) }
    }
}

/** Zawartość niewysłanej wiadomości z mediami: miniatury, nazwy i stan (wysyłanie pliku / wiadomości / błąd). */
@Composable
internal fun PendingMediaContent(p: PendingMessage) {
    val context = LocalContext.current
    val images = p.media.filter { it.kind == "image" }
    if (images.isNotEmpty()) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(WwSpacing.xs)) {
            images.forEach { img ->
                AsyncImage(
                    model = img.uri, contentDescription = null, imageLoader = LocalWinkImageLoader.current ?: context.imageLoader,
                    contentScale = ContentScale.Crop, modifier = Modifier.size(72.dp).clip(MaterialTheme.shapes.small),
                )
            }
        }
    }
    p.media.filter { it.kind == "document" }.forEach { d ->
        Text(d.name ?: stringResource(R.string.attachment_document), style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    p.voice?.let { v -> Text(stringResource(R.string.voice_message_duration, formatDuration(v.durationMs)), style = MaterialTheme.typography.bodyMedium) }
}
