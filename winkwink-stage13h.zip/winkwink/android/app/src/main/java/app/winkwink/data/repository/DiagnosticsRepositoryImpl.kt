package app.winkwink.data.repository

import app.winkwink.data.remote.CleartextBlockedException
import app.winkwink.data.remote.HealthApi
import app.winkwink.data.remote.HealthDto
import app.winkwink.data.remote.toDomain
import app.winkwink.domain.model.ConnectionFailure
import app.winkwink.domain.model.HealthCheckResult
import app.winkwink.domain.repository.DiagnosticsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import java.io.IOException
import java.net.SocketTimeoutException
import javax.inject.Inject
import javax.inject.Singleton
import javax.net.ssl.SSLException

@Singleton
class DiagnosticsRepositoryImpl @Inject constructor(
    private val api: HealthApi,
    private val json: Json,
) : DiagnosticsRepository {

    override suspend fun checkHealth(): HealthCheckResult = withContext(Dispatchers.IO) {
        try {
            val started = System.nanoTime()
            val response = api.health()
            val roundTripMs = (System.nanoTime() - started) / 1_000_000

            // 200 = zdrowy, 503 = serwer żyje, ale baza niedostępna (też zawiera pełne ciało).
            val dto: HealthDto? = when {
                response.isSuccessful -> response.body()
                response.code() == 503 ->
                    response.errorBody()?.string()?.let { json.decodeFromString<HealthDto>(it) }
                else -> null
            }
            if (dto != null) {
                HealthCheckResult.Success(dto.toDomain(roundTripMs))
            } else if (response.isSuccessful) {
                HealthCheckResult.Failure(ConnectionFailure.InvalidResponse)
            } else {
                HealthCheckResult.Failure(ConnectionFailure.ServerError(response.code()))
            }
        } catch (e: SerializationException) {
            HealthCheckResult.Failure(ConnectionFailure.InvalidResponse)
        } catch (e: CleartextBlockedException) {
            HealthCheckResult.Failure(ConnectionFailure.InsecureEndpoint)
        } catch (e: SocketTimeoutException) {
            HealthCheckResult.Failure(ConnectionFailure.Timeout)
        } catch (e: SSLException) {
            HealthCheckResult.Failure(ConnectionFailure.TlsError)
        } catch (e: IOException) {
            HealthCheckResult.Failure(ConnectionFailure.Unreachable)
        }
    }
}
