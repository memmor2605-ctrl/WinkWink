package app.winkwink.ui.account

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.winkwink.R
import app.winkwink.ui.auth.FailureBanner
import app.winkwink.ui.auth.WwTextField
import app.winkwink.ui.components.WwCard
import app.winkwink.ui.components.WwPrimaryButton
import app.winkwink.ui.components.WwScreenHeader
import app.winkwink.ui.theme.WwSpacing

@Composable
fun ChangePasswordScreen(onBack: () -> Unit, viewModel: ChangePasswordViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    Column(
        modifier = Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(WwSpacing.md),
        verticalArrangement = Arrangement.spacedBy(WwSpacing.md),
    ) {
        WwScreenHeader(title = stringResource(R.string.change_pw_title), onBack = onBack)
        WwTextField(s.current, viewModel::onCurrent, stringResource(R.string.change_pw_current), s.currentError, password = true, enabled = !s.loading)
        WwTextField(s.new, viewModel::onNew, stringResource(R.string.change_pw_new), s.newError, password = true, imeAction = ImeAction.Done, enabled = !s.loading)
        Text(stringResource(R.string.change_pw_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        s.failure?.let { FailureBanner(it) }
        if (s.done) Text(stringResource(R.string.change_pw_done), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
        WwPrimaryButton(stringResource(R.string.change_pw_action), viewModel::submit, enabled = !s.loading, loading = s.loading)
    }
}

@Composable
fun SessionsScreen(onBack: () -> Unit, viewModel: SessionsViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    var confirmOthers by rememberSaveable { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(WwSpacing.md),
        verticalArrangement = Arrangement.spacedBy(WwSpacing.md),
    ) {
        WwScreenHeader(title = stringResource(R.string.sessions_title), subtitle = stringResource(R.string.sessions_subtitle), onBack = onBack)
        s.failure?.let {
            FailureBanner(it)
            TextButton(onClick = viewModel::load) { Text(stringResource(R.string.action_retry)) }
        }
        s.revokedOthers?.let { Text(stringResource(R.string.sessions_revoked_n, it), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary) }
        if (s.loading && s.sessions.isEmpty()) {
            Text(stringResource(R.string.diagnostics_checking), style = MaterialTheme.typography.bodyMedium)
        }
        s.sessions.forEach { session ->
            WwCard {
                Text(session.deviceName ?: stringResource(R.string.sessions_unknown_device), style = MaterialTheme.typography.titleMedium)
                Text(
                    stringResource(R.string.sessions_last_used, session.lastUsedAt.take(16).replace('T', ' ')),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (session.current) {
                    Text(stringResource(R.string.sessions_this_device), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                } else {
                    TextButton(onClick = { viewModel.revoke(session.id) }, enabled = s.busyId != session.id) {
                        Text(stringResource(R.string.sessions_revoke))
                    }
                }
            }
        }
        if (s.sessions.size > 1) {
            WwPrimaryButton(stringResource(R.string.sessions_revoke_others), { confirmOthers = true }, enabled = !s.loading)
        }
    }
    if (confirmOthers) {
        AlertDialog(
            onDismissRequest = { confirmOthers = false },
            title = { Text(stringResource(R.string.sessions_revoke_others)) },
            text = { Text(stringResource(R.string.sessions_revoke_others_confirm)) },
            confirmButton = { TextButton(onClick = { confirmOthers = false; viewModel.revokeOthers() }) { Text(stringResource(R.string.sessions_revoke_others)) } },
            dismissButton = { TextButton(onClick = { confirmOthers = false }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
}

@Composable
fun DeleteAccountScreen(onBack: () -> Unit, viewModel: DeleteAccountViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    Column(
        modifier = Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(WwSpacing.md),
        verticalArrangement = Arrangement.spacedBy(WwSpacing.md),
    ) {
        WwScreenHeader(title = stringResource(R.string.delete_account_title), onBack = onBack)
        Text(stringResource(R.string.delete_account_warning), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
        WwTextField(s.password, viewModel::onPassword, stringResource(R.string.delete_account_password), s.passwordError, password = true, imeAction = ImeAction.Done, enabled = !s.loading)
        androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            androidx.compose.material3.Checkbox(checked = s.understood, onCheckedChange = viewModel::onUnderstood, enabled = !s.loading)
            Text(stringResource(R.string.delete_account_understand), style = MaterialTheme.typography.bodyMedium)
        }
        s.failure?.let { FailureBanner(it) }
        WwPrimaryButton(stringResource(R.string.delete_account_action), viewModel::requestConfirm, enabled = !s.loading && s.understood && s.password.isNotEmpty(), loading = s.loading)
    }
    if (s.confirming) {
        AlertDialog(
            onDismissRequest = viewModel::dismissConfirm,
            title = { Text(stringResource(R.string.delete_account_confirm_title)) },
            text = { Text(stringResource(R.string.delete_account_confirm_body)) },
            confirmButton = { TextButton(onClick = viewModel::delete) { Text(stringResource(R.string.delete_account_confirm), color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = viewModel::dismissConfirm) { Text(stringResource(R.string.action_cancel)) } },
        )
    }
}
