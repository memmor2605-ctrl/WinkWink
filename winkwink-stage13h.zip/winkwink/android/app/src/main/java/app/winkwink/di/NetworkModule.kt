package app.winkwink.di

import app.winkwink.BuildConfig
import app.winkwink.data.remote.AccountApi
import app.winkwink.data.remote.AuthHeaderInterceptor
import app.winkwink.data.remote.CommunityApi
import app.winkwink.data.remote.FeedApi
import app.winkwink.data.remote.MessageApi
import app.winkwink.data.remote.NotificationApi
import app.winkwink.data.remote.ProfileExtrasApi
import android.content.Context
import coil.ImageLoader
import dagger.hilt.android.qualifiers.ApplicationContext
import app.winkwink.data.remote.HealthApi
import app.winkwink.data.remote.PublicAuthApi
import app.winkwink.data.remote.SessionRefresher
import app.winkwink.data.remote.SocialApi
import app.winkwink.data.remote.TokenAuthenticator
import app.winkwink.domain.repository.SessionStore
import javax.inject.Named
import dagger.Lazy
import app.winkwink.data.remote.HttpsOnlyInterceptor
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.json.Json
import okhttp3.ConnectionSpec
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideJson(): Json = Json { ignoreUnknownKeys = true }

    @Provides
    @Singleton
    fun provideOkHttp(): OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(HttpsOnlyInterceptor())
        .connectionSpecs(listOf(ConnectionSpec.MODERN_TLS)) // wyłącznie TLS 1.2/1.3
        .followSslRedirects(false) // brak przekierowań HTTPS → HTTP
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        // Bez limitu całego wywołania (przesyłanie plików trwa dłużej); każda faza ma własny limit (connect/read/write).
        .build()

    /** Klient chronionych endpointów: Bearer token + automatyczne odświeżenie po 401. Refresher jest leniwy, by uniknąć cyklu DI. */
    @Provides
    @Singleton
    @Named("authed")
    fun provideAuthedOkHttp(base: OkHttpClient, store: SessionStore, refresher: Lazy<SessionRefresher>): OkHttpClient =
        base.newBuilder()
            .addInterceptor(AuthHeaderInterceptor(store))
            .addInterceptor(app.winkwink.data.remote.TransferTimeoutInterceptor())
            .addInterceptor(app.winkwink.data.remote.IdempotentRetryInterceptor())
            .authenticator(TokenAuthenticator(refresher))
            .build()

    private fun retrofit(client: OkHttpClient, json: Json): Retrofit = Retrofit.Builder()
        .baseUrl(BuildConfig.API_BASE_URL)
        .client(client)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()

    @Provides
    @Singleton
    fun provideRetrofit(client: OkHttpClient, json: Json): Retrofit = retrofit(client, json)

    @Provides
    @Singleton
    @Named("authed")
    fun provideAuthedRetrofit(@Named("authed") client: OkHttpClient, json: Json): Retrofit = retrofit(client, json)

    @Provides
    @Singleton
    fun provideHealthApi(retrofit: Retrofit): HealthApi = retrofit.create(HealthApi::class.java)

    @Provides
    @Singleton
    fun providePublicAuthApi(retrofit: Retrofit): PublicAuthApi = retrofit.create(PublicAuthApi::class.java)

    @Provides
    @Singleton
    fun provideAccountApi(@Named("authed") retrofit: Retrofit): AccountApi = retrofit.create(AccountApi::class.java)

    @Provides
    @Singleton
    fun provideSocialApi(@Named("authed") retrofit: Retrofit): SocialApi = retrofit.create(SocialApi::class.java)

    @Provides
    @Singleton
    fun provideFeedApi(@Named("authed") retrofit: Retrofit): FeedApi = retrofit.create(FeedApi::class.java)

    @Provides
    @Singleton
    fun provideCommunityApi(@Named("authed") retrofit: Retrofit): CommunityApi = retrofit.create(CommunityApi::class.java)

    @Provides
    @Singleton
    fun provideNotificationApi(@Named("authed") retrofit: Retrofit): NotificationApi = retrofit.create(NotificationApi::class.java)

    @Provides
    @Singleton
    fun providePushApi(@Named("authed") retrofit: Retrofit): app.winkwink.data.remote.PushApi = retrofit.create(app.winkwink.data.remote.PushApi::class.java)

    @Provides
    @Singleton
    fun provideMessageApi(@Named("authed") retrofit: Retrofit): MessageApi = retrofit.create(MessageApi::class.java)

    @Provides
    @Singleton
    fun provideProfileExtrasApi(@Named("authed") retrofit: Retrofit): ProfileExtrasApi = retrofit.create(ProfileExtrasApi::class.java)

    /**
     * Ładowarka obrazów korzysta z klienta z tokenem (avatary i tła wymagają zalogowania) i jego ograniczeń TLS.
     * Cache dyskowy Coil jest prywatny dla aplikacji; adresy zawierają znacznik wersji, więc zmiana obrazu unieważnia cache.
     */
    @Provides
    @Singleton
    fun provideImageLoader(@ApplicationContext context: Context, @Named("authed") client: OkHttpClient): ImageLoader =
        ImageLoader.Builder(context).okHttpClient(client).crossfade(true).build()
}
