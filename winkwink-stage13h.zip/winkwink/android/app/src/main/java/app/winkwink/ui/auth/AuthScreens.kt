package app.winkwink.ui.auth

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.winkwink.R
import app.winkwink.ui.components.WwBrandMark
import app.winkwink.ui.components.WwPrimaryButton
import app.winkwink.ui.theme.WwSpacing

@Composable
fun AuthScreen(onForgotPassword: () -> Unit, viewModel: AuthViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    val register = s.mode == AuthMode.REGISTER
    Column(
        modifier = Modifier.fillMaxSize().systemBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(WwSpacing.lg),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(WwSpacing.md),
    ) {
        WwBrandMark(markSize = 96.dp)
        Text(
            stringResource(if (register) R.string.auth_title_register else R.string.auth_title_login),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
        WwTextField(s.email, viewModel::onEmail, stringResource(R.string.field_email), s.emailError, keyboardType = KeyboardType.Email, enabled = !s.loading)
        if (register) {
            WwTextField(s.nickname, viewModel::onNickname, stringResource(R.string.field_nickname), s.nicknameError, enabled = !s.loading)
        }
        WwTextField(
            s.password, viewModel::onPassword, stringResource(R.string.field_password), s.passwordError,
            password = true, imeAction = ImeAction.Done, enabled = !s.loading,
        )
        if (register) {
            Text(
                stringResource(R.string.password_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        s.failure?.let { FailureBanner(it) }
        WwPrimaryButton(
            text = stringResource(if (register) R.string.action_register else R.string.action_login),
            onClick = viewModel::submit,
            enabled = !s.loading,
            loading = s.loading,
        )
        if (!register) TextButton(onClick = onForgotPassword) { Text(stringResource(R.string.auth_forgot_link)) }
        TextButton(onClick = { viewModel.setMode(if (register) AuthMode.LOGIN else AuthMode.REGISTER) }) {
            Text(stringResource(if (register) R.string.auth_switch_to_login else R.string.auth_switch_to_register))
        }
    }
}

@Composable
fun ForgotPasswordScreen(onBack: () -> Unit, viewModel: ForgotPasswordViewModel = hiltViewModel()) {
    val s by viewModel.state.collectAsStateWithLifecycle()
    Column(
        modifier = Modifier.fillMaxSize().systemBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(WwSpacing.lg),
        verticalArrangement = Arrangement.spacedBy(WwSpacing.md),
    ) {
        Text(stringResource(R.string.forgot_title), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onBackground)
        when (s.step) {
            ForgotStep.REQUEST -> {
                Text(stringResource(R.string.forgot_body), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                WwTextField(s.email, viewModel::onEmail, stringResource(R.string.field_email), s.emailError, keyboardType = KeyboardType.Email, imeAction = ImeAction.Done, enabled = !s.loading)
                s.failure?.let { FailureBanner(it) }
                WwPrimaryButton(stringResource(R.string.forgot_send), viewModel::sendCode, enabled = !s.loading, loading = s.loading)
                TextButton(onClick = viewModel::haveCode) { Text(stringResource(R.string.forgot_have_code)) }
            }
            ForgotStep.RESET -> {
                if (s.requestSent) {
                    Text(stringResource(R.string.forgot_sent), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                WwTextField(s.token, viewModel::onToken, stringResource(R.string.forgot_code_label), s.tokenError, enabled = !s.loading)
                WwTextField(s.newPassword, viewModel::onNewPassword, stringResource(R.string.forgot_new_password), s.passwordError, password = true, imeAction = ImeAction.Done, enabled = !s.loading)
                s.failure?.let { FailureBanner(it) }
                WwPrimaryButton(stringResource(R.string.forgot_reset_action), viewModel::reset, enabled = !s.loading, loading = s.loading)
            }
            ForgotStep.DONE -> {
                Text(stringResource(R.string.forgot_done), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onBackground)
            }
        }
        TextButton(onClick = onBack) { Text(stringResource(R.string.action_back_to_login)) }
    }
}
