package app.winkwink.data.remote

import app.winkwink.domain.model.Profile
import app.winkwink.domain.model.SessionInfo
import app.winkwink.domain.model.StoredSession
import app.winkwink.domain.model.UserAccount
import kotlinx.serialization.Serializable

@Serializable data class RegisterRequestDto(val email: String, val password: String, val nickname: String, val platform: String = "android", val deviceName: String? = null)
@Serializable data class LoginRequestDto(val email: String, val password: String, val platform: String = "android", val deviceName: String? = null)
@Serializable data class RefreshRequestDto(val refreshToken: String)
@Serializable data class ForgotPasswordRequestDto(val email: String)
@Serializable data class ResetPasswordRequestDto(val token: String, val newPassword: String)
@Serializable data class DeleteAccountRequestDto(val password: String)
@Serializable data class ChangePasswordRequestDto(val currentPassword: String, val newPassword: String)

@Serializable data class ProfileDto(val nickname: String, val winkwinkId: String, val bio: String? = null, val visibility: String)
@Serializable data class MeDto(val email: String, val profile: ProfileDto)
@Serializable data class TokensDto(val sessionId: String, val accessToken: String, val accessExpiresAt: String, val refreshToken: String, val refreshExpiresAt: String)
@Serializable data class AuthResponseDto(val tokens: TokensDto, val me: MeDto)
@Serializable data class SessionDto(val id: String, val platform: String? = null, val deviceName: String? = null, val createdAt: String, val lastUsedAt: String, val current: Boolean)
@Serializable data class SessionsResponseDto(val sessions: List<SessionDto>)
@Serializable data class RevokedDto(val revoked: Int)

@Serializable data class ApiErrorDto(val error: ApiErrorBodyDto)
@Serializable data class ApiErrorBodyDto(val code: String, val message: String, val requestId: String? = null, val details: List<String>? = null)

fun TokensDto.toStored() = StoredSession(sessionId, accessToken, refreshToken)
fun MeDto.toDomain() = UserAccount(email, Profile(profile.nickname, profile.winkwinkId, profile.bio, profile.visibility))
fun SessionDto.toDomain() = SessionInfo(id, platform, deviceName, createdAt, lastUsedAt, current)
