package app.winkwink.data.remote

import app.winkwink.domain.model.Channel
import app.winkwink.domain.model.Community
import app.winkwink.domain.model.CommunityPage
import app.winkwink.domain.model.InviteCandidate
import app.winkwink.domain.model.Person
import app.winkwink.domain.model.PersonPage
import kotlinx.serialization.Serializable
import java.time.Instant

@Serializable
data class CommunityDto(
    val id: String,
    val name: String,
    val description: String = "",
    val rules: String = "",
    val type: String,
    val memberCount: Int = 0,
    val myRole: String? = null,
    val myStatus: String = "none",
    val createdAt: String,
)

@Serializable data class CommunityListDto(val communities: List<CommunityDto>, val nextCursor: String? = null)
@Serializable data class ChannelDto(val id: String, val name: String)
@Serializable data class ChannelListDto(val channels: List<ChannelDto>)
@Serializable data class JoinResponseDto(val state: String)
/** Pola null są pomijane w JSON (domyślnie `encodeDefaults = false`) — backend zmienia tylko podane. */
@Serializable data class UpdateCommunityRequestDto(val name: String? = null, val description: String? = null, val rules: String? = null, val type: String? = null)
@Serializable data class CreateCommunityRequestDto(val name: String, val description: String, val rules: String, val type: String)

@Serializable data class PersonDto(val winkwinkId: String, val nickname: String, val displayName: String? = null, val role: String? = null, val at: String, val muted: Boolean = false)
@Serializable data class PersonListDto(val people: List<PersonDto>, val nextCursor: String? = null)
@Serializable data class RoleRequestDto(val role: String)
@Serializable data class InviteRequestDto(val user: String)
@Serializable data class TransferOwnershipRequestDto(val user: String)
@Serializable data class InviteCandidateDto(val winkwinkId: String, val nickname: String, val displayName: String? = null, val invited: Boolean = false)
@Serializable data class InviteCandidateListDto(val candidates: List<InviteCandidateDto>)
@Serializable data class CreateChannelRequestDto(val name: String)

fun PersonDto.toDomain() = Person(winkwinkId, nickname, displayName, role, Instant.parse(at), muted)
fun InviteCandidateDto.toDomain() = InviteCandidate(winkwinkId, nickname, displayName, invited)
fun PersonListDto.toDomain() = PersonPage(people.map { it.toDomain() }, nextCursor)
fun CommunityDto.toDomain() = Community(id, name, description, rules, type, memberCount, myRole, myStatus, Instant.parse(createdAt))
fun CommunityListDto.toDomain() = CommunityPage(communities.map { it.toDomain() }, nextCursor)
fun ChannelDto.toDomain() = Channel(id, name)
