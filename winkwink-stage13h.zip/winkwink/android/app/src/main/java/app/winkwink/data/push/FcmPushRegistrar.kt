package app.winkwink.data.push

import android.content.Context
import android.os.Build
import app.winkwink.data.remote.PushApi
import app.winkwink.data.remote.RegisterPushTokenDto
import app.winkwink.data.remote.apiCall
import app.winkwink.domain.push.PushRegistrar
import app.winkwink.domain.repository.SessionStore
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

/**
 * Token FCM należy do instalacji, nie do konta: po każdej zmianie sesji (logowanie) i po każdym nowym tokenie wołamy PUT /push/token.
 * Gdy projekt Firebase nie jest skonfigurowany (brak google-services.json), [available] == false i nic nie jest robione.
 */
@Singleton
class FcmPushRegistrar @Inject constructor(
    @ApplicationContext private val context: Context,
    private val api: PushApi,
    private val store: SessionStore,
    private val json: Json,
) : PushRegistrar {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val available: Boolean get() = FirebaseApp.getApps(context).isNotEmpty()

    /** Wołane raz z Application: rejestruje przy starcie i po każdym (ponownym) zalogowaniu. */
    fun start() {
        if (!available) return
        scope.launch {
            store.session.map { it?.sessionId }.distinctUntilChanged().collect { id -> if (id != null) register() }
        }
    }

    override suspend fun register() {
        if (!available || store.session.value == null) return
        val token = currentToken() ?: return
        apiCall(json) { api.register(RegisterPushTokenDto(token, Build.MODEL?.take(100))) }
    }

    override suspend fun deregister(remote: Boolean) {
        if (!available) return
        val token = currentToken()
        if (remote && token != null && store.session.value != null) apiCall(json) { api.unregister(token) }
        // Nowy token po wylogowaniu: stary (znany serwerowi/innemu kontu) przestaje działać.
        suspendCancellableCoroutine { c -> FirebaseMessaging.getInstance().deleteToken().addOnCompleteListener { c.resume(Unit) } }
    }

    private suspend fun currentToken(): String? = suspendCancellableCoroutine { c ->
        FirebaseMessaging.getInstance().token.addOnCompleteListener { t -> c.resume(if (t.isSuccessful) t.result else null) }
    }
}
