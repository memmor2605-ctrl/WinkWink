package app.winkwink.domain.media

enum class ImageKind(val maxEdge: Int, val maxBytes: Int) {
    AVATAR(maxEdge = 1024, maxBytes = 2 * 1024 * 1024),
    BACKGROUND(maxEdge = 2048, maxBytes = 5 * 1024 * 1024),
    /** Zdjęcia w postach (zgodne z AttachmentService na backendzie). */
    POST(maxEdge = 2048, maxBytes = 8 * 1024 * 1024),
}

/** Błąd przygotowania obrazu do wysłania (nieczytelny plik, nie obraz, brak pamięci). */
class ImagePrepareException(message: String) : Exception(message)

/**
 * Zamienia wskazany przez systemowy wybierak obraz (Uri jako tekst) na JPEG gotowy do wysłania: uwzględnia obrót z EXIF,
 * skaluje do [ImageKind.maxEdge] i koduje od nowa, co usuwa metadane (w tym lokalizację GPS) przed wysłaniem na serwer.
 * Interfejs pozwala testować ViewModele bez Androida.
 */
interface ImagePreparer {
    suspend fun prepare(uri: String, kind: ImageKind): Result<ByteArray>
}
