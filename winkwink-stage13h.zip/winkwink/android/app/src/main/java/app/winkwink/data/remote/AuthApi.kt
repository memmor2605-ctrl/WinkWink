package app.winkwink.data.remote

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

/** Endpointy publiczne — klient bez nagłówka Authorization i bez automatycznego odświeżania. */
interface PublicAuthApi {
    @POST("api/v1/auth/register") suspend fun register(@Body body: RegisterRequestDto): Response<AuthResponseDto>
    @POST("api/v1/auth/login") suspend fun login(@Body body: LoginRequestDto): Response<AuthResponseDto>
    @POST("api/v1/auth/refresh") suspend fun refresh(@Body body: RefreshRequestDto): Response<TokensDto>
    @POST("api/v1/auth/password/forgot") suspend fun forgot(@Body body: ForgotPasswordRequestDto): Response<Unit>
    @POST("api/v1/auth/password/reset") suspend fun reset(@Body body: ResetPasswordRequestDto): Response<Unit>
}

/** Endpointy chronione — klient z tokenem i automatycznym odświeżaniem po 401. */
interface AccountApi {
    @POST("api/v1/auth/logout") suspend fun logout(): Response<Unit>
    @POST("api/v1/me/delete") suspend fun deleteAccount(@Body body: DeleteAccountRequestDto): Response<Unit>
    @GET("api/v1/me") suspend fun me(): Response<MeDto>
    @POST("api/v1/me/password") suspend fun changePassword(@Body body: ChangePasswordRequestDto): Response<Unit>
    @GET("api/v1/me/sessions") suspend fun sessions(): Response<SessionsResponseDto>
    @DELETE("api/v1/me/sessions/{id}") suspend fun revokeSession(@Path("id") id: String): Response<Unit>
    @DELETE("api/v1/me/sessions") suspend fun revokeOthers(): Response<RevokedDto>
}
