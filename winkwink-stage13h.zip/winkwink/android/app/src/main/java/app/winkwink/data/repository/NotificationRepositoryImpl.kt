package app.winkwink.data.repository

import app.winkwink.data.remote.NotificationApi
import app.winkwink.data.remote.NotificationSettingsDto
import app.winkwink.data.remote.apiCall
import app.winkwink.data.remote.toDomain
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.NotificationPage
import app.winkwink.domain.repository.NotificationRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationRepositoryImpl @Inject constructor(
    private val api: NotificationApi,
    private val json: Json,
) : NotificationRepository {

    override suspend fun list(type: String?, unreadOnly: Boolean, cursor: String?): Result<NotificationPage> = io {
        val r = apiCall(json) { api.list(type, if (unreadOnly) true else null, PAGE_SIZE, cursor) }
        r.fold(
            onSuccess = { dto ->
                try { Result.success(dto.toDomain()) } catch (e: java.time.DateTimeException) {
                    Result.failure(ApiFailure("invalid_response", "Unexpected response"))
                }
            },
            onFailure = { Result.failure(it) },
        )
    }

    override suspend fun unreadCount(): Result<Int> = io { apiCall(json) { api.unreadCount() }.map { it.unreadCount } }
    override suspend fun markRead(id: String): Result<Unit> = io { apiCall(json) { api.markRead(id) }.map { } }
    override suspend fun markAllRead(type: String?): Result<Unit> = io { apiCall(json) { api.markAllRead(type) }.map { } }
    override suspend fun settings(): Result<Map<String, Boolean>> = io { apiCall(json) { api.settings() }.map { it.types } }
    override suspend fun updateSettings(changes: Map<String, Boolean>): Result<Map<String, Boolean>> =
        io { apiCall(json) { api.updateSettings(NotificationSettingsDto(changes)) }.map { it.types } }

    private suspend fun <T> io(block: suspend () -> Result<T>): Result<T> = withContext(Dispatchers.IO) { block() }

    private companion object { const val PAGE_SIZE = 20 }
}
