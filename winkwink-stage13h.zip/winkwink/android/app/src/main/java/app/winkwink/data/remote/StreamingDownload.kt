package app.winkwink.data.remote

import app.winkwink.domain.model.ApiFailure
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.ResponseBody
import retrofit2.Response
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.SocketTimeoutException

/**
 * Pobieranie strumieniowe: ciało odpowiedzi (`@Streaming`) jest czytane kawałkami po 64 KB prosto do [sink], więc plik
 * nigdy nie leży w całości w pamięci. Anulowanie korutyny przerywa pętlę między kawałkami i zamyka połączenie.
 * Błędy sieci mapowane są na te same kody co reszta aplikacji (network / timeout / http_*).
 */
internal suspend fun streamBody(call: suspend () -> Response<ResponseBody>, sink: (ByteArray, Int) -> Unit): Result<Unit> = try {
    val response = call()
    if (!response.isSuccessful) {
        val code = when (response.code()) { 404 -> "attachment_not_found"; 403 -> "forbidden"; 416 -> "range_not_satisfiable"; else -> "http_${response.code()}" }
        response.errorBody()?.close()
        Result.failure(ApiFailure(code, "HTTP ${response.code()}", httpStatus = response.code()))
    } else {
        val body = response.body()
        if (body == null) Result.failure(ApiFailure("invalid_response", "Empty response")) else {
            body.use { b ->
                val buf = ByteArray(64 * 1024)
                val input = b.byteStream()
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val n = input.read(buf)
                    if (n < 0) break
                    sink(buf, n)
                }
            }
            Result.success(Unit)
        }
    }
} catch (e: SocketTimeoutException) {
    Result.failure(ApiFailure("timeout", "Timeout"))
} catch (e: IOException) {
    Result.failure(ApiFailure("network", "Network unreachable"))
}

/** Pobiera do [target] przez plik tymczasowy `.part` (pełny plik pojawia się atomowo; po błędzie lub anulowaniu nic nie zostaje). */
internal suspend fun streamToFile(call: suspend () -> Response<ResponseBody>, target: File): Result<Unit> = withContext(Dispatchers.IO) {
    target.parentFile?.mkdirs()
    val tmp = File(target.parentFile, target.name + ".part")
    var ok = false
    try {
        val r = try {
            FileOutputStream(tmp).use { os -> streamBody(call) { buf, n -> os.write(buf, 0, n) } }
        } catch (e: IOException) {
            Result.failure(ApiFailure("storage", "Cannot write file"))
        }
        if (r.isSuccess) {
            if (tmp.renameTo(target)) { ok = true; Result.success(Unit) } else Result.failure(ApiFailure("storage", "Cannot write file"))
        } else r
    } finally {
        if (!ok) tmp.delete() // także przy CancellationException
    }
}
