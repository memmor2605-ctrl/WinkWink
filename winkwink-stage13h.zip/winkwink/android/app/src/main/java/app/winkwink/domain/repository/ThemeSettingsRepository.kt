package app.winkwink.domain.repository

import app.winkwink.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow

interface ThemeSettingsRepository {
    val themeMode: Flow<ThemeMode>
    suspend fun setThemeMode(mode: ThemeMode)
}
