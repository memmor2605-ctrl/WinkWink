package app.winkwink

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import app.winkwink.data.session.SessionCleaner
import app.winkwink.domain.outbox.OutboxScheduler
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class WinkWinkApp : Application(), Configuration.Provider {
    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var sessionCleaner: SessionCleaner
    @Inject lateinit var outboxScheduler: OutboxScheduler
    @Inject lateinit var pushRegistrar: app.winkwink.data.push.FcmPushRegistrar
    @Inject lateinit var pushPresenter: app.winkwink.data.push.PushNotificationPresenter

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder().setWorkerFactory(workerFactory).build()

    override fun onCreate() {
        super.onCreate()
        sessionCleaner.start()
        pushPresenter.ensureChannels() // kanały muszą istnieć, zanim system pokaże ustawienia powiadomień aplikacji
        pushRegistrar.start()          // rejestracja tokenu FCM po zalogowaniu (no-op bez konfiguracji Firebase)
        // Po każdym starcie procesu wznawiamy to, co zostało w kolejce (ubity proces, restart telefonu).
        outboxScheduler.schedule()
    }
}
