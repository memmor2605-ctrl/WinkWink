package app.winkwink.domain.media

import app.winkwink.domain.model.PreparedFile

/** Limity zgodne z backendem (AttachmentService); serwer pozostaje źródłem prawdy. */
object AttachmentLimits {
    const val VIDEO_MAX_BYTES = 30 * 1024 * 1024
    const val DOCUMENT_MAX_BYTES = 10 * 1024 * 1024
    const val MAX_ATTACHMENTS = 10
    const val MAX_VIDEOS = 1
    const val MAX_DOCUMENTS = 3
}

/** Kody błędów przygotowania pliku (mapowane na teksty w UI). */
class AttachmentPrepareException(val code: String) : Exception(code) {
    companion object {
        const val UNSUPPORTED = "unsupported_type"
        const val TOO_LARGE = "file_too_large"
        const val UNREADABLE = "file_unreadable"
    }
}

/**
 * Zamienia Uri z systemowego wybieraka na plik gotowy do wysłania. Obrazy są zmniejszane i kodowane od nowa (bez EXIF/GPS);
 * filmy MP4 i dokumenty PDF są wysyłane bez zmian — urządzenie nie usuwa z nich metadanych, dlatego anonimowe posty ich nie przyjmują.
 */
interface AttachmentPreparer {
    suspend fun prepare(uri: String): Result<PreparedFile>
}
