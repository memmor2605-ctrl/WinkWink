package app.winkwink

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.compose.runtime.CompositionLocalProvider
import app.winkwink.ui.components.LocalWinkImageLoader
import coil.ImageLoader
import javax.inject.Inject
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.winkwink.ui.auth.AuthGateViewModel
import app.winkwink.ui.auth.AuthScreen
import app.winkwink.ui.auth.ForgotPasswordScreen
import app.winkwink.ui.navigation.WinkWinkMainShell
import app.winkwink.ui.screens.SettingsViewModel
import app.winkwink.ui.screens.StartScreen
import app.winkwink.ui.theme.WinkWinkTheme
import app.winkwink.ui.theme.WwMotion
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    @Inject lateinit var imageLoader: ImageLoader
    @Inject lateinit var deepLinks: app.winkwink.data.push.DeepLinkBus

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleDeepLink(intent)
    }

    /** Intencja z powiadomienia push niesie cel w extras; trafia do magistrali, którą konsumuje ekran główny po zalogowaniu. */
    private fun handleDeepLink(intent: android.content.Intent?) {
        app.winkwink.data.push.PushNotificationPresenter.parse(intent?.extras)?.let(deepLinks::post)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handleDeepLink(intent)
        setContent {
            val settings: SettingsViewModel = hiltViewModel()
            val themeMode by settings.themeMode.collectAsStateWithLifecycle()
            WinkWinkTheme(themeMode) {
                CompositionLocalProvider(LocalWinkImageLoader provides imageLoader) {
                    Surface(color = MaterialTheme.colorScheme.background) {
                        WinkWinkRoot()
                    }
                }
            }
        }
    }
}

private enum class RootScreen { START, AUTH, FORGOT, MAIN }

@Composable
private fun WinkWinkRoot(gate: AuthGateViewModel = hiltViewModel()) {
    val signedIn by gate.signedIn.collectAsStateWithLifecycle()
    var started by rememberSaveable { mutableStateOf(false) }
    var forgot by rememberSaveable { mutableStateOf(false) }
    // Niezalogowany użytkownik nigdy nie widzi powłoki z chronionymi zasobami.
    val target = when {
        signedIn -> RootScreen.MAIN
        !started -> RootScreen.START
        forgot -> RootScreen.FORGOT
        else -> RootScreen.AUTH
    }
    Crossfade(targetState = target, animationSpec = tween(WwMotion.MEDIUM_MS), label = "root") { screen ->
        when (screen) {
            RootScreen.START -> StartScreen(onStart = { started = true })
            RootScreen.AUTH -> AuthScreen(onForgotPassword = { forgot = true })
            RootScreen.FORGOT -> ForgotPasswordScreen(onBack = { forgot = false })
            RootScreen.MAIN -> WinkWinkMainShell()
        }
    }
}
