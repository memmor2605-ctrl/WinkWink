package app.winkwink.ui.feed

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.winkwink.domain.media.AttachmentLimits
import app.winkwink.domain.media.AttachmentPrepareException
import app.winkwink.domain.media.AttachmentPreparer
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.Channel
import app.winkwink.domain.model.Community
import app.winkwink.domain.model.Comment
import app.winkwink.domain.model.FeedKind
import app.winkwink.domain.model.Post
import app.winkwink.domain.repository.CommunityRepository
import app.winkwink.domain.repository.FeedRepository
import app.winkwink.domain.validation.PostValidation
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

// ---------- Lista (Following / Discover) ----------

data class FeedListState(
    val posts: List<Post> = emptyList(),
    /** Pierwsze ładowanie albo odświeżanie. */
    val loading: Boolean = false,
    val loadingMore: Boolean = false,
    val nextCursor: String? = null,
    /** Czy choć raz pobrano pierwszą stronę (odróżnia „pusto” od „jeszcze nie ładowano”). */
    val loaded: Boolean = false,
    val failure: ApiFailure? = null,
)

data class FeedUiState(
    val tab: FeedKind = FeedKind.Following,
    val following: FeedListState = FeedListState(),
    val discover: FeedListState = FeedListState(),
    val actionFailure: ApiFailure? = null,
    /** Udostępnienie zakończone powodzeniem (do jednorazowego komunikatu). */
    val shareNotice: Boolean = false,
) {
    fun list(kind: FeedKind) = if (kind == FeedKind.Following) following else discover
    fun withList(kind: FeedKind, f: (FeedListState) -> FeedListState) =
        if (kind == FeedKind.Following) copy(following = f(following)) else copy(discover = f(discover))
}

@HiltViewModel
class FeedViewModel @Inject constructor(private val repository: FeedRepository) : ViewModel() {
    private val _state = MutableStateFlow(FeedUiState())
    val state: StateFlow<FeedUiState> = _state.asStateFlow()
    private val jobs = mutableMapOf<FeedKind, Job>()

    init { refresh(FeedKind.Following) }

    fun selectTab(kind: FeedKind) {
        _state.update { it.copy(tab = kind) }
        val l = _state.value.list(kind)
        if (!l.loaded && !l.loading) refresh(kind)
    }

    fun refreshCurrent() = refresh(_state.value.tab)

    /** Pobiera pierwszą stronę od nowa; przerywa trwające ładowanie kolejnych stron tej listy. */
    fun refresh(kind: FeedKind) {
        jobs[kind]?.cancel()
        _state.update { it.withList(kind) { l -> l.copy(loading = true, loadingMore = false, failure = null) } }
        jobs[kind] = viewModelScope.launch {
            val r = repository.feed(kind, null)
            _state.update {
                it.withList(kind) { l ->
                    r.fold(
                        onSuccess = { page -> l.copy(posts = page.posts, nextCursor = page.nextCursor, loading = false, loaded = true, failure = null) },
                        onFailure = { e -> l.copy(loading = false, failure = e as? ApiFailure ?: ApiFailure("unknown", "Unknown error")) },
                    )
                }
            }
        }
    }

    fun loadMore(kind: FeedKind) {
        val l = _state.value.list(kind)
        val cursor = l.nextCursor ?: return
        if (l.loading || l.loadingMore) return
        _state.update { it.withList(kind) { x -> x.copy(loadingMore = true, failure = null) } }
        jobs[kind] = viewModelScope.launch {
            val r = repository.feed(kind, cursor)
            _state.update {
                it.withList(kind) { x ->
                    r.fold(
                        onSuccess = { page ->
                            // Dedup po id na wypadek przesunięcia stron przy nowych postach.
                            val known = x.posts.mapTo(HashSet()) { p -> p.id }
                            x.copy(posts = x.posts + page.posts.filter { p -> p.id !in known }, nextCursor = page.nextCursor, loadingMore = false)
                        },
                        onFailure = { e -> x.copy(loadingMore = false, failure = e as? ApiFailure ?: ApiFailure("unknown", "Unknown error")) },
                    )
                }
            }
        }
    }

    fun react(post: Post, type: String) = viewModelScope.launch {
        applyPostResult(repository.react(post.id, type))
    }

    fun unreact(post: Post) = viewModelScope.launch {
        applyPostResult(repository.unreact(post.id))
    }

    fun toggleSave(post: Post) = viewModelScope.launch {
        repository.setSaved(post.id, !post.saved).fold(
            onSuccess = { replace(post.copy(saved = !post.saved)) },
            onFailure = { e -> _state.update { it.copy(actionFailure = e as? ApiFailure) } },
        )
    }

    fun dismissActionFailure() = _state.update { it.copy(actionFailure = null) }
    fun dismissShareNotice() = _state.update { it.copy(shareNotice = false) }

    /** Udostępnia post na własnym profilu; lista „Following” jest ładowana od nowa, bo zawiera teraz nowy post użytkownika. */
    fun share(post: Post, comment: String, visibility: String) = viewModelScope.launch {
        repository.share(post.id, comment, visibility).fold(
            onSuccess = {
                _state.update { s -> s.copy(shareNotice = true, actionFailure = null) }
                refresh(FeedKind.Following)
            },
            onFailure = { e -> _state.update { s -> s.copy(actionFailure = e as? ApiFailure) } },
        )
    }

    private fun applyPostResult(r: Result<Post>) = r.fold(
        onSuccess = { replace(it) },
        onFailure = { e -> _state.update { s -> s.copy(actionFailure = e as? ApiFailure) } },
    )

    private fun replace(updated: Post) = _state.update { s ->
        fun FeedListState.swap() = copy(posts = posts.map { if (it.id == updated.id) updated else it })
        s.copy(following = s.following.swap(), discover = s.discover.swap(), actionFailure = null)
    }
}

// ---------- Nowy post ----------

enum class UploadStatus { Uploading, Done, Failed }

/** Załącznik w szkicu. Plik jest wysyłany od razu po wybraniu; do posta trafiają tylko identyfikatory ([remoteId]). */
data class DraftAttachment(
    val localId: Int,
    val uri: String,
    val kind: String,
    val name: String?,
    val status: UploadStatus,
    val remoteId: String? = null,
    val errorCode: String? = null,
)

data class ComposeUiState(
    val body: String = "",
    val visibility: String = "public",
    val anonymous: Boolean = false,
    val posting: Boolean = false,
    val created: Boolean = false,
    val failure: ApiFailure? = null,
    val attachments: List<DraftAttachment> = emptyList(),
    /** Liczba plików w trakcie przygotowania (zmniejszanie / czytanie) — zanim pojawią się na liście. */
    val preparing: Int = 0,
    /** Kod komunikatu o załączniku: too_many | too_many_videos | too_many_documents | anonymous_images_only | unsupported_type | file_too_large | file_unreadable. */
    val attachmentNotice: String? = null,
    val communities: List<Community> = emptyList(),
    val communitiesLoading: Boolean = false,
    val communitiesLoaded: Boolean = false,
    val communitiesFailure: ApiFailure? = null,
    val communityId: String? = null,
    val channels: List<Channel> = emptyList(),
    val channelsLoading: Boolean = false,
    val channelId: String? = null,
) {
    val tooLong get() = body.trim().length > PostValidation.POST_MAX
    val communityMode get() = visibility == "community"
    val uploading get() = preparing > 0 || attachments.any { it.status == UploadStatus.Uploading }
    val hasFailedUpload get() = attachments.any { it.status == UploadStatus.Failed }
    val hasNonImage get() = attachments.any { it.kind != "image" }
    private val bodyOk get() = if (attachments.isNotEmpty()) !tooLong else PostValidation.postBodyValid(body)
    private val communityReady get() = !communityMode || (communityId != null && channelId != null)
    val canPost get() = bodyOk && !tooLong && !posting && !uploading && !hasFailedUpload && communityReady
}

@HiltViewModel
class ComposePostViewModel @Inject constructor(
    private val repository: FeedRepository,
    private val communityRepository: CommunityRepository,
    private val preparer: AttachmentPreparer,
) : ViewModel() {
    private val _state = MutableStateFlow(ComposeUiState())
    val state: StateFlow<ComposeUiState> = _state.asStateFlow()
    private var nextLocalId = 1

    fun onBody(v: String) = _state.update { it.copy(body = v, failure = null) }

    fun onVisibility(v: String) {
        val s = _state.value
        if (s.anonymous && v != "public") return
        _state.update { it.copy(visibility = v, anonymous = if (v == "community") false else it.anonymous, failure = null) }
        if (v == "community" && !s.communitiesLoaded && !s.communitiesLoading) loadCommunities()
    }

    /** Anonimowy post jest zawsze publiczny i przyjmuje tylko obrazy (pliki innego typu nie są czyszczone z metadanych). */
    fun onAnonymous(v: Boolean) {
        val s = _state.value
        if (v && s.communityMode) return // post w społeczności nie bywa anonimowy
        if (v && s.hasNonImage) { _state.update { it.copy(attachmentNotice = "anonymous_images_only") }; return }
        _state.update { it.copy(anonymous = v, visibility = if (v) "public" else it.visibility, attachmentNotice = null) }
    }

    fun loadCommunities() {
        _state.update { it.copy(communitiesLoading = true, communitiesFailure = null) }
        viewModelScope.launch {
            val all = mutableListOf<Community>()
            var cursor: String? = null
            var failure: ApiFailure? = null
            var pages = 0
            do {
                val r = communityRepository.mine(cursor)
                val page = r.getOrNull()
                if (page == null) { failure = r.exceptionOrNull() as? ApiFailure ?: ApiFailure("unknown", "Unknown error"); break }
                all += page.communities.filter { it.isMember }
                cursor = page.nextCursor
                pages++
            } while (cursor != null && pages < MAX_COMMUNITY_PAGES)
            _state.update { it.copy(communities = all, communitiesLoading = false, communitiesLoaded = failure == null, communitiesFailure = failure) }
            // Jedna społeczność → wybieramy ją od razu (mniej stukania na małym ekranie).
            if (failure == null && all.size == 1 && _state.value.communityId == null) onCommunity(all.first().id)
        }
    }

    fun onCommunity(id: String) {
        _state.update { it.copy(communityId = id, channels = emptyList(), channelId = null, channelsLoading = true, failure = null) }
        viewModelScope.launch {
            communityRepository.channels(id).fold(
                onSuccess = { list ->
                    _state.update { s ->
                        if (s.communityId != id) s else s.copy(channels = list, channelsLoading = false, channelId = list.firstOrNull()?.id)
                    }
                },
                onFailure = { e -> _state.update { s -> if (s.communityId != id) s else s.copy(channelsLoading = false, failure = e as? ApiFailure) } },
            )
        }
    }

    fun onChannel(id: String) = _state.update { it.copy(channelId = id) }

    fun dismissAttachmentNotice() = _state.update { it.copy(attachmentNotice = null) }

    /** Dodaje wybrane pliki po kolei: przygotowanie na urządzeniu, sprawdzenie limitów, wysłanie. */
    fun addAttachments(uris: List<String>) {
        viewModelScope.launch { uris.forEach { addOne(it) } }
    }

    private suspend fun addOne(uri: String) {
        _state.update { it.copy(preparing = it.preparing + 1, attachmentNotice = null) }
        val prepared = preparer.prepare(uri)
        _state.update { it.copy(preparing = it.preparing - 1) }
        val file = prepared.getOrNull() ?: run {
            val code = (prepared.exceptionOrNull() as? AttachmentPrepareException)?.code ?: AttachmentPrepareException.UNREADABLE
            _state.update { it.copy(attachmentNotice = code) }
            return
        }
        val s = _state.value
        val violation = when {
            s.attachments.size >= AttachmentLimits.MAX_ATTACHMENTS -> "too_many"
            file.kind == "video" && s.attachments.count { it.kind == "video" } >= AttachmentLimits.MAX_VIDEOS -> "too_many_videos"
            file.kind == "document" && s.attachments.count { it.kind == "document" } >= AttachmentLimits.MAX_DOCUMENTS -> "too_many_documents"
            file.kind != "image" && s.anonymous -> "anonymous_images_only"
            else -> null
        }
        if (violation != null) { _state.update { it.copy(attachmentNotice = violation) }; return }
        val localId = nextLocalId++
        _state.update { it.copy(attachments = it.attachments + DraftAttachment(localId, uri, file.kind, file.name, UploadStatus.Uploading)) }
        repository.uploadAttachment(file).fold(
            onSuccess = { a -> updateAttachment(localId) { it.copy(status = UploadStatus.Done, remoteId = a.id, errorCode = null) } },
            onFailure = { e -> updateAttachment(localId) { it.copy(status = UploadStatus.Failed, errorCode = (e as? ApiFailure)?.code ?: "unknown") } },
        )
    }

    fun retryAttachment(localId: Int) {
        val a = _state.value.attachments.firstOrNull { it.localId == localId && it.status == UploadStatus.Failed } ?: return
        _state.update { s -> s.copy(attachments = s.attachments.filter { it.localId != localId }) }
        addAttachments(listOf(a.uri))
    }

    fun removeAttachment(localId: Int) {
        val a = _state.value.attachments.firstOrNull { it.localId == localId } ?: return
        _state.update { s -> s.copy(attachments = s.attachments.filter { it.localId != localId }, attachmentNotice = null) }
        // Usunięcie niedołączonego pliku z serwera jest „best effort”; porzucone wysyłki serwer i tak sprząta po 24 h.
        a.remoteId?.let { id -> viewModelScope.launch { repository.deleteAttachment(id) } }
    }

    private fun updateAttachment(localId: Int, f: (DraftAttachment) -> DraftAttachment) =
        _state.update { s -> s.copy(attachments = s.attachments.map { if (it.localId == localId) f(it) else it }) }

    fun publish() {
        val s = _state.value
        if (!s.canPost) return
        _state.update { it.copy(posting = true, failure = null) }
        val ids = s.attachments.mapNotNull { it.remoteId }
        viewModelScope.launch {
            val r = if (s.communityMode) repository.createCommunityPost(s.body, s.communityId!!, s.channelId!!, ids)
            else repository.createPost(s.body, s.visibility, s.anonymous, ids)
            _state.update { it.copy(posting = false, created = r.isSuccess, failure = r.exceptionOrNull() as? ApiFailure) }
        }
    }

    private companion object { const val MAX_COMMUNITY_PAGES = 5 }
}

// ---------- Szczegóły posta + komentarze ----------

data class RepliesState(
    val items: List<Comment> = emptyList(),
    val nextCursor: String? = null,
    val loading: Boolean = false,
    val expanded: Boolean = false,
)

data class PostDetailUiState(
    val loading: Boolean = true,
    val post: Post? = null,
    val comments: List<Comment> = emptyList(),
    val commentsCursor: String? = null,
    val commentsLoading: Boolean = false,
    val replies: Map<String, RepliesState> = emptyMap(),
    val draft: String = "",
    val replyingTo: Comment? = null,
    val sending: Boolean = false,
    val failure: ApiFailure? = null,
    val actionFailure: ApiFailure? = null,
    /** Ustawiane po każdej zmianie widocznej na liście (reakcja, zapis, komentarz, edycja) — lista się odświeża. */
    val changed: Boolean = false,
    val deleted: Boolean = false,
    val shareNotice: Boolean = false,
) {
    val draftValid get() = PostValidation.commentBodyValid(draft)
}

@HiltViewModel
class PostDetailViewModel @Inject constructor(
    private val repository: FeedRepository,
    savedState: SavedStateHandle,
) : ViewModel() {
    private val postId: String = checkNotNull(savedState["id"])
    private val _state = MutableStateFlow(PostDetailUiState())
    val state: StateFlow<PostDetailUiState> = _state.asStateFlow()

    init { load() }

    fun load() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val p = repository.post(postId)
            _state.update { it.copy(loading = false, post = p.getOrNull() ?: it.post, failure = p.exceptionOrNull() as? ApiFailure) }
            if (p.isSuccess) loadComments(reset = true)
        }
    }

    fun loadComments(reset: Boolean = false) {
        val s = _state.value
        if (s.commentsLoading) return
        val cursor = if (reset) null else s.commentsCursor ?: if (s.comments.isNotEmpty()) return else null
        _state.update { it.copy(commentsLoading = true) }
        viewModelScope.launch {
            val r = repository.comments(postId, null, cursor)
            _state.update { st ->
                r.fold(
                    onSuccess = { page ->
                        val base = if (reset) emptyList() else st.comments
                        val known = base.mapTo(HashSet()) { c -> c.id }
                        st.copy(comments = base + page.comments.filter { c -> c.id !in known }, commentsCursor = page.nextCursor, commentsLoading = false)
                    },
                    onFailure = { e -> st.copy(commentsLoading = false, actionFailure = e as? ApiFailure) },
                )
            }
        }
    }

    fun toggleReplies(comment: Comment) {
        val cur = _state.value.replies[comment.id]
        if (cur?.expanded == true) { setReplies(comment.id) { it.copy(expanded = false) }; return }
        if (cur != null && cur.items.isNotEmpty()) { setReplies(comment.id) { it.copy(expanded = true) }; return }
        loadReplies(comment.id)
    }

    fun loadReplies(commentId: String) {
        val cur = _state.value.replies[commentId] ?: RepliesState()
        if (cur.loading) return
        setReplies(commentId) { it.copy(loading = true, expanded = true) }
        viewModelScope.launch {
            val r = repository.comments(postId, commentId, cur.nextCursor)
            r.fold(
                onSuccess = { page ->
                    setReplies(commentId) {
                        val known = it.items.mapTo(HashSet()) { c -> c.id }
                        it.copy(items = it.items + page.comments.filter { c -> c.id !in known }, nextCursor = page.nextCursor, loading = false)
                    }
                },
                onFailure = { e ->
                    setReplies(commentId) { it.copy(loading = false) }
                    _state.update { it.copy(actionFailure = e as? ApiFailure) }
                },
            )
        }
    }

    fun onDraft(v: String) = _state.update { it.copy(draft = v) }
    fun startReply(c: Comment) = _state.update { it.copy(replyingTo = c) }
    fun cancelReply() = _state.update { it.copy(replyingTo = null) }
    fun dismissActionFailure() = _state.update { it.copy(actionFailure = null) }

    fun sendComment() {
        val s = _state.value
        if (!s.draftValid || s.sending) return
        val parent = s.replyingTo
        _state.update { it.copy(sending = true, actionFailure = null) }
        viewModelScope.launch {
            repository.addComment(postId, parent?.id, s.draft).fold(
                onSuccess = { c ->
                    _state.update { st ->
                        if (parent == null) {
                            st.copy(comments = st.comments + c, draft = "", sending = false, changed = true)
                        } else {
                            val r = st.replies[parent.id]
                            val updatedReplies = if (r != null && r.expanded) st.replies + (parent.id to r.copy(items = r.items + c)) else st.replies
                            st.copy(
                                comments = st.comments.map { x -> if (x.id == parent.id) x.copy(replyCount = x.replyCount + 1) else x },
                                replies = updatedReplies, draft = "", replyingTo = null, sending = false, changed = true,
                            )
                        }
                    }
                    refreshPostCounters()
                },
                onFailure = { e -> _state.update { it.copy(sending = false, actionFailure = e as? ApiFailure) } },
            )
        }
    }

    fun deleteComment(c: Comment) = viewModelScope.launch {
        repository.deleteComment(c.id).fold(
            onSuccess = {
                _state.update { st ->
                    st.copy(
                        comments = st.comments.filter { x -> x.id != c.id }.map { x ->
                            if (x.id == c.parentId) x.copy(replyCount = (x.replyCount - 1).coerceAtLeast(0)) else x
                        },
                        replies = (st.replies - c.id).mapValues { (_, r) -> r.copy(items = r.items.filter { x -> x.id != c.id }) },
                        replyingTo = st.replyingTo?.takeIf { it.id != c.id },
                        changed = true,
                    )
                }
                refreshPostCounters()
            },
            onFailure = { e -> _state.update { it.copy(actionFailure = e as? ApiFailure) } },
        )
    }

    fun react(type: String) = viewModelScope.launch { postResult(repository.react(postId, type)) }
    fun unreact() = viewModelScope.launch { postResult(repository.unreact(postId)) }

    fun toggleSave() = viewModelScope.launch {
        val p = _state.value.post ?: return@launch
        repository.setSaved(p.id, !p.saved).fold(
            onSuccess = { _state.update { it.copy(post = p.copy(saved = !p.saved), changed = true) } },
            onFailure = { e -> _state.update { it.copy(actionFailure = e as? ApiFailure) } },
        )
    }

    fun editPost(body: String) = viewModelScope.launch { postResult(repository.updatePost(postId, body)) }

    fun share(comment: String, visibility: String) = viewModelScope.launch {
        repository.share(postId, comment, visibility).fold(
            onSuccess = { _state.update { it.copy(shareNotice = true, changed = true, actionFailure = null) }; refreshPostCounters() },
            onFailure = { e -> _state.update { it.copy(actionFailure = e as? ApiFailure) } },
        )
    }

    fun dismissShareNotice() = _state.update { it.copy(shareNotice = false) }

    fun deletePost() = viewModelScope.launch {
        repository.deletePost(postId).fold(
            onSuccess = { _state.update { it.copy(deleted = true, changed = true) } },
            onFailure = { e -> _state.update { it.copy(actionFailure = e as? ApiFailure) } },
        )
    }

    private fun postResult(r: Result<Post>) = r.fold(
        onSuccess = { p -> _state.update { it.copy(post = p, changed = true, actionFailure = null) } },
        onFailure = { e -> _state.update { it.copy(actionFailure = e as? ApiFailure) } },
    )

    /** Liczniki komentarzy liczy serwer (usunięcie komentarza kasuje też odpowiedzi) — nie zgadujemy ich lokalnie. */
    private suspend fun refreshPostCounters() {
        repository.post(postId).getOrNull()?.let { p -> _state.update { it.copy(post = p) } }
    }

    private fun setReplies(commentId: String, f: (RepliesState) -> RepliesState) =
        _state.update { it.copy(replies = it.replies + (commentId to f(it.replies[commentId] ?: RepliesState()))) }
}

// ---------- Zapisane posty ----------

data class SavedUiState(
    val posts: List<Post> = emptyList(),
    val loading: Boolean = true,
    val loadingMore: Boolean = false,
    val nextCursor: String? = null,
    val failure: ApiFailure? = null,
)

@HiltViewModel
class SavedPostsViewModel @Inject constructor(private val repository: FeedRepository) : ViewModel() {
    private val _state = MutableStateFlow(SavedUiState())
    val state: StateFlow<SavedUiState> = _state.asStateFlow()

    init { refresh() }

    fun refresh() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            repository.saved(null).fold(
                onSuccess = { p -> _state.update { it.copy(posts = p.posts, nextCursor = p.nextCursor, loading = false) } },
                onFailure = { e -> _state.update { it.copy(loading = false, failure = e as? ApiFailure ?: ApiFailure("unknown", "Unknown error")) } },
            )
        }
    }

    fun loadMore() {
        val cursor = _state.value.nextCursor ?: return
        if (_state.value.loading || _state.value.loadingMore) return
        _state.update { it.copy(loadingMore = true, failure = null) }
        viewModelScope.launch {
            repository.saved(cursor).fold(
                onSuccess = { p ->
                    _state.update { st ->
                        val known = st.posts.mapTo(HashSet()) { x -> x.id }
                        st.copy(posts = st.posts + p.posts.filter { x -> x.id !in known }, nextCursor = p.nextCursor, loadingMore = false)
                    }
                },
                onFailure = { e -> _state.update { it.copy(loadingMore = false, failure = e as? ApiFailure ?: ApiFailure("unknown", "Unknown error")) } },
            )
        }
    }

    fun react(post: Post, type: String) = viewModelScope.launch { repository.react(post.id, type).onSuccess { replace(it) } }
    fun unreact(post: Post) = viewModelScope.launch { repository.unreact(post.id).onSuccess { replace(it) } }

    /** Odznaczenie zapisu usuwa post z tej listy dopiero po potwierdzeniu przez serwer. */
    fun unsave(post: Post) = viewModelScope.launch {
        repository.setSaved(post.id, false).fold(
            onSuccess = { _state.update { st -> st.copy(posts = st.posts.filter { it.id != post.id }) } },
            onFailure = { e -> _state.update { it.copy(failure = e as? ApiFailure) } },
        )
    }

    private fun replace(updated: Post) = _state.update { st -> st.copy(posts = st.posts.map { if (it.id == updated.id) updated else it }) }
}

// ---------- Wyszukiwanie publikacji ----------

data class SearchUiState(
    val query: String = "",
    val posts: List<Post> = emptyList(),
    val loading: Boolean = false,
    val loadingMore: Boolean = false,
    val nextCursor: String? = null,
    /** Czy wykonano już wyszukiwanie dla bieżącego zapytania (odróżnia „brak wyników” od „jeszcze nie szukano”). */
    val searched: Boolean = false,
    val failure: ApiFailure? = null,
    val actionFailure: ApiFailure? = null,
    val shareNotice: Boolean = false,
) {
    val tooShort get() = query.trim().length < PostValidation.SEARCH_MIN
    val tooLong get() = query.trim().length > PostValidation.SEARCH_MAX
}

@OptIn(FlowPreview::class)
@HiltViewModel
class SearchPostsViewModel @Inject constructor(private val repository: FeedRepository) : ViewModel() {
    private val _state = MutableStateFlow(SearchUiState())
    val state: StateFlow<SearchUiState> = _state.asStateFlow()
    private val queries = MutableStateFlow("")
    private var job: Job? = null

    init {
        viewModelScope.launch {
            queries.debounce(DEBOUNCE_MS).map { it.trim() }.distinctUntilChanged().collect { run(it) }
        }
    }

    fun onQuery(v: String) {
        _state.update { it.copy(query = v) }
        queries.value = v
    }

    /** Wyszukiwanie bez czekania na debounce (przycisk / klawisz Szukaj). */
    fun submit() = run(_state.value.query.trim())

    fun retry() = run(_state.value.query.trim())

    private fun run(q: String) {
        job?.cancel()
        if (q.length < PostValidation.SEARCH_MIN || q.length > PostValidation.SEARCH_MAX) {
            _state.update { it.copy(posts = emptyList(), nextCursor = null, loading = false, loadingMore = false, searched = false, failure = null) }
            return
        }
        _state.update { it.copy(loading = true, loadingMore = false, failure = null) }
        job = viewModelScope.launch {
            repository.search(q, null).fold(
                onSuccess = { page -> _state.update { it.copy(posts = page.posts, nextCursor = page.nextCursor, loading = false, searched = true) } },
                onFailure = { e -> _state.update { it.copy(loading = false, searched = false, failure = e as? ApiFailure ?: ApiFailure("unknown", "Unknown error")) } },
            )
        }
    }

    fun loadMore() {
        val s = _state.value
        val cursor = s.nextCursor ?: return
        if (s.loading || s.loadingMore) return
        val q = s.query.trim()
        _state.update { it.copy(loadingMore = true, failure = null) }
        job = viewModelScope.launch {
            repository.search(q, cursor).fold(
                onSuccess = { page ->
                    _state.update { st ->
                        val known = st.posts.mapTo(HashSet()) { x -> x.id }
                        st.copy(posts = st.posts + page.posts.filter { x -> x.id !in known }, nextCursor = page.nextCursor, loadingMore = false)
                    }
                },
                onFailure = { e -> _state.update { it.copy(loadingMore = false, failure = e as? ApiFailure ?: ApiFailure("unknown", "Unknown error")) } },
            )
        }
    }

    fun react(post: Post, type: String) = viewModelScope.launch { apply(repository.react(post.id, type)) }
    fun unreact(post: Post) = viewModelScope.launch { apply(repository.unreact(post.id)) }

    fun toggleSave(post: Post) = viewModelScope.launch {
        repository.setSaved(post.id, !post.saved).fold(
            onSuccess = { replace(post.copy(saved = !post.saved)) },
            onFailure = { e -> _state.update { it.copy(actionFailure = e as? ApiFailure) } },
        )
    }

    fun share(post: Post, comment: String, visibility: String) = viewModelScope.launch {
        repository.share(post.id, comment, visibility).fold(
            onSuccess = { _state.update { it.copy(shareNotice = true, actionFailure = null) } },
            onFailure = { e -> _state.update { it.copy(actionFailure = e as? ApiFailure) } },
        )
    }

    fun dismissActionFailure() = _state.update { it.copy(actionFailure = null) }
    fun dismissShareNotice() = _state.update { it.copy(shareNotice = false) }

    private fun apply(r: Result<Post>) = r.fold(
        onSuccess = { replace(it) },
        onFailure = { e -> _state.update { it.copy(actionFailure = e as? ApiFailure) } },
    )

    private fun replace(updated: Post) = _state.update { st -> st.copy(posts = st.posts.map { if (it.id == updated.id) updated else it }, actionFailure = null) }

    private companion object { const val DEBOUNCE_MS = 400L }
}
