package app.winkwink.domain.validation

object ProfileValidation {
    const val BIO_MAX = 280
    const val DISPLAY_NAME_MAX = 50
    const val LINKS_MAX = 5

    /** Jeden link na linię; puste linie pomijane. Właściwa walidacja (https, host) jest po stronie serwera. */
    fun splitLinks(raw: String): List<String> = raw.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()

    fun bioTooLong(bio: String) = bio.trim().length > BIO_MAX
    fun displayNameTooLong(name: String) = name.trim().length > DISPLAY_NAME_MAX
    fun tooManyLinks(links: List<String>) = links.size > LINKS_MAX
}
