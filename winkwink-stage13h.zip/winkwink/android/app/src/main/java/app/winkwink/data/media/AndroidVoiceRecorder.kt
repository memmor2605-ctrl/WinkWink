package app.winkwink.data.media

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.os.SystemClock
import app.winkwink.domain.media.RecordedVoice
import app.winkwink.domain.media.VoiceRecordException
import app.winkwink.domain.media.VoiceRecorder
import app.winkwink.domain.model.MessageMediaLimits
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Nagrywanie przez [MediaRecorder]: źródło MIC, AAC w MPEG-4 (.m4a), mono 44,1 kHz, 64 kb/s (~0,5 MB/min; 10 min ≈ 4,8 MB < limit 8 MB).
 * Pliki trafiają do prywatnego katalogu cache aplikacji (`cache/voice-out`) — nie są widoczne dla innych aplikacji.
 * Osierocone nagrania (np. po zabiciu procesu w trakcie nagrywania) są kasowane przy pierwszym użyciu po starcie procesu.
 */
@Singleton
class AndroidVoiceRecorder @Inject constructor(
    @ApplicationContext private val context: Context,
) : VoiceRecorder {

    private var recorder: MediaRecorder? = null
    private var file: File? = null
    private var startedAt = 0L
    private var swept = false

    override val isRecording: Boolean get() = recorder != null

    private fun dir(): File = File(context.cacheDir, DIR).apply { mkdirs() }

    private fun sweepOld() {
        if (swept) return
        swept = true
        val cutoff = System.currentTimeMillis() - 24L * 60 * 60 * 1000
        dir().listFiles()?.filter { it.lastModified() < cutoff }?.forEach { it.delete() }
    }

    @Suppress("DEPRECATION")
    override fun start(): Result<Unit> {
        if (recorder != null) return Result.failure(VoiceRecordException(VoiceRecordException.BUSY))
        sweepOld()
        val out = File(dir(), "voice-${UUID.randomUUID()}.m4a")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else MediaRecorder()
        return try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(44_100)
            r.setAudioEncodingBitRate(64_000)
            r.setMaxDuration(MessageMediaLimits.VOICE_MAX_MS.toInt())
            r.setOutputFile(out.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            file = out
            startedAt = SystemClock.elapsedRealtime()
            Result.success(Unit)
        } catch (e: Exception) {
            // Mikrofon zajęty (np. rozmowa), brak uprawnienia lub błąd sprzętu.
            runCatching { r.release() }
            out.delete()
            Result.failure(VoiceRecordException(VoiceRecordException.START_FAILED))
        }
    }

    override fun stop(): Result<RecordedVoice> {
        val r = recorder ?: return Result.failure(VoiceRecordException(VoiceRecordException.STOP_FAILED))
        val out = file
        val elapsed = SystemClock.elapsedRealtime() - startedAt
        recorder = null; file = null
        return try {
            r.stop()
            r.release()
            if (out == null || !out.exists()) return Result.failure(VoiceRecordException(VoiceRecordException.STOP_FAILED))
            // stop() zbyt szybko po start() rzuca RuntimeException, a krótsze niż próg nagrania i tak nie ma sensu wysyłać.
            if (elapsed < MessageMediaLimits.VOICE_MIN_MS) {
                out.delete()
                return Result.failure(VoiceRecordException(VoiceRecordException.TOO_SHORT))
            }
            Result.success(RecordedVoice(out.absolutePath, minOf(elapsed, MessageMediaLimits.VOICE_MAX_MS), out.length()))
        } catch (e: RuntimeException) {
            runCatching { r.release() }
            out?.delete()
            Result.failure(VoiceRecordException(if (elapsed < MessageMediaLimits.VOICE_MIN_MS) VoiceRecordException.TOO_SHORT else VoiceRecordException.STOP_FAILED))
        }
    }

    override fun cancel() {
        val r = recorder ?: return
        val out = file
        recorder = null; file = null
        runCatching { r.stop() }
        runCatching { r.release() }
        out?.delete()
    }

    override fun discard(path: String) {
        // Kasujemy wyłącznie pliki z własnego katalogu nagrań.
        val f = File(path)
        if (f.parentFile?.canonicalPath == dir().canonicalPath) f.delete()
    }

    override suspend fun read(path: String): ByteArray? = withContext(Dispatchers.IO) {
        // Czytamy wyłącznie z własnego katalogu nagrań.
        val f = File(path)
        if (f.parentFile?.canonicalPath != dir().canonicalPath) null else runCatching { f.readBytes() }.getOrNull()
    }

    private companion object { const val DIR = "voice-out" }
}
