package app.winkwink.domain.repository

import app.winkwink.domain.model.StoredSession
import kotlinx.coroutines.flow.StateFlow

interface SessionStore {
    /** Aktualna sesja albo null, gdy użytkownik jest wylogowany. */
    val session: StateFlow<StoredSession?>
    suspend fun save(session: StoredSession)
    suspend fun clear()
}
