package app.winkwink.data.remote

import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Streaming

/** Endpointy chronione (klient z tokenem). Kontrakt: docs/API.md, „Etap 3”. */
interface FeedApi {
    @GET("api/v1/feed/following") suspend fun following(@Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<PostListDto>
    @GET("api/v1/feed/discover") suspend fun discover(@Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<PostListDto>
    @GET("api/v1/me/saved") suspend fun saved(@Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<PostListDto>
    @GET("api/v1/posts/search") suspend fun search(@Query("q") query: String, @Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<PostListDto>
    @POST("api/v1/posts/{id}/share") suspend fun share(@Path("id") id: String, @Body body: SharePostRequestDto): Response<PostDto>
    /** Surowe ciało = plik; Content-Type i Content-Length ustawia OkHttp na podstawie [RequestBody]. */
    @POST("api/v1/attachments") suspend fun uploadAttachment(@Body body: RequestBody, @Query("name") name: String?): Response<AttachmentDto>
    @DELETE("api/v1/attachments/{id}") suspend fun deleteAttachment(@Path("id") id: String): Response<Unit>
    @Streaming @GET("api/v1/attachments/{id}") suspend fun downloadAttachment(@Path("id") id: String): Response<ResponseBody>
    @GET("api/v1/posts/{id}") suspend fun post(@Path("id") id: String): Response<PostDto>
    @POST("api/v1/posts") suspend fun createPost(@Body body: CreatePostRequestDto): Response<PostDto>
    @PATCH("api/v1/posts/{id}") suspend fun updatePost(@Path("id") id: String, @Body body: UpdatePostRequestDto): Response<PostDto>
    @DELETE("api/v1/posts/{id}") suspend fun deletePost(@Path("id") id: String): Response<Unit>
    @PUT("api/v1/posts/{id}/reaction") suspend fun react(@Path("id") id: String, @Body body: ReactionRequestDto): Response<PostDto>
    @DELETE("api/v1/posts/{id}/reaction") suspend fun unreact(@Path("id") id: String): Response<PostDto>
    @POST("api/v1/posts/{id}/save") suspend fun save(@Path("id") id: String): Response<Unit>
    @DELETE("api/v1/posts/{id}/save") suspend fun unsave(@Path("id") id: String): Response<Unit>
    @GET("api/v1/posts/{id}/comments") suspend fun comments(@Path("id") id: String, @Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<CommentListDto>
    @GET("api/v1/posts/{id}/comments/{commentId}/replies")
    suspend fun replies(@Path("id") id: String, @Path("commentId") commentId: String, @Query("limit") limit: Int, @Query("cursor") cursor: String?): Response<CommentListDto>
    @POST("api/v1/posts/{id}/comments") suspend fun addComment(@Path("id") id: String, @Body body: CreateCommentRequestDto): Response<CommentDto>
    @DELETE("api/v1/comments/{id}") suspend fun deleteComment(@Path("id") id: String): Response<Unit>
}
