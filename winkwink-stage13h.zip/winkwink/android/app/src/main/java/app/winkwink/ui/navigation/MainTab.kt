package app.winkwink.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.ui.graphics.vector.ImageVector
import app.winkwink.R

enum class MainTab(val route: String, @StringRes val labelRes: Int, val icon: ImageVector) {
    Feed("feed", R.string.tab_feed, Icons.Filled.Home),
    Communities("communities", R.string.tab_communities, Icons.Filled.Face),
    Messages("messages", R.string.tab_messages, Icons.Filled.Email),
    Activity("activity", R.string.tab_activity, Icons.Filled.Notifications),
    Profile("profile", R.string.tab_profile, Icons.Filled.Person),
}

object Routes {
    const val FEED_HOME = "feed/home"
    const val FEED_COMPOSE = "feed/compose"
    const val FEED_SEARCH = "feed/search"
    const val POST = "feed/post/{id}"
    fun post(id: String) = "feed/post/${android.net.Uri.encode(id)}"
    /** Klucz w SavedStateHandle ekranu listy: szczegóły posta zmieniły dane widoczne na liście. */
    const val FEED_STALE_KEY = "feed_stale"

    const val COMMUNITIES_HOME = "communities/home"
    const val COMMUNITY_CREATE = "communities/create"
    const val COMMUNITY = "communities/detail/{id}"
    const val COMMUNITY_MANAGE = "communities/manage/{id}"
    fun communityManage(id: String) = "communities/manage/${android.net.Uri.encode(id)}"
    fun community(id: String) = "communities/detail/${android.net.Uri.encode(id)}"

    const val MESSAGES_HOME = "messages/home"
    const val MESSAGES_NEW = "messages/new/{mode}"
    /** mode = direct | group */
    fun messagesNew(mode: String) = "messages/new/${android.net.Uri.encode(mode)}"
    const val MESSAGES_SETTINGS = "messages/settings"
    const val MESSAGES_WITH = "messages/with/{user}"
    /** Otwiera (lub tworzy) rozmowę 1:1 z użytkownikiem o podanym WinkWink ID. */
    fun messagesWith(user: String) = "messages/with/${android.net.Uri.encode(user)}"
    const val CHAT = "messages/chat/{id}"
    fun chat(id: String) = "messages/chat/${android.net.Uri.encode(id)}"
    const val CHAT_MEMBERS = "messages/members/{id}"
    fun chatMembers(id: String) = "messages/members/${android.net.Uri.encode(id)}"

    const val ACTIVITY_HOME = "activity/home"
    const val NOTIFICATION_SETTINGS = "activity/settings"

    const val PROFILE_HOME = "profile/home"
    const val DIAGNOSTICS = "profile/diagnostics"
    const val CHANGE_PASSWORD = "profile/password"
    const val SESSIONS = "profile/sessions"
    const val DELETE_ACCOUNT = "profile/delete"
    const val USER_SEARCH = "profile/search"
    const val EDIT_PROFILE = "profile/edit"
    const val SAVED = "profile/saved"
    const val MUTED = "profile/muted"
    /** Listy użytkowników: kind = followers | following | requests | blocked; id = identyfikator profilu ("me" dla requests/blocked). */
    const val USER_LIST = "profile/list/{kind}/{id}"
    fun userList(kind: String, id: String = "me") = "profile/list/${android.net.Uri.encode(kind)}/${android.net.Uri.encode(id)}"
    const val USER = "profile/user/{id}"
    fun user(id: String) = "profile/user/${android.net.Uri.encode(id)}"
}
