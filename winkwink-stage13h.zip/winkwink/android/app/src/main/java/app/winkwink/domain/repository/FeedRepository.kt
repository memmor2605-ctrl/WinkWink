package app.winkwink.domain.repository

import app.winkwink.domain.model.Attachment
import app.winkwink.domain.model.Comment
import app.winkwink.domain.model.CommentPage
import app.winkwink.domain.model.FeedKind
import app.winkwink.domain.model.Post
import app.winkwink.domain.model.PostPage
import app.winkwink.domain.model.PreparedFile

interface FeedRepository {
    suspend fun feed(kind: FeedKind, cursor: String?): Result<PostPage>
    /** Zapisane posty widza, od ostatnio zapisanych. */
    suspend fun saved(cursor: String?): Result<PostPage>
    suspend fun post(id: String): Result<Post>
    suspend fun createPost(body: String, visibility: String, anonymous: Boolean, attachmentIds: List<String>): Result<Post>
    /** Post widoczny tylko dla członków społeczności; backend sprawdza członkostwo i przynależność kanału. */
    suspend fun createCommunityPost(body: String, communityId: String, channelId: String, attachmentIds: List<String>): Result<Post>
    suspend fun updatePost(id: String, body: String): Result<Post>
    suspend fun deletePost(id: String): Result<Unit>
    /** Ustawia reakcję [type] (zastępuje poprzednią). */
    suspend fun react(id: String, type: String): Result<Post>
    suspend fun unreact(id: String): Result<Post>
    suspend fun setSaved(id: String, saved: Boolean): Result<Unit>
    /** [parentId] == null → komentarze najwyższego poziomu, inaczej odpowiedzi na ten komentarz. */
    suspend fun comments(postId: String, parentId: String?, cursor: String?): Result<CommentPage>
    suspend fun addComment(postId: String, parentId: String?, body: String): Result<Comment>
    suspend fun deleteComment(id: String): Result<Unit>

    /** Wyszukiwanie publikacji widocznych dla widza; backend wymaga co najmniej 3 znaków. */
    suspend fun search(query: String, cursor: String?): Result<PostPage>
    /** Udostępnia publiczny post na własnym profilu ([visibility] = public | followers) z opcjonalnym komentarzem. */
    suspend fun share(id: String, comment: String, visibility: String): Result<Post>
    suspend fun uploadAttachment(file: PreparedFile): Result<Attachment>
    suspend fun deleteAttachment(id: String): Result<Unit>
    /** Pobiera cały plik załącznika (limity: obraz 8 MB, dokument 10 MB, film 30 MB). */
    suspend fun downloadAttachment(id: String): Result<ByteArray>
    /** Pobiera strumieniowo do pliku (bez całości w RAM); anulowanie korutyny przerywa i sprząta plik tymczasowy. */
    suspend fun downloadAttachmentToFile(id: String, target: java.io.File): Result<Unit> =
        downloadAttachment(id).mapCatching { target.writeBytes(it) }
}
