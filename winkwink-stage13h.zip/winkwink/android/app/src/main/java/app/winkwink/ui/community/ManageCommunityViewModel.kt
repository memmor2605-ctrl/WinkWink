package app.winkwink.ui.community

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.winkwink.domain.model.ApiFailure
import app.winkwink.domain.model.Channel
import app.winkwink.domain.model.Community
import app.winkwink.domain.model.CommunityRoles
import app.winkwink.domain.model.InviteCandidate
import app.winkwink.domain.model.Person
import app.winkwink.domain.repository.CommunityRepository
import app.winkwink.domain.validation.CommunityValidation
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ManageUiState(
    val loading: Boolean = true,
    val community: Community? = null,
    val members: List<Person> = emptyList(),
    val membersCursor: String? = null,
    val requests: List<Person> = emptyList(),
    val channels: List<Channel> = emptyList(),
    val inviteDraft: String = "",
    /** Wyniki wyszukiwania osób do zaproszenia (zapytanie = [inviteDraft], min. 2 znaki). */
    val candidates: List<InviteCandidate> = emptyList(),
    val candidatesLoading: Boolean = false,
    /** Czy wykonano wyszukiwanie dla bieżącego zapytania (odróżnia „brak wyników” od „jeszcze nie szukano”). */
    val candidatesSearched: Boolean = false,
    val candidatesFailure: ApiFailure? = null,
    val channelDraft: String = "",
    val editName: String = "",
    val editDescription: String = "",
    val editRules: String = "",
    val editType: String = "public",
    val saved: Boolean = false,
    val busy: Boolean = false,
    /** true po usunięciu społeczności — ekran wraca do listy. */
    val deleted: Boolean = false,
    val notice: Notice? = null,
    val failure: ApiFailure? = null,
) {
    val myRole get() = community?.myRole
    val canModerate get() = CommunityRoles.isModeratorOrAbove(myRole)
    val canManageChannels get() = CommunityRoles.isAdminOrAbove(myRole)
    val isOwner get() = myRole == "owner"
    val editDirty get() = community?.let {
        editName.trim() != it.name || editDescription.trim() != it.description || editRules.trim() != it.rules || editType != it.type
    } ?: false
    val editValid get() = CommunityValidation.nameValid(editName) && CommunityValidation.descriptionValid(editDescription) && CommunityValidation.rulesValid(editRules)
    enum class Notice { InviteSent }
}

/** Zarządzanie społecznością. Przyciski odzwierciedlają rolę, ale uprawnienia egzekwuje backend przy każdym żądaniu. */
@OptIn(FlowPreview::class)
@HiltViewModel
class ManageCommunityViewModel @Inject constructor(
    private val repository: CommunityRepository,
    savedState: SavedStateHandle,
) : ViewModel() {
    private val communityId: String = checkNotNull(savedState["id"])
    private val _state = MutableStateFlow(ManageUiState())
    val state: StateFlow<ManageUiState> = _state.asStateFlow()

    private val candidateQueries = MutableStateFlow("")
    private var candidateJob: Job? = null

    init {
        load()
        viewModelScope.launch {
            candidateQueries.debounce(CANDIDATE_DEBOUNCE_MS).map { it.trim().removePrefix("@") }.distinctUntilChanged().collect { searchCandidates(it) }
        }
    }

    fun load() {
        _state.update { it.copy(loading = true, failure = null) }
        viewModelScope.launch {
            val c = repository.get(communityId)
            val community = c.getOrNull()
            if (community == null) {
                _state.update { it.copy(loading = false, failure = c.exceptionOrNull() as? ApiFailure ?: ApiFailure("unknown", "Unknown error")) }
                return@launch
            }
            _state.update {
                // Szkic edycji nadpisujemy tylko wtedy, gdy użytkownik niczego jeszcze nie zmienił.
                val fresh = !it.editDirty
                it.copy(
                    community = community,
                    editName = if (fresh) community.name else it.editName, editDescription = if (fresh) community.description else it.editDescription,
                    editRules = if (fresh) community.rules else it.editRules, editType = if (fresh) community.type else it.editType,
                )
            }
            if (!CommunityRoles.isModeratorOrAbove(community.myRole)) {
                _state.update { it.copy(loading = false, failure = ApiFailure("forbidden", "Forbidden", httpStatus = 403)) }
                return@launch
            }
            val members = repository.members(communityId, null)
            val requests = repository.requests(communityId, null)
            val channels = repository.channels(communityId)
            _state.update {
                it.copy(
                    loading = false,
                    members = members.getOrNull()?.people ?: it.members, membersCursor = members.getOrNull()?.nextCursor,
                    requests = requests.getOrNull()?.people ?: emptyList(),
                    channels = channels.getOrNull() ?: it.channels,
                    failure = listOf(members, requests, channels).firstNotNullOfOrNull { r -> r.exceptionOrNull() }?.let { e -> e as? ApiFailure ?: ApiFailure("unknown", "Unknown error") },
                )
            }
        }
    }

    fun loadMoreMembers() {
        val cursor = _state.value.membersCursor ?: return
        if (_state.value.busy) return
        viewModelScope.launch {
            repository.members(communityId, cursor).fold(
                onSuccess = { page ->
                    _state.update { st ->
                        val known = st.members.mapTo(HashSet()) { p -> p.winkwinkId }
                        st.copy(members = st.members + page.people.filter { p -> p.winkwinkId !in known }, membersCursor = page.nextCursor)
                    }
                },
                onFailure = { e -> fail(e) },
            )
        }
    }

    fun onInviteDraft(v: String) {
        _state.update { it.copy(inviteDraft = v, notice = null, failure = null) }
        candidateQueries.value = v
    }

    private fun searchCandidates(q: String) {
        candidateJob?.cancel()
        if (q.length < CANDIDATE_MIN) {
            _state.update { it.copy(candidates = emptyList(), candidatesLoading = false, candidatesSearched = false, candidatesFailure = null) }
            return
        }
        _state.update { it.copy(candidatesLoading = true, candidatesFailure = null) }
        candidateJob = viewModelScope.launch {
            repository.inviteCandidates(communityId, q).fold(
                onSuccess = { list -> _state.update { it.copy(candidates = list, candidatesLoading = false, candidatesSearched = true) } },
                onFailure = { e -> _state.update { it.copy(candidatesLoading = false, candidatesSearched = false, candidatesFailure = e as? ApiFailure ?: ApiFailure("unknown", "Unknown error")) } },
            )
        }
    }

    /** Wyszukiwanie bez czekania na debounce (przycisk „Szukaj”). */
    fun searchNow() = searchCandidates(_state.value.inviteDraft.trim().removePrefix("@"))

    /** Zaprasza osobę z listy wyników; po sukcesie oznacza ją jako zaproszoną (bez ponownego ładowania). */
    fun inviteCandidate(c: InviteCandidate) {
        if (c.invited) return
        act(
            reload = false,
            onSuccess = {
                _state.update { st -> st.copy(notice = ManageUiState.Notice.InviteSent, candidates = st.candidates.map { x -> if (x.winkwinkId == c.winkwinkId) x.copy(invited = true) else x }) }
            },
        ) { repository.invite(communityId, c.winkwinkId) }
    }
    fun onEditName(v: String) = _state.update { it.copy(editName = v, saved = false, failure = null) }
    fun onEditDescription(v: String) = _state.update { it.copy(editDescription = v, saved = false, failure = null) }
    fun onEditRules(v: String) = _state.update { it.copy(editRules = v, saved = false, failure = null) }
    fun onEditType(v: String) = _state.update { it.copy(editType = v, saved = false, failure = null) }

    /** Wysyła tylko zmienione pola; typ tylko właściciel (administrator dostałby 403). */
    fun saveEdit() {
        val s = _state.value
        val c = s.community ?: return
        if (!s.canManageChannels || !s.editDirty || !s.editValid || s.busy) return
        val name = s.editName.trim().takeIf { it != c.name }
        val description = s.editDescription.trim().takeIf { it != c.description }
        val rules = s.editRules.trim().takeIf { it != c.rules }
        val type = s.editType.takeIf { it != c.type && s.isOwner }
        if (name == null && description == null && rules == null && type == null) return
        _state.update { it.copy(busy = true, failure = null, saved = false) }
        viewModelScope.launch {
            repository.update(communityId, name, description, rules, type).fold(
                onSuccess = { updated ->
                    _state.update { st ->
                        st.copy(
                            busy = false, saved = true, community = updated,
                            editName = updated.name, editDescription = updated.description, editRules = updated.rules, editType = updated.type,
                        )
                    }
                },
                onFailure = { e -> _state.update { it.copy(busy = false) }; fail(e) },
            )
        }
    }

    fun onChannelDraft(v: String) = _state.update { it.copy(channelDraft = v, failure = null) }
    fun dismissFailure() = _state.update { it.copy(failure = null) }

    fun invite() {
        val id = _state.value.inviteDraft.trim().removePrefix("@")
        if (id.isEmpty()) return
        act(reload = false, onSuccess = { _state.update { it.copy(inviteDraft = "", notice = ManageUiState.Notice.InviteSent) } }) { repository.invite(communityId, id) }
    }

    /** Przekazanie własności (po potwierdzeniu w UI). Dotychczasowy właściciel zostaje administratorem; dane są ładowane od nowa. */
    fun transferOwnership(person: Person) {
        if (!CommunityRoles.canTransfer(_state.value.myRole, person.role)) return
        act { repository.transferOwnership(communityId, person.winkwinkId) }
    }

    fun setMuted(person: Person, muted: Boolean) {
        if (!CommunityRoles.canMute(_state.value.myRole, person.role)) return
        act { repository.setMuted(communityId, person.winkwinkId, muted) }
    }

    fun decide(person: Person, approve: Boolean) = act { repository.decideRequest(communityId, person.winkwinkId, approve) }
    fun setRole(person: Person, role: String) = act { repository.setRole(communityId, person.winkwinkId, role) }

    fun remove(person: Person) {
        if (!CommunityRoles.canRemove(_state.value.myRole, person.role)) return
        act { repository.removeMember(communityId, person.winkwinkId) }
    }

    fun addChannel() {
        val name = _state.value.channelDraft.trim()
        if (name.isEmpty()) return
        act(onSuccess = { _state.update { it.copy(channelDraft = "") } }) { repository.createChannel(communityId, name).map { } }
    }

    fun deleteChannel(channel: Channel) = act { repository.deleteChannel(communityId, channel.id) }

    fun deleteCommunity() {
        if (!_state.value.isOwner || _state.value.busy) return
        _state.update { it.copy(busy = true, failure = null) }
        viewModelScope.launch {
            repository.delete(communityId).fold(
                onSuccess = { _state.update { it.copy(busy = false, deleted = true) } },
                onFailure = { e -> _state.update { it.copy(busy = false) }; fail(e) },
            )
        }
    }

    /** Akcja administracyjna; po sukcesie stan list zawsze pochodzi z serwera (ładowanie od nowa). */
    private fun act(reload: Boolean = true, onSuccess: () -> Unit = {}, action: suspend () -> Result<Unit>) {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, failure = null, notice = null) }
        viewModelScope.launch {
            action().fold(
                onSuccess = {
                    _state.update { it.copy(busy = false) }
                    onSuccess()
                    if (reload) load()
                },
                onFailure = { e -> _state.update { it.copy(busy = false) }; fail(e) },
            )
        }
    }

    private fun fail(e: Throwable) = _state.update { it.copy(failure = e as? ApiFailure ?: ApiFailure("unknown", "Unknown error")) }

    private companion object {
        const val CANDIDATE_DEBOUNCE_MS = 400L
        const val CANDIDATE_MIN = 2
    }
}
