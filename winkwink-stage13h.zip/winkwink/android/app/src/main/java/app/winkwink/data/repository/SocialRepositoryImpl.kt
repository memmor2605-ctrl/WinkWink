package app.winkwink.data.repository

import app.winkwink.data.remote.SocialApi
import app.winkwink.data.remote.UpdateProfileRequestDto
import app.winkwink.data.remote.UserListDto
import app.winkwink.data.remote.apiCall
import app.winkwink.data.remote.toDomain
import app.winkwink.domain.model.UserPage
import app.winkwink.domain.model.UserProfile
import app.winkwink.domain.model.UserSummary
import app.winkwink.domain.repository.SocialRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SocialRepositoryImpl @Inject constructor(
    private val api: SocialApi,
    private val json: Json,
) : SocialRepository {

    override suspend fun profile(identifier: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        apiCall(json) { api.profile(identifier) }.map { it.toDomain() }
    }

    override suspend fun search(query: String): Result<List<UserSummary>> = withContext(Dispatchers.IO) {
        apiCall(json) { api.search(query.trim(), 20) }.map { r -> r.users.map { it.toDomain() } }
    }

    override suspend fun follow(identifier: String): Result<String> = withContext(Dispatchers.IO) {
        apiCall(json) { api.follow(identifier) }.map { it.state }
    }

    override suspend fun unfollow(identifier: String): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { api.unfollow(identifier) }.map { }
    }

    override suspend fun block(identifier: String): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { api.block(identifier) }.map { }
    }

    override suspend fun unblock(identifier: String): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { api.unblock(identifier) }.map { }
    }

    override suspend fun followers(identifier: String, cursor: String?): Result<UserPage> = withContext(Dispatchers.IO) {
        apiCall(json) { api.followers(identifier, PAGE, cursor) }.map { it.toPage() }
    }

    override suspend fun following(identifier: String, cursor: String?): Result<UserPage> = withContext(Dispatchers.IO) {
        apiCall(json) { api.following(identifier, PAGE, cursor) }.map { it.toPage() }
    }

    override suspend fun followRequests(cursor: String?): Result<UserPage> = withContext(Dispatchers.IO) {
        apiCall(json) { api.followRequests(PAGE, cursor) }.map { it.toPage() }
    }

    override suspend fun approveRequest(identifier: String): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { api.approveRequest(identifier) }.map { }
    }

    override suspend fun rejectRequest(identifier: String): Result<Unit> = withContext(Dispatchers.IO) {
        apiCall(json) { api.rejectRequest(identifier) }.map { }
    }

    override suspend fun blocked(cursor: String?): Result<UserPage> = withContext(Dispatchers.IO) {
        apiCall(json) { api.blocks(PAGE, cursor) }.map { it.toPage() }
    }

    private fun UserListDto.toPage() = UserPage(users.map { it.toDomain() }, nextCursor)

    private companion object { const val PAGE = 30 }

    override suspend fun updateProfile(displayName: String, bio: String, links: List<String>, visibility: String): Result<UserProfile> =
        withContext(Dispatchers.IO) {
            val name = displayName.trim()
            apiCall(json) {
                api.updateProfile(
                    UpdateProfileRequestDto(
                        displayName = name.ifEmpty { null },
                        clearDisplayName = name.isEmpty(),
                        bio = bio.trim(),
                        links = links,
                        visibility = visibility,
                    ),
                )
            }.map { it.toDomain() }
        }
}
