package app.winkwink.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.navigation
import androidx.navigation.compose.rememberNavController
import androidx.compose.foundation.layout.padding
import app.winkwink.ui.account.ChangePasswordScreen
import app.winkwink.ui.activity.ActivityHomeScreen
import app.winkwink.ui.activity.NotificationSettingsScreen
import app.winkwink.ui.activity.UnreadBadgeViewModel
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.LifecycleResumeEffect
import app.winkwink.ui.messages.MessagingBackgroundViewModel
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.winkwink.ui.account.SessionsScreen
import app.winkwink.ui.community.CommunitiesHomeScreen
import app.winkwink.ui.community.CommunityDetailScreen
import app.winkwink.ui.community.CreateCommunityScreen
import app.winkwink.ui.community.ManageCommunityScreen
import app.winkwink.ui.diagnostics.DiagnosticsScreen
import app.winkwink.ui.feed.ComposePostScreen
import app.winkwink.ui.feed.FeedHomeScreen
import app.winkwink.ui.feed.PostDetailScreen
import app.winkwink.ui.feed.SavedPostsScreen
import app.winkwink.ui.feed.SearchPostsScreen
import app.winkwink.ui.messages.ChatScreen
import app.winkwink.ui.messages.ConversationListScreen
import app.winkwink.ui.messages.GroupMembersScreen
import app.winkwink.ui.messages.MessageSettingsScreen
import app.winkwink.ui.messages.NewConversationScreen
import app.winkwink.ui.messages.StartDirectScreen
import app.winkwink.ui.screens.ProfileScreen
import app.winkwink.ui.social.EditProfileScreen
import app.winkwink.ui.social.MutedUsersScreen
import app.winkwink.ui.social.UserListScreen
import app.winkwink.ui.social.UserProfileScreen
import app.winkwink.ui.social.UserSearchScreen
import androidx.navigation.NavType
import androidx.navigation.navArgument
import app.winkwink.ui.theme.WwMotion

@Composable
fun WinkWinkMainShell() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val destination = backStackEntry?.destination
    val badgeViewModel: UnreadBadgeViewModel = hiltViewModel()
    val unread by badgeViewModel.count.collectAsStateWithLifecycle()
    val messaging: MessagingBackgroundViewModel = hiltViewModel()
    val messageUnread by messaging.unread.collectAsStateWithLifecycle()
    DeepLinkEffect(navController)
    NotificationPermissionEffect()
    // WSS działa tylko, gdy aplikacja jest na pierwszym planie; po powrocie łączy się od nowa i dogania stan przez REST.
    LifecycleResumeEffect(Unit) {
        messaging.start()
        onPauseOrDispose { messaging.stop() }
    }
    // Licznik odświeża się przy każdej zmianie ekranu (tania, pojedyncza liczba); błąd sieci zostawia poprzednią wartość.
    LaunchedEffect(destination?.route) { badgeViewModel.refresh() }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                MainTab.entries.forEach { tab ->
                    val selected = destination?.hierarchy?.any { it.route == tab.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            val count = when (tab) { MainTab.Activity -> unread; MainTab.Messages -> messageUnread; else -> 0 }
                            if (count > 0) {
                                BadgedBox(badge = { Badge { Text(if (count > 99) "99+" else count.toString()) } }) { Icon(tab.icon, contentDescription = null) }
                            } else {
                                Icon(tab.icon, contentDescription = null)
                            }
                        },
                        label = { Text(stringResource(tab.labelRes)) },
                    )
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = MainTab.Feed.route,
            modifier = Modifier.padding(padding),
            enterTransition = { fadeIn(tween(WwMotion.SHORT_MS)) },
            exitTransition = { fadeOut(tween(WwMotion.SHORT_MS)) },
        ) {
            navigation(startDestination = Routes.FEED_HOME, route = MainTab.Feed.route) {
                composable(Routes.FEED_HOME) { entry ->
                    val stale by entry.savedStateHandle.getStateFlow(Routes.FEED_STALE_KEY, false).collectAsState()
                    FeedHomeScreen(
                        onOpenPost = { navController.navigate(Routes.post(it)) },
                        onCompose = { navController.navigate(Routes.FEED_COMPOSE) },
                        onSearch = { navController.navigate(Routes.FEED_SEARCH) },
                        onOpenUser = { navController.navigate(Routes.user(it)) },
                        stale = stale,
                        onStaleHandled = { entry.savedStateHandle[Routes.FEED_STALE_KEY] = false },
                    )
                }
                composable(Routes.FEED_COMPOSE) {
                    ComposePostScreen(
                        onBack = { navController.popBackStack() },
                        onPosted = {
                            navController.previousBackStackEntry?.savedStateHandle?.set(Routes.FEED_STALE_KEY, true)
                            navController.popBackStack()
                        },
                    )
                }
                composable(Routes.FEED_SEARCH) {
                    SearchPostsScreen(
                        onBack = { navController.popBackStack() },
                        onOpenPost = { navController.navigate(Routes.post(it)) },
                        onOpenUser = { navController.navigate(Routes.user(it)) },
                    )
                }
                composable(Routes.POST, arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                    PostDetailScreen(
                        onBack = { navController.popBackStack() },
                        onOpenUser = { navController.navigate(Routes.user(it)) },
                        onOpenPost = { navController.navigate(Routes.post(it)) },
                        onChanged = { navController.previousBackStackEntry?.savedStateHandle?.set(Routes.FEED_STALE_KEY, true) },
                    )
                }
            }
            navigation(startDestination = Routes.COMMUNITIES_HOME, route = MainTab.Communities.route) {
                composable(Routes.COMMUNITIES_HOME) {
                    CommunitiesHomeScreen(
                        onOpen = { navController.navigate(Routes.community(it)) },
                        onCreate = { navController.navigate(Routes.COMMUNITY_CREATE) },
                    )
                }
                composable(Routes.COMMUNITY_CREATE) {
                    CreateCommunityScreen(
                        onBack = { navController.popBackStack() },
                        onCreated = { id ->
                            navController.navigate(Routes.community(id)) { popUpTo(Routes.COMMUNITY_CREATE) { inclusive = true } }
                        },
                    )
                }
                composable(Routes.COMMUNITY, arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                    CommunityDetailScreen(
                        onBack = { navController.popBackStack() },
                        onOpenPost = { navController.navigate(Routes.post(it)) },
                        onOpenUser = { navController.navigate(Routes.user(it)) },
                        onManage = { navController.navigate(Routes.communityManage(it)) },
                    )
                }
                composable(Routes.COMMUNITY_MANAGE, arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                    ManageCommunityScreen(
                        onBack = { navController.popBackStack() },
                        onDeleted = { navController.popBackStack(Routes.COMMUNITIES_HOME, inclusive = false) },
                    )
                }
            }
            navigation(startDestination = Routes.MESSAGES_HOME, route = MainTab.Messages.route) {
                composable(Routes.MESSAGES_HOME) {
                    ConversationListScreen(
                        onOpen = { navController.navigate(Routes.chat(it)) },
                        onNewChat = { navController.navigate(Routes.messagesNew("direct")) },
                        onNewGroup = { navController.navigate(Routes.messagesNew("group")) },
                        onSettings = { navController.navigate(Routes.MESSAGES_SETTINGS) },
                    )
                }
                composable(Routes.MESSAGES_NEW, arguments = listOf(navArgument("mode") { type = NavType.StringType })) { entry ->
                    NewConversationScreen(
                        group = entry.arguments?.getString("mode") == "group",
                        onBack = { navController.popBackStack() },
                        onOpened = { id -> navController.navigate(Routes.chat(id)) { popUpTo(Routes.MESSAGES_NEW) { inclusive = true } } },
                    )
                }
                composable(Routes.MESSAGES_WITH, arguments = listOf(navArgument("user") { type = NavType.StringType })) { entry ->
                    StartDirectScreen(
                        user = entry.arguments?.getString("user").orEmpty(),
                        onBack = { navController.popBackStack() },
                        onOpened = { id -> navController.navigate(Routes.chat(id)) { popUpTo(Routes.MESSAGES_WITH) { inclusive = true } } },
                    )
                }
                composable(Routes.CHAT, arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                    ChatScreen(
                        onBack = { navController.popBackStack() },
                        onOpenMembers = { navController.navigate(Routes.chatMembers(it)) },
                    )
                }
                composable(Routes.CHAT_MEMBERS, arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                    GroupMembersScreen(
                        onBack = { navController.popBackStack() },
                        onOpenUser = { navController.navigate(Routes.user(it)) },
                        // Po opuszczeniu grupy wracamy na listę rozmów (czat tej grupy nie jest już dostępny).
                        onLeft = { navController.popBackStack(Routes.MESSAGES_HOME, inclusive = false) },
                    )
                }
                composable(Routes.MESSAGES_SETTINGS) {
                    MessageSettingsScreen(onBack = { navController.popBackStack() })
                }
            }
            navigation(startDestination = Routes.ACTIVITY_HOME, route = MainTab.Activity.route) {
                composable(Routes.ACTIVITY_HOME) {
                    ActivityHomeScreen(
                        onOpenUser = { navController.navigate(Routes.user(it)) },
                        onOpenPost = { navController.navigate(Routes.post(it)) },
                        onOpenCommunity = { navController.navigate(Routes.community(it)) },
                        onSettings = { navController.navigate(Routes.NOTIFICATION_SETTINGS) },
                    )
                }
                composable(Routes.NOTIFICATION_SETTINGS) {
                    NotificationSettingsScreen(onBack = { navController.popBackStack() })
                }
            }

            navigation(startDestination = Routes.PROFILE_HOME, route = MainTab.Profile.route) {
                composable(Routes.PROFILE_HOME) {
                    ProfileScreen(
                        onOpenDiagnostics = { navController.navigate(Routes.DIAGNOSTICS) },
                        onChangePassword = { navController.navigate(Routes.CHANGE_PASSWORD) },
                        onOpenSessions = { navController.navigate(Routes.SESSIONS) },
                        onSearchUsers = { navController.navigate(Routes.USER_SEARCH) },
                        onEditProfile = { navController.navigate(Routes.EDIT_PROFILE) },
                        onOpenSaved = { navController.navigate(Routes.SAVED) },
                        onOpenFollowRequests = { navController.navigate(Routes.userList("requests")) },
                        onOpenBlocked = { navController.navigate(Routes.userList("blocked")) },
                        onOpenMuted = { navController.navigate(Routes.MUTED) },
                        onOpenMyProfile = { navController.navigate(Routes.user(it)) },
                        onDeleteAccount = { navController.navigate(Routes.DELETE_ACCOUNT) },
                    )
                }
                composable(Routes.MUTED) {
                    MutedUsersScreen(onBack = { navController.popBackStack() }, onOpenUser = { navController.navigate(Routes.user(it)) })
                }
                composable(Routes.DELETE_ACCOUNT) {
                    app.winkwink.ui.account.DeleteAccountScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.CHANGE_PASSWORD) {
                    ChangePasswordScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.SESSIONS) {
                    SessionsScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.USER_SEARCH) {
                    UserSearchScreen(onBack = { navController.popBackStack() }, onOpenUser = { navController.navigate(Routes.user(it)) })
                }
                composable(Routes.SAVED) {
                    SavedPostsScreen(
                        onBack = { navController.popBackStack() },
                        onOpenPost = { navController.navigate(Routes.post(it)) },
                        onOpenUser = { navController.navigate(Routes.user(it)) },
                    )
                }
                composable(Routes.EDIT_PROFILE) {
                    EditProfileScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.USER, arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                    UserProfileScreen(
                        onBack = { navController.popBackStack() },
                        onEditProfile = { navController.navigate(Routes.EDIT_PROFILE) },
                        onOpenFollowers = { navController.navigate(Routes.userList("followers", it)) },
                        onOpenFollowing = { navController.navigate(Routes.userList("following", it)) },
                        onOpenPost = { navController.navigate(Routes.post(it)) },
                        onOpenUser = { navController.navigate(Routes.user(it)) },
                        onMessage = { navController.navigate(Routes.messagesWith(it)) },
                    )
                }
                composable(
                    Routes.USER_LIST,
                    arguments = listOf(navArgument("kind") { type = NavType.StringType }, navArgument("id") { type = NavType.StringType }),
                ) {
                    UserListScreen(onBack = { navController.popBackStack() }, onOpenUser = { navController.navigate(Routes.user(it)) })
                }
                composable(Routes.DIAGNOSTICS) {
                    DiagnosticsScreen(onBack = { navController.popBackStack() })
                }
            }
        }
    }
}
